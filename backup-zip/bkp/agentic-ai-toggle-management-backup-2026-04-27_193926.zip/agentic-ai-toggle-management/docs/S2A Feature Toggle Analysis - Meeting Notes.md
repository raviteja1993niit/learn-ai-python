# S2A Feature Toggle Analysis - Meeting Notes

## Problem Statement

**Challenge**: Feature toggle flags are impacting S2A (Service-to-Acquirer) services during modernization, creating uncertainty about which toggles need to be migrated, modified, or maintained.

**Core Issues**:
   - Lack of comprehensive visibility into all feature toggles currently active across S2A acquirer
 services
   - Unclear ownership and responsibility for individual toggles across different domains and regions
   - Inconsistent toggle behavior implementation across multiple acquirer services
   - Risk of duplicated logic and inconsistent behavior when migrating toggles to modernized services
   - Missing or incomplete toggle registry data making analysis difficult
   - Potential for toggles to be overlooked if they haven't been triggered recently
   - Regional variations where same toggles have different domain owners or missing ownership information

**Business Impact**:
   - **Blocking S2A modernization progress** - Without proper toggle analysis, the modernization effort cannot proceed
   - Risk of breaking existing functionality during migration
   - Potential inconsistent merchant experience across different acquirer services
   - Increased technical debt if toggles are not properly consolidated

**Immediate Need**:
   - Systematic identification and cataloging of all feature toggles across S2A services
   - Clear action plan for each toggle (migrate, modify, maintain, or decommission)
   - Architectural guidance on common vs. service-specific toggle implementation
   - Prioritized approach to handle the most critical acquirer services first

---

## Meeting Analysis Notes

### Feature Toggle Analysis Approach
   - Sandeep suggests raising a PDR to fetch toggle information from database in one shot
   - Export toggle data similar to how reports are currently exported
   - Analyze which toggles are enabled for specific merchants and MSOs
   - Identify toggle ownership and responsibility for maintenance

### Toggle Ownership and Scope Analysis
   - Sandeep emphasizes need to identify who owns each toggle and who introduced it
   - Example: "Enable issuer country code in transaction response" - owned by processing and localization
   - Each toggle should have clear ownership for responsibility and maintenance
   - Reference actual confluence pages for detailed toggle information

### Action Required vs No Action Needed Classification
   - Sandeep explains "no action needed" means current state should be maintained
   - For toggles requiring action, need to determine what specific changes are needed
   - Must identify which domain should handle each toggle behavior
   - Share findings with different domains to ensure proper implementation

### Toggle Implementation Strategy
   - Sandeep recommends common logic approach for consistent behavior across acquirers
   - Avoid implementing same toggle logic in multiple services
   - Use mapper library or common utility before generating TSPI
   - Example: Credential on file value changes should have consistent behavior

### Data Collection and Consolidation Process
   - Sandeep requests toggle lists from all S2A services (currently 71 toggles identified for one service)
   - Remove duplicates and create consolidated list
   - Use Splunk queries to extract toggle data over multiple time periods
   - Anup suggests sampling data from 3 different months to capture all triggered toggles

### Team Distribution and Prioritization
   - Sandeep proposes distributing analysis based on existing S2A modernization team assignments
   - WorldPay to be prioritized first, followed by Payment Excellence and other services
   - Teams should extract toggle lists for their assigned acquirers
   - Overlap expected between different acquirer services

### Database Query and PDR Requirements
   - Sandeep mentions need for PDR to get toggle registry data from database
   - Database query will provide toggle status, MSON, and merchant information
   - Challenge: no primary key structure, only toggle names available
   - This process can run in parallel with list consolidation

### Regional and Domain Variations
   - Anup raises concern about toggles having different domain owners in different regions
   - Some toggles missing owner information in certain regions
   - Sandeep acknowledges need for case-by-case discussion for such instances
   - Each toggle has different expectations and objectives

### Timeline and Urgency
   - Sandeep emphasizes this analysis is high priority
   - Results needed to provide input to architects for decision making
   - Delay will block S2A modernization progress
   - Regular follow-up meetings planned to track progress

---

## Summary

The meeting focused on establishing a systematic approach to analyze feature toggle flags affecting S2A (Service-to-Acquirer) modernization. Sandeep led the discussion on creating a comprehensive methodology to identify, categorize, and manage toggles across different acquirer services. Key outcomes include the need for consolidated toggle lists from all S2A services
, establishing clear ownership and action requirements for each toggle, and implementing common logic approaches to avoid duplication. The team agreed on a phased approach starting with WorldPay, followed by other acquirer services, with emphasis on removing duplicates and ensuring consistent behavior across the platform. The analysis is critical for architectural decisions and preventing modernization blockers.