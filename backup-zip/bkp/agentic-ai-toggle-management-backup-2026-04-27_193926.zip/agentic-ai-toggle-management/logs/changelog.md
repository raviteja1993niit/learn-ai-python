﻿# AI-Driven Toggle Management System — Operational Changelog
> Live operational log. Maintained by all agents after every file write.
> Started fresh: 2026-04-12
---

## [2026-04-12T00:00:00Z] Workflow H — Lightweight Workspace Cleanup (Auto-triggered at Batch 10)

### Agent: toggle-workspace-manager (SA-5) | Mode: Skill C — Workspace Cleanup

### Task: Deduplicate and validate `data/analysis/toggle-codebase-usage-analysis.csv`

**Schema Validated:** `Toggle Name,Implementation Class Name,Line Number Code,Toggle ON Impact,Toggle OFF Impact,Repository` ✅

**Dedup Key:** `(Toggle Name + Implementation Class Name + Line Number Code)` triple

| Metric | Count |
|---|---|
| Original data rows loaded (Import-Csv) | 314 |
| Duplicate `(Toggle Name + Class + Line)` triples found | 0 |
| Blank/null/empty rows found | 0 |
| Data corruption fixed | 1 — Line 177: `Repository` cell contained stray junk `"Allow MDES Token Respository Sharing"` appended after `MSOUI` (CSV double-quote escape artefact from Batch 0 write). Corrected to `"MSOUI"`. |
| Clean rows written | 314 |

**Corruption Fixed:**
- Line 177 (`Allow SCOF Registration via Merchant Manager` / `TokenRepositoryUtils` / `42`): Repository field was `MSOUI"Allow MDES Token Respository Sharing` → corrected to `MSOUI`

**Dedup Result:** 0 duplicate triples — file was already clean post-Batch-5 cleanup.

**Blank Row Result:** 0 blank/null/empty rows — file is clean.

**Encoding:** UTF-8 WITH BOM (`0xEF 0xBB 0xBF`) ✅

**Repository row distribution (post-fix):**

| Repository | Rows |
|---|---|
| BatchSettlementService | 6 |
| BusinessService | 6 |
| Console | 2 |
| CPE | 185 |
| DirectAPI | 11 |
| MSOUI | 31 |
| NOT_FOUND | 1 |
| Orchestrator | 60 |
| UNKNOWN | 12 |
| **TOTAL** | **314** |

**File written:** `data/analysis/toggle-codebase-usage-analysis.csv` — 315 lines (1 header + 314 data rows)

---

## [2026-04-12T00:00:00Z] Workflow A — Toggle Analysis Batch 10 of 42

### Agent: toggle-analysis-engine | Mode: Skill A+B+C

### Task: Analyse 5 toggles — Batch 10/42

**Pre-Flight Registry Cross-Check**: 5/5 in registry → all queued for analysis.

**PRE-WRITE CHECK**: All 5 (Toggle Name + Class + Line) triples confirmed absent from combined analysis CSV before write.

| Toggle | Class | Line | Repo | Status |
|---|---|---|---|---|
| Enable Transit Aggregation Rule for US Region | FinancialTransactionUtil | 457 | CPE | ✅ NEW ROW WRITTEN |
| Enable Update Application Transaction Counter for Amex | TransactionRequestValidator | 1758 | CPE | ✅ NEW ROW WRITTEN |
| Enable Update Application Transaction Counter for Mastercard | TransactionRequestValidator | 1758 | CPE | ✅ NEW ROW WRITTEN |
| Enable VISA Tap Initiated Debt Recovery DE61SF11=4 mapping | IsoDataField61Populator | 689 | CPE | ✅ NEW ROW WRITTEN |
| Enable Verify POS Fields Validation | VerificationRequestValidator | 134 | Orchestrator | ✅ NEW ROW WRITTEN |

**S2A Check**: No S2A trigger classes identified — Skill D/E not invoked.

**Files Updated**:
- `data/analysis/toggle-codebase-usage-analysis.csv` — 5 new rows appended (total +5)
- `data/analysis/toggle-codebase-usage-analysis-cpe.csv` — 4 new rows appended
- `data/analysis/toggle-codebase-usage-analysis-orchestrator.csv` — 1 new row appended

## [2026-04-12T22:00:00Z] Workflow A — Toggle Analysis Batch 8 of 42

### Agent: toggle-analysis-engine | Mode: Skill A+B+C

### Task: Analyse 5 toggles — Batch 8/42

**Pre-Flight Registry Cross-Check**: 5/5 in registry → all queued for analysis.

**PRE-WRITE CHECK**: All 9 (Toggle Name + Class + Line) triples confirmed absent from combined analysis CSV before write.

| Toggle | Class | Line | Repo | Status |
|---|---|---|---|---|
| Enable S2I Visa Mandate CardOnFile | S2IAcquirerV1 | 5536 | CPE | ✅ NEW ROW WRITTEN |
| Enable SRC V2 Services | SecureRemoteCommerceConfigurationController | 152 | MSOUI | ✅ NEW ROW WRITTEN |
| Enable STX indicator for CIT transaction for S2I acquirers | FinancialTransactionUtil | 858 | CPE | ✅ NEW ROW WRITTEN |
| Enable Scheme Token Provisioning Mode | TokenizationDetailsValidator | 181 | MSOUI | ✅ NEW ROW WRITTEN |
| Enable Scheme Token Provisioning Mode | TokenRepositoryServiceImpl | 2107 | MSOUI | ✅ NEW ROW WRITTEN |
| Enable Scheme Token Provisioning Mode | TokenRepositoryController | 1244 | MSOUI | ✅ NEW ROW WRITTEN |
| Enable Scheme Token Provisioning Mode | TokenRepositoryReadOnlyController | 498 | MSOUI | ✅ NEW ROW WRITTEN |
| Enable Scheme Tokenization Indicator Tag | IsoDataField123Populator | 538 | CPE | ✅ NEW ROW WRITTEN |

**Skill D/E S2A Check**: None of the 5 toggles involve S2A trigger classes — no S2A enrichment required.

**Rows written**: 8 new rows (combined + per-repo)
**Files updated**:
- `data/analysis/toggle-codebase-usage-analysis.csv` (+8 rows → 297 total)
- `data/analysis/toggle-codebase-usage-analysis-cpe.csv` (+3 rows)
- `data/analysis/toggle-codebase-usage-analysis-msoui.csv` (+5 rows)

---

## [2026-04-12T17:00:00Z] Workflow H — Workspace Cleanup (Lightweight Dedup Pass, Batch 5)

### Agent: toggle-workspace-manager (SA-5) | Mode: Skill C — Workspace Cleanup

### Task: Deduplicate `data/analysis/toggle-codebase-usage-analysis.csv`

**Schema Validated:** `Toggle Name,Implementation Class Name,Line Number Code,Toggle ON Impact,Toggle OFF Impact,Repository` ✅

**Dedup Key:** `(Toggle Name + Implementation Class Name + Line Number Code)` triple

| Metric | Count |
|---|---|
| Original data rows loaded | 263 |
| Duplicate triples found | 0 |
| Blank/empty rows removed | 1 (line 150: `,NULL,NULL,NULL,NULL,NULL`) |
| Trailing empty line removed | 1 (line 265: empty) |
| Clean rows written | 262 |

**Blank rows removed:**
- Line 150: `,NULL,NULL,NULL,NULL,NULL` — empty toggle entry
- Line 265: trailing blank line (end-of-file artifact)

**Duplicates deduplicated:** None — 0 duplicate `(Toggle Name + Class + Line)` triples found across all 262 rows.

**Encoding:** UTF-8 WITH BOM ✅

**File written:** `data/analysis/toggle-codebase-usage-analysis.csv` — 263 lines (1 header + 262 data rows)

---

## [2026-04-12T16:00:00Z] Workflow A — Analyse-All Batch 5 of 42 (5 Toggles)

### Analysis Engine: toggle-analysis-engine | Mode: SA-1 Workflow A

### Pre-Flight Registry Check
- Total pending: 5 | ✅ In registry: 5 | ❌ Not in registry: 0

### Toggle Results

| # | Toggle Name | Class | Line | Repo | Action |
|---|---|---|---|---|---|
| 1 | Enable Merchant End of Business Day | IsoDataField123Populator | 418 | CPE | ✅ WRITTEN |
| 1 | Enable Merchant End of Business Day | MerchantEndOfBusinessDayTimeValidator | 48 | MSOUI | ✅ WRITTEN |
| 1 | Enable Merchant End of Business Day | AcquirerLinkDetailsController | 1219 | MSOUI | ✅ WRITTEN |
| 1 | Enable Merchant End of Business Day | MerchantServiceImpl | 1440 | MSOUI | ✅ WRITTEN |
| 1 | Enable Merchant End of Business Day | AcquirerLinkForResponseBuilder | 84 | MSOUI | ✅ WRITTEN |
| 1 | Enable Merchant End of Business Day | MerchantApprovalController | 634 | MSOUI | ✅ WRITTEN |
| 1 | Enable Merchant End of Business Day | MerchantSummaryController | 507 | MSOUI | ✅ WRITTEN |
| 1 | Enable Merchant End of Business Day | AcquirerLinkRequestHandler | 133 | MSOUI | ✅ WRITTEN |
| 2 | Enable Net Amount and Charge Amounts in TSPI | TspiRequestMessageBuilder | 3802 | CPE | ✅ WRITTEN (S2A enriched) |
| 2 | Enable Net Amount and Charge Amounts in TSPI | JsonMegaMessageRequestBuilder | 4373 | CPE | ✅ WRITTEN (S2A enriched) |
| 3 | Enable Network Transaction ID | IsoField105DataMapper | 72 | CPE | ✅ WRITTEN |
| 3 | Enable Network Transaction ID | RecurringPaymentAgreementService | 695 | Orchestrator | ✅ WRITTEN |
| 3 | Enable Network Transaction ID | AgreementDataService | 198 | Orchestrator | ✅ WRITTEN |
| 3 | Enable Network Transaction ID | MITIndustryPracticeValidator | 97 | Orchestrator | ✅ WRITTEN |
| 3 | Enable Network Transaction ID | S2IAcquirerV1 | 43 | CPE | ✅ WRITTEN |
| 4 | Enable New RRN for capture transaction | S2IAcquirerV1 | 2609 | CPE | ✅ WRITTEN |
| 5 | Enable New RRN for void transaction | S2IAcquirerV1 | 1716 | CPE | ✅ WRITTEN |

### S2A Enrichment (Skill D)
- Enable Net Amount and Charge Amounts in TSPI / TspiRequestMessageBuilder / 3802: S2A trigger class (TSPI_ROUTING_HEADER) → TSPI: Transaction.MerchantCharge (type + chargeAmount) + TSPI: Transaction.NetAmount notation applied inline.
- Enable Net Amount and Charge Amounts in TSPI / JsonMegaMessageRequestBuilder / 4373: S2A trigger class (TSPI_JSON) → TSPI: Transaction.NetAmount + TSPI: Transaction.MerchantCharge (MerchantChargeType + MerchantChargeAmount) notation applied inline.

### Rows Written
- data/analysis/toggle-codebase-usage-analysis.csv: +17 rows (Toggle 1: 8 rows, Toggle 2: 2 rows, Toggle 3: 5 rows, Toggle 4: 1 row, Toggle 5: 1 row)
- data/analysis/toggle-codebase-usage-analysis-cpe.csv: +8 rows
- data/analysis/toggle-codebase-usage-analysis-msoui.csv: +7 rows
- data/analysis/toggle-codebase-usage-analysis-orchestrator.csv: +3 rows

---

## [2026-04-12T14:00:00Z] Workflow A — Analyse-All Batch 4 of 42 (5 Toggles)

### Analysis Engine: toggle-analysis-engine | Mode: SA-1 Workflow A

### Pre-Flight Registry Check
- Total pending: 5 | ✅ In registry: 5 | ❌ Not in registry: 0

### Toggle Results

| # | Toggle Name | Class | Line | Repo | Action |
|---|---|---|---|---|---|
| 1 | Enable MADA SMS Refund Reversal | S2IAcquirerV1 | 3080 | CPE | ✅ WRITTEN |
| 2 | Enable MDQ Edit 38 For WSAPI | S2IAcquirerV1 | 7973 | CPE | ✅ WRITTEN |
| 3 | Enable MIT Industry Practice and Resubmission transaction for Non-Stored COF | RecurringPaymentAgreementValidator | 421 | Orchestrator | ✅ WRITTEN |
| 3 | Enable MIT Industry Practice and Resubmission transaction for Non-Stored COF | JsonMegaMessageRequestBuilder | 2098 | CPE | ✅ WRITTEN (S2A enriched) |
| 4 | Enable MSO enroll merchant in C2P | SecureRemoteCommerceConfigurationController | 152 | MSOUI | ✅ WRITTEN |
| 5 | Enable Merchant Charge Disclosure Statement | MerchantConfigurationPopulator | 106 | BusinessService | ✅ WRITTEN |
| 5 | Enable Merchant Charge Disclosure Statement | OrderDetailsBuilder | 76 | BusinessService | ✅ WRITTEN |

### S2A Enrichment
- Enable MIT Industry Practice and Resubmission transaction for Non-Stored COF / JsonMegaMessageRequestBuilder / 2098: S2A trigger class detected → TSPI: Transaction.FinancialNetworkTransactionId (Acquirer.FinancialNetworkTransactionId) notation applied inline.

### Files Modified
- data/analysis/toggle-codebase-usage-analysis.csv (+7 rows)
- data/analysis/toggle-codebase-usage-analysis-cpe.csv (+3 rows)
- data/analysis/toggle-codebase-usage-analysis-orchestrator.csv (+1 row)
- data/analysis/toggle-codebase-usage-analysis-business-service.csv (+2 rows)
- data/analysis/toggle-codebase-usage-analysis-msoui.csv (+1 row)

---

## [2026-04-12T11:30:00Z] Workflow A — Analyse-All Batch 3 of 42 (5 Toggles)

### Analysis Engine: toggle-analysis-engine | Mode: SA-1 Workflow A

### Pre-Flight Registry Check
- Total pending: 5 | ✅ In registry: 5 | ❌ Not in registry: 0

### Toggle Results

| # | Toggle Name | Class | Line | Repo | Action |
|---|---|---|---|---|---|
| 1 | Enable Known Fare Transit for Deferred Auth and Debt Recovery on S2I | FinancialTransactionUtil | 350 | CPE | ✅ WRITTEN |
| 1 | Enable Known Fare Transit for Deferred Auth and Debt Recovery on S2I | S2IAcquirerV1 | 5657 | CPE | ✅ WRITTEN |
| 1 | Enable Known Fare Transit for Deferred Auth and Debt Recovery on S2I | IsoDataField61Populator | 390 | CPE | ✅ WRITTEN |
| 2 | Enable Known Fare Transit for Real Time Auth on S2I | S2IAcquirerV1 | 8523 | CPE | ✅ WRITTEN |
| 2 | Enable Known Fare Transit for Real Time Auth on S2I | PurchaseServiceImpl | 148 | CPE | ✅ WRITTEN |
| 3 | Enable Known Fare Transit on S2I for AMEX | S2IAcquirerV1 | 9960 | CPE | ✅ WRITTEN |
| 3 | Enable Known Fare Transit on S2I for AMEX | IsoDataField61Populator | 407 | CPE | ✅ WRITTEN |
| 4 | Enable MADA DMS transaction | UpdateAuthorisationRequestValidator | 452 | Orchestrator | ✅ WRITTEN |
| 4 | Enable MADA DMS transaction | FinancialTransactionUtil | 810 | CPE | ✅ WRITTEN |
| 5 | Enable MADA S2A operations | UpdateAuthHelper | 70 | CPE | ✅ WRITTEN |
| 5 | Enable MADA S2A operations | MegaMessageMap | 1035 | CPE | ✅ WRITTEN (S2A enriched) |
| 5 | Enable MADA S2A operations | AcquirerProxy | 887 | CPE | ✅ WRITTEN |

### Skill D/E S2A Enrichment
- **MegaMessageMap** (line 1035) — S2A Flow Toggle; failure handling routing enriched with TSPI: Transaction notation (in-place update applied).

### Files Updated
- `data/analysis/toggle-codebase-usage-analysis.csv` — 12 rows appended (combined)
- `data/analysis/toggle-codebase-usage-analysis-cpe.csv` — 11 rows appended (CPE per-repo)
- `data/analysis/toggle-codebase-usage-analysis-orchestrator.csv` — 1 row appended (Orchestrator per-repo)

### Summary
- Total rows written: 12 (across 2 repos — 11 CPE, 1 Orchestrator)
- Total rows skipped (pre-write duplicate check): 0
- S2A enrichment applied: 1 (MegaMessageMap/1035)



### Analysis Engine: toggle-analysis-engine | Mode: SA-1 Workflow A

### Pre-Flight Registry Check
- Total pending: 5 | ✅ In registry: 5 | ❌ Not in registry: 0

### Toggle Results

| # | Toggle Name | Class | Line | Repo | Action |
|---|---|---|---|---|---|
| 1 | Enable HSM key cryptography for Risk Rule Input Management | ListManagementService | 274 | MSOUI | ✅ WRITTEN |
| 1 | Enable HSM key cryptography for Risk Rule Input Management | RiskListManagementController | 153 | MSOUI | ✅ WRITTEN |
| 2 | Enable HSM key cryptography for Token search UI | JsonWithJweEncryptedContentToPlainStringConverter | 44 | DirectAPI | ✅ WRITTEN |
| 3 | Enable ISO Mapping for Surcharge and Convenience fee | S2IAcquirerV1 | 2888 | CPE | ✅ WRITTEN |
| 4 | Enable ISO20022 Data Quality Standard for Mastercard | S2IAcquirerV1 | 7985 | CPE | ✅ WRITTEN |
| 5 | Enable Incremental Authorization | S2IAcquirerV1 | 2650 | CPE | ✅ WRITTEN |
| 5 | Enable Incremental Authorization | UpdateAuthHelper | 43 | CPE | ✅ WRITTEN |
| 5 | Enable Incremental Authorization | AuthCaptureModeHelper | 747 | CPE | ✅ WRITTEN |
| 5 | Enable Incremental Authorization | S2IAcquirerHelper | 661 | CPE | ✅ WRITTEN |
| 5 | Enable Incremental Authorization | UpdateAuthorisationThenCaptureExecutor | 160 | CPE | ✅ WRITTEN |

### S2A Enrichment Applied
- None — all implementation classes are S2I (S2IAcquirerV1, S2IAcquirerHelper — SKIP_S2A_ANALYSIS) or non-S2A (ListManagementService, RiskListManagementController, JsonWithJweEncryptedContentToPlainStringConverter, UpdateAuthHelper, AuthCaptureModeHelper, UpdateAuthorisationThenCaptureExecutor).

### Files Modified
- `data/analysis/toggle-codebase-usage-analysis.csv` — +10 new rows written
- `data/analysis/toggle-codebase-usage-analysis-msoui.csv` — +2 new rows (ListManagementService, RiskListManagementController)
- `data/analysis/toggle-codebase-usage-analysis-direct-api.csv` — +1 new row (JsonWithJweEncryptedContentToPlainStringConverter); schema corrected to fixed schema
- `data/analysis/toggle-codebase-usage-analysis-cpe.csv` — +7 new rows (S2IAcquirerV1 ×2, UpdateAuthHelper, AuthCaptureModeHelper, S2IAcquirerHelper, UpdateAuthorisationThenCaptureExecutor)

### Timestamp: 2026-04-12T10:00:00Z

---



### Analysis Engine: toggle-analysis-engine | Mode: SA-1 Workflow A

### Pre-Flight Registry Check
- Total pending: 5 | ✅ In registry: 5 | ❌ Not in registry: 0

### Toggle Results

| # | Toggle Name | Class | Line | Repo | Action |
|---|---|---|---|---|---|
| 1 | Allow MDES Token Respository Sharing | ServicesSupport | 776 | MSOUI | **SKIPPED** — row already exists in analysis CSV |
| 2 | Enable Exclusion Rule configuration through UI and API | MerchantAcquirerLinksValidator | 357 | MSOUI | ✅ WRITTEN |
| 2 | Enable Exclusion Rule configuration through UI and API | AcquirerLinkJsonDataServiceImpl | 362 | MSOUI | ✅ WRITTEN |
| 2 | Enable Exclusion Rule configuration through UI and API | MerchantServiceImpl | 3802 | MSOUI | ✅ WRITTEN |
| 2 | Enable Exclusion Rule configuration through UI and API | ExclusionRuleValidator | 64 | MSOUI | ✅ WRITTEN |
| 2 | Enable Exclusion Rule configuration through UI and API | MerchantApprovalController | 713 | MSOUI | ✅ WRITTEN |
| 2 | Enable Exclusion Rule configuration through UI and API | AcquirerLinkDetailsController | 747 | MSOUI | ✅ WRITTEN |
| 3 | Enable External Plan ID for Installment Plans | S2IAcquirerV1 | 5705 | CPE | ✅ WRITTEN |
| 4 | Enable External Plan ID for Installment Plans in TSPI | MegaMessageRequestBuilder | 610 | CPE | ✅ WRITTEN (S2A enriched — TSPI: Transaction.PaymentPlanExternalPlanId) |
| 4 | Enable External Plan ID for Installment Plans in TSPI | JsonMegaMessageRequestBuilder | 1156 | CPE | ✅ WRITTEN (S2A enriched — TSPI: Transaction.PaymentPlanExternalPlanId) |
| 5 | Enable FPAN Tokenization Block for SCOF | TokenRepositoryServiceImpl | 1692 | MSOUI | ✅ WRITTEN |

### Files Modified
- `data/analysis/toggle-codebase-usage-analysis.csv` — +10 new rows (9 written + 1 skipped)
- `data/analysis/toggle-codebase-usage-analysis-msoui.csv` — +7 new rows
- `data/analysis/toggle-codebase-usage-analysis-cpe.csv` — +3 new rows (1 S2I + 2 S2A)

### S2A Enrichment Applied
- Toggle 4 (TSPI): MegaMessageRequestBuilder (S2A) + JsonMegaMessageRequestBuilder (S2A) — TSPI JSON notation applied: `TSPI: Transaction.PaymentPlanExternalPlanId`

### Timestamp: 2026-04-12T00:00:00Z

---



### Script executed
- `tools/active/build-toggle-registry-lookup.ps1` — TWO-PASS architecture (Declaration Harvest + Usage Harvest)

### Per-repo files written (`data/registry/`)
- `toggle-registry-cpe.csv` — 694 rows (415 IMPL / 7 IMPORT / 272 DECL)
- `toggle-registry-orchestrator.csv` — 208 rows (125 IMPL / 0 IMPORT / 83 DECL)
- `toggle-registry-business-service.csv` — 60 rows (15 IMPL / 28 IMPORT / 17 DECL)
- `toggle-registry-console.csv` — 24 rows (14 IMPL / 7 IMPORT / 9 DECL)
- `toggle-registry-msoui.csv` — 113 rows (68 IMPL / 15 IMPORT / 30 DECL)
- `toggle-registry-direct-api.csv` — 45 rows (23 IMPL / 2 IMPORT / 20 DECL)
- `toggle-registry-batch-settlement-service.csv` — 14 rows (5 IMPL / 0 IMPORT / 9 DECL)
- `toggle-registry-lookup.csv` (combined) — **1,158 total entries**

### Summary
- Unique toggle names discovered: **358**
- Total Java files scanned: 5,851 (CPE 2420 + Orchestrator 751 + BusinessService 581 + Console 749 + MSOUI 1065 + BSS 285 + DirectAPI 23 targeted)
- DirectAPI: used embedded fallback targeted file list (23 files)

---

## [2026-04-12] Workspace Reorganization — Full Cleanup & Path Sync

### Files REMOVED (9 one-off debug/helper scripts from tools/active/)
- `audit-sync.ps1` — ad-hoc audit helper, not referenced anywhere
- `check-encoding.ps1` — encoding investigation helper
- `check-registry.ps1` — one-off registry row counter
- `fix-audit-encoding.ps1` — encoding fix for debug script
- `fix-script-encoding.ps1` — initial encoding fix helper (superseded by permanent BOM fix in main script)
- `re-encode-and-dryrun.ps1` — combined encode + dry-run runner
- `run-bss-scan.ps1` — BSS string constant scan runner
- `scan-bss-all-string-constants.ps1` — BSS constant scan (Bug 6 investigation, no longer needed)
- `encode-and-run-bss.ps1` — one-time BSS rebuild runner

### Directory REMOVED
- `knowledge/archive/` — contained only "REMOVED" stub placeholder files with no content

### Files ARCHIVED
- `.github/agents/toggle-code-quality-inspector.agent.md` → `.github/agents/archive/`
- `.github/agents/toggle-output-governance.agent.md` → `.github/agents/archive/`
- `.github/agents/toggle-security-inspector.agent.md` → `.github/agents/archive/`
- `.github/agents/toggle-session-manager.agent.md` → `.github/agents/archive/`
- `.github/agents/universal-optimizer.agent.md` → `.github/agents/archive/`
- `data/analysis/toggle-dependency-on-card-payment-engine.csv` → `data/archive/`

### Files UPDATED (stale content fixed)

**knowledge/tool-command-registry.yml**
- Removed ghost reference to `build-toggle-registry-lookup.min.py` (Python — never existed)
- Documented real tool: `build-toggle-registry-lookup.ps1` (PowerShell) with correct invocation
- Added TOOL-02 through TOOL-07 entries matching all scripts registered in `config.yml`

**knowledge/index.md**
- Fixed all stale flat paths (`data/toggle-registry-lookup.csv` etc.) to correct subdirectory paths
- Added `data/registry/` and `data/analysis/` prefixes throughout
- Added BatchSettlementService to registered repositories table

**knowledge/session-state.yml**
- Fixed `key_files` block: all 4 paths now point to correct subdirectory locations
- Updated `batchsettlement_onboarding.toggles_found`: 7 → 9 (post Bug 6 fix)
- Added `registry_rows: 14` field
- Fixed `tool_notes`: removed sec_launcher reference, clarified PS1 vs Python

**knowledge/optimizer-config.yml**
- Removed unused checkpoint schema and non-existent `checkpoints/` directory references
- Retained only context_summarisation triggers (still active)

**.github/agents/docs/01-repositories.md**
- Fixed all 7 per-repo `registry_file` and `analysis_file` paths to include `data/registry/` and `data/analysis/` subdirectory prefixes
- Updated BSS toggle inventory count: 11 entries → 9 unique toggles / 14 registry rows

**.github/agent-registry.yml**
- Added `archived_agents: 5` count
- Added `archived_agent_files` field pointing to `.github/agents/archive/`
- Updated `updated_by` and `note` to document what was archived

---

## [2026-04-12] Bug 6 Fix — Missing BSS Toggles due to $isToggle Prefix Filter Gap

### ROOT CAUSE ANALYSIS
`AccountValidationToggleHelper.java` contains `ACCOUNT_VALIDATION_TOGGLE_NAME` which calls
`Toggles.isToggleOn(ACCOUNT_VALIDATION_TOGGLE_NAME)` — a hybrid declare-and-use class.
Pass 1 rejected it because `ACCOUNT_VALIDATION_` did not match any prefix in `$isToggle`.
Full BSS scan of all static final String constants revealed 5 more missed toggles with the same root cause.

### MISSED TOGGLE CONSTANTS (all now fixed)

| Constant | Toggle Name | Miss Reason |
|---|---|---|
| `ACCOUNT_VALIDATION_TOGGLE_NAME` | ACH Account Validation for Paymentech Salem ACH Acquirer | `_TOGGLE_NAME$` suffix not in filter |
| `ACQUIRER_TRANSACTION_ID_TOGGLE_NAME` | Enable TSPI Response Mapping of AcquirerTransactionId... | `_TOGGLE_NAME$` suffix not in filter |
| `SYSTEM_TOGGLE_ENABLE_TO_READ_ACQUIRER_CONFIG_FROM_DB` | System Toggle: Enable T-SPI BSS to read Acquirer Config... | `^SYSTEM_TOGGLE` prefix not in filter |
| `ACQ_SUBSYSTEM_SWITCH_SETTLEMENT_TXNS_TO_NEW_VM_FOR` | System Toggle:AcqSubsystem - Switch Settlement to new VM... | `^ACQ_` prefix not in filter; caught by new value-based guard |
| `BSS_USE_BASE32_ID_GENERATOR` | Batch Settlement Service use Base32 ID Generator | `^BSS_` prefix not in filter |

### FIXED: tools/active/build-toggle-registry-lookup.ps1

**`$isToggle` prefix filter** — added:
- `_TOGGLE_NAME$` suffix (catches `*_TOGGLE_NAME` constants)
- `^SYSTEM_TOGGLE` prefix (catches `SYSTEM_TOGGLE_*` constants)
- `^BSS_` prefix (catches BSS-specific `BSS_*` toggle constants)
- **Value-based override** (new): if `$toggleValue` starts with `"System Toggle:"` or
  `"Feature Toggle:"`, the constant is treated as a toggle unconditionally regardless
  of constant name prefix — the most reliable signal for BSS toggle conventions.

**`$refreshPattern`** (DirectAPI targeted scan) — same new prefixes added to stay in sync.

### RE-RUN: build-toggle-registry-lookup.ps1 -TargetRepo BatchSettlementService
- **Before**: 4 unique toggle names, 4 rows (all DECLARATION)
- **After**: 9 unique toggle names, **14 rows** (5 IMPL + 9 DECL)
- Combined registry: **713 rows** (was 703)
- Per-repo file: `toggle-registry-batch-settlement-service.csv` — 14 rows

---

## [2026-04-12] Script Path Sync Fix — build-toggle-registry-lookup.ps1

### FIXED: tools/active/build-toggle-registry-lookup.ps1

**Issue 1 — CRITICAL: framework_root "." caused wrong output path (Step 1c)**
- Root cause: `workspace.framework_root: "."` in config.yml was treated as a literal string, not resolved to an absolute path. When the script ran from `tools/active/`, `$resolvedFrameworkRoot` became `"."` and all output paths became relative to CWD (`tools/active/data/...`) instead of the framework root (`agentic-ai-toggle-management/data/registry/...`).
- Fix: Added explicit check — if value is `"."` or any relative path, resolve it to absolute using `Split-Path` from the config file location. Framework root is now always an absolute path.

**Issue 2 — CRITICAL: Combined output hardcoded to wrong path (Step 1d)**
- Root cause: `$OutputPath` was hardcoded as `Join-Path $dataDir "toggle-registry-lookup.csv"` → resolved to `data\toggle-registry-lookup.csv`. The correct path from config is `data/registry/toggle-registry-lookup.csv`.
- Fix: `$OutputPath` now driven from `config.yml` → `registry.combined_output` key. `$dataDir` is derived as the parent of `$OutputPath` (= `data\registry\`).

**Issue 3 — Step 1g: directory creation used wrong dir**
- Root cause: `New-Item` only created `data\` not `data\registry\`. If registry dir didn't exist the write would fail.
- Fix: Now creates `$dataDir` (= `data\registry\`) and `$topDataDir` (= `data\`) separately.

**Issue 4 — .DESCRIPTION header missing BatchSettlementService**
- Updated Repositories and Output files sections in the script header to include BatchSettlementService and its per-repo file.

**Encoding fix (permanent)**
- Script re-saved as UTF-8 with BOM after all edits. Em-dash characters (U+2014) replaced with `--` throughout.

**DryRun verification — all paths confirmed [EXISTS]:**
```
Framework root  : <framework_root>
Registry dir    : <framework_root>/data/registry
Combined output : <framework_root>/data/registry/toggle-registry-lookup.csv
CPE             : <mpgs_source>/cardpaymentengine/src/main/java         [EXISTS]
Orchestrator    : <mpgs_source>/orchestrator/src/main/java              [EXISTS]
BusinessService : <mpgs_source>/businessservice/src/main/java           [EXISTS]
Console         : <mpgs_source>/console/console/src/main/java           [EXISTS]
MSOUI           : <mpgs_source>/msoui/src/main/java                     [EXISTS]
BatchSettlementService: <mpgs_source>/batchsettlementservice/src/main/java [EXISTS]
DirectAPI       : <mpgs_source>/directapi/src/main/java                 [EXISTS] (targeted: 23 files)
```

### RE-RUN: build-toggle-registry-lookup.ps1 -TargetRepo BatchSettlementService (post-fix)
- Preserved rows correctly loaded from existing combined registry: **699 rows** (was 0 before fix)
- Combined registry total: **703 rows** across all 7 repos
- Per-repo files written to correct absolute path: `data\registry\`

---

## [2026-04-12] Registry Rebuild — BatchSettlementService (Single-Repo Mode)

### RUN: build-toggle-registry-lookup.ps1 -TargetRepo BatchSettlementService
- **Mode**: SINGLE-REPO — only BatchSettlementService scanned; all other repos preserved from existing combined registry.
- **Pass 1 (Declaration Harvest)**: 285 Java files scanned under `batchsettlementservice/src/main/java`. Found 4 unique toggle constants.
- **Pass 2 (Usage Harvest)**: 285 files scanned. 0 external usage rows found (all toggles are DECLARATION-only in BSS).
- **Pre-condition fix**: Script re-saved as UTF-8 with BOM; em-dash characters (U+2014) replaced with `--` to resolve PowerShell 5.1 parse errors.

### WRITTEN: data/registry/toggle-registry-batch-settlement-service.csv
| toggle_name | constant_name | class_name | usage_type |
|---|---|---|---|
| Support STRIPE failover using Operations console | TOGGLE_SUPPORT_STRIPE_FAILOVER_USING_OPERATIONS_CONSOLE | StripeServiceClient | DECLARATION |
| System Toggle: Revert cut down SQL fix in BatchSettlementService for Acknowledgement | TOGGLE_USE_ORIGINAL_BULKY_SQL_FOR_ACKS | JpaTransactionSubmissionDao | DECLARATION |
| System Toggle: Revert cut down SQL fix in BatchSettlementService for Notification | TOGGLE_USE_ORIGINAL_BULKY_SQL_FOR_TRANSACTIONSUBMISSIONS | NotificationTransactionManager | DECLARATION |
| System Toggle:Enable HSM Encryption For BatchSettlementService and PTS | ENABLE_HSM_ENCRYPTION_FOR_BSS_PTS | CryptoServiceClient | DECLARATION |

### UPDATED: data/registry/toggle-registry-lookup.csv
- Combined registry updated. Total rows: 704 across 7 repositories (BSS: 5 rows, CPE: 420, Orchestrator: 120, MSOUI: 82, DirectAPI: 29, BusinessService: 41, Console: 7).

---

## [2026-04-12] UX Improvement — Agent Chat UI Redesign (Clean, Concise, Well-Formatted)

### MODIFIED: .github/agents/toggle-orchestrator.agent.md
- **Chat Display Format**: Replaced plain-text separator dashes with structured box borders (`╔══╗`) for the toggle analysis header; usage blocks now use `┌─ Usage N / total ─┐` border style for clear visual grouping.
- **Command Menu**: Reorganised into grouped sections (ANALYSIS, REPORTS, MAINTENANCE, DECOMPOSITION) with section separators; added `/toggle-analyse-all` command entry.
- **Bulk Request Banner**: Replaced flat text `BULK REQUEST: N toggles →...` with a clean `╔══╗` box banner showing toggle count and batch plan.
- **Batch Progress Banner**: Replaced single-line `Batch N/total COMPLETE — names — Status` with a structured multi-line block showing toggle names, status, and ASCII progress bar.
- **All Batches Complete Banner**: Replaced flat `ALL BATCHES COMPLETE` text with a `╔══╗` summary box.
- **Stuck Detection Format**: Replaced inline run-on text with a clean labelled block (Batch / Toggle / Reason / Action).
- **Guardrail Responses**: All 5 guardrail rules now have explicit, formatted code-block responses instead of prose descriptions.
- **Report Offer Hint**: Wrapped in separator lines for visual separation from toggle content.
- **Routing Table**: Added `/toggle-analyse-all from <source>` command row.

### MODIFIED: .github/instructions/ux-and-progress.instructions.md
- Batch progress format updated to structured multi-line block with labelled fields and ASCII progress bar.
- All Batches Complete updated to `╔══╗` box format.
- Help command display reorganised into grouped sections matching the orchestrator command menu.
- Added §3 Process Flow Hints specification.

### MODIFIED: .github/instructions/workflow-commands.instructions.md
- Workflow I analysis gap detected banner upgraded to `╔══╗` box format.
- Workflow I batch progress banner updated to match new structured multi-line format.
- Workflow I backfill complete summary upgraded to `╔══╗` box format.
- Workflow D-P post-all completion upgraded to `╔══╗` box format.
- Workflow D-P batch progress banner updated to match new structured multi-line format.

## [2026-04-12] Bug Fix — Chat Enquiry Used show_content Instead of Inline Chat Response

### MODIFIED: .github/agents/toggle-orchestrator.agent.md
- **Bug fix**: Single Toggle Analyse Rule (step 3) now explicitly states **NEVER use `show_content`** for chat analysis responses — results must be returned as plain chat text, not a rendered file panel.
- **Bug fix**: Chat Enquiry Rule updated to explicitly prohibit `show_content` for all chat enquiries — `show_content` is reserved for Polished Report file previews (Workflow D-P) only.
- **Bug fix**: Key Rules summary lines for "Chat Enquiry Rule" and "Single Toggle Analyse Rule" updated to reflect `show_content` prohibition.
- **Root cause**: When user requested "analyze toggle X", the orchestrator incorrectly used `show_content` to display results as a file panel. The correct behaviour is to write the analysis directly as a plain chat text response.

---

## [2026-04-12] Bug Fix — Agent Duplicate Write & CSV Schema Issues

### MODIFIED: .github/agents/toggle-analysis-engine.agent.md
- **Bug fix**: Skill C now includes a mandatory PRE-WRITE CHECK — reads `toggle-codebase-usage-analysis.csv` first and checks for existing row by `(Toggle Name + Implementation Class Name + Line Number Code)` triple before any append. Prevents duplicate rows on re-analysis.
- **Bug fix**: Removed incorrect internal-variable CSV schema (`toggle_name, class_name, line_number, ...`) and replaced with the FIXED immutable display schema: `Toggle Name, Implementation Class Name, Line Number Code, Toggle ON Impact, Toggle OFF Impact, Repository`. Prevents per-toggle column name inconsistencies.
- **Bug fix**: Skill E (in-place CSV update) now looks up rows using the fixed schema column names and only updates if the row exists — never appends a second row.

### MODIFIED: .github/agents/toggle-orchestrator.agent.md
- **Bug fix**: Added **Single Toggle Analyse Rule** — `"analyze toggle <name>"` MUST check `toggle-codebase-usage-analysis.csv` FIRST. If the toggle already has rows → display inline, DO NOT delegate to SA-1, DO NOT write new CSV rows.
- **Bug fix**: Routing table updated — `analyze toggle <name>` now shows CSV-first check as the primary action.
- Added CSV Schema Enforcement to Key Rules — fixed column names explicitly documented for SA-1.

### MODIFIED: .github/instructions/workflow-commands.instructions.md
- **Bug fix**: Extracted new **Workflow A (Single)** for `"analyze toggle <name>"` with CSV-FIRST pre-check logic before any SA-1 delegation.
- **Bug fix**: Workflow A (batch), Workflow I (backfill) — added mandatory PRE-WRITE CHECK step before every SA-1 skill C CSV write.
- All CSV write steps in all workflows now use the fixed schema column names.

---

## [2026-04-12] Project Rename & User Guide Added

### RENAMED: Project
- Old name: `agentic-ai-toggle-management`
- New name: `ai-driven-toggle-management`
- Files updated: `README.md`, `knowledge/index.md`, `.github/agent-registry.yml`, `logs/changelog.md`, `.iml` module file
- Added: `USER-GUIDE.md` — shortcut interaction quick-reference for end users

---

## [2026-04-12] Framework Optimization & Cleanup

### MODIFIED: `.github/agents/toggle-workspace-manager.agent.md`
- Removed stale duplicate body (PRE/POST hooks, checkpoint JSON, context summarisation, milestone recording â€” lines 122â€“386)
- Removed deprecated agent deletion list from Skill C (those files already deleted)
- Rewrote file cleanly in UTF-8 (was garbled em-dashes/arrows from encoding issue)
- Added `/cleanup` slash command alias to Skill C trigger

### MODIFIED: `.github/agents/toggle-orchestrator.agent.md`
- Fixed SA-4 Who-Does-What description (removed "QA, optimizer" â€” now "decomp-plan, decomp-impl, stuck-recovery")
- Removed stale `SESSION LIFECYCLE` key rule (PRE/POST hook delegation to SA-5)
- Added slash command column to Command->Workflow routing table
- Updated cold-start display block with slash command quick-start examples

### MODIFIED: `.github/agent-registry.yml`
- Added full slash command aliases to orchestrator `accepts_commands` list
- Removed stale `session-lifecycle-hooks.instructions.md` from orchestrator `reads`
- Removed `sessions/new-session-execution-guide.md` from SA-5 `files_owned.writes`
- Updated `updated_by` description to reflect cleanup changes
- Fixed stale `session-lifecycle-hooks` comment reference

### MODIFIED: `knowledge/config.yml`
- Removed stale `execution_guide` entry pointing to deleted `sessions/new-session-execution-guide.md`

### DELETED: `sessions/new-session-execution-guide.md`

### DELETED: `.github/agents/universal-optimizer.agent.md`
- Orphaned standalone file â€” not wired into any orchestrator routing or agent registry

### MODIFIED: `README.md`
- Added clarification to "How to Resume a Session" re: no session IDs or checkpoint JSON files

## [2026-04-12] Session State Format Migration â€” YAML to .properties

- All 13 fields preserved: progress counters, file paths, tool notes

### MODIFIED: `.github/agents/toggle-orchestrator.agent.md`

### MODIFIED: `.github/agents/toggle-workspace-manager.agent.md`

### MODIFIED: `.github/agent-registry.yml`

### MODIFIED: `knowledge/config.yml`

### MODIFIED: `README.md`
- Updated "single plain YAML file" to "single plain properties file"
## [2026-04-12] Toggle Analysis: "Pass OnlinePin data in DE110 for Amex in S2I message"
### COMPLETED: Workflow A Analysis (Skill B → C → D → E)
- **Toggle**: "Pass OnlinePin data in DE110 for Amex in S2I message"
- **Registry**: Already in 	oggle-registry-lookup.csv (CPE repo)
  - Constant: ONLINE_PIN_IN_DE110_AMEX_TOGGLE
  - Declaration: S2IAcquirerConstants.java:71
- **Usage Found**: IsoDataField110Populator.java:91 (IMPLEMENTATION)
  - Line 91: Check in shouldPopulateForAmexScheme() — determines if DE110 should be populated
  - Line 114: Conditional KCV tag addition in uildDataSet1() — adds destination KCV for Amex when ON
- **Flow Type**: S2I (ISO 8583) — NOT S2A
  - Class IsoDataField110Populator is S2I field populator
  - No S2A trigger per s2a-keywords-lookup.csv
  - S2A analysis SKIPPED per Rule D
- **Impact Analysis**:
  - **ON**: Populates ISO DE110 with Amex online PIN translation data (PIN block format, encryption algorithm, key index, encrypted PIN block, and destination KCV tag)
  - **OFF**: DE110 not populated for Amex transactions
- **CSV Output**: Row written to both:
  - data/analysis/toggle-codebase-usage-analysis.csv (combined)
  - data/analysis/toggle-codebase-usage-analysis-cpe.csv (per-repo)
- **Status**: ✓ Analysis complete — no blockers

## [2026-04-12] Workflow B: Registry Rebuild for Orchestrator Repository

### SKILL A: Registry Management — Rebuild Toggle Registry (Orchestrator Scope)

**Task**: Rebuild the toggle registry by scanning the Orchestrator Java source code (full scope)

**Execution Details**:
- **Configuration**: knowledge/config.yml loaded successfully
- **Target Repository**: Orchestrator
  - Java root: <mpgs_source>/orchestrator/src/main/java
  - Scan strategy: full
  - Java files scanned: 751

**Pass 1 — Harvesting Toggle Declarations**:
- Total unique toggle names discovered: 340 (across all 7 configured repositories)
- Total declaration entries: 447
- Toggle pattern matching: Strict TOGGLE_*, ENABLE_*, FEATURE_* patterns with validation

**Pass 2 — Harvesting Toggle Usages**:
- All 7 repositories scanned: 6 full-scan + 1 targeted (DirectAPI)
  - CPE: 2,420 files
  - Orchestrator: 751 files
  - BusinessService: 581 files
  - Console: 749 files
  - MSOUI: 1,065 files
  - BatchSettlementService: 285 files
  - DirectAPI: 23 targeted files
- Total usage entries found: 672

**Registry Merge & Output**:
- Total entries in final combined registry: 704
- **Orchestrator Registry File**: toggle-registry-orchestrator.csv
  - **Total rows**: 120 (including header)
  - **Unique toggles**: 75
  - **Entry types**:
    - IMPLEMENTATION: 117 entries (direct toggle usage in code)
    - IMPORT: 0 entries (static imports)
    - DECLARATION: 3 entries (toggle constants declared but not used)

**Per-Repository Registry Summary**:
| Repository | Entries | IMPL | IMPORT | DECL | File |
|---|---|---|---|---|---|
| CPE | 420 | 401 | 7 | 12 | toggle-registry-cpe.csv |
| Orchestrator | 120 | 117 | 0 | 3 | toggle-registry-orchestrator.csv |
| BusinessService | 41 | 12 | 22 | 7 | toggle-registry-business-service.csv |
| MSOUI | 82 | 67 | 13 | 2 | toggle-registry-msoui.csv |
| DirectAPI | 29 | 23 | 2 | 4 | toggle-registry-direct-api.csv |
| Console | 7 | 6 | 1 | 0 | toggle-registry-console.csv |
| BatchSettlementService | 5 | 1 | 0 | 4 | toggle-registry-batch-settlement-service.csv |

**Files Written**:
- ✓ data/registry/toggle-registry-lookup.csv (combined, 704 rows)
- ✓ data/registry/toggle-registry-orchestrator.csv (120 rows, 75 unique toggles)
- ✓ All 7 per-repo registry files updated

**Validation**:
- ✓ No toggle names in reject list ["-", "SQL", "TODO"]
- ✓ All 7 columns present in all registry rows
- ✓ Per-repo files written successfully
- ✓ Header row intact in all files

**Status**: ✓ COMPLETE — Orchestrator registry rebuilt successfully

---

## [2026-04-12] Chat Format — Replace all box-drawing & ASCII banners with standard Markdown

### MODIFIED: .github/agents/toggle-orchestrator.agent.md
- Replaced all `╔══╗ ║ ╚══╝` box-drawing banners with Markdown blockquotes and tables.
- Bulk-request announcement: now uses `> **Bulk Request Detected**` blockquote + bullet list.
- Batch progress: now uses `| Field | Value |` Markdown table.
- All-batches summary: now uses `| Metric | Count |` Markdown table.
- Stuck detection: now uses `> **Stuck Detected**` blockquote + bullet list.
- Guardrail responses: now use Markdown blockquotes instead of `⛔` code blocks.
- Session command menu: replaced ASCII box + dashes menu with grouped `| Category | Command | Description |` Markdown table.
- Report Offer Hint: replaced `──` separator + `💡` prefix with `---` horizontal rule + Markdown blockquote.
- Added **Chat Format Rule** to Key Rules: no box-drawing chars, no ASCII progress bars, no emoji banners.

### MODIFIED: .github/instructions/workflow-commands.instructions.md
- Removed all `╔══╗` / `╚══╝` completion banners from Workflows D-P and I.
- Removed `✅` prefixed code-block progress lines from all workflows (A, B, C, D, E, F, G, H, I).
- Removed `[PRE] Show 💡 PROCESS FLOW hint` lines.
- Replaced `[<filled>░<remaining>]` progress bar pattern with Markdown table.
- Coverage gap blocks in Workflow D-P now use Markdown blockquotes.
- Analysis gap block in Workflow I now uses Markdown blockquote.
- Post-all completion summaries in Workflows D-P and I now use Markdown tables.

### MODIFIED: .github/agents/toggle-report-writer.agent.md
- Coverage gap response now uses Markdown blockquote format.
- Batch progress changed from `✅ Batch N of M COMPLETE` code-block line to Markdown `| Field | Value |` table.
- Added explicit formatting rules: never use box-drawing chars, never use ASCII progress bars, emoji only in H3 headings.

### MODIFIED: .github/instructions/ux-and-progress.instructions.md
- Section 1 (Progress Reporting): replaced `✅ Batch ...` code block + `╔══╗` all-batches box with Markdown tables.
- Section 2 (Help Command): replaced ASCII `╔══╗` box + dashes menu with `| Category | Command | Description |` Markdown table.
- Section 3 (Process Flow Hints): replaced `💡` code-block prefix with Markdown blockquote format.

---

## [2026-04-12T00:00:00Z] Workflow A — Toggle Analysis Batch 6 of 42

### Agent: toggle-analysis-engine (SA-1) | Mode: Skill B + Skill C + Skill D/E

### PRE-FLIGHT REGISTRY CROSS-CHECK

| Metric | Count |
|---|---|
| Total pending toggles | 5 |
| In registry (queued) | 5 |
| Not in registry (skipped) | 0 |

All 5 toggles confirmed in registry. Pre-flight passed. ✅

---

### Toggle 1: Enable Online Refund

**Registry rows:** 2 (IMPLEMENTATION — FinancialTransactionUtil:575, S2IAcquirerV1:11347) — both CPE

**PRE-WRITE CHECK:** No existing rows for `(Enable Online Refund, FinancialTransactionUtil, 575)` or `(Enable Online Refund, S2IAcquirerV1, 11347)` in analysis CSV. ✅ Confirmed new.

**S2A Check:** Neither `FinancialTransactionUtil` nor `S2IAcquirerV1` is an S2A trigger class. No Skill D/E required.

**Rows WRITTEN: 2**
| Class | Line | Repository |
|---|---|---|
| FinancialTransactionUtil | 575 | CPE |
| S2IAcquirerV1 | 11347 | CPE |

**Files updated:** `toggle-codebase-usage-analysis.csv`, `toggle-codebase-usage-analysis-cpe.csv`

---

### Toggle 2: Enable PAR functionality for S2I transactions

**Registry rows:** 3 (S2IAcquirerV1:4807 IMPLEMENTATION CPE, CardPaymentDecorator:442 IMPLEMENTATION CPE, S2IAcquirerToggleConstants DECLARATION CPE)

**PRE-WRITE CHECK:** No existing rows for `(Enable PAR functionality for S2I transactions, S2IAcquirerV1, 4807)` or `(Enable PAR functionality for S2I transactions, CardPaymentDecorator, 442)` in analysis CSV. ✅ Confirmed new.

**S2A Check:** Neither class is an S2A trigger class. No Skill D/E required.

**Rows WRITTEN: 2** (DECLARATION rows not written — IMPLEMENTATION only)
| Class | Line | Repository |
|---|---|---|
| S2IAcquirerV1 | 4807 | CPE |
| CardPaymentDecorator | 442 | CPE |

**Files updated:** `toggle-codebase-usage-analysis.csv`, `toggle-codebase-usage-analysis-cpe.csv`

---

### Toggle 3: Enable PAR functionality in S2I for Verify transaction

**Registry rows:** 2 (S2IAcquirerV1:4807 IMPLEMENTATION CPE, S2IAcquirerToggleConstants DECLARATION CPE)

**PRE-WRITE CHECK:** No existing rows for `(Enable PAR functionality in S2I for Verify transaction, S2IAcquirerV1, 4807)` in analysis CSV. ✅ Confirmed new.

**S2A Check:** S2IAcquirerV1 is an S2I class (SKIP_S2A_ANALYSIS). No Skill D/E required.

**Rows WRITTEN: 1** (DECLARATION rows not written — IMPLEMENTATION only)
| Class | Line | Repository |
|---|---|---|
| S2IAcquirerV1 | 4807 | CPE |

**Files updated:** `toggle-codebase-usage-analysis.csv`, `toggle-codebase-usage-analysis-cpe.csv`

---

### Toggle 4: Enable PSD2 Exemptions for Discover Protect Buy Authentications

**Registry rows:** 4 (S2IAcquirerV1:8076 CPE, S2IAcquirerToggleConstants DECLARATION CPE, JsonMegaMessageRequestBuilder:3835 CPE, TspiRequestMessageBuilder:2996 CPE)

**PRE-WRITE CHECK:** No existing rows for any of the 3 IMPLEMENTATION triples. ✅ Confirmed new.

**S2A Check:**
- `S2IAcquirerV1` → S2I class → SKIP_S2A_ANALYSIS
- `JsonMegaMessageRequestBuilder` → S2A TRIGGER class → Skill D/E required
- `TspiRequestMessageBuilder` → S2A TRIGGER class → Skill D/E required

**Skill D/E (S2A enrichment):** Both S2A rows already written with full TSPI field notation inline:
- `JsonMegaMessageRequestBuilder:3835` → `TSPI: Transaction.Authentication.Psd2Exemption` and `Transaction.Authentication.PSD2RegulationExemption` ✅
- `TspiRequestMessageBuilder:2996` → `TSPI: Transaction.PsD2RegulationExemption` and `Transaction.Psd2Exemption` ✅

No in-place update needed — notation included at write time.

**Rows WRITTEN: 3** (DECLARATION rows not written — IMPLEMENTATION only)
| Class | Line | Repository |
|---|---|---|
| S2IAcquirerV1 | 8076 | CPE |
| JsonMegaMessageRequestBuilder | 3835 | CPE |
| TspiRequestMessageBuilder | 2996 | CPE |

**Files updated:** `toggle-codebase-usage-analysis.csv`, `toggle-codebase-usage-analysis-cpe.csv`

---

### Toggle 5: Enable Partner solution identifier configuration

**Registry rows:** 8 (multi-repo — MSOUI: AcquirerValidator:72, MerchantValidationServiceHelper:266, AcquirerLinkDetailsController:1430, MerchantApprovalController:713, MerchantSummaryController:488; CPE: IsoDataField123Populator:1005; plus DECLARATION rows)

**PRE-WRITE CHECK:** No existing rows for any of the 6 IMPLEMENTATION triples. ✅ Confirmed new.

**S2A Check:** `IsoDataField123Populator` → S2I class (SKIP_S2A_ANALYSIS). No MSOUI class is an S2A trigger. No Skill D/E required.

**Rows WRITTEN: 6** (DECLARATION rows not written — IMPLEMENTATION only)
| Class | Line | Repository |
|---|---|---|
| AcquirerValidator | 72 | MSOUI |
| MerchantValidationServiceHelper | 266 | MSOUI |
| AcquirerLinkDetailsController | 1430 | MSOUI |
| IsoDataField123Populator | 1005 | CPE |
| MerchantApprovalController | 713 | MSOUI |
| MerchantSummaryController | 488 | MSOUI |

**Files updated:** `toggle-codebase-usage-analysis.csv`, `toggle-codebase-usage-analysis-cpe.csv`, `toggle-codebase-usage-analysis-msoui.csv`

---

### BATCH 6 SUMMARY

| Toggle | Rows Written | Rows Skipped | Repositories |
|---|---|---|---|
| Enable Online Refund | 2 | 0 | CPE |
| Enable PAR functionality for S2I transactions | 2 | 0 | CPE |
| Enable PAR functionality in S2I for Verify transaction | 1 | 0 | CPE |
| Enable PSD2 Exemptions for Discover Protect Buy Authentications | 3 | 0 | CPE |
| Enable Partner solution identifier configuration | 6 | 0 | MSOUI, CPE |
| **TOTAL** | **14** | **0** | CPE, MSOUI |

**Combined analysis CSV:** 262 rows → 276 rows (+14)
**S2A enrichment applied:** 2 rows (JsonMegaMessageRequestBuilder:3835, TspiRequestMessageBuilder:2996) — TSPI notation embedded at write time

## [2026-04-12T11:30:00Z] Workflow A — Toggle Analysis Batch 7 of 42
### Agent: toggle-analysis-engine | Mode: SA-1 Full Skill A+B+C+D/E
### Task: Analyse 5 toggles — Batch 7
**Pre-flight registry cross-check**: 5/5 in registry → all queued for analysis.
**NOT IDENTIFIED**: None.
#### Rows Written — Combined CSV
| Toggle Name | Class | Line | Repo | Status |
|---|---|---|---|---|
| Enable PayPal V2 Functionality | PaymentTypeWrapperBuilder | 305 | BusinessService | ✅ NEW |
| Enable PayPal V2 Functionality | MsoPayPalConfigurationService | 94 | MSOUI | ✅ NEW |
| Enable Payer and Tap Initiated Debt Recovery For Mastercard and Visa | S2IAcquirerV1 | 8555 | CPE | ✅ NEW |
| Enable Rate Limit For Unauthenticated Requests | UnauthenticatedPaymentRateLimiter | 80 | DirectAPI | ✅ NEW |
| Enable ReAuthorization | UpdateAuthorisationExecutorFactory | 49 | CPE | ✅ NEW |
| Enable ReAuthorization | UpdateAuthorisationRequestValidator | 314 | Orchestrator | ✅ NEW |
| Enable ReAuthorization | TransactionRequestValidator | 721 | CPE | ✅ NEW |
| Enable ReAuthorization | AuthReversalServiceProcessor | 114 | CPE | ✅ NEW |
| Enable ReAuthorization | TspiRequestMessageBuilder | 2442 | CPE | ✅ NEW (S2A enriched — TSPI: Transaction.IndustryTransactionType) |
| Enable ReAuthorization | JsonMegaMessageRequestBuilder | 1574 | CPE | ✅ NEW |
| Enable ReAuthorization | AuthCaptureModeHelper | 622 | CPE | ✅ NEW |
| Enable S2I Mastercard Mandate CardOnFile | S2IAcquirerV1 | 5551 | CPE | ✅ NEW |
**Total new rows written**: 12
**Rows skipped (already existed)**: 0
#### Per-Repo Files Updated
- 	oggle-codebase-usage-analysis-business-service.csv (+1 row)
- 	oggle-codebase-usage-analysis-msoui.csv (+1 row)
- 	oggle-codebase-usage-analysis-cpe.csv (+8 rows)
- 	oggle-codebase-usage-analysis-direct-api.csv (+1 row)
- 	oggle-codebase-usage-analysis-orchestrator.csv (+1 row)
#### Skill D/E S2A Enrichment
- TspiRequestMessageBuilder (Enable ReAuthorization, line 2442): S2A T-SPI class — TSPI field notation applied inline: TSPI: Transaction.IndustryTransactionType = REAUTHORIZATION
- All other classes: S2I, internal, or non-S2A → no enrichment required
---

## [2026-04-12T23:00:00Z] Workflow A — Toggle Analysis Batch 9 of 42

### Agent: toggle-analysis-engine | Mode: Skill A+B+C+D/E

### Task: Analyse 5 toggles — Batch 9/42

**Pre-Flight Registry Cross-Check**: 5/5 in registry → all queued for analysis.

**PRE-WRITE CHECK**: All 14 (Toggle Name + Class + Line) triples confirmed absent from combined analysis CSV before write.

| Toggle | Class | Line | Repo | Status |
|---|---|---|---|---|
| Enable Software Online Pin for S2I | PosTerminalEntryModeTranslator | 103 | CPE | ✅ NEW ROW WRITTEN |
| Enable TAS for SCOF | MerchantApprovalController | 728 | MSOUI | ✅ NEW ROW WRITTEN |
| Enable TAS for SCOF | StoredCardTokensConfigurationController | 197 | MSOUI | ✅ NEW ROW WRITTEN |
| Enable TAS for SCOF | MerchantPaymentDetailsDtoBuilder | 124 | MSOUI | ✅ NEW ROW WRITTEN |
| Enable TAS for SCOF | RetrieveMerchantRequestHandler | 588 | MSOUI | ✅ NEW ROW WRITTEN |
| Enable TAS for SCOF | MerchantValidationServiceImpl | 562 | MSOUI | ✅ NEW ROW WRITTEN |
| Enable TAS for SCOF | RoutedServicesDelegate | 387 | Orchestrator | ✅ NEW ROW WRITTEN |
| Enable TAS for SCOF | ScpDetailsServiceImpl | 249 | MSOUI | ✅ NEW ROW WRITTEN |
| Enable TAS for SCOF | TokenizationDetailsValidator | 110 | MSOUI | ✅ NEW ROW WRITTEN |
| Enable TSPI Mastercard Mandate CardOnFile | TspiRequestMessageBuilder | 1320 | CPE | ✅ NEW ROW WRITTEN (S2A enriched) |
| Enable TSPI Mastercard Mandate CardOnFile | JsonMegaMessageRequestBuilder | 1647 | CPE | ✅ NEW ROW WRITTEN (S2A enriched) |
| Enable TSPI Response Mapping of AcquirerTransactionId from Acquiring Service to BSS | ToggleHelper | 27 | BatchSettlementService | ✅ NEW ROW WRITTEN |
| Enable Transit Aggregated Fare in Verify for Amex | S2IAcquirerV1 | 11365 | CPE | ✅ NEW ROW WRITTEN |

#### Files Modified
- toggle-codebase-usage-analysis.csv (+13 rows)
- toggle-codebase-usage-analysis-cpe.csv (+5 rows: PosTerminalEntryModeTranslator/103, TspiRequestMessageBuilder/1320, JsonMegaMessageRequestBuilder/1647, S2IAcquirerV1/11365 + existing S2I MC mandate row)
- toggle-codebase-usage-analysis-msoui.csv (+7 rows: MerchantApprovalController/728, StoredCardTokensConfigurationController/197, MerchantPaymentDetailsDtoBuilder/124, RetrieveMerchantRequestHandler/588, MerchantValidationServiceImpl/562, ScpDetailsServiceImpl/249, TokenizationDetailsValidator/110)
- toggle-codebase-usage-analysis-orchestrator.csv (+1 row: RoutedServicesDelegate/387)
- toggle-codebase-usage-analysis-batch-settlement-service.csv (CREATED — +1 new row for ToggleHelper/27 + pre-existing BSS rows migrated)

#### Skill D/E S2A Enrichment
- TspiRequestMessageBuilder (Enable TSPI Mastercard Mandate CardOnFile, line 1320): S2A T-SPI class — TSPI: AgreementData.FirstTransactionOfAgreement.FinancialNetworkTransactionId notation applied inline
- JsonMegaMessageRequestBuilder (Enable TSPI Mastercard Mandate CardOnFile, line 1647): S2A MEGA JSON class — TSPI: Agreement.FirstTransactionOfAgreement.FinancialNetworkTransactionId notation applied inline
- All other classes: S2I (S2IAcquirerV1/PosTerminalEntryModeTranslator), MSOUI UI, Orchestrator internal, BSS → no S2A enrichment required
---

## [2026-04-12T00:00:00Z] Workflow A — Analyse-All Batch 11 of 42 (5 Toggles)

### Agent: toggle-analysis-engine (SA-1) | Mode: Full Workflow A Chain

### Toggles Processed

**Pre-Flight Registry Cross-Check**: 5/5 in registry → all queued for analysis.

**PRE-WRITE CHECK**: All 8 (Toggle Name + Class + Line) triples confirmed absent from combined analysis CSV before write.

| Toggle | Class | Line | Repo | Status |
|---|---|---|---|---|
| Enable Visa Deferred Authorization for transit | S2IAcquirerV1 | 5691 | CPE | ✅ NEW ROW WRITTEN |
| Enable Visa Transit | CaptureServiceImpl | 237 | CPE | ✅ NEW ROW WRITTEN |
| Enable Visa Transit | S2IAcquirerV1 | 2330 | CPE | ✅ NEW ROW WRITTEN |
| Enable Visa Transit | AddressVerificationRequest | 492 | CPE | ✅ NEW ROW WRITTEN |
| Enable Visa Transit Terminal mapping for NOT_CARDHOLDER_ACTIVATED DE61SF10=2 | IsoDataField61Populator | 624 | CPE | ✅ NEW ROW WRITTEN |
| Enable additional response codes | ResponseExtractor | 49 | CPE | ✅ NEW ROW WRITTEN |
| Enable alternate S2I transport | AffinityTokenResolver | 180 | CPE | ✅ NEW ROW WRITTEN |

**Note:** `Enable Visa Transit` — RecurringPaymentAgreementValidator line 68 is a DECLARATION (constant reference only, no isToggleOn() call — no analysis row written per registry usage_type=DECLARATION). All 3 CPE IMPLEMENTATION rows written.

#### Files Modified
- toggle-codebase-usage-analysis.csv (+7 rows — total 323 rows)
- toggle-codebase-usage-analysis-cpe.csv (+7 rows)

#### Skill D/E S2A Enrichment
- S2IAcquirerV1 → SKIP_S2A_ANALYSIS (S2I class)
- IsoDataField61Populator → SKIP_S2A_ANALYSIS (S2I class)
- CaptureServiceImpl → not in S2A keyword list → no S2A enrichment
- AddressVerificationRequest → not in S2A keyword list → no S2A enrichment
- ResponseExtractor → not in S2A keyword list → no S2A enrichment
- AffinityTokenResolver → not in S2A keyword list → no S2A enrichment
- No Skill D/E invoked for any toggle in this batch
---

## [2026-04-12T00:00:00Z] SA-5 — Session Checkpoint Created

### Agent: toggle-workspace-manager (SA-5) | Mode: Skill A — Post-Batch Knowledge Update

### Task: Create session checkpoint file for Analyse-All workflow (Batches 1–11 complete)

**File written:** `logs/session-checkpoint-2026-04-12.md`

| Field | Value |
|---|---|
| Workflow | Analyse-All from `data/enquiry/feature-toggle-confluence-page-enquiry-v2.csv` |
| Source toggles | 334 |
| ALREADY_ANALYSED (skipped) | 122 |
| REGISTRY_NOT_FOUND (skipped) | 6 |
| Work queue | 206 |
| Batches complete | 11 of 42 |
| Toggles processed | 55 of 206 |
| Toggles remaining | 151 |
| Next batch resume | Batch 12 — starting with "Enable card resolution using cardbinsets for Agreements" |

**Purpose:** Persistent session state snapshot to enable safe resume across sessions without relying on volatile context window state.

---

## [2026-04-12T00:00:00Z] Workflow A — Batch 12 of 42 — Toggle Analysis (5 toggles)

### Agent: toggle-analysis-engine | Mode: SA-1 Full Workflow A Chain

---

#### ⚡ Pre-Flight Registry Cross-Check
- Total pending: 5 | ✅ In registry: 5 | ❌ Not in registry: 0
- All 5 toggles queued for Skill B + C analysis

---

#### Toggle 1: Enable card resolution using cardbinsets for Agreements

| Field | Value |
|---|---|
| Registry rows | 1 IMPLEMENTATION (RecurringPaymentAgreementValidator / line 127 / Orchestrator) |
| Pre-write check | ✅ No existing row — NEW |
| Row written | ✅ combined + orchestrator per-repo |
| S2A check | RecurringPaymentAgreementValidator — not in S2A keyword list → no Skill D/E |

---

#### Toggle 2: Enable data element mapping DE61SF11=0 for Visa MIDR transit transactions

| Field | Value |
|---|---|
| Registry rows | 1 IMPLEMENTATION (IsoDataField61Populator / line 531 / CPE) |
| Pre-write check | ✅ No existing row — NEW |
| Row written | ✅ combined + cpe per-repo |
| S2A check | IsoDataField61Populator → SKIP_S2A_ANALYSIS (S2I class) |

---

#### Toggle 3: Enable debugInformation mapping in the response for S2A

| Field | Value |
|---|---|
| Registry rows | 2 IMPLEMENTATION (FinancialTransactionUtil/870/CPE, JsonMessageParserImpl/156/CPE) |
| Note | BSS ToggleHelper line 27 is DECOMPOSED ([TOGGLE-DECOMP]) — not a live implementation row |
| Pre-write check | ✅ Both rows NEW |
| Rows written | ✅ 2 rows — combined + cpe per-repo |
| S2A check | JsonMessageParserImpl → TRIGGER_S2A_ANALYSIS; FinancialTransactionUtil → not in S2A keyword list |
| Skill D/E | JsonMessageParserImpl row enriched with TSPI field notation: TSPI: Transaction.DebugInformation (custom field 'Debug') — S2A Feature Toggle controlling DebugInformation passthrough vs. filtered suppression in MEGA JSON response parsing |

---

#### Toggle 4: Enable domestic transactions mandates for MADA

| Field | Value |
|---|---|
| Registry rows | 1 IMPLEMENTATION (FinancialTransactionUtil / line 269 / CPE) |
| Pre-write check | ✅ No existing row — NEW |
| Row written | ✅ combined + cpe per-repo |
| S2A check | FinancialTransactionUtil — not in S2A keyword list (utility method, not S2A class) → no Skill D/E |

---

#### Toggle 5: Enable eftpos under transit for S2I

| Field | Value |
|---|---|
| Registry rows | 2 IMPLEMENTATION (ResponseExtractor/49/CPE, S2IAcquirerV1/821/CPE) |
| Pre-write check | ✅ Both rows NEW |
| Rows written | ✅ 2 rows — combined + cpe per-repo |
| S2A check | ResponseExtractor → not in S2A keyword list; S2IAcquirerV1 → SKIP_S2A_ANALYSIS (S2I class) |

---

#### Files Modified
- `data/analysis/toggle-codebase-usage-analysis.csv` (+7 rows — total 330 rows)
- `data/analysis/toggle-codebase-usage-analysis-orchestrator.csv` (+1 row)
- `data/analysis/toggle-codebase-usage-analysis-cpe.csv` (+6 rows)

#### Rows Written Summary
| Toggle | Class | Line | Repo | Status |
|---|---|---|---|---|
| Enable card resolution using cardbinsets for Agreements | RecurringPaymentAgreementValidator | 127 | Orchestrator | ✅ WRITTEN |
| Enable data element mapping DE61SF11=0 for Visa MIDR transit transactions | IsoDataField61Populator | 531 | CPE | ✅ WRITTEN |
| Enable debugInformation mapping in the response for S2A | FinancialTransactionUtil | 870 | CPE | ✅ WRITTEN |
| Enable debugInformation mapping in the response for S2A | JsonMessageParserImpl | 156 | CPE | ✅ WRITTEN (S2A enriched) |
| Enable domestic transactions mandates for MADA | FinancialTransactionUtil | 269 | CPE | ✅ WRITTEN |
| Enable eftpos under transit for S2I | ResponseExtractor | 49 | CPE | ✅ WRITTEN |
| Enable eftpos under transit for S2I | S2IAcquirerV1 | 821 | CPE | ✅ WRITTEN |

---

## [2026-04-27] toggle-orchestrator (Orchestrator)

### CREATED: `reports/toggle-decomp-plan-ach-account-validation-2026-04-27.md`

- **Action**: `CREATED`
- **Agent**: `toggle-orchestrator` (Orchestrator)
- **Reason**: Polished Markdown decomposition plan generated for toggle "ACH Account Validation for Paymentech Salem ACH Acquirer" in BatchSettlementService, converted from SA-4 raw plan file at user request.
- **Details**:
  - Full decomposition plan rendered as structured Markdown report in `reports/`
  - Covers: branch decision (keep toggle-ON), files to delete (×2), files to modify (×2), ripple-effect analysis, step-by-step execution order (dry run + actual run), risk assessment table, and pre-flight checklist
  - AI disclaimer and copyright footer included per governance rules

---
