﻿
---
# AI-Driven Toggle Management System

> **Author:** MPGS - EPAM  
> **Date:** April 26, 2026  
> **Status:** Active — Analysis in progress  
> **Architecture:** Multi-agent system with 1 orchestrator + 5 sub-agents  
> **Platform:** Mastercard Payment Gateway Services (MPGS)

---

## Table of Contents

1. [Overview](#overview)
2. [Source Repositories](#source-repositories)
3. [Agent Architecture](#agent-architecture)
4. [Supported Workflows](#supported-workflows)
5. [Workflow Examples — Sample Prompts](#workflow-examples--sample-prompts)
6. [How to Resume a Session](#how-to-resume-a-session)
7. [User Guide](#user-guide)
8. [Key Design Principles](#key-design-principles)

---

## Overview

This is the **framework repository** for the AI-Driven Toggle Management System — an enterprise-grade, multi-agent AI system that performs comprehensive feature toggle analysis across all registered MPGS payment gateway repositories.

The system provides:

1. Locate where each registered feature toggle is used across all configured Java repositories
2. Analyze the business and field-level impact when each toggle is in the ON versus OFF state
3. Fetch and associate Confluence documentation pages for each toggle
4. Generate structured analysis reports (per-toggle, per-repository, S2A-only, status dashboard, polished summary)
5. Maintain analysis currency following code releases and toggle additions
6. Support seamless onboarding of additional repositories into the toggle registry

The system is **fully extensible** — new repositories and toggles can be added without any changes to agent definitions or tooling.

---

## Source Repositories

The system analyses system/feature toggles across all registered MPGS Java repositories. The registry automatically covers all configured repositories and can be extended by onboarding new ones via Workflow F.

| Repository | Approx. Java Files | Scan Strategy |
|---|---|---|
| CardPaymentEngine (CPE) | ~2,420 | Full |
| Orchestrator | ~751 | Full |
| BusinessService | ~581 | Full |
| Console | ~749 | Full |
| MSOUI | ~1,065 | Full |
| DirectAPI | ~10,367 | Targeted |
| BatchSettlementService | ~285 | Full |
| *(additional repositories)* | — | Configured on onboarding |

---

## Agent Architecture

The system is built around a central **toggle-orchestrator** that receives all user commands and delegates to the appropriate specialised sub-agent. You only ever type a plain-English command (or slash command) — the orchestrator handles all routing, state management, and coordination internally.

| ID | Agent | Skills / Responsibilities |
|---|---|---|
| — | toggle-orchestrator | Central coordinator — routes all commands, enforces guardrails, never does leaf work |
| SA-1 | toggle-analysis-engine | Registry build/lookup · Java source search · ON/OFF impact analysis · S2A enrichment · S2A CSV update |
| SA-2 | toggle-report-writer | 6 structured report types · Polished Markdown report (with coverage pre-check) |
| SA-3 | toggle-confluence-enquiry | Confluence 4-tier search · metadata extraction · results CSV |
| SA-4 | toggle-advisor ⚡ | Decomp planning · Decomp implementation (dry/actual) · Stuck recovery |
| SA-5 | toggle-workspace-manager | Session state persistence · Knowledge docs · Onboarding · Workspace cleanup |

> ⚡ SA-4 is on-request only — never auto-invoked except for stuck recovery (called by orchestrator).

---

## Supported Workflows

| Command / Slash Command | Workflow | Description |
|---|---|---|
| `analyze toggle <toggle-name>` · `/analyse-toggle <toggle-name>` | A | Locate toggle usages and produce ON/OFF business and field-level impact for a specific toggle |
| `analyze all remaining toggles` · `/analyse-all` | A | Locate usages and analyse all toggles not yet processed from the input list |
| `rebuild registry` · `/rebuild-registry` | B | Rebuild the toggle registry by re-scanning all registered repositories |
| `fetch confluence data for <toggle-name>` · `/fetch-confluence <toggle-name>` | C | Retrieve Confluence page metadata for a specific toggle |
| `fetch confluence data for all pending toggles` · `/fetch-confluence-all` | C | Retrieve Confluence page metadata for all toggles not yet enriched |
| `generate report` · `/generate-report` | D | Generate structured analysis reports |
| `generate polished report` · `/generate-polished-report` | D-P | Generate a final human-readable Markdown summary report |
| `check for missing toggles` · `/check-missing` | E | Identify toggles not yet analysed or not found in the codebase |
| `onboard repo <name>` · `/onboard-repo <name>` | F | Register a new repository into the toggle system |
| `check for toggle changes` · `/check-changes` | G | Detect toggle additions, removals, and renames since last run |
| `clean up files` · `/cleanup` | H | Deduplicate, repair encoding, and clean workspace files |
| `backfill missing analysis` · `/backfill` | I | Fill analysis gaps for any unprocessed toggles |
| `plan toggle decomposition for <repo>` · `/plan-decomp <repo>` | — ⚡ | Produce a read-only decomposition change plan — no source edits |
| `decompose toggles in <repo> dry run` · `/decompose <repo>` | — ⚡ | Refactor source to remove toggles (dry run first, confirm for actual) |
| `review toggle quality for <toggle-name>` · `/review-toggle <toggle-name>` | — ⚡ | Review output quality for a completed toggle analysis — returns advisory |

> ⚡ On-request only — never auto-invoked by the system.

---

## Workflow Examples — Sample Prompts

### Workflow A — Analyse a Specific Toggle

Analyse a single toggle by its exact name from `data/enquiry/feature-toggle-confluence-page-enquiry.csv`:

```
analyze toggle "Apply New Order ID Reuse Rule"
analyze toggle "Enable Unusual Transaction Protection"
analyze toggle "Enable issuer country code in transaction response"
analyze toggle "System Toggle: CPE Load Balancer Uses Ping"
analyze toggle "Bypass CSC checks for Scheme Token Transactions"
analyze toggle "Enable CIT MIT indicators for Mastercard"
analyze toggle "Random Terminal Allocation"
```

Analyse all remaining unprocessed toggles from the input list at once:

```
analyze all remaining toggles
resume from toggle "Enable Lookup up to 11 digit bin for Card Identification"
```

### Workflow B — Rebuild Toggle Registry

```
rebuild registry
/rebuild-registry
rebuild registry for CPE
```

### Workflow C — Fetch Confluence Data

Fetch Confluence documentation for a specific toggle:

```
fetch confluence data for "Apply New Order ID Reuse Rule"
fetch confluence data for "Enable Unusual Transaction Protection"
fetch confluence data for "System Toggle: Use 8_4 Masked PAN for Scheme Token Transaction Response"
fetch confluence data for "Route Risk Operations via the R-SPI Service and enable Merchant Risk"
```

Fetch for all toggles not yet enriched:

```
fetch confluence data for all pending toggles
```

### Workflow D — Generate Reports

```
generate report
/generate-report
generate S2A report for CPE
generate per-repo summary for BusinessService
generate missing toggle report
generate toggle status dashboard
```

### Workflow D-P — Generate Polished Report *(On-Request Only)*

```
generate polished report
/generate-polished-report
generate polished report for CPE
generate polished report with S2A context
```

### Workflow E — Check for Missing Toggles

```
check for missing toggles
/check-missing
check for missing toggles in CPE
```

### Workflow F — Onboard a New Repository

```
onboard repo BatchSettlementService
/onboard-repo BatchSettlementService
```

### Workflow G — Check for Toggle Changes

```
check for toggle changes
/check-changes
check for toggle changes after release 6.2.1
```

### Workflow H — Clean Up Files

```
clean up files
/cleanup
```

### Workflow I — Backfill Missing Analysis

```
backfill missing analysis
/backfill
fill analysis gaps
```

### Plan Toggle Decomposition *(On-Request Only)*

```
plan toggle decomposition for CPE
/plan-decomp CPE
plan toggle decomposition for Orchestrator
```

### Decompose Toggles *(On-Request Only)*

```
decompose toggles in CPE dry run
/decompose CPE
confirm actual run for CPE
```

### Review Toggle Quality *(On-Request Only)*

```
review toggle quality for "Enable Unusual Transaction Protection"
review toggle quality for "Apply New Order ID Reuse Rule"
/review-toggle "System Toggle: CPE Load Balancer Uses Ping"
```

---

## How to Resume a Session

**To check current progress:**
```
what is the current analysis status
```

**To resume analysis from a specific toggle:**
```
resume from toggle "Enable Lookup up to 11 digit bin for Card Identification"
resume from toggle "Route Risk Operations via the R-SPI Service and enable Merchant Risk"
```

---

## User Guide

### Prerequisites

- JetBrains AI Assistant (or compatible agentic AI environment) is active in the workspace
- All MPGS source repositories are cloned and locally accessible
- The workspace data directory is writable by the agent session

---

### Initial Setup — First Run

1. Open the workspace in JetBrains and activate the AI Assistant agent panel.
2. The orchestrator will automatically load all configuration and session state on startup.
3. If the toggle registry is missing, run: `rebuild registry`
4. Begin analysis with: `analyze all remaining toggles`

---

### How to Add New Repositories

New repositories are onboarded without any manual changes to agent definitions. Simply run:

```
onboard repo <repository-name>
```

The system will scan the repository, build its registry, and include it in all future analysis runs. Rebuild the combined registry afterwards:

```
rebuild registry
```

---

### How to Add New Toggles

New toggles are added by appending them to the input toggle list. No changes to any agent are required. After adding, run:

```
check for missing toggles
```

Then proceed with the normal analysis workflow.

---

### Troubleshooting

| Symptom | Resolution |
|---|---|
| Toggle reported as not found | Run `rebuild registry`, then retry the toggle |
| Garbled characters in output files | Run `clean up files` to repair file encoding |
| Registry missing or empty | Run `rebuild registry` |
| Confluence search returns no results | Re-run `fetch confluence data for <toggle-name>` — the system uses a multi-tier search strategy |
| Duplicate rows in analysis output | Run `clean up files` to deduplicate |
| New repository not included in analysis | Run `onboard repo <name>`, then `rebuild registry` |

---

## Key Design Principles

- **One agent, one responsibility** — no agent performs work outside its declared role
- **Registry is the source of truth** — all agents query the central registry and never bypass it
- **Extensibility by design** — adding repositories or toggles requires no agent code changes
- **Dry run before destructive operations** — decomposition always runs in dry-run mode first; actual source changes require explicit user confirmation
- **Read is free, write is exclusive** — any agent may read any file; only the designated owner agent writes to each file
- **Slash commands as first-class citizens** — every workflow has both a plain-English command and a `/slash-command` alias

---

*For the authoritative session state, start a session and type `what is the current analysis status`.*

---
<!-- COPYRIGHT-FOOTER -->
© 2026 Mastercard. All rights reserved.
This file is part of the AI-Driven Toggle Management System.
Maintained by the multi-agent AI framework.
