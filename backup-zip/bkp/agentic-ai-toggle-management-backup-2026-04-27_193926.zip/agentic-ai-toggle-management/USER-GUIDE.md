---
# AI-Driven Toggle Management — User Quick-Start Guide

> **Project:** AI-Driven Toggle Management System
> **Platform:** Mastercard Payment Gateway Services (MPGS)
> **Date:** April 12, 2026
> **Status:** Active

---

## Prerequisites

| # | Requirement |
|---|---|
| 1 | JetBrains AI Assistant is active in the workspace |
| 2 | All MPGS source repositories are cloned and locally accessible |
| 3 | Workspace `data/` directory is writable by the agent session |

---

## First-Time Setup

```
rebuild registry
analyze all remaining toggles
```

That's it — the orchestrator handles everything else automatically.

---

## Shortcut Command Reference

### ⚡ Slash Commands (fastest way to interact)

| Slash Command | What it does |
|---|---|
| `/toggle-rebuild-registry` | Rebuild the toggle registry across all repos |
| `/toggle-analyse <toggle-name>` | Discover usages and analyse a specific toggle across all repos |
| `/toggle-analyse-all` | Discover usages for all remaining unprocessed toggles |
| `/toggle-fetch-confluence <toggle-name>` | Fetch Confluence page enquiry for a specific toggle |
| `/toggle-fetch-confluence-all` | Fetch Confluence data for all toggles not yet enriched |
| `/toggle-generate-report` | Generate structured analysis reports |
| `/toggle-generate-polished-report` | Generate a polished Markdown summary |
| `/toggle-check-missing` | Find toggles not yet analysed |
| `/toggle-onboard-repo <name>` | Register a new repository |
| `/toggle-check-changes` | Detect toggle additions/removals since last run |
| `/toggle-cleanup` | Fix encoding issues and remove duplicates |
| `/toggle-backfill` | Fill analysis gaps for unprocessed toggles |
| `/toggle-plan-decomp <repo>` | ⚡ Read-only decomposition plan for a repo |
| `/toggle-decompose <repo>` | ⚡ Refactor source to remove toggles (dry run first) |
| `/toggle-review <toggle-name>` | ⚡ Review output quality for a completed toggle analysis |
| `/toggle-help` | Show all available commands |

> ⚡ On-request only — never auto-invoked by the system.

---

## Common Task Shortcuts

### 1. Build the toggle registry (always do this first)
```
rebuild registry
```
or
```
/toggle-rebuild-registry
```

### 2. Analyse a specific toggle
```
analyze toggle "Apply New Order ID Reuse Rule"
analyze toggle "Enable Unusual Transaction Protection"
analyze toggle "Bypass CSC checks for Scheme Token Transactions"
analyze toggle "Random Terminal Allocation"
analyze toggle "Enable CIT MIT indicators for Mastercard"
analyze toggle "Enable issuer country code in transaction response"
analyze toggle "Route Risk Operations via the R-SPI Service and enable Merchant Risk"
```
These toggle names come directly from `data/enquiry/feature-toggle-confluence-page-enquiry.csv`.

Or analyse all remaining unprocessed toggles at once:
```
analyze all remaining toggles
```

### 3. Fetch Confluence page enquiry for toggles
Fetch documentation for all pending toggles:
```
fetch confluence data for all pending toggles
```
Or for a specific toggle:
```
fetch confluence data for "Apply New Order ID Reuse Rule"
fetch confluence data for "System Toggle: Use 8_4 Masked PAN for Scheme Token Transaction Response"
fetch confluence data for "Enable Unusual Transaction Protection"
fetch confluence data for "System Toggle: CPE Load Balancer Uses Ping"
```

### 4. Check where you left off
```
what is the current analysis status
```

### 5. Resume from a specific toggle
```
resume from toggle "Enable Lookup up to 11 digit bin for Card Identification"
resume from toggle "Route Risk Operations via the R-SPI Service and enable Merchant Risk"
```

### 6. Check for missing toggles not yet analysed
```
check for missing toggles
```
or
```
/toggle-check-missing
```

### 7. Generate reports
```
generate report
generate polished report
```

### 8. Add new toggles and run analysis
```
check for missing toggles
analyze all remaining toggles
```

### Full Standard Workflow (in order)
```
Step 1 — Build registry:        rebuild registry
Step 2 — Discover usages:       analyze all remaining toggles
Step 3 — Confluence enquiry:    fetch confluence data for all pending toggles
Step 4 — Generate report:       generate report
Step 5 — Polished summary:      generate polished report
```

---

## Onboarding a New Repository

Use this when you want to include a new Java repository in toggle analysis.

### Step 1 — Register the new repository
```
onboard repo BatchSettlementService
```
or
```
/toggle-onboard-repo BatchSettlementService
```

### Step 2 — Rebuild the registry to include the new repo
```
rebuild registry
```

### Step 3 — Run analysis (the new repo is now included automatically)
```
analyze all remaining toggles
```

> The system scans the new repository, updates the combined registry, and includes it in all future analysis runs without any manual config changes.

---

## Troubleshooting Shortcuts

| Problem | Quick Fix |
|---|---|
| Toggle not found | `/toggle-rebuild-registry` then retry the toggle |
| Garbled characters in output | `/toggle-cleanup` |
| Registry missing or empty | `/toggle-rebuild-registry` |
| Confluence returns no results | Re-run `/toggle-fetch-confluence <toggle-name>` |
| Duplicate rows in CSV output | `/toggle-cleanup` |
| New repo missing from analysis | `/toggle-onboard-repo <name>` then `/toggle-rebuild-registry` |

---

## Agent Cheat Sheet

| Agent | What it does | When it runs |
|---|---|---|
| toggle-orchestrator | Routes your commands | Always — entry point |
| toggle-analysis-engine | Searches Java source & writes ON/OFF impact | Workflows A, B, E, G, I |
| toggle-report-writer | Produces structured and polished reports | Workflows D, D-P |
| toggle-confluence-enquiry | Fetches Confluence page metadata | Workflow C |
| toggle-advisor ⚡ | Decomp planning, dry-run refactoring, QA | On-request only |
| toggle-workspace-manager | Onboarding, cleanup, session state | Auto + on-request |

---

## Output Files at a Glance

| File | What's in it |
|---|---|
| `data/registry/toggle-registry-lookup.csv` | Master toggle registry (all repos) |
| `data/analysis/toggle-codebase-usage-analysis.csv` | ON/OFF impact analysis results |
| `data/enquiry/feature-toggle-confluence-page-enquiry-results.csv` | Confluence metadata |
| `reports/toggle-polished-usage-report-{date}.md` | Human-readable polished report |
| `reports/toggle-status-dashboard-{date}.txt` | Status dashboard |
| `logs/changelog.md` | Audit log of all file changes |

---

<!-- COPYRIGHT-FOOTER -->
© 2026 Mastercard. All rights reserved.
This file is part of the AI-Driven Toggle Management System.
Maintained by the multi-agent AI framework.

