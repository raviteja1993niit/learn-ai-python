﻿---
applyTo: "on-demand"
category: "search-rules"
usedBy: ["toggle-analysis-engine"]
description: "Cardinal Error checks and search pattern rules for locating toggles in Java code"
---

# Toggle Search Rules — Cardinal Error Checks

## Dual Search Pattern (MANDATORY for every toggle)
Search by BOTH:
1. Display string exactly as-is from the input CSV
2. All `constant_name` values from `toggle-registry-lookup.csv`

**Scope**: `src/main/java/**/*.java` — NEVER `**/*.java`  
**Exclude**: `/test/`, `*Test.java`, `*Tests.java`, `*Spec.java`, `*IT.java`, `*ITest.java`

## Cardinal Error 6 — Hybrid Class Detection (MANDATORY)
After finding a DECLARATION file, ALWAYS scan the **same file** for `isToggleOn|isOn` calls.
- IF found → HYBRID class → keep as analysis target, use isToggleOn line as actual usage
- IF not found → pure constants class → safe to skip

Known hybrid classes:
- `CardTypeDetailsDecorator.java` — declaration line 70, usage line 124
- `SanctionHelper.java` — declaration line 327, usage lines 1568, 1708, 1729, 1755
- `TransactionDataCommonService.java` — declaration line 157, usage lines 550, 1540

## Cardinal Error 9 — ToggleHelper Indirection
If no direct `isToggleOn` callers found:
1. Search for a `ToggleHelper` wrapper method referencing the constant
2. Note the wrapper method name (e.g., `isToggleOnFoo`)
3. `grep_search('isToggleOnFoo')` across all repos → find actual caller classes

## Cardinal Error 10 — Fully-Qualified Usage
Search for `ClassName.CONSTANT_NAME` in addition to bare `CONSTANT_NAME`.  
Example: `isToggleOn(S2IAcquirerToggleConstants.TOGGLE_VISA_MANDATE_COF)`  
The bare constant name WILL NOT match — must include the class prefix.

## Cardinal Error 11 — Wildcard Import Expansion
Search for `import static pkg.ClassName.*` pattern.  
Wildcard imports expose ALL constants from that class without named imports — invisible to named-import-only searches.

## Cardinal Error 12 — isOn() Pattern
Search `Toggles.isOn(CONSTANT_NAME)` in addition to `isToggleOn()`.  
Some classes (e.g., `CassandraThreeDsTogglesUtils`) use `Toggles.isOn()`.

## Cardinal Error 21 — Inline String Literal
Search `Toggles.isOn("display string")` — used as inline string literal, bypassing the constant registry.

## Cross-Repo Search (MANDATORY)
After finding in the registry-indicated repo, ALWAYS scan all other configured repos too.  
A toggle used in CPE may also have an Orchestrator implementation — produce separate rows.

## Structured Output Contract
Return one object per hit:
```json
{
  "toggle_name": "...",
  "className":   "...",
  "filePath":    "...",
  "fullPath":    "...",
  "lineNumber":  0,
  "blockStart":  0,
  "blockEnd":    0,
  "repo":        "CPE"
}
```

## NOT_FOUND Validation (20-Step Checklist)
Before returning NOT_FOUND, complete ALL 20 steps.  
Full checklist: `.github/agents/docs/07-lessons-learned.md`---
<!-- COPYRIGHT-FOOTER -->
© 2026 Mastercard. All rights reserved.
This file is part of the Toggle Management System.
Maintained by the multi-agent AI framework.
