---
applyTo: "all"
category: "ux"
usedBy: ["toggle-orchestrator", "toggle-workspace-manager"]
description: >
  Minimal UX rules. Progress reporting and help reference only.
---

# UX Rules — Toggle Management System

## 1. Progress Reporting

After every completed batch of 5 toggles, emit a Markdown table:

| Field | Value |
|---|---|
| **Batch** | `<N>` / `<total>` |
| **Status** | `PASSED` / `PARTIAL` / `FAILED` |
| **Toggles** | `<t1>`, `<t2>`, `<t3>`, `<t4>`, `<t5>` |
| **Progress** | `<processed>` / `<total>` |

After all batches, emit a Markdown summary table:

| Metric | Count |
|---|---|
| **Total** | `<N>` |
| **Passed** | `<N>` |
| **Partial** | `<N>` |
| **Failed** | `<N>` |

For errors: state the agent, toggle name, reason, and action taken — plain Markdown text, no ASCII boxes.

## 2. Help Command

When user types `"help"` or `"show hints"`, render a Markdown table:

**Toggle Management System — Commands**

| Category | Command | Description |
|---|---|---|
| **Analysis** | `analyze toggle <name>` | Single toggle ON/OFF analysis |
| | `analyze toggles batch <N>` | Batch ON/OFF impact analysis |
| | `fetch confluence data for batch <N>` | Fetch Confluence page metadata |
| | `rebuild registry` | Re-scan all repos for toggle constants |
| | `check for missing toggles` | Gap detection across registry + CSV |
| | `backfill missing analysis` | Fill gaps in analysis CSV |
| | `check for toggle changes` | Detect new / removed / renamed toggles |
| **Reports** | `generate report` | Structured text report |
| | `generate polished report` | Markdown report (coverage check first) |
| | `show toggle profile for <name>` | Inline toggle details |
| **Maintenance** | `onboard repo at <path>` | Add a new Java repository |
| | `clean up files` | Deduplicate, archive, validate CSVs |
| **Decomposition** | `plan toggle decomposition for <repo>` | Read-only removal plan |
| | `decompose toggles in <repo> dry run` | Preview changes (no writes) |
| | `confirm actual run for <repo>` | Apply (requires explicit confirm) |

## 3. Process Flow Hints (prepended to each workflow start)

Render as a single plain line:

> **`<Workflow letter>`** — `<one-line description>` — Steps: `<brief ordered list>`

Example:

> **A** — Analyze toggle — registry lookup → source search → ON/OFF impact → CSV write

---

<!-- COPYRIGHT-FOOTER -->
© 2026 Mastercard. All rights reserved.
This file is part of the Toggle Management System.
Maintained by the multi-agent AI framework.

