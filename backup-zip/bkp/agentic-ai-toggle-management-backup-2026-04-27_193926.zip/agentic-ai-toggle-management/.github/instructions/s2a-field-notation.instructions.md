﻿---
applyTo: "on-demand"
category: "s2a-analysis"
usedBy: ["toggle-analysis-engine"]
description: "S2A trigger detection, toggle type classification, and field notation rules"
---

# S2A Field Notation & Analysis Rules

## ⚠️ MANDATORY: S2I vs S2A Are Completely Separate Flows

> `S2IAcquirerV1` and `S2IAcquirerV2` are **S2I-flow classes** (Streamlined to Issuer, ISO 8583).
> They have **zero functional impact on the S2A flow**.
> They appear in toggle registry lookups only because they declare shared toggle constants.
> **They are NOT S2A trigger classes and must never produce S2A impact output.**

| Flow | Classes | Message Format | Scope |
|---|---|---|---|
| **S2I** | `S2IAcquirerV1`, `S2IAcquirerV2`, `IsoDataField*Populator` | ISO 8583 | Issuer-bound — constant declaration source only for toggle lookup |
| **S2A** | `JsonMegaMessageRequestBuilder`, `TspiRequestMessageBuilder`, `S2AProcessor`, etc. | TSPI JSON | Acquirer-bound — true S2A functional impact |

---

## S2A Trigger Detection

Trigger S2A analysis **only** when `className` or `filePath` matches a **true S2A class**:

| Pattern | Flow | Action |
|---|---|---|
| `*JsonMegaMessageRequestBuilder*`, `*JsonMegaMessageMap*` | **S2A** | ✅ Trigger S2A analysis — use TSPI JSON notation |
| `*TspiRequestMessageBuilder*` | **S2A** | ✅ Trigger S2A analysis — use TSPI RoutingHeader notation |
| `*/acquirer/messagemapimpl/*` | **S2A** | ✅ Trigger S2A analysis |
| `*S2AProcessor*`, `*StreamlinedAcquirer*` | **S2A** | ✅ Trigger S2A analysis |
| `*S2IAcquirerV1*`, `*S2IAcquirerV2*` | **S2I** | ❌ Do NOT trigger S2A analysis — S2I declaration class, lookup only |
| `*IsoDataField*Populator*` | **S2I** | ❌ Do NOT include in S2A output — S2I ISO 8583 field populator |

---

## S2A Toggle Type Classification
| Type | Description |
|---|---|
| Flow Toggle | ON routes to S2A/TSPI path; OFF uses legacy path |
| Feature Toggle | ON enables a specific feature within S2A; OFF disables (both still use S2A) |
| Routing Toggle | ON changes routing strategy within S2A; OFF uses default routing |
| Message Format Toggle | ON adds/modifies specific TSPI JSON fields in the MegaMessage |
| API Validation Toggle | ON applies/relaxes validation on TSPI API request fields before acquirer message built |

---

## S2I ISO 8583 Field Notation (S2I output only — never include in S2A rows)

> ⚠️ ISO DE field notation applies to **S2I analysis only**.
> **Never use ISO DE notation in an S2A impact row.**

**Use for**: `S2IAcquirerV1`, `S2IAcquirerV2`, `IsoDataField*Populator`  
**Format**: `ISO DE<n> [SE<n>] [SF<n>]`

| DE | Description | Common Toggle Usage |
|---|---|---|
| DE48 | Additional Data — Private Use | SE36 SF05=purposeOfPayment; SE03 SF05=purpose sub; SE86=COF; SE91=CIT TID |
| DE54 | Additional Amounts | Foreign Exchange Fee for Visa AFT; cashback |
| DE61 SF<n> | Point of Service Data | SF3=terminal type; SF10=cardholder-activated; SF11=input capability |
| DE108 | Money Transfer Information | SF01=Transaction Reference; SE03 SF05=purpose code |
| DE120 | Record Data | SE96=unique transaction identifier |
| DE123 | Address Verification / Tag Data | OTD tag, CTI tag, statement descriptor, clearing tag |

---

## TSPI/MEGA JSON Field Notation (S2A output — TSPI classes only)

**Use for**: `JsonMegaMessageRequestBuilder`, `TspiRequestMessageBuilder`  
**Format**: `TSPI: <ContextObject>.<FieldName>`

| Context Object | Toggle-Gated Fields |
|---|---|
| `Transaction` | Amount, Currency, CardNumber, TransactionType, CredentialOnFile |
| `Transaction.AccountFunding` | AccountFundingPurpose, AccountFundingPaymentPurpose, AccountFundingForeignExchangeFee |
| `Transaction.AccountFunding.Recipient` | PaymentRecipientFirstName, PaymentRecipientLastName, PaymentRecipientMiddleName |
| `Transaction.AccountFunding.Recipient.Address` | PaymentRecipientStreet, PaymentRecipientStreet2, PaymentRecipientCity |
| `Transaction.CustomerIdentification` | CustomerIdentificationType, CustomerIdentificationCountry, CustomerIdentificationValue |
| `Acquirer` | AcquirerId, AcquirerBin, NetworkTransactionId, FinancialNetworkTransactionId |
| `Merchant` | MerchantId, MerchantCategoryCode, SubMerchant.Id, AggregatorName |
| `RoutingHeader` | MessageType, AcquirerType, RoutingStrategy |

---

## Toggle Constant Declared in S2IAcquirer* AND Used in a True S2A Class

> This is NOT a "dual-format" scenario — it is a declaration + S2A usage scenario.

When a toggle constant is declared in `S2IAcquirerV1/V2` but also used in a true S2A class:

- `S2IAcquirerV1/V2` hit → **S2I declaration** — produces **no S2A output**; ignore for S2A impact
- True S2A class hit → **drives the entire S2A impact output**
- Result: **one S2A CSV row** with TSPI field notation only — no ISO DE fields

---

## Full Field Reference
Complete ISO DE sub-field tables: `.github/agents/docs/05-s2a-field-notation.md`---
<!-- COPYRIGHT-FOOTER -->
© 2026 Mastercard. All rights reserved.
This file is part of the Toggle Management System.
Maintained by the multi-agent AI framework.
