﻿---
applyTo: "all"
category: "context-management"
usedBy: ["toggle-workspace-manager"]
description: >
  Context window summarisation rule. Triggers and compact format in optimizer-config.yml.
  Implementation in toggle-workspace-manager (SA-5) context summarisation section.
---


# Context Window Monitor — Reference

> Fully implemented by `toggle-workspace-manager` (SA-5).
> Triggers and compact summary format are in `knowledge/optimizer-config.yml → context_summarisation`.

## Summarisation is silent and automatic
- Fires on: >12 files read, >25 exchanges, every 3rd batch, `"summarize context"`, or before `"run optimizer"`
- Compacts everything to a ≤200-token summary (see `optimizer-config.yml → compact_summary_format`)
- Appends `CONTEXT_SUMMARISED` milestone to checkpoint + increments `context_summarisations`
- Logs to `logs/context-summaries.txt`
- Drops full history from context — continues from compact summary only

## What the compact summary preserves
- Completed milestone event keys
- Finding counts (OE/SEC/TOK/SUG)
- Filenames already analysed
- Pending next_actions
- Current batch number and status

Everything else (file contents, reasoning chains) is dropped and re-read if needed via `read_file`.

---

<!-- COPYRIGHT-FOOTER -->
© 2026 Mastercard. All rights reserved.
This file is part of the Toggle Management System.
Maintained by the multi-agent AI framework.
