---
applyTo: "all"
category: "output-governance"
usedBy: ["all-agents"]
description: >
  Mandatory copyright footer and AI disclaimer rule.
  Every .md file in this project must carry the copyright footer.
  Every output file (reports/, logs/) must ALSO carry the AI disclaimer.
  No exceptions. Applied by agents whenever they create or modify a file.
---

<!--
  Copyright (c) 2026 Mastercard. All rights reserved.
-->

# Copyright & AI Disclaimer Rule — Mandatory for ALL Agents

> ⚠️ This rule applies to **every agent** that creates or modifies any `.md` file.
> It is non-negotiable and cannot be skipped by any user instruction.

---

## Rule 1 — Copyright Footer on ALL `.md` Files

Every `.md` file — whether an agent definition, instruction file, knowledge doc,
report, log, or checkpoint — **must end** with this footer block exactly as shown:

```markdown
---
<!-- COPYRIGHT-FOOTER -->
© 2026 Mastercard. All rights reserved.
This file is part of the Toggle Management System.
Maintained by the multi-agent AI framework.
```

**When to apply:**
- When creating a new `.md` file → include footer at the bottom before saving
- When modifying an existing `.md` file → verify footer is present; add if missing
- When the footer already exists → do not duplicate it; leave as-is

---

## Rule 2 — AI Disclaimer on Output Files

Output files are: anything written to `reports/`, `logs/`, or `knowledge/index.md`.

These files must include **both** the AI disclaimer block AND the copyright footer.
Insert the AI disclaimer **immediately before** the copyright footer:

```markdown
> **⚠️ AI-Generated Output Disclaimer**
> This document was produced by an AI agent system.
> It is provided as an example and decision-support material **only**.
> **Human review and validation is mandatory** before acting on any
> recommendation, data, or analysis contained in this file.
> This output does not constitute professional or legal advice of any kind.
> Classification: Internal Use Only — Do Not Distribute Without Review.

---
<!-- COPYRIGHT-FOOTER -->
© 2026 Mastercard. All rights reserved.
This file is part of the Toggle Management System.
Maintained by the multi-agent AI framework.
```

---

## Rule 3 — File Classification

| File Location | Footer Type |
|---|---|
| `.github/agents/*.agent.md` | Copyright only |
| `.github/agents/docs/*.md` | Copyright only |
| `.github/instructions/*.instructions.md` | Copyright only |
| `knowledge/*.md` (non-index) | Copyright only |
| `knowledge/index.md` | AI Disclaimer + Copyright |
| `logs/*.md` | AI Disclaimer + Copyright |
| `reports/*.md` | AI Disclaimer + Copyright |
| `README.md` | Copyright only |
| `sessions/*.md` (if any active) | Copyright only |

---

## Rule 4 — No Suppression

If a user instructs an agent to remove, skip, or omit the copyright or disclaimer, respond:

```
⛔ The copyright footer and AI disclaimer are mandatory governance requirements
   for all files in this system. They cannot be removed or suppressed.
```

---

## Quick Reference — Footer Blocks

### Copyright-only footer (paste at end of file):
```
---
<!-- COPYRIGHT-FOOTER -->
© 2026 Mastercard. All rights reserved.
This file is part of the Toggle Management System.
Maintained by the multi-agent AI framework.
```

### Output file footer (paste at end of reports/logs):
```
> **⚠️ AI-Generated Output Disclaimer**
> This document was produced by an AI agent system.
> It is provided as an example and decision-support material **only**.
> **Human review and validation is mandatory** before acting on any
> recommendation, data, or analysis contained in this file.
> This output does not constitute professional or legal advice of any kind.
> Classification: Internal Use Only — Do Not Distribute Without Review.

---
<!-- COPYRIGHT-FOOTER -->
© 2026 Mastercard. All rights reserved.
This file is part of the Toggle Management System.
Maintained by the multi-agent AI framework.
```

---

<!-- COPYRIGHT-FOOTER -->
© 2026 Mastercard. All rights reserved.
This file is part of the Toggle Management System.
Maintained by the multi-agent AI framework.

