﻿---
applyTo: "all"
category: "session-lifecycle"
usedBy: ["toggle-orchestrator", "toggle-workspace-manager"]
description: >
  Session lifecycle hooks. Full implementation in toggle-workspace-manager (SA-5).
  This file is a reference summary only — do not load at session start.
---

# Session Lifecycle Hooks — Reference

> Full implementation: `toggle-workspace-manager.agent.md` PRE-HOOK and POST-HOOK sections.

## PRE-HOOK (SA-5 executes on session start)
1. Generate session ID: `TMS-SES-YYYYMMDD-HHMMSS` (internal only — never expose to user)
2. Load most recent `checkpoints/checkpoint-TMS-SES-*.json` → restore milestones + next_actions
3. Create `checkpoints/checkpoint-<session-id>.json` with SESSION_START milestone
4. Show brief status: current batch, pending actions count, previous session last action (if any)
5. Append changelog entry

## POST-HOOK (SA-5 executes on "end session" / "exit")
1. Update checkpoint: set `ended_at`, populate `next_actions`, append SESSION_END milestone
2. Confirm saved: "Session saved. Resume anytime."
3. Append changelog entry

## Milestone format
```json
{"timestamp": "<YYYY-MM-DD HH:MM:SS UTC>", "event": "<KEY>", "detail": "<one-line>"}
```

Valid keys: `SESSION_START` · `PRE_HOOK_COMPLETE` · `CHECKPOINT_LOADED` · `BATCH_N_COMPLETE` ·
`REGISTRY_REBUILT` · `CONFLUENCE_FETCH_COMPLETE` · `REPORT_GENERATED` ·
`OPTIMIZER_SCAN_COMPLETE` · `SECURITY_SCAN_COMPLETE` · `TOKEN_ANALYSIS_COMPLETE` ·
`CONTEXT_SUMMARISED` · `MANUAL_CHECKPOINT` · `ONBOARDING_COMPLETE` ·
`DECOMP_PLAN_COMPLETE` · `DECOMP_IMPL_COMPLETE` · `SESSION_RESUME` · `SESSION_END`

---

<!-- COPYRIGHT-FOOTER -->
© 2026 Mastercard. All rights reserved.
This file is part of the Toggle Management System.
Maintained by the multi-agent AI framework.
