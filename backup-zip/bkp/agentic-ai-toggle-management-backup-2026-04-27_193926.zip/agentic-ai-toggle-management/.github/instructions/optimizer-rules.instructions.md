﻿---
applyTo: "all"
category: "optimization"
usedBy: ["toggle-orchestrator", "universal-optimizer"]
description: >
  Over-engineering detector, LLM token analyser, security scanner,
  and functionality suggestion engine. Pure instruction-based — no scripts.
  The agent executes every check using read_file, grep_search, list_dir only.
---


# Optimizer Rules — Over-Engineering · Token · Security · Suggestions

> ⚠️ All findings are AI-generated examples. Human review mandatory before acting.
> These rules require **zero scripts** — the LLM executes every check directly.

---

## ═══ SECTION A — Over-Engineering Detector ═══

Run when: `"check over-engineering"` or as part of `"run optimizer"`.

### A1 — What to Scan

Use `list_dir` (2 levels) + `read_file` on each `.agent.md`, `.yml`, `.json`, `.md`, `.py`, `.ps1`.

### A2 — Patterns to Detect

| ID | Pattern | Severity |
|---|---|---|
| OE-01 | Same content block in 2+ files (>30% overlap) | 🔴 High |
| OE-02 | File >500 lines loaded at session start | 🔴 High |
| OE-03 | Two agents share >50% of described responsibilities | 🔴 High |
| OE-04 | Deprecated/WARNING entries still in active config sections | 🟠 Medium |
| OE-05 | File paths in config referencing non-existent locations | 🟠 Medium |
| OE-06 | Registry/index file >300 lines for <20 entities | 🟠 Medium |
| OE-07 | Same key-value pair duplicated across multiple config files | 🟡 Low |
| OE-08 | Tool/script registered with status WARNING or NOT_RECOMMENDED still in active list | 🟡 Low |
| OE-09 | Documentation re-explaining what config already expresses | 🟡 Low |
| OE-10 | Agent that has only 1 task and could be inlined into its caller | 🟡 Low |

### A3 — Finding Format

```
[OE-<N>] 🔴/🟠/🟡 <Title>
  File    : <path>
  Problem : <1-2 sentences>
  Impact  : <tokens wasted / complexity added>
  Fix     : <concrete action>
  Risk    : NONE | LOW | MEDIUM
```

### A4 — Score

After all findings:
```
OVER-ENGINEERING SCORE: <N>/100
  🔴 High   : <N>  × 15 pts
  🟠 Medium : <N>  × 8  pts
  🟡 Low    : <N>  × 3  pts
  Grade: REFACTOR URGENTLY | MODERATE CLEANUP | HEALTHY
```

---

## ═══ SECTION B — LLM Token Optimisation Analyser ═══

Run when: `"token analysis"` or as part of `"run optimizer"`.

### B1 — Estimate Token Cost

For every file listed in the orchestrator's Initial Load (Steps 1–8):
1. Read file with `read_file`
2. Estimate tokens: `lines × 6.5` (avg tokens/line for prose/YAML)
3. Classify content: **dynamic state** (changes per session) vs **static docs** (never changes)
4. Waste ratio = `(total - essential) / total × 100`

### B2 — Token Cost Table

```
TOKEN COST — Session Start Overhead
═══════════════════════════════════════════════════════════════════
File                               Lines   Tokens   Waste%   Action
───────────────────────────────────────────────────────────────────
<filename>                         <N>     <N>      <N>%     <TRIM|SPLIT|ARCHIVE|OK>
───────────────────────────────────────────────────────────────────
TOTAL OVERHEAD :                           <N> tokens
SAVEABLE       :                           <N> tokens  (<N>% reduction)
═══════════════════════════════════════════════════════════════════
```

### B3 — Finding Format (for files with waste > 40%)

```
[TOK-<N>] 💰 Token Waste — <filename>
  Current  : ~<N> tokens/session
  Saveable : ~<N> tokens (<N>%)
  Strategy : SPLIT_STATIC_FROM_DYNAMIC | REPLACE_WITH_COMPACT_YML |
              MOVE_TO_ARCHIVE | TRIM_HISTORICAL_CONTENT
  How      : <1-2 sentence instruction>
```

---

## ═══ SECTION C — Security Scanner ═══

Run when: `"security scan"` or as part of `"run optimizer"`.

### C1 — What to Scan

Use `grep_search` across ALL text files (all depths). Search for:

| ID | Pattern to grep | Severity |
|---|---|---|
| SEC-01 | `password\s*[:=]\s*["'][^$]` — hardcoded password not using env var | 🔴 Critical |
| SEC-02 | `secret\s*[:=]\s*["'][^$]` — hardcoded secret literal | 🔴 Critical |
| SEC-03 | `key\s*[:=]\s*["'][A-Za-z0-9+/]{20,}` — hardcoded key/token | 🔴 Critical |
| SEC-04 | `print.*key\|print.*secret\|print.*password` — credentials printed to stdout | 🔴 Critical |
| SEC-05 | `C:/Users/[a-zA-Z]+/` — absolute local user path hardcoded | 🟠 Medium |
| SEC-06 | `BEGIN.*PRIVATE KEY` — plaintext private key in any file | 🔴 Critical |
| SEC-07 | `eval(\|exec(` — dynamic code execution on potentially untrusted input | 🟠 Medium |
| SEC-08 | `TODO.*secure\|FIXME.*auth\|HACK.*cred` — explicit security debt markers | 🟡 Low |
| SEC-09 | `.env` / `secrets.*` / `credentials.*` files not in `.gitignore` | 🟠 Medium |
| SEC-10 | `archive_password` with a literal value (not env var reference) | 🔴 Critical |

### C2 — Finding Format

> ⚠️ NEVER print the actual secret value — only file, line, and pattern type.

```
[SEC-<N>] 🔴/🟠/🟡 <Title>
  File    : <path>
  Line    : <N>
  Pattern : <type — value REDACTED>
  Risk    : <what exposure enables>
  Fix     : Move to environment variable or secret manager
```

### C3 — Posture Rating

```
SECURITY POSTURE: CRITICAL | AT RISK | MODERATE | SECURE
  🔴 Critical : <N>
  🟠 Medium   : <N>
  🟡 Low      : <N>
```

---

## ═══ SECTION D — Functionality Suggestions ═══

Run when: `"check functionality gaps"` or as part of `"run optimizer"`.

After scanning project structure, suggest improvements in these categories:

### D1 — Missing Safety Nets
- No retry logic in workflow delegation chains
- No rollback mechanism for destructive file operations
- No dry-run mode before bulk CSV writes
- No validation of CSV schema before append

### D2 — Missing Observability
- No structured timing for long-running workflows
- No diff output shown before/after file changes
- No health-check command to verify all data files are consistent
- No count of rows written vs rows expected after each batch

### D3 — Missing UX
- No estimated time remaining for multi-batch operations
- No "what changed this session" summary before `end session`
- No confirmation prompt before any destructive action
- No inline toggle lookup without requiring a report file

### D4 — Missing Resilience
- No circuit breaker for a sub-agent that fails >2 times consecutively
- No timeout handling for Confluence calls
- No fallback when primary grep_search returns zero results

### D5 — Architecture Gaps
- Sequential agent chains that could be parallelised
- Config values scattered vs single source of truth in `config.yml`
- Agent with >5 responsibilities that should be split

### D6 — Finding Format

```
[SUG-<N>] 💡 <Category> — <Title>
  Gap      : <what is missing>
  Value    : <reliability | UX | performance>
  Effort   : LOW (<1h) | MEDIUM (half day) | HIGH (>1 day)
  Approach : <2-3 sentence implementation sketch>
  Priority : QUICK WIN | RECOMMENDED | NICE TO HAVE
```

---

<!-- COPYRIGHT-FOOTER -->
© 2026 Mastercard. All rights reserved.
This file is part of the Toggle Management System.
Maintained by the multi-agent AI framework.

