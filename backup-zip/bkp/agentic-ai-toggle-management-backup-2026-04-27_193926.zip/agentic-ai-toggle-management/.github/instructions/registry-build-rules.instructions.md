﻿---
applyTo: "on-demand"
category: "registry"
usedBy: ["toggle-analysis-engine"]
description: "Rules for building, validating, splitting, and serving toggle registry lookups"
---

# Toggle Registry Build & Validation Rules

## Registry Schema (7 columns — ALL mandatory)
`toggle_name`, `constant_name`, `class_name`, `file_path`, `line_number`, `usage_type`, `repository`

## Validation Rules (apply after every build)
- No row where `toggle_name = "-"` or `toggle_name = "SQL"` or `toggle_name = "TODO"`
- All 7 columns populated in every row
- `usage_type` must be `DECLARATION` or `IMPLEMENTATION` only
- No duplicate rows (same toggle_name + class_name + line_number + repo)

## Per-Repo Output Files (split from combined after each build)
| File | Repo | Expected ~Row Count |
|---|---|---|
| `toggle-registry-cpe.csv` | CPE | ~540 |
| `toggle-registry-orchestrator.csv` | Orchestrator | ~180 |
| `toggle-registry-business-service.csv` | BusinessService | ~80 |
| `toggle-registry-console.csv` | Console | ~50 |
| `toggle-registry-msoui.csv` | MSOUI | ~80 |
| `toggle-registry-direct-api.csv` | DirectAPI | ~100 |
| `toggle-registry-lookup.csv` | ALL (combined) | ~1030+ |

## Build Summary Report (emit after every build)
```
=== Registry Build Summary — {date} ===
Unique toggle names  : N
Total rows           : N
IMPLEMENTATION rows  : N
DECLARATION-only     : N
Per-repo: CPE=N  Orch=N  BS=N  Console=N  MSOUI=N  DirectAPI=N
Suspicious rows      : N  (short names, SQL patterns, empty toggle_name)
Per-repo files written: 6 of 6
```

## Tool Invocation (plain Python — run directly)

> ℹ️ All tool scripts are now plain `.py` / `.ps1` files. The encrypted `.enc` files have been removed.
> Invoke TOOL-01 directly with Python — no sec_launcher needed.

```bash
# Normal mode (fast — DirectAPI uses targeted file list)
python tools/active/build-toggle-registry-lookup.min.py --config-file "knowledge/config.yml"

# Dry run preview (validate without writing output files)
python tools/active/build-toggle-registry-lookup.min.py --config-file "knowledge/config.yml" --dry-run

# Force full DirectAPI rescan (rediscovers toggle-bearing files, ~5 min)
python tools/active/build-toggle-registry-lookup.min.py --config-file "knowledge/config.yml" --refresh-directapi
```

> ℹ️ Tool produces stdout progress output (Pass 1, Pass 2, per-repo row counts, summary).
> Verified working via `run_in_terminal`. Results are also written to output files — always confirm by reading the output files after the run.

## Missing-Toggle Cross-Reference
Compare `toggle-registry-lookup.csv` toggle names against `toggle-codebase-usage-analysis.csv`:
- In registry, NOT in analysis → candidates for SA-2a queue
- In analysis as NOT_FOUND → candidates for re-check via SA-2a
- In confluence results, NOT in registry → no codebase trace found

## Inline String Literal Detection (Cardinal Error 21)
After standard passes, scan all `.java` files for:
`(?:isToggleOn|Toggles\.isOn)\s*\(\s*"([^"]{5,})"`  
Emit matched inline strings as IMPLEMENTATION rows with `toggle_name = <matched string>`.

## Config Reference
All repo paths from `config.yml` → `repositories[*].java_root`  
Output paths from `config.yml` → `data.registry_combined` and `data.registry_per_repo_dir`---
<!-- COPYRIGHT-FOOTER -->
© 2026 Mastercard. All rights reserved.
This file is part of the Toggle Management System.
Maintained by the multi-agent AI framework.
