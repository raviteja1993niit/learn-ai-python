﻿---
applyTo: "initial"
category: "standards"
usedBy: ["all"]
description: "Kebab-case file naming standard — loaded at session start, enforced by SA-5 (toggle-workspace-manager)"
---

# File Naming Standards — Kebab-Case Convention

## Rule
ALL files use **lowercase words separated by hyphens (`-`)**.  
No underscores, no camelCase, no PascalCase, no spaces.

## Patterns by File Type
| File Type | Pattern | Example |
|---|---|---|
| Data CSV | `<subject>-<descriptor>.csv` | `toggle-registry-lookup.csv` |
| Per-repo registry | `toggle-registry-<repo>.csv` | `toggle-registry-cpe.csv`, `toggle-registry-direct-api.csv` |
| Analysis output | `toggle-codebase-usage-analysis.csv` | fixed name |
| CSV backup | `<original-name>-bkp-<YYYY-MM-DD>.csv` | `toggle-codebase-usage-analysis-bkp-2026-04-11.csv` |
| Batch checkpoint | `toggle-batch-<N>-checkpoint.txt` | `toggle-batch-3-checkpoint.txt` |
| Change report | `toggle-change-report-<YYYY-MM-DD>.txt` | `toggle-change-report-2026-04-11.txt` |
| Onboarding report | `onboarding-<repo>-<YYYY-MM-DD>.txt` | `onboarding-token-service-2026-04-11.txt` |
| S2A report | `s2a-report-<repo>-<YYYY-MM-DD>.txt` | `s2a-report-cpe-2026-04-11.txt` |
| Per-repo summary | `per-repo-summary-<YYYY-MM-DD>.txt` | `per-repo-summary-2026-04-11.txt` |
| Missing toggle report | `missing-toggle-report-<YYYY-MM-DD>.txt` | `missing-toggle-report-2026-04-11.txt` |
| Status dashboard | `toggle-status-dashboard-<YYYY-MM-DD>.txt` | `toggle-status-dashboard-2026-04-11.txt` |
| Agent definition | `toggle-<role>.agent.md` | `toggle-orchestrator.agent.md` |
| Instruction/skill | `<subject>.instructions.md` | `toggle-search-rules.instructions.md` |
| PS1 scripts | `<verb>-<subject>[-<qualifier>].ps1` | `build-toggle-registry-lookup.ps1` |
| Documentation | `<NN>-<subject>.md` | `01-repositories.md`, `07-lessons-learned.md` |
| Guide | `<descriptor>.md` | `new-session-execution-guide.md`, `index.md` |
| Config | `config.yml` | fixed name per project |

## Migration Reference (Old → New)
| Old Name | New Name |
|---|---|
| `ToggleRegistryLookup.csv` | `toggle-registry-lookup.csv` |
| `ToggleCodebaseUsageAnalysis.csv` | `toggle-codebase-usage-analysis.csv` |
| `FeatureToggleConfluencePageEnquiry.csv` | `feature-toggle-confluence-page-enquiry.csv` |
| `FeatureToggleConfluencePageEnquiryResults.csv` | `feature-toggle-confluence-page-enquiry-results.csv` |
| `S2AKeywordsLookup.csv` | `s2a-keywords-lookup.csv` |
| `ToggleBatch_Final_Checkpoint.txt` | `toggle-batch-final-checkpoint.txt` |
| `BuildToggleRegistryLookup.ps1` | `build-toggle-registry-lookup.ps1` |
| `Toggle-SearchUtility.ps1` | `toggle-search-utility.ps1` |
| `Toggle-PublishUtility.ps1` | `toggle-publish-utility.ps1` |
| `Toggle-AnalysisBatchProcessor.ps1` | `toggle-analysis-batch-processor.ps1` |
| `NEW_SESSION_EXECUTION_GUIDE.md` | `new-session-execution-guide.md` |
| `CHANGELOG.md` | `changelog.md` |

## Enforcement
- **SA-5** (toggle-workspace-manager, skill C) detects and reports violations during each workspace clean-up run
- **SA-5** uses correct names when creating any new files
- All agent `.agent.md` files reference files by their kebab-case names only---
<!-- COPYRIGHT-FOOTER -->
© 2026 Mastercard. All rights reserved.
This file is part of the Toggle Management System.
Maintained by the multi-agent AI framework.
