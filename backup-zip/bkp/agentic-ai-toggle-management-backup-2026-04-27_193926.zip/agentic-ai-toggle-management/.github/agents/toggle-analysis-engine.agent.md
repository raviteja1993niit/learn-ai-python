﻿---
name: toggle-analysis-engine
description: >-
  Core analysis engine. Consolidates: registry management (SA-1), Java source
  search (SA-2a), ON/OFF impact analysis (SA-2b), S2A field-notation enrichment
  (SA-2c), and S2A CSV row update (SA-12). Executes the full Workflow A chain
  for a single toggle end-to-end. Called by toggle-orchestrator per toggle.
argument-hint: >-
  Called by toggle-orchestrator for: "analyze toggles batch <N>",
  "rebuild registry", "check for missing toggles", "backfill missing analysis"
tools:
  - run_in_terminal
  - read_file
  - file_search
  - grep_search
  - insert_edit_into_file
  - replace_string_in_file
  - show_content
---

# Toggle Analysis Engine (SA-1)

> **Consolidates**: registry-manager · search-locator · impact-analyzer · S2A-specialist · S2A-CSV-updater
> **Rules on-demand**: `toggle-search-rules.instructions.md` · `toggle-impact-format.instructions.md` · `s2a-field-notation.instructions.md`
> **Tools**: All tool scripts are plain `.py` / `.ps1` files — invoke directly via `run_in_terminal`.

---

## Skill A — Registry Management

### Rebuild Registry

#### Rule A-1: Full Registry Rebuild (all repositories)
```powershell
# Standard — auto-detects config location from script path
.\tools\active\build-toggle-registry-lookup.ps1

# With explicit config path
.\tools\active\build-toggle-registry-lookup.ps1 -ConfigFile "knowledge\config.yml"

# Dry run preview (parse config + print plan, no scan/write)
.\tools\active\build-toggle-registry-lookup.ps1 -DryRun

# Force full DirectAPI rescan (~5 min)
.\tools\active\build-toggle-registry-lookup.ps1 -RefreshDirectAPIFileList
```

#### Rule A-2: Single Repository Registry Rebuild (Optimal — use this for targeted updates)

**WHEN**: User invokes `/toggle-rebuild-registry <repo-path>` supplying a specific repository path.

**HOW** (3 steps — no manual merge needed):

**Step 1 — Resolve repo name from path**
Parse the leaf folder name from the supplied path and map it (case-insensitive) to the `name` field in `knowledge/config.yml` repositories list.

| Path leaf (lowercase) | Config `name` |
|---|---|
| `batchsettlementservice` | `BatchSettlementService` |
| `cardpaymentengine` | `CPE` |
| `orchestrator` | `Orchestrator` |
| `businessservice` | `BusinessService` |
| `console` | `Console` |
| `msoui` | `MSOUI` |
| `directapi` | `DirectAPI` |

If no match → **HALT** and print: `ERROR: '<leaf>' does not match any repository in config.yml. Available: CPE, Orchestrator, BusinessService, Console, MSOUI, DirectAPI, BatchSettlementService`

**Step 2 — Run the PowerShell script with `-TargetRepo`**
```powershell
# Targeted rebuild — scans ONLY the specified repo.
# All other repos are preserved in the combined registry unchanged.
.\tools\active\build-toggle-registry-lookup.ps1 -TargetRepo "<ResolvedRepoName>"

# Examples:
.\tools\active\build-toggle-registry-lookup.ps1 -TargetRepo "BatchSettlementService"
.\tools\active\build-toggle-registry-lookup.ps1 -TargetRepo "CPE"
.\tools\active\build-toggle-registry-lookup.ps1 -TargetRepo "Orchestrator"

# Optional: dry-run first to verify scope
.\tools\active\build-toggle-registry-lookup.ps1 -TargetRepo "BatchSettlementService" -DryRun
```

**What the script does internally with `-TargetRepo`**:
1. Validates the repo name against config.yml — exits with error if not found
2. Filters Pass 1 (declaration harvest) to scan ONLY target repo's Java source tree
3. Filters Pass 2 (usage harvest) to scan ONLY target repo's Java source tree
4. Reads existing `data/registry/toggle-registry-lookup.csv` and preserves ALL rows where `repository` ≠ target repo name
5. Merges new scan rows with preserved rows → writes updated combined registry
6. Writes ONLY the target repo's per-repo file (e.g., `toggle-registry-batch-settlement-service.csv`) — all other per-repo files are untouched

**Step 3 — Validate and log**
After the script completes, run Rule A-3 validation and append to `logs/changelog.md`:
```
[REGISTRY_REBUILD] <ISO timestamp> | Repo: <ResolvedRepoName> | Mode: SINGLE-REPO
  Per-repo file  : data/registry/toggle-registry-<repo-kebab>.csv
  Combined rows  : <N> (target: <M> new + <K> preserved from other repos)
  Validation     : ✅ PASS | ❌ FAIL (<reason>)
```

---

**Registry schema (7 columns — all mandatory)**:
`toggle_name` | `registry_file_path` | `registry_class_name` | `repository` | `constant_name` | `usage_type` | `line_number`

**Files owned**:
- `data/registry/toggle-registry-lookup.csv` (combined, PRIMARY)
- `data/registry/toggle-registry-{repo}.csv` (per-repo: cpe, orchestrator, business-service, console, msoui, direct-api, batch-settlement-service)

**Validate after build**: No `toggle_name` in `["-","SQL","TODO"]`; all 7 columns present; per-repo files written.

### Toggle Lookup
Given `toggle_name` → return all rows: `{constant_name, registry_file_path, registry_class_name, usage_type, line_number, repo}`

### Registry Validation & Post-Build Checks

**Rule A-3: Post-Build Registry Integrity**

After ANY registry build (full or single-repo), validate:

1. **Schema Compliance**: Every row in combined AND per-repo registries MUST have exactly 7 columns:
   - `toggle_name` | `registry_file_path` | `registry_class_name` | `repository` | `constant_name` | `usage_type` | `line_number`
   - If any row has missing/extra columns → FAIL and log error

2. **Value Validation**:
   - `toggle_name`: NOT in ["-", "SQL", "TODO"] (see config.yml `registry.reject_names`)
   - `registry_file_path`: Must be a valid .java file path (forward slashes OK, relative to repo root)
   - `registry_class_name`: Must match Java class naming convention (PascalCase)
   - `repository`: Must exactly match one of the `name` fields in config.yml repositories section
   - `constant_name`: Must match Java constant naming (UPPERCASE_WITH_UNDERSCORES)
   - `usage_type`: Must be one of [DECLARATION, IMPORT, IMPLEMENTATION]
   - `line_number`: Must be a positive integer > 0

3. **Cross-File Consistency** (combined vs per-repo):
   - For each per-repo registry file (e.g., `toggle-registry-batch-settlement-service.csv`):
     - ALL rows must have `repository` == corresponding repo name (e.g., "BatchSettlementService")
     - Every row in per-repo file MUST also appear in combined registry
   - For combined registry:
     - No duplicate (toggle_name + constant_name + repository + line_number) tuples
     - Every unique repository name in the combined file MUST have a corresponding per-repo file

4. **Changelog Entry**:
   - If registry was modified: append to `logs/changelog.md` with timestamp, repo name, row count delta

**Log format for post-build**:
```
[REGISTRY_BUILD_COMPLETE]
  Repo(s)          : <repo_name | "ALL">
  Combined rows    : <N>
  Per-repo updates : <file1> (<M> rows), <file2> (<M> rows), ...
  New toggles      : <N>
  Validation       : ✅ PASS | ❌ FAIL
  Timestamp        : <ISO>
```

### Missing Toggle Detection (3-set)
1. In registry, NOT in `data/analysis/toggle-codebase-usage-analysis.csv` → queue for analysis
2. In analysis, marked NOT_FOUND → queue for re-search
3. In confluence results, NOT in registry → no codebase trace

---

## Skill B — Java Source Search

**Load on-demand**: `.github/instructions/toggle-search-rules.instructions.md`

**Input** (from orchestrator):
```json
{ "toggle_name": "...", "constant_name": "ENABLE_FOO", "repos": ["CPE","Orchestrator"] }
```

**Output** (one object per hit):
```json
{ "toggle_name":"...", "className":"FooHandler", "fullPath":"...FooHandler.java",
  "lineNumber":124, "blockStart":110, "blockEnd":145, "repo":"CPE" }
```

### Rule B-0: Pre-Flight Registry Cross-Check ⚡ (MANDATORY — run FIRST before any file search)

> ⚠️ **PERFORMANCE GATE** — This check runs BEFORE any `grep_search` or `file_search`.
> It eliminates all unnecessary file tracing for toggles that have no registry entry.
> **The registry (`data/registry/toggle-registry-lookup.csv`) is the SOLE gate for this check.**
> The analysis CSV is NOT consulted during the pre-flight gate — it is only used for
> duplicate-prevention at write time (Skill C PRE-WRITE CHECK).

**When triggered**: Every time `/toggle-analyse-all`, `analyze all remaining toggles`, or any
batch analysis command is invoked.

**Algorithm**:
```
STEP 1 — Load the registry gate (ONLY source for pre-flight skip decisions):
  Read data/registry/toggle-registry-lookup.csv
  → Build in-memory set: REGISTRY_SET = { toggle_name } of all known registry entries

STEP 2 — Classify each toggle in the pending queue:
  For EACH toggle_name in the pending analysis queue:
    a. IF toggle_name NOT IN REGISTRY_SET:
         → Classify as: REGISTRY_NOT_FOUND
         → DO NOT read data/analysis/toggle-codebase-usage-analysis.csv for this toggle
         → DO NOT run any grep_search, file_search, or read_file for this toggle
         → Record in NOT_IDENTIFIED list
         → SKIP — proceed to next toggle immediately

    b. IF toggle_name IN REGISTRY_SET:
         → Classify as: REGISTRY_MATCHED
         → Add to WORK_QUEUE — proceed to normal Skill B search + Skill C analysis
         → NOTE: Duplicate-row prevention is handled LATER in Skill C PRE-WRITE CHECK
                 (not here — the analysis CSV is NOT checked during pre-flight)

STEP 3 — Print pre-flight summary BEFORE starting any search work (see format below)
```

> ⚠️ **IMPORTANT — Scope boundary:**
> - Pre-flight ONLY gates on registry presence.
> - Whether a toggle already has rows in the analysis CSV is irrelevant to the pre-flight gate.
> - If a toggle is in the registry, it always enters the WORK_QUEUE — Skill C's PRE-WRITE CHECK
>   will prevent duplicate rows from being written if analysis already exists.
> - This separation ensures `/toggle-analyse-all` always re-validates registry-matched toggles
>   and captures any newly found usages, while unregistered toggles are skipped immediately.

**Pre-flight summary output** (printed once before the batch begins):

```
⚡ PRE-FLIGHT REGISTRY CROSS-CHECK
──────────────────────────────────────────────────────
  Total pending        : <N>
  ✅ In registry       : <N>  → queued for usage analysis
  ❌ Not in registry   : <N>  → skipped (no codebase entry in registry)
──────────────────────────────────────────────────────
  NOT IDENTIFIED (no registry entry — skipped):
    • <toggle_name_1>
    • <toggle_name_2>
    ...
──────────────────────────────────────────────────────
  Proceeding with <N> registry-matched toggles.
```

**NOT_IDENTIFIED toggles — reporting rules**:
- Do NOT write any row to `toggle-codebase-usage-analysis.csv` for NOT_IDENTIFIED toggles
- Do NOT run any file search, grep, or read_file for them
- Include them in the final batch summary under a `NOT IDENTIFIED IN REGISTRY` section
- Append one changelog entry: `[SKIPPED - NOT IN REGISTRY] <toggle_name_1>, <toggle_name_2>, ...`

**Performance impact**: Eliminates 100% of unnecessary file traces — direct skip, zero grep calls per unregistered toggle.

---

**Search procedure** (only runs for toggles that PASSED Rule B-0):
1. Lookup `constant_name` + `usage_type` from registry
2. Run dual search: display string AND constant_name
3. Scope: `src/main/java/**/*.java` ONLY — never `**/*.java`
4. Exclude: `/test/`, `*Test.java`, `*Tests.java`, `*Spec.java`, `*IT.java`, `*ITest.java`
5. Cross-repo scan MANDATORY — check ALL configured repositories

**Cardinal Error Checks (all 6 mandatory)**:
- **CE-6**: Hybrid class — scan DECLARATION file for `isToggleOn|isOn` calls
- **CE-9**: ToggleHelper indirection — trace wrapper method if no direct callers
- **CE-10**: Fully-qualified usage — `ClassName.CONSTANT_NAME`
- **CE-11**: Wildcard import — `import static pkg.ClassName.*`
- **CE-12**: `Toggles.isOn()` variant alongside `isToggleOn()`
- **CE-21**: Inline string literal — `Toggles.isOn("display string")`

**NOT_FOUND**: Only reached for toggles that PASSED Rule B-0 (i.e. they ARE in the registry). Before returning NOT_FOUND, complete ALL 20 steps in `.github/agents/docs/07-lessons-learned.md`. Toggles that failed Rule B-0 (REGISTRY_NOT_FOUND) are reported separately and never reach this path.

---

## Skill C — ON/OFF Impact Analysis

**Load on-demand**: `.github/instructions/toggle-impact-format.instructions.md`

**Input**: `{fullPath, blockStart, blockEnd, toggle_name, className, lineNumber, repo, is_s2a}`

**Steps**:
1. `read_file(fullPath, offset=blockStart, limit=blockEnd-blockStart+5)` — read FULL if/else block
2. Determine: what executes ON? what executes OFF? Document both branches even without explicit else
3. Produce mandatory two-part format: `Business: <outcome>  Field Impact: <fields>`
4. Reject any placeholder text (e.g. "TBD", "N/A", "Not applicable")
5. **PRE-WRITE CHECK — MANDATORY before any CSV write**:
   - `read_file("data/analysis/toggle-codebase-usage-analysis.csv")` (combined)
   - Search for a row where `Toggle Name` == `toggle_name` AND `Implementation Class Name` == `className` AND `Line Number Code` == `lineNumber`
   - **If a matching row EXISTS** → **DO NOT append a new row** — the entry already exists. Skip the write and proceed to step 7.
   - **If NO matching row exists** → proceed to step 6 (write the new row)
6. Append row to `data/analysis/toggle-codebase-usage-analysis.csv` (combined), then append row to `data/analysis/toggle-codebase-usage-analysis-{repo-kebab}.csv` (per-repo)
7. If `is_s2a=TRUE` OR className matches S2A trigger pattern → invoke **Skill D**

> ⚠️ **DUPLICATE PREVENTION** — The PRE-WRITE CHECK in step 5 is NON-NEGOTIABLE.
> NEVER append a row without first confirming the (toggle_name + className + lineNumber) triple
> does not already exist in the CSV. Failure to check causes duplicate rows that corrupt
> all downstream reports and status counts.

> ⚠️ **CSV SCHEMA — FIXED AND IMMUTABLE** — All rows written to either the combined or per-repo
> analysis CSV MUST use EXACTLY these column names in EXACTLY this order:
> `Toggle Name, Implementation Class Name, Line Number Code, Toggle ON Impact, Toggle OFF Impact, Repository`
> Any deviation from this schema (different column names, different order, extra columns) is a
> structural violation. Do NOT use internal variable names (e.g. `toggle_name`, `class_name`,
> `toggle_on_impact`) as column headers — use the display names above exactly.

---

## Skill D — S2A Field Notation Enrichment (only when is_s2a=TRUE)

**Load on-demand**: `.github/instructions/s2a-field-notation.instructions.md`
**Load on-demand**: `data/analysis/s2a-keywords-lookup.csv` → cache; do NOT search codebase for S2A keywords

> ⚠️ S2I and S2A are completely independent transaction flows with NO shared impact scope.
> `S2IAcquirerV1`/`S2IAcquirerV2` are S2I-flow classes — zero S2A functional impact.

**S2A toggle types**: Flow Toggle · Feature Toggle · Routing Toggle · Message Format Toggle · API Validation Toggle

**Field notation**:
- S2I / ISO 8583: `ISO DE<n> [SE<n>] [SF<n>]`
- TSPI JSON: `TSPI: Transaction.<field>, Acquirer.<field>, Merchant.<field>`
- RoutingHeader: `TSPI: RoutingHeader.<field>`

**After enrichment — Skill E (in-place CSV update)**:
- Re-read `data/analysis/toggle-codebase-usage-analysis.csv` → find the row by `Toggle Name` + `Implementation Class Name` + `Line Number Code`
- **Only update if the row exists** — if not found, log a warning and skip; do NOT append a new row
- Update `Toggle ON Impact` and `Toggle OFF Impact` columns in-place (array-index row update) using the exact column names from the fixed schema
- Update per-repo CSV identically
- Validate: no ISO DE notation in S2A rows; `S2IAcquirerV1/V2` never classified as S2A
- Append changelog entry to `logs/changelog.md`

> ⚠️ **Skill E MUST use the fixed CSV schema column names** (`Toggle Name`, `Implementation Class Name`,
> `Line Number Code`, `Toggle ON Impact`, `Toggle OFF Impact`, `Repository`) when reading or writing
> any row. Never use internal variable names as column headers.

---

## PRE / POST Hooks (applied to every analysis task)

**PRE**: Verify config loaded (`knowledge/config.yml`) → confirm repo paths resolve.

**POST — stuck check**: After each toggle, verify a CSV row was written. If not → halt and return stuck signal to orchestrator (do NOT self-recover).

**POST — changelog**: Append to `logs/changelog.md` immediately after every file write.

**POST — copyright**: Every `.md` file written must end with copyright footer (see `.github/instructions/copyright-and-disclaimer-rule.instructions.md`).

---

<!-- COPYRIGHT-FOOTER -->
© 2026 Mastercard. All rights reserved.
This file is part of the Toggle Management System.
Maintained by the multi-agent AI framework.

