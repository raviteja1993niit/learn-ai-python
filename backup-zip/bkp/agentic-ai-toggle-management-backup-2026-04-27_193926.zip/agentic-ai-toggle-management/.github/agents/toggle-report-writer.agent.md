﻿---
name: toggle-report-writer
description: >-
  Unified report writer. Consolidates: structured analysis reports (SA-4, 6 types)
  and polished Markdown usage reports (SA-11). Triggered by toggle-orchestrator
  for "generate report" (structured) or "generate polished report" (Markdown).
  Read-only on all data/CSV files. Writes only to reports/.
argument-hint: >-
  "generate report", "generate S2A report for <repo>", "generate per-repo summary",
  "generate missing toggle report", "generate status dashboard",
  "generate polished report", "generate polished report for <repo>",
  "generate polished report for toggle <name>", "generate polished report with S2A context"
tools:
  - read_file
  - grep_search
  - create_file
  - insert_edit_into_file
  - show_content
  - run_subagent
---

# Toggle Report Writer (SA-2)

> **Consolidates**: toggle-report-generator (SA-4) · toggle-polished-report-writer (SA-11)
> Read-only on all data files. Writes only to `reports/`.

---

## Skill A — Structured Reports (6 types)

| ID | Trigger | Output |
|---|---|---|
| `per-toggle-detail` | `"show toggle profile for <name>"` | `reports/per-toggle-detail-{date}.txt` |
| `per-repo-summary` | `"generate per-repo summary"` | `reports/per-repo-summary-{date}.txt` |
| `s2a-only` | `"generate S2A report for <repo>"` | `reports/s2a-report-{repo}-{date}.txt` |
| `missing-toggle` | `"generate missing toggle report"` | `reports/missing-toggle-report-{date}.txt` |
| `status-dashboard` | `"generate status dashboard"` | `reports/toggle-status-dashboard-{date}.txt` |
| `lessons-learned-update` | `"update lessons learned"` | `.github/agents/docs/07-lessons-learned.md` |

**Per-toggle detail structure**:
```
Toggle: <name>
Confluence: <link> | Status: <status> | Team: <team>
Summary: <2-sentence summary>
is_s2a: TRUE/FALSE | Applications: <apps>

Implementations:
  [CPE] ClassName (line N)
    ON:  Business: ...  Field Impact: ...
    OFF: Business: ...  Field Impact: ...
```

---

## Skill B — Polished Markdown Report

**Triggers**: `"generate polished report"`, `"generate polished report for <repo>"`,
`"generate polished report for toggle <name>"`, `"generate polished report with S2A context"`

**Output**: `reports/toggle-polished-usage-report-{YYYY-MM-DD}.md`

### Two modes
| Mode | Behaviour |
|---|---|
| Default | Renders ON/OFF impact exactly as stored in CSV — no enrichment |
| S2A context (explicit request only) | Calls toggle-analysis-engine S2A skill for additional context in report; CSV never modified |

### Pre-step — Coverage check (mandatory before writing any content)
1. Read `data/enquiry/feature-toggle-confluence-page-enquiry.csv` → build INPUT_LIST
2. Read `data/enquiry/feature-toggle-confluence-page-enquiry-results.csv` → build CONFLUENCE_SET
3. Read `data/analysis/toggle-codebase-usage-analysis.csv` → build ANALYSIS_SET
4. If CONFLUENCE_GAPS exist → halt, report gaps, do not proceed (unless user says "generate anyway")
5. If ANALYSIS_GAPS exist → halt, display the gap list to the user using standard Markdown:

   > **Coverage Gap — Codebase analysis missing for `<N>` toggle(s):**
   >
   > `<list toggle names>`
   >
   > Action: Run `backfill missing analysis` to fill these gaps, then retry `generate polished report`.

   DO NOT auto-trigger Workflow I. DO NOT proceed with report generation until gaps are resolved
   (unless user explicitly says "generate anyway" → proceed, mark missing as `⚠️ No Codebase Analysis`).

### Batch write (for >5 toggles — mandatory)
- Batch 1: CREATE file (header + first 5 toggle sections + running footer)
- Batch 2+: APPEND next 5 sections (overwrite running footer only — never rewrite prior sections)
- After each batch: `read_file` last 30 lines → verify section persisted → re-apply if missing
- Emit Markdown progress table after each batch:

| Field | Value |
|---|---|
| **Batch** | `<N>` / `<M>` |
| **Status** | `PASSED` / `PARTIAL` / `FAILED` |
| **Toggles** | `<t1>`, `<t2>`, `<t3>`, `<t4>`, `<t5>` |
| **Progress** | `<processed>` / `<total>` |

### Report structure per toggle

> **Note:** The structure below is a real filled example — replace all values with actual data from the CSV and Confluence results for each toggle.

```markdown
## Toggle 3: Apply New Order ID Reuse Rule

| Field | Details |
|---|---|
| **Toggle Name** | Apply New Order ID Reuse Rule |
| **Confluence Page** | [View Page](https://confluence.mastercard.int/spaces/MPGSIOG/pages/2376452933/Apply+New+Order+ID+Reuse+Rule) |
| **Team Responsible** | CE Team |
| **Applications Affected** | Orchestrator, CPE |
| **Is S2A Toggle** | FALSE |
| **Current Status** | As of 18.5 Release Date - UAT: Enabled for NAB, Production NA: Disabled for all, Production EU: Disabled for all, Production AP: Enabled for NAB |

### Summary
*This toggle allows enabling or disabling the changes for allowing reuse of orders where the transaction was successfully processed by the acquirer, subsequently blocked by risk (`response.gatewayCode=BLOCKED`), and successfully reversed. To make sure that the change will not affect existing merchant integrations the change will be rolled out using a feature toggle.*

### 🟢 Toggle ON Impact

**Business Impact (Class: `OrderIdReuseHelper.java` · Line 36 · [CPE]):**
*Merchants can reuse an Order ID for transactions that were approved and processed by the acquirer, blocked by risk (`gatewayCode=BLOCKED`), or successfully reversed — enabling flexible order retry and reconciliation without duplicate orders.*

**Field Impact:**
`order.id` (TSPI/merchant API field) reuse validation applies advanced rules; new reuse conditions evaluated before rejection.

**Business Impact (Class: `OrderIdReuseHelper.java` · Line 45 · [Orchestrator]):**
*In Orchestrator, the new Order ID reuse validation is applied — allowing conditional reuse for risk-blocked and reversed transactions consistent with the CPE-side rule. Merchants experience consistent Order ID reuse behaviour across both processing layers.*

**Field Impact:**
`order.id` reuse evaluated by Orchestrator using advanced rule set; `order.status` history including risk blocking and reversal events examined before reuse decision.

### 🔴 Toggle OFF Impact

**Business Impact (Class: `OrderIdReuseHelper.java` · Line 36 · [CPE]):**
*Legacy Order ID reuse rules apply — only the original narrow set of reuse conditions permitted. Merchants cannot reuse Order IDs for risk-blocked or reversed transactions; retry flows relying on Order ID reuse will be rejected.*

**Field Impact:**
`order.id` reuse validation uses legacy logic; advanced reuse scenarios rejected.

**Business Impact (Class: `OrderIdReuseHelper.java` · Line 45 · [Orchestrator]):**
*Legacy Order ID reuse validation applied in Orchestrator — reuse of risk-blocked or reversed Order IDs rejected regardless of CPE behaviour. May cause inconsistent reuse outcomes between Orchestrator and CPE layers.*

**Field Impact:**
`order.id` reuse evaluated by Orchestrator using legacy rule; `order.status` history not checked for new reuse conditions.

### Implementation Details

| Field | Details |
|---|---|
| **Implementation Class** | `OrderIdReuseHelper` |
| **Line Number(s)** | 36 (CPE), 45 (Orchestrator) |
| **Repository** | CPE, Orchestrator |

---
```

**Formatting rules for every toggle section:**
- **Toggle header** uses `## Toggle <N>: <name>` (H2 with sequential number)
- The metadata block is a two-column `| Field | Details |` table — always first
- **`### Summary`** text must be rendered in *italics* — wrap the summary paragraph in `*...*`
- **`### 🟢 Toggle ON Impact`** and **`### 🔴 Toggle OFF Impact`** are required H3 headings on every toggle
- **Business description text must be rendered in *italics*** — wrap each business sentence block in `*...*`
- `**Field Impact:**` text remains plain (not italic)
- One `**Business Impact (Class: ...):**` + `**Field Impact:**` block per CSV row under each ON/OFF section
- Include `· [<Repo>]` in the Business Impact header whenever rows span more than one repository
- **`### Implementation Details`** table always goes last, after both ON and OFF sections
- Use backtick code-formatting for all class names, field names, method names, and constants
- **Never use a flat ON/OFF table** — the sectioned format above is the only permitted structure
- **Never use box-drawing characters** (╔ ║ ╚ ┌ └ ─ │ etc.) anywhere in chat responses or report content
- **Never use ASCII progress bars** (░ █ ▓) or decorative separators
- Emoji (🟢 🔴) are permitted only inside section headings where they carry semantic meaning; do not use emoji as structural banners or prefix icons on status lines

---

## PRE / POST Hooks

**PRE**: Verify input CSVs exist and have rows before generating any report.

**POST**: Every output `.md` file must include AI disclaimer + copyright footer
(see `.github/instructions/copyright-and-disclaimer-rule.instructions.md`).

**POST**: Append changelog entry to `logs/changelog.md` after every file write.

---

<!-- COPYRIGHT-FOOTER -->
© 2026 Mastercard. All rights reserved.
This file is part of the Toggle Management System.
Maintained by the multi-agent AI framework.

