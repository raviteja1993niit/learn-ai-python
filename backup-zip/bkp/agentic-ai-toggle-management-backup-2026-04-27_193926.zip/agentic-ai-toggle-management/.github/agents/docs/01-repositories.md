﻿# Onboarded Repositories

This document catalogues every repository registered in the toggle management system.
Each section describes the repo's Java file count, scan strategy, and toggle inventory.

> ⚠️ **All repo paths are defined in `knowledge/config.yml` → `repositories[*].java_root`.**
> Never hardcode paths here — always read from config at runtime.

---

## CPE (CardPaymentEngine)

- **Repo path**: see `knowledge/config.yml` → `repositories[name=CPE].java_root`
- **Java file count**: 2 420
- **Scan strategy**: `full`
- **Registry file**: `data/registry/toggle-registry-cpe.csv`
- **Analysis file**: `data/analysis/toggle-codebase-usage-analysis-cpe.csv`
- **Notes**: Largest repo in the workspace. Full scan applied despite being above the 2 000-file threshold because it is the primary repo and all toggles must be captured.

---

## Orchestrator

- **Repo path**: see `knowledge/config.yml` → `repositories[name=Orchestrator].java_root`
- **Java file count**: 751
- **Scan strategy**: `full`
- **Registry file**: `data/registry/toggle-registry-orchestrator.csv`
- **Analysis file**: `data/analysis/toggle-codebase-usage-analysis-orchestrator.csv`

---

## BusinessService

- **Repo path**: see `knowledge/config.yml` → `repositories[name=BusinessService].java_root`
- **Java file count**: 581
- **Scan strategy**: `full`
- **Registry file**: `data/registry/toggle-registry-business-service.csv`
- **Analysis file**: `data/analysis/toggle-codebase-usage-analysis-business-service.csv`

---

## Console

- **Repo path**: see `knowledge/config.yml` → `repositories[name=Console].java_root`
- **Java file count**: 749
- **Scan strategy**: `full`
- **Registry file**: `data/registry/toggle-registry-console.csv`
- **Analysis file**: `data/analysis/toggle-codebase-usage-analysis-console.csv`

---

## MSOUI

- **Repo path**: see `knowledge/config.yml` → `repositories[name=MSOUI].java_root`
- **Java file count**: 1 065
- **Scan strategy**: `full`
- **Registry file**: `data/registry/toggle-registry-msoui.csv`
- **Analysis file**: `data/analysis/toggle-codebase-usage-analysis-msoui.csv`

---

## DirectAPI

- **Repo path**: see `knowledge/config.yml` → `repositories[name=DirectAPI].java_root`
- **Java file count**: 10 367
- **Scan strategy**: `targeted` (≥ 2 000-file threshold)
- **Targeted file list**: `data/direct-api-toggle-bearing-files.txt`
- **Registry file**: `data/registry/toggle-registry-direct-api.csv`
- **Analysis file**: `data/analysis/toggle-codebase-usage-analysis-direct-api.csv`
- **Notes**: Targeted scan — only files containing toggle-bearing identifiers are processed.

---

## BatchSettlementService

- **Repo path**: see `knowledge/config.yml` → `repositories[name=BatchSettlementService].java_root`
- **Java file count**: 285
- **Scan strategy**: `full` (< 2 000-file threshold)
- **Onboarded**: 2026-04-12
- **Registry file**: `data/registry/toggle-registry-batch-settlement-service.csv`
- **Analysis file**: `data/analysis/toggle-codebase-usage-analysis-batch-settlement-service.csv`

### Toggle Inventory (9 unique toggles / 14 registry rows)

| Toggle Name | Constant | Class | Usage Type |
|---|---|---|---|
| ACH Account Validation for Paymentech Salem ACH Acquirer | `ACCOUNT_VALIDATION_TOGGLE_NAME` | `AccountValidationToggleHelper` | IMPLEMENTATION |
| Batch Settlement Service use Base32 ID Generator | `BSS_USE_BASE32_ID_GENERATOR` | `InternalTransactionIdGenerator` | IMPLEMENTATION |
| Enable debugInformation mapping in the response for S2A | `TOGGLE_TO_ENABLE_DEBUGINFORMATION_FOR_S2A` | `ToggleHelper` | IMPLEMENTATION |
| Support STRIPE failover using Operations console | `TOGGLE_SUPPORT_STRIPE_FAILOVER_USING_OPERATIONS_CONSOLE` | `StripeServiceClient` | IMPLEMENTATION |
| System Toggle: AcqSubsystem - Switch Settlement to new VM for | `ACQ_SUBSYSTEM_SWITCH_SETTLEMENT_TXNS_TO_NEW_VM_FOR` | `RoutingConfigurationRetriever` | IMPLEMENTATION |
| System Toggle: Cleartext value for PaymentRecipientAccountNumber in BSS for AFT settlements | `TOGGLE_TO_SET_CLEARTEXT_VALUE_TO_PAYMENT_RECIPIENT_ACCOUNT_NUMBER` | `ToggleHelper` | IMPLEMENTATION |
| System Toggle: Enable T-SPI Batch Settlement Service to read Acquirer Configurations From Database | `SYSTEM_TOGGLE_ENABLE_TO_READ_ACQUIRER_CONFIG_FROM_DB` | `MegaJsonEndPoint` | IMPLEMENTATION |
| System Toggle: Revert cut down SQL fix in BatchSettlementService for Acknowledgement | `TOGGLE_USE_ORIGINAL_BULKY_SQL_FOR_ACKS` | `JpaTransactionSubmissionDao` | IMPLEMENTATION |
| System Toggle: Revert cut down SQL fix in BatchSettlementService for Notification | `TOGGLE_USE_ORIGINAL_BULKY_SQL_FOR_TRANSACTIONSUBMISSIONS` | `NotificationTransactionManager` | IMPLEMENTATION |
| System Toggle:Enable HSM Encryption For BatchSettlementService and PTS | `ENABLE_HSM_ENCRYPTION_FOR_BSS_PTS` | `CryptoServiceClient` | IMPLEMENTATION |
| System Toggle:Enable fetching new VM config | `ENABLE_FETCHING_NEW_VM_CONFIG` | `RoutingConfigurationRetriever` | IMPLEMENTATION |

### Key Toggle Files

| File | Package |
|---|---|
| `InternalTransactionIdGenerator.java` | `com.tnsi.batchsettle.messaging` |
| `AccountValidationToggleHelper.java` | `com.tnsi.batchsettle.utility.toggle` |
| `ToggleHelper.java` | `com.tnsi.batchsettle.utility.toggle` |
| `RoutingConfigurationRetriever.java` | `com.tnsi.batchsettle.cache` |
| `MegaJsonEndPoint.java` | `com.tnsi.batchsettle.messaging.megajson` |
| `StripeServiceClient.java` | `com.tnsi.batchsettle.schedule` |
| `CryptoServiceClient.java` | `com.tnsi.batchsettle.remoting` |
| `JpaTransactionSubmissionDao.java` | `com.tnsi.batchsettle.dao.jpa` |
| `NotificationTransactionManager.java` | `com.tnsi.batchsettle.notifications` |

### Decomp Notes

Several toggles have been decomposed (permanently enabled) and are preserved as `[TOGGLE-DECOMP]` comments:

- `System Toggle:Enable fetching new VM config` — always ON, guarding code removed
- `System Toggle:Enable HSM Encryption For BatchSettlementService and PTS` — always ON
- `System Toggle: Revert cut down SQL fix in BatchSettlementService for Acknowledgement` — always OFF
- `System Toggle: Revert cut down SQL fix in BatchSettlementService for Notification` — always OFF
- `System Toggle: Cleartext value for PaymentRecipientAccountNumber in BSS for AFT settlements` — decomposed
- `Enable debugInformation mapping in the response for S2A` — decomposed
- `Support STRIPE failover using Operations console` — decomposed

---

*Last updated: 2026-04-12 by toggle-workspace-manager (SA-5)*---
<!-- COPYRIGHT-FOOTER -->
© 2026 Mastercard. All rights reserved.
This file is part of the Toggle Management System.
Maintained by the multi-agent AI framework.
