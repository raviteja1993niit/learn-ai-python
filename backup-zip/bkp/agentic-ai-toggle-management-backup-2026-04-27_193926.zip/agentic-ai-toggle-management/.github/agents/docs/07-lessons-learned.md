﻿# Toggle Analysis — Cardinal Errors & NOT_FOUND Checklist
> Maintained by: toggle-workspace-manager (SA-5)
> Loaded by: toggle-orchestrator (LAZY Step 3), toggle-analysis-engine (SA-1), toggle-advisor (SA-4)
---
## NOT_FOUND Validation — 20-Step Mandatory Checklist
Before marking any toggle as NOT_FOUND, ALL 20 steps must be completed:
1.  Search by display string (exact match)
2.  Search by constant name (exact match)
3.  Search by fully-qualified constant (ClassName.CONSTANT_NAME)
4.  Search with wildcard import pattern (import static pkg.ClassName.*)
5.  Search for Toggles.isOn("display string") inline literal
6.  Search for isToggleOn() variant
7.  Search for Toggles.isOn() variant
8.  Check ToggleHelper indirection — trace wrapper method
9.  Check hybrid class — scan DECLARATION file for isToggleOn|isOn calls
10. Scan ALL configured repositories (not just CPE)
11. Confirm src/main/java scope only (exclude /test/)
12. Check DirectAPI targeted file list if repo=DirectAPI
13. Verify registry entry exists and constant_name is correct
14. Check for typo in toggle display string vs constant name
15. Re-run registry lookup — confirm toggle_name row exists
16. Check if toggle was renamed — cross-reference changelog
17. Check per-repo registry CSV directly
18. Attempt broader grep (partial name match)
19. Confirm Java file count is current — rebuild registry if stale
20. Document failure reason before marking NOT_FOUND
---
## Cardinal Errors
<!-- New Cardinal Errors appended below by SA-5 -->
<!-- COPYRIGHT-FOOTER -->
© 2026 Mastercard. All rights reserved.
This file is part of the Toggle Management System.
Maintained by the multi-agent AI framework.
