# MPGS Feature Toggle Impact Report
**Generated:** 2026-04-11  
**Total Toggles:** 99  
**Batches:** 20 of 20  
**Report Status:** ✅ COMPLETE — All 99 toggles documented

---

## Table of Contents
*(Auto-built across all batches — Running TOC)*

1. [System Toggle: CPE Load Balancer Uses Ping](#toggle-1-system-toggle-cpe-load-balancer-uses-ping)
2. [System Toggle: Enable Lookup up to 8 digit bin for Card Identification](#toggle-2-system-toggle-enable-lookup-up-to-8-digit-bin-for-card-identification)
3. [Apply New Order ID Reuse Rule](#toggle-3-apply-new-order-id-reuse-rule)
4. [System Toggle: Disables loading from orderCache in CPE for Transaction Retrieval](#toggle-4-system-toggle-disables-loading-from-ordercache-in-cpe-for-transaction-retrieval)
5. [Enable TAF fields support for Passthrough](#toggle-5-enable-taf-fields-support-for-passthrough)

---

## Toggle 1: System Toggle: CPE Load Balancer Uses Ping

| Field | Details |
|---|---|
| **Toggle Name** | System Toggle: CPE Load Balancer Uses Ping |
| **Confluence Page** | [View Page](https://confluence.mastercard.int/spaces/MPGSIOG/pages/2376453154/System+Toggle+CPE+Load+Balancer+Uses+Ping) |
| **Team Responsible** | MPGS Architecture Team |
| **Applications Affected** | CardPaymentEngine |
| **Is S2A Toggle** | FALSE |
| **Current Status** | TBD |

### Summary
This toggle is introduced as part of implementation to fix merchant load balancing issue when a remoting call for available servers return an inconsistent response. When remoting call for available servers returns only one server because of an unspecified reason, the merchant load balancing fails and sends requests to default load balanced.

### 🟢 Toggle ON Impact

**Business Impact (Class: `MerchantLoadBalancer.java` · Line 82):**
The gateway actively monitors the health of each load-balanced merchant server by pinging it on a fixed schedule — only healthy (responding) servers receive transaction traffic, preventing failed servers from being routed to.

**Field Impact:**
Internal only — no TSPI/ISO/acquirer fields affected. Internal server health map (`usableServers`) updated per server ping result.

**Business Impact (Class: `MerchantLoadBalancer.java` · Line 195):**
The candidate server list for routing a transaction is filtered to only servers that passed the last health ping — guaranteeing transactions are sent only to live servers.

**Field Impact:**
Internal only — no TSPI/ISO/acquirer fields affected. Internal: `usableServers` entries with `value==true` (healthy) are the only candidates returned for load balancing.

### 🔴 Toggle OFF Impact

**Business Impact (Class: `MerchantLoadBalancer.java` · Line 82):**
Server health monitoring is disabled — all configured servers are treated as available regardless of their actual state. Failed or unreachable servers may still receive transaction traffic causing transaction failures at the network layer.

**Field Impact:**
Internal only — `usableServers` health map not updated; all servers included in routing candidates regardless of ping status.

**Business Impact (Class: `MerchantLoadBalancer.java` · Line 195):**
All configured servers are returned as routing candidates regardless of health status — transactions may be routed to unreachable or degraded servers.

**Field Impact:**
Internal only — full `candidateServerList` returned without health filtering.

### Implementation Details

| Field | Details |
|---|---|
| **Implementation Class** | `MerchantLoadBalancer` |
| **Line Number(s)** | 82, 195 |
| **Repository** | CPE |

---

## Toggle 2: System Toggle: Enable Lookup up to 8 digit bin for Card Identification

| Field | Details |
|---|---|
| **Toggle Name** | System Toggle: Enable Lookup up to 8 digit bin for Card Identification |
| **Confluence Page** | [View Page](https://confluence.mastercard.int/spaces/MPGSIOGWIP/pages/478592841/System+Toggle+Enable+Lookup+up+to+8+Digit+BIN+for+Card+Identification) |
| **Team Responsible** | MPGS Hyperloop Scrumdiddlyumptious, MPGS Hyperloop Sombrero |
| **Applications Affected** | Gateway Processing of BIN Files, CPE, Card Identification Service |
| **Is S2A Toggle** | FALSE |
| **Current Status** | As of 21.1.0 Release Date - UAT: Disabled for all, Production NA: Disabled for all, Production EU: Disabled for all, Production AP: Disabled for all |

### Summary
This System toggle will ensure that for up to 8 Digit BIN must be supported when received in Global BIN file for Card Type Identification. This System toggle has been introduced to enable/disable the Lookup up to 8 Digit (6,7,8 Digit) BIN for Card Type Identification in the Global BIN files.

### 🟢 Toggle ON Impact

**Business Impact:**
BIN-based card identification supports 6-digit, 7-digit, and 8-digit BIN lookups — enabling more precise card brand and type resolution for extended-BIN card ranges. Merchants benefit from accurate card type detection for newer card products.

**Field Impact:**
Internal card identification pipeline only — affects card scheme/type resolved for the transaction which flows into downstream acquirer routing and ISO message fields (e.g. `cardType` used in DE61 SF3). No direct TSPI field.

### 🔴 Toggle OFF Impact

**Business Impact:**
BIN lookup is limited to standard 6-digit BINs only — extended-BIN card ranges may be misidentified or fall back to a generic card type. Card brand resolution accuracy reduced for newer card products.

**Field Impact:**
Internal card identification only; shorter BIN ranges queried against BinBase; card scheme/type result may be less accurate for 7/8-digit BIN cards.

### Implementation Details

| Field | Details |
|---|---|
| **Implementation Class** | `BinBaseCardBrandService` |
| **Line Number(s)** | 63 |
| **Repository** | CPE |

---

## Toggle 3: Apply New Order ID Reuse Rule

| Field | Details |
|---|---|
| **Toggle Name** | Apply New Order ID Reuse Rule |
| **Confluence Page** | [View Page](https://confluence.mastercard.int/spaces/MPGSIOG/pages/2376452933/Apply+New+Order+ID+Reuse+Rule) |
| **Team Responsible** | CE Team |
| **Applications Affected** | Orchestrator, CPE |
| **Is S2A Toggle** | FALSE |
| **Current Status** | As of 18.5 Release Date - UAT: Enabled for NAB, Production NA: Disabled for all, Production EU: Disabled for all, Production AP: Enabled for NAB |

### Summary
This toggle allows to enable or disable the changes for allowing reuse of orders where the transaction was successfully processed by the acquirer, subsequently blocked by risk (response.gatewayCode=BLOCKED) and successfully reversed. To make sure that the change will not affect existing merchant integrations the change will be rolled out using a feature toggle.

### 🟢 Toggle ON Impact

**Business Impact (Class: `OrderIdReuseHelper.java` · Line 36 · [CPE]):**
Merchants can reuse an Order ID for transactions that were approved and processed by the acquirer, blocked by risk (`gatewayCode=BLOCKED`), or successfully reversed — enabling flexible order retry and reconciliation without duplicate orders.

**Field Impact:**
`order.id` (TSPI/merchant API field) reuse validation applies advanced rules; new reuse conditions evaluated before rejection.

**Business Impact (Class: `OrderIdReuseHelper.java` · Line 45 · [Orchestrator]):**
In Orchestrator, the new Order ID reuse validation is applied — allowing conditional reuse for risk-blocked and reversed transactions consistent with the CPE-side rule. Merchants experience consistent Order ID reuse behaviour across both processing layers.

**Field Impact:**
`order.id` (TSPI/merchant API field) reuse evaluated by Orchestrator using advanced rule set; `order.status` history including risk blocking and reversal events examined before reuse decision.

### 🔴 Toggle OFF Impact

**Business Impact (Class: `OrderIdReuseHelper.java` · Line 36 · [CPE]):**
Legacy Order ID reuse rules apply — only the original narrow set of reuse conditions permitted. Merchants cannot reuse Order IDs for risk-blocked or reversed transactions; retry flows relying on Order ID reuse will be rejected.

**Field Impact:**
`order.id` reuse validation uses legacy logic; advanced reuse scenarios rejected.

**Business Impact (Class: `OrderIdReuseHelper.java` · Line 45 · [Orchestrator]):**
Legacy Order ID reuse validation applied in Orchestrator — reuse of risk-blocked or reversed Order IDs rejected regardless of CPE behaviour. May cause inconsistent reuse outcomes between Orchestrator and CPE layers.

**Field Impact:**
`order.id` reuse evaluated by Orchestrator using legacy rule; `order.status` history not checked for new reuse conditions.

### Implementation Details

| Field | Details |
|---|---|
| **Implementation Class** | `OrderIdReuseHelper` |
| **Line Number(s)** | 36 (CPE), 45 (Orchestrator) |
| **Repository** | CPE, Orchestrator |

---

## Toggle 4: System Toggle: Disables loading from orderCache in CPE for Transaction Retrieval

| Field | Details |
|---|---|
| **Toggle Name** | System Toggle: Disables loading from orderCache in CPE for Transaction Retrieval |
| **Confluence Page** | [View Page](https://confluence.mastercard.int/spaces/MPGSIOG/pages/2376453453/System+Toggle+Disables+loading+from+orderCache+in+CPE+for+Transaction+Retrieval) |
| **Team Responsible** | MPGS Team Cosmos |
| **Applications Affected** | cardPaymentEngine |
| **Is S2A Toggle** | FALSE |
| **Current Status** | Initially disabled state. Will be tested with no cache being used. If performance issues occur, toggle will be enabled after deployment. |

### Summary
As part of DE376193, there is a very rare race condition in the order cache within the CPE. This can manifest when a capture request is received immediately after the auth is processed, and the auth used a card wallet.

### 🟢 Toggle ON Impact

**Business Impact:**
Transaction retrieval always reads directly from the database, bypassing the order cache — eliminating a race condition (DE376193) where a capture immediately following an authorisation could return stale cached data for card wallet transactions, ensuring retrieval accuracy.

**Field Impact:**
Internal only — no TSPI/ISO/acquirer fields affected. Internal: `orderCache` lookup skipped; transaction data always sourced from database in `getTransaction()`.

### 🔴 Toggle OFF Impact

**Business Impact:**
Transaction retrieval uses the order cache first for performance — but risks returning stale data in rapid auth-to-capture sequences for card wallet transactions (DE376193 race condition).

**Field Impact:**
Internal only — `orderCache` consulted before database; performance optimised but cache consistency not guaranteed for all card wallet transaction patterns.

### Implementation Details

| Field | Details |
|---|---|
| **Implementation Class** | `TransactionRetrievalDataAccess` |
| **Line Number(s)** | 40 |
| **Repository** | CPE |

---

## Toggle 5: Enable TAF fields support for Passthrough

| Field | Details |
|---|---|
| **Toggle Name** | Enable TAF fields support for Passthrough |
| **Confluence Page** | [View Page](https://confluence.mastercard.int/spaces/MPGSIOG/pages/2376453550/Enable+TAF+fields+support+for+Passthrough) |
| **Team Responsible** | Team Heimdall |
| **Applications Affected** | cardPaymentEngine |
| **Is S2A Toggle** | FALSE |
| **Current Status** | *(Not specified)* |

### Summary
When merchant completes the authentication flow as per TAF requirement (including cardholder completing successful ID&V), merchant would send all the required fields with transaction as required by TAF. MC Gateway should be able to process this transaction and successfully accept and process the new fields for TAF.

### 🟢 Toggle ON Impact

**Business Impact (Class: `AuthorisationServiceImpl.java` · Line 85 · [CPE]):**
For authorisation transactions, a reporting record (TAF Passthrough record) is created via `createReportingRecordForTAFPassthrough()` before the authorisation is processed — enabling Transaction Authentication Framework (TAF) passthrough data to be captured for reporting. Merchants submitting TAF passthrough transactions receive a correctly generated passthrough reporting record.

**Field Impact:**
Internal processing/reporting only — no TSPI/ISO/acquirer request fields affected; authentication billing event reporting record created for TAF passthrough transactions.

**Business Impact (Class: `PurchaseServiceImpl.java` · Line 110 · [CPE]):**
For purchase (pay) transactions, a TAF Passthrough reporting record is created via `createReportingRecordForTAFPassthrough()` before the purchase is processed — ensuring TAF passthrough data is captured for pay operations.

**Field Impact:**
Internal processing/reporting only — no TSPI/ISO/acquirer fields affected; TAF passthrough reporting record created for pay transactions.

**Business Impact (Class: `S2IAcquirerV1.java` · Line 6902 · [CPE]):**
When building the S2I ISO 8583 DE48 field for passthrough transactions, the SE42 sub-element is updated with a TAF Passthrough Token SLI value derived from the ECI indicator — ensuring correct SLI encoding for TAF passthrough scheme token transactions sent to the S2I acquirer.

**Field Impact:**
ISO ***DE48 SE42*** (Service Level Indicator) overridden with TAF passthrough-specific SLI value computed from `paddedEciIndicator`; `updateSE42ForSchemeToken()` called with TAF-derived `sliForTafPassthrough`.

### 🔴 Toggle OFF Impact

**Business Impact (Class: `AuthorisationServiceImpl.java` · Line 85 · [CPE]):**
No TAF Passthrough reporting record is created for authorisation transactions — `createReportingRecordForTAFPassthrough()` not called; TAF passthrough data is not captured. Merchants relying on TAF passthrough reporting do not receive the reporting record.

**Field Impact:**
Internal only — no reporting record created; authentication billing event not enriched with TAF passthrough data for auth transactions.

**Business Impact (Class: `PurchaseServiceImpl.java` · Line 110 · [CPE]):**
No TAF Passthrough reporting record created for purchase transactions — `createReportingRecordForTAFPassthrough()` not called. TAF passthrough data absent from pay operation reporting.

**Field Impact:**
Internal only.

**Business Impact (Class: `S2IAcquirerV1.java` · Line 6902 · [CPE]):**
SE42 sub-element in DE48 is not overridden for TAF passthrough transactions — standard DE48 SE42 logic applies without TAF-specific SLI mapping.

**Field Impact:**
ISO ***DE48 SE42*** not updated for TAF passthrough; TAF passthrough token SLI value absent from S2I acquirer message.

### Implementation Details

| Field | Details |
|---|---|
| **Implementation Class** | `AuthorisationServiceImpl`, `PurchaseServiceImpl`, `S2IAcquirerV1` |
| **Line Number(s)** | 85 (`AuthorisationServiceImpl`), 110 (`PurchaseServiceImpl`), 6902 (`S2IAcquirerV1`) |
| **Repository** | CPE |

---

## Toggle 6: MEA PVL and Co-branded Card Transaction Processing

| Field | Details |
|---|---|
| **Toggle Name** | MEA PVL and Co-branded Card Transaction Processing |
| **Confluence Page** | [View Page](https://confluence.mastercard.int/spaces/MPGSIOG/pages/2376453287/MEA+PVL+and+Co-branded+Card+Transaction+Processing) |
| **Team Responsible** | T-Centaurus |
| **Applications Affected** | Target |
| **Is S2A Toggle** | FALSE |
| **Current Status** | Roll Out Plan: Currently planning to roll out by the 22.6.0 release, once the dynamic card bins are onboarded. |

### Summary
This toggle has been implemented to enable MEA PVL and Co-branded Card Transaction Processing implemented in feature F460534 to process Mastercard PVL or Co-Branded card transactions which are transformed into processingBrand's specification before it is sent to RSC.

### 🟢 Toggle ON Impact

**Business Impact (Class: `AcquirerProxy.java` · Line 202 · [CPE]):**
***MEA (Middle East and Africa) PVL and co-branded card transactions*** are dynamically processed — the gateway identifies the dynamic/processing brand for PVL cards and uses that processing brand for S2I message generation instead of the original card brand, enabling proper routing and processing through S2I acquirer networks.

**Field Impact:**
***Internal processing logic only*** — affects card brand determination (`cardType`) used during S2I message building; impacts ISO 8583 message field populations that depend on card brand/type.

### 🔴 Toggle OFF Impact

**Business Impact (Class: `AcquirerProxy.java` · Line 202 · [CPE]):**
***MEA PVL and co-branded cards*** are processed using their original card brand without dynamic processing brand substitution — may result in incorrect S2I message generation or routing if the original brand is not supported by the target acquirer.

**Field Impact:**
***Internal processing logic only*** — card type remains as originally provided; full brand details in `CardTypeDetails` not consulted; ISO 8583 message built using original card brand.

### Implementation Details

| Field | Details |
|---|---|
| **Implementation Class** | `AcquirerProxy` |
| **Line Number(s)** | 202 |
| **Repository** | CPE |

---

## Toggle 7: Enable issuer country code in transaction response

| Field | Details |
|---|---|
| **Toggle Name** | Enable issuer country code in transaction response |
| **Confluence Page** | [View Page](https://confluence.mastercard.int/spaces/MPGSIOG/pages/2376453724/Enable+issuer+country+code+in+transaction+response) |
| **Team Responsible** | Team Musang King |
| **Applications Affected** | CardPaymentEngine, DirectApi |
| **Is S2A Toggle** | FALSE |
| **Current Status** | As of 25.5 Release Date - MTF: Disabled for all (except specified MSOs/merchants) |

### Summary
To return additional `sourceOfFunds.provided.card.issuerCountryCode` and `transaction[n].sourceOfFunds.provided.card.issuerCountryCode` field in the Response of Retrieve Order and Retrieve Transaction APIs, this addition will only be supported in WSAPI version 100.

### 🟢 Toggle ON Impact

**Business Impact (Class: `CardTypeDetailsDecorator.java` · Line 124 · [CPE]):**
***Issuer country code*** (A3 country code in ISO 3166-1 alpha-3 format) is populated in the transaction response for `cardTypeDetails`. The gateway retrieves the issuer country from `order.getGatewayCardCountryOfIssue()` and validates it against ISO 3166-1 alpha-3 standard before setting `cardTypeDetails.setIssuerCountry()`. Merchants receive `issuerCountryCode` in Retrieve Transaction/Order responses.

**Field Impact:**
***`sourceOfFunds.provided.card.issuerCountryCode`*** (TSPI/merchant API response field) populated with validated A3 country code when available and toggle enabled.

### 🔴 Toggle OFF Impact

**Business Impact (Class: `CardTypeDetailsDecorator.java` · Line 124 · [CPE]):**
***Issuer country code*** is not populated in transaction responses — `cardTypeDetails.getIssuerCountry()` remains null and `issuerCountryCode` field absent from API responses. Merchants do not receive country of card issuance information in retrieve operations.

**Field Impact:**
***`sourceOfFunds.provided.card.issuerCountryCode`*** not populated; retrieval responses do not include issuer country data.

### Implementation Details

| Field | Details |
|---|---|
| **Implementation Class** | `CardTypeDetailsDecorator` |
| **Line Number(s)** | 124 |
| **Repository** | CPE |

---

## Toggle 8: System Toggle: Use 8_4 Masked PAN for Scheme Token Transaction Response

| Field | Details |
|---|---|
| **Toggle Name** | System Toggle: Use 8_4 Masked PAN for Scheme Token Transaction Response |
| **Confluence Page** | [View Page](https://confluence.mastercard.int/spaces/MPGSIOG/pages/2376453810/System+Toggle+Use+8_4+Masked+PAN+for+Scheme+Token+Transaction+Response) |
| **Team Responsible** | Team Lotus |
| **Applications Affected** | WSAPI v100 |
| **Is S2A Toggle** | FALSE |
| **Current Status** | 26.2 |

### Summary
An issue was raised related to 8_4 masking in WSAPI response that card number comes back in 6_4 Masked format instead of 8_4 when using a Network/Scheme Token for transactions.

### 🟢 Toggle ON Impact

**Business Impact (Class: `CardPaymentDecoratorPostRetrieveAction.java` · Line 62 · [CPE]):**
***The CPE retrieval decorator*** reads the 8-4 masked FPAN from `SensitiveDataHelper` (`getSensitiveMaskedFpan`) for scheme token transactions — if a sensitive 8-4 masked FPAN is available, it replaces the standard masked FPAN value used to set `cardPayment.cardNumber`. Merchants retrieving scheme token transactions receive PAN values masked in 8-4 format (first 8 + last 4 visible) instead of the default 6-4 format.

**Field Impact:**
***`sourceOfFunds.provided.card.number`*** (TSPI/merchant API response field) — `maskedFpan` overridden with 8-4 sensitive masked value from `getSensitiveMaskedFpan()` when `TOGGLE_ENABLE_84_PAN_MASKING` is ON; affects the card number returned in retrieve transaction/order responses for scheme token transactions.

**Business Impact (Class: `TokenDetailsContainer.java` · Line 119 · [Orchestrator]):**
***The Orchestrator token details container*** retrieves the 8-4 masked PAN (`DISPLAY_8_4` card mask) from the token details for scheme token transactions — preferring the 8-4 masked format from `maskedPans` map over the default `getMaskedData()` value. The `maskedFPan` field in `TokenDetailsContainer` is set to the 8-4 format.

**Field Impact:**
***`sourceOfFunds.provided.card.number`*** (TSPI/merchant API response field) — `TokenDetailsContainer.maskedFPan` populated with `DISPLAY_8_4` masked value from `PrimaryAccountNumber.getMaskedPans()` when toggle ON; used in Orchestrator-layer transaction responses involving scheme tokens.

### 🔴 Toggle OFF Impact

**Business Impact (Class: `CardPaymentDecoratorPostRetrieveAction.java` · Line 62 · [CPE]):**
***The sensitive 8-4 masked FPAN*** is not retrieved — `maskedFpan` retains its prior value from `getMaskedFpan(jsonDataBean)`; standard 6-4 masked card number used for scheme token transactions in retrieval responses.

**Field Impact:**
***`sourceOfFunds.provided.card.number`*** — standard `getMaskedFpan()` value used; 8-4 PAN masking enhancement not applied for scheme token transactions.

**Business Impact (Class: `TokenDetailsContainer.java` · Line 119 · [Orchestrator]):**
***The default `getMaskedData()` value*** is used for the token `maskedFPan` — standard masking format applied; 8-4 masked PAN not preferred for scheme token details.

**Field Impact:**
***`sourceOfFunds.provided.card.number`*** — `TokenDetailsContainer.maskedFPan` set from `PrimaryAccountNumber.getMaskedData()` standard format; 8-4 masking not applied.

### Implementation Details

| Field | Details |
|---|---|
| **Implementation Class** | `CardPaymentDecoratorPostRetrieveAction`, `TokenDetailsContainer` |
| **Line Number(s)** | 62 (`CardPaymentDecoratorPostRetrieveAction`), 119 (`TokenDetailsContainer`) |
| **Repository** | CPE (`CardPaymentDecoratorPostRetrieveAction`), Orchestrator (`TokenDetailsContainer`) |

---

## Toggle 9: Support New Merchant Advice Codes with optimal retry advice for Mastercard

| Field | Details |
|---|---|
| **Toggle Name** | Support New Merchant Advice Codes with optimal retry advice for Mastercard |
| **Confluence Page** | [View Page](https://confluence.mastercard.int/spaces/MPGSIOG/pages/2376453349/Support+New+Merchant+Advice+Codes+with+optimal+retry+advice+for+Mastercard) |
| **Team Responsible** | Team Hercules |
| **Applications Affected** | cardPaymentEngine, directApi |
| **Is S2A Toggle** | FALSE |
| **Current Status** | As of 23.3 Release Date - MTF: Not Yet Available, Production NA: Not Yet Available |

### Summary
As per Feature F489958 functionality of populating new merchant advice code DE48 SE84 for Authorize, Pay Operations being added in gateway in PI1/2023.

### 🟢 Toggle ON Impact

**Business Impact (Class: `AcquirerResponseJsonProcessor.java` · Line 223 · [CPE]):**
***The merchant advice code*** returned in the acquirer response is parsed using the enhanced `getMerchantAdviceCodeFromJson()` method — supporting new advice codes including optimal retry advice codes for Mastercard transactions. Merchants receive accurate, complete retry advice codes in the authorization response data.

**Field Impact:**
***`transaction.response.merchantAdviceCode`*** (internal acquirer response DTO field) set via `getMerchantAdviceCodeFromJson()`; new Mastercard advice codes (including optimal retry codes) parsed and returned.

### 🔴 Toggle OFF Impact

**Business Impact (Class: `AcquirerResponseJsonProcessor.java` · Line 223 · [CPE]):**
***Merchant advice code*** falls back to legacy `getRecurringPaymentAdviceCodeFromJson()` — only the original narrow set of recurring payment advice codes are parsed; new Mastercard optimal retry advice codes not recognized.

**Field Impact:**
***`transaction.response.merchantAdviceCode`*** set via legacy `getRecurringPaymentAdviceCodeFromJson()`; extended advice code values not parsed; merchants may not receive retry optimization codes.

### Implementation Details

| Field | Details |
|---|---|
| **Implementation Class** | `AcquirerResponseJsonProcessor` |
| **Line Number(s)** | 223 |
| **Repository** | CPE |

---

## Toggle 10: Log Acquirer Details for Sanctioned Transactions

| Field | Details |
|---|---|
| **Toggle Name** | Log Acquirer Details for Sanctioned Transactions |
| **Confluence Page** | [View Page](https://confluence.mastercard.int/spaces/MPGSIOG/pages/2376453802/Log+Acquirer+Details+for+Sanctioned+Transactions) |
| **Team Responsible** | T-Pyxis |
| **Applications Affected** | Target |
| **Is S2A Toggle** | FALSE |
| **Current Status** | As of 26.1.0 Release Date - MTF: Disabled for all (will be enabled for test MSOs) |

### Summary
US law requires that the acquirer of a sanctioned transaction is identified, however this information is not currently recorded in the logs by the PGS Sanctions Service.

### 🟢 Toggle ON Impact

**Business Impact (Class: `SanctionHelper.java` · Line 1568 · [Orchestrator]):**
***Acquirer details*** (line of business, acquirer ID, acquirer bin, country code) are included in the sanctions screening request data sent to the external Sanctions Service — enabling sanctions officers to see full acquirer context for flagged transactions.

**Field Impact:**
***Internal only*** — no TSPI/ISO/acquirer fields affected. Internal: `addAcquirerDetailsToSanctionData()` called; acquirer detail fields added to `sanctionRequestDataList` at lines 1568, 1708, 1729, 1755.

### 🔴 Toggle OFF Impact

**Business Impact (Class: `SanctionHelper.java` · Line 1568 · [Orchestrator]):**
***Acquirer details*** are not added to the sanctions screening request — sanctions checks proceed without acquirer context data. Sanctioned transaction logs contain reduced data.

**Field Impact:**
***Internal only*** — `addAcquirerDetailsToSanctionData()` not called; acquirer fields omitted from `sanctionRequestDataList`.

### Implementation Details

| Field | Details |
|---|---|
| **Implementation Class** | `SanctionHelper` |
| **Line Number(s)** | 1568 |
| **Repository** | Orchestrator |

---

## Toggle 11: Enable New COF Token Value for Target

| Field | Details |
|---|---|
| **Toggle Name** | Enable New COF Token Value for Target |
| **Confluence Page** | [View Page](https://confluence.mastercard.int/spaces/MPGSIOG/pages/2376453230/Enable+New+COF+Token+Value+for+Target) |
| **Team Responsible** | T-Sombrero |
| **Applications Affected** | Target |
| **Is S2A Toggle** | FALSE |
| **Current Status** | Post 22.2.0.6 release - MTF: Enabled for specific MSOs |

### Summary
This toggle has been implemented to cater to the logic of rectifying the COF token value for Target transactions. It ensures that Credential-on-File indicators are correctly mapped for internet Mastercard transactions processed via the S2I acquirer, addressing inaccuracies in StoredOnFile and CardOnFile indicator values for Target merchant tokenised transactions.

### 🟢 Toggle ON Impact

**Business Impact (Class: `S2IAcquirerV1.java` · Line 5525 · [CPE]):**
***For internet Mastercard transactions***, the enhanced COF token logic is applied during S2I message building — `getCardOnFileForTarget()` or `isToggleOn` check drives `StoredOnFile` and `CardOnFile` indicator mapping for CPE auth/purchase/refund messages. Merchants benefit from accurate COF indicator mapping that correctly represents tokenised card-on-file status for Target merchant transactions.

**Field Impact:**
***ISO DE48 SE86*** (Credential on File indicator) sub-element populated using enhanced COF rules; `StoredOnFile`/`CardOnFile` mapping uses `isInternetTransaction` and scheme token checks.

### 🔴 Toggle OFF Impact

**Business Impact (Class: `S2IAcquirerV1.java` · Line 5525 · [CPE]):**
***Legacy COF indicator logic*** applies — `StoredOnFile`/`CardOnFile` indicator for S2I DE48 SE86 determined without the enhanced Target merchant-specific COF token rules; less precise COF representation for internet Mastercard transactions.

**Field Impact:**
***ISO DE48 SE86*** set using legacy `isCardRetrievedFromToken()`/`isStoredExternally()` checks only.

### Implementation Details

| Field | Details |
|---|---|
| **Implementation Class** | `S2IAcquirerV1` |
| **Line Number(s)** | 5525 |
| **Repository** | CPE |

---

## Toggle 12: System Toggle: Enable Data Instrumentation Logging for WSAPI requests

| Field | Details |
|---|---|
| **Toggle Name** | System Toggle: Enable Data Instrumentation Logging for WSAPI requests |
| **Confluence Page** | [View Page](https://confluence.mastercard.int/spaces/MPGSIOG/pages/2376453450/System+Toggle+Enable+Data+Instrumentation+Logging+for+WSAPI+requests) |
| **Team Responsible** | Team Trailblazer |
| **Applications Affected** | Target-Orchestrator |
| **Is S2A Toggle** | FALSE |
| **Current Status** | As of 24.1.0 Release Date - MTF: Disabled for all, Production: Disabled for all |

### Summary
Enabling data instrumentation in Target platform for WS-API operation through asynchronous logging. This toggle controls whether full WSAPI request payloads are captured via the `transactionRequestLogHandler` before operation processing, providing diagnostic and audit capability for operators and stakeholders.

### 🟢 Toggle ON Impact

**Business Impact (Class: `DoNotProcessAfterTimeHandler.java` · Line 101 · [Orchestrator]):**
***WSAPI transaction request data*** is logged via `transactionRequestLogHandler.log(request, action)` before processing — enables full data instrumentation logging of WSAPI request payloads for diagnostic and audit purposes. Operators can capture complete request/response data for each WSAPI transaction operation.

**Field Impact:**
***Internal logging only*** — no TSPI/ISO/acquirer fields affected. Internal: `transactionRequestLogHandler.log()` called with full request object and action name before `operation.apply(request)` executes.

### 🔴 Toggle OFF Impact

**Business Impact (Class: `DoNotProcessAfterTimeHandler.java` · Line 101 · [Orchestrator]):**
***WSAPI request data*** is not logged via `transactionRequestLogHandler` — data instrumentation logging disabled for WSAPI requests (unless the other logging toggle is also on).

**Field Impact:**
***Internal only*** — `transactionRequestLogHandler.log()` not called; WSAPI request payload not captured in instrumentation logs.

### Implementation Details

| Field | Details |
|---|---|
| **Implementation Class** | `DoNotProcessAfterTimeHandler` |
| **Line Number(s)** | 101 |
| **Repository** | Orchestrator |

---

## Toggle 13: Unify Order Creation Time In Retrieval

| Field | Details |
|---|---|
| **Toggle Name** | Unify Order Creation Time In Retrieval |
| **Confluence Page** | [View Page](https://confluence.mastercard.int/spaces/MPGSIOG/pages/2376453003/Unify+Order+Creation+Time+In+Retrieval) |
| **Team Responsible** | Team Continuing Engineering |
| **Applications Affected** | Orchestrator |
| **Is S2A Toggle** | FALSE |
| **Current Status** | As of 19.4 Release Date - UAT: Disabled for all, Production: Disabled for all |

### Summary
There is a defect for orders having Order ID reused — when retrieving the order it shows an inconsistent order creation time. This toggle fixes the inconsistency by unifying the order creation time in retrieval responses to match the date of the first chronologically ordered transaction, ensuring merchants who reuse Order IDs see a consistent creation time.

### 🟢 Toggle ON Impact

**Business Impact (Class: `TransactionDataCommonService.java` · Line 1540 · [Orchestrator]):**
***When ON and the order has at least one transaction*** with a non-null transaction date, the order creation time in the retrieval response is unified to match the date of the first (chronologically ordered) transaction — fixing an inconsistency where reused Order IDs could show different creation times across retrieval calls. Merchants who reuse Order IDs see a consistent creation time in Retrieve Order responses.

**Field Impact:**
***`order.creationTime`*** (TSPI/merchant API retrieval field) — set to `orderTransactions.get(0).getTransactionDate()` when toggle ON; ensures consistent creation time across all retrieval responses for an order.

### 🔴 Toggle OFF Impact

**Business Impact (Class: `TransactionDataCommonService.java` · Line 1540 · [Orchestrator]):**
***The order creation time*** is not overridden from the transaction date — the original order-level creation time from the order record is used as-is. For orders with reused Order IDs this may result in inconsistent or incorrect order creation times in retrieval responses.

**Field Impact:**
***`order.creationTime`*** — not updated from transaction data; original order-record creation time used.

### Implementation Details

| Field | Details |
|---|---|
| **Implementation Class** | `TransactionDataCommonService` |
| **Line Number(s)** | 1540 |
| **Repository** | Orchestrator |

---

## Toggle 14: Get Most Recent Transaction as Initial Transaction If Auto-Capture Failed in Settlement Transaction

| Field | Details |
|---|---|
| **Toggle Name** | Get Most Recent Transaction as Initial Transaction If Auto-Capture Failed in Settlement Transaction |
| **Confluence Page** | [View Page](https://confluence.mastercard.int/spaces/MPGSIOG/pages/2376453053/Get+Most+Recent+Transaction+as+Initial+Transaction+If+Auto-Capture+Failed+in+Settlement+Transaction) |
| **Team Responsible** | CE |
| **Applications Affected** | MPGS |
| **Is S2A Toggle** | FALSE |
| **Current Status** | As of 23.5 Release Date - MTF: Disabled for all, Production: Disabled for all |

### Summary
There is a defect where an incorrect Order Status is computed for Auto-Capture where the settlement transaction failed. This toggle addresses the issue by using the most recent transaction as the initial transaction when an auto-capture has failed in a settlement transaction flow.

### 🟢 Toggle ON Impact

**Business Impact:**
NOT_FOUND — Toggle name not found in any implementation class across CPE, Orchestrator, or any other repository. The toggle string does not appear as a declared constant or `isToggleOn()` call in the codebase.

**Field Impact:**
NOT_FOUND — No implementation class located in the analysed repositories. Toggle may exist in an external settlement service or batch processing component not present in this workspace.

### 🔴 Toggle OFF Impact

**Business Impact:**
NOT_FOUND — Toggle name not found in any implementation class across CPE, Orchestrator, or any other repository.

**Field Impact:**
NOT_FOUND — When OFF or absent, the legacy/default initial transaction selection logic applies for auto-capture failure scenarios in settlement. Field Impact: Unknown.

### Implementation Details

| Field | Details |
|---|---|
| **Implementation Class** | NOT_FOUND |
| **Line Number(s)** | N/A |
| **Repository** | NOT_FOUND |

---

## Toggle 15: Enable historical transaction data aggregation for prioritised merchant flow control

| Field | Details |
|---|---|
| **Toggle Name** | Enable historical transaction data aggregation for prioritised merchant flow control |
| **Confluence Page** | [View Page](https://confluence.mastercard.int/spaces/MPGSIOG/pages/2376453441/Enable+historical+transaction+data+aggregation+for+prioritised+merchant+flow+control) |
| **Team Responsible** | Sixth Sense |
| **Applications Affected** | directApi |
| **Is S2A Toggle** | FALSE |
| **Current Status** | As of 23.5 Release Date - MTF: Disabled for all, Production NA: Disabled for all, Production EU: Disabled for all, Production AP: Disabled for all, Production IN: Disabled for all |

### Summary
This toggle has been introduced to prevent the activation of the historical transaction data for prioritised merchant flow control as the remainder of the feature has been shifted to PI5. It controls both the aggregation of historical transaction statistics and the collection of per-merchant transaction counts used for intelligent rate-limiting decisions in DirectAPI.

### 🟢 Toggle ON Impact

**Business Impact (Class: `HistoricalTransactionDataAggregator.java` · Line 87 · [DirectAPI]):**
***The gateway node checks eligibility*** and aggregates historical per-merchant transaction data on a scheduled interval — building statistical records used for prioritised merchant flow control (rate limiting based on historical throughput patterns). DirectAPI can apply intelligent per-merchant rate limits informed by real historical transaction volumes.

**Field Impact:**
***Internal only*** — no TSPI/ISO/acquirer fields affected. Internal: `isAggregatedCandidate()` checked; aggregation of last N days of transaction history executed; `TransactionAggregationHistory` entries created or updated in the database.

**Business Impact (Class: `HistoricalTransactionDataCollector.java` · Line 88 · [DirectAPI]):**
***Individual transaction results*** that match the collection criteria (operation type and request attributes) are counted against the merchant in the in-memory historical data store; periodically this in-memory count is persisted to the database. This enables accurate real-time accumulation of per-merchant transaction counts for flow control decisions.

**Field Impact:**
***Internal only*** — no TSPI/ISO/acquirer fields affected. Internal: `shouldCollectTransactionResult()` returns true when toggle ON and operation is collectible; `historicalData.countTransaction()` increments in-memory merchant count; `persistTransactionCounts()` saves data to DB on schedule.

### 🔴 Toggle OFF Impact

**Business Impact (Class: `HistoricalTransactionDataAggregator.java` · Line 87 · [DirectAPI]):**
***The aggregation task returns immediately*** with a warning log — no historical transaction data is aggregated regardless of schedule. Statistical data for prioritised merchant flow control is not built or maintained.

**Field Impact:**
***Internal only*** — aggregation skipped; `transactionAggregationHistoryRepository` not updated; historical flow control data stale or absent.

**Business Impact (Class: `HistoricalTransactionDataCollector.java` · Line 88 · [DirectAPI]):**
***Transaction results are not counted*** (`shouldCollectTransactionResult` returns false) and periodic persistence also skips immediately with a warning — no historical transaction count data is collected or saved. The in-memory and database counters are not updated.

**Field Impact:**
***Internal only*** — merchant transaction counts not incremented; historical data DB not updated; flow control features that rely on historical data have no current data.

### Implementation Details

| Field | Details |
|---|---|
| **Implementation Class** | `HistoricalTransactionDataAggregator`, `HistoricalTransactionDataCollector` |
| **Line Number(s)** | 87, 88 |
| **Repository** | DirectAPI |

---

## Toggle 16: System Toggle: Enable Data Instrumentation Logging for WSAPI Transactions

| Field | Details |
|---|---|
| **Toggle Name** | System Toggle: Enable Data Instrumentation Logging for WSAPI Transactions |
| **Confluence Page** | [View Page](https://confluence.mastercard.int/spaces/MPGSIOG/pages/2376453450/System+Toggle+Enable+Data+Instrumentation+Logging+for+WSAPI+requests) |
| **Team Responsible** | Team Trailblazer |
| **Applications Affected** | Target-Orchestrator |
| **Is S2A Toggle** | FALSE |
| **Current Status** | As of 24.1.0 Release Date - MTF: Disabled for all, Production NA: Disabled for all, Production EU: Disabled for all, Production AP: Disabled for all |

### Summary
Enabling data instrumentation in Target platform for WS-API operation through asynchronous logging. The logging will enable stakeholders to define the roadmap for the Boost initiative by capturing usage patterns.

### 🟢 Toggle ON Impact

**Business Impact (Class: `DoNotProcessAfterTimeHandler.java` · Line 102 · [Orchestrator]):**
***WSAPI transaction data is logged*** via `transactionRequestLogHandler.log(request, action)` — this toggle, OR the WSAPI requests toggle, enables full data instrumentation logging of all WSAPI transaction payloads. Enables complete audit trail for WSAPI transaction request/response data.

**Field Impact:**
***Internal logging only*** — no TSPI/ISO/acquirer fields affected. Internal: `transactionRequestLogHandler.log()` invoked when either this toggle OR `ENABLE_DATA_INSTRUMENTATION_LOGGING_TOGGLE` is on.

### 🔴 Toggle OFF Impact

**Business Impact (Class: `DoNotProcessAfterTimeHandler.java` · Line 102 · [Orchestrator]):**
***Transaction-level instrumentation logging is not enabled*** by this toggle alone — logging only occurs if the WSAPI requests logging toggle is also on.

**Field Impact:**
***Internal only*** — WSAPI transaction payload not logged via instrumentation handler when only this toggle is off.

### Implementation Details

| Field | Details |
|---|---|
| **Implementation Class** | `DoNotProcessAfterTimeHandler` |
| **Line Number(s)** | 102 |
| **Repository** | Orchestrator |

---

## Toggle 17: System Toggle: Enable 8-4 PAN Masking in API Response

| Field | Details |
|---|---|
| **Toggle Name** | System Toggle: Enable 8-4 PAN Masking in API Response |
| **Confluence Page** | [View Page](https://confluence.mastercard.int/spaces/MPGSIOG/pages/2376453743/System+Toggle+Enable+8-4+PAN+Masking+in+API+Response) |
| **Team Responsible** | MPGS Team Lotus |
| **Applications Affected** | WSAPI v100 |
| **Is S2A Toggle** | FALSE |
| **Current Status** | Target release: Release 25.7 |

### Summary
The new toggle enables new feature to support new 8-4 masking format in WSAPI version 100. When enabled, card PANs in API responses are masked in 8-4 format (first 8 digits visible, last 4 visible, middle masked) instead of the standard 6-4 format.

### 🟢 Toggle ON Impact

**Business Impact (Class: `PANMaskingHelper.java` · Line 68 · [DirectAPI]):**
***API responses for non-reporting contexts mask card PANs*** in 8-4 format (first 8 digits visible, last 4 visible, middle masked) — `shouldUse84PanMasking()` returns true when toggle is ON AND PAN length is sufficient AND merchant has the privilege AND the operation supports 8-4 masking. Card numbers in API responses are masked with enhanced 8-4 format instead of standard 6-4.

**Field Impact:**
***`sourceOfFunds.provided.card.number`*** (DirectAPI response field) — masked using 8-4 format when `shouldUse84PanMasking()` returns true; `PANMaskingHelper.shouldUse84PanMasking()` gates the masking format in the API response layer.

### 🔴 Toggle OFF Impact

**Business Impact (Class: `PANMaskingHelper.java` · Line 68 · [DirectAPI]):**
***Standard PAN masking applies*** — `shouldUse84PanMasking()` returns false; standard 6-4 or other configured masking format used for card numbers in API responses.

**Field Impact:**
***`sourceOfFunds.provided.card.number`*** — masked with standard format; 8-4 masking not applied.

### Implementation Details

| Field | Details |
|---|---|
| **Implementation Class** | `PANMaskingHelper` |
| **Line Number(s)** | 68 |
| **Repository** | DirectAPI |

---

## Toggle 18: System Toggle: Honour DoNotProcessAfterTime for transaction processing

| Field | Details |
|---|---|
| **Toggle Name** | System Toggle: Honour DoNotProcessAfterTime for transaction processing |
| **Confluence Page** | [View Page](https://confluence.mastercard.int/spaces/MPGSIOG/pages/2376453319/System+Toggle+Honour+DoNotProcessAfterTime+for+transaction+processing) |
| **Team Responsible** | Team Bergen |
| **Applications Affected** | Orchestrator, Card Payment Engine, ISO Web Gateway |
| **Is S2A Toggle** | FALSE |
| **Current Status** | As of 22.7 Release Date - MTF: Enabled, Production: Disabled for all |

### Summary
Stopping processing of transactions once WSAPI has timed out, will prevent transactions being performed after the merchant has been told they have failed. This toggle enforces hard transaction processing time limits across CPE, Orchestrator, and DirectAPI to prevent financial data inconsistencies caused by expired in-flight transactions.

### 🟢 Toggle ON Impact

**Business Impact (Class: `DoNotProcessAfterTimeHandler.java` · Line 103 · [CPE]):**
***The gateway enforces hard transaction processing time limits*** — if insufficient time remains (< threshold ms) before the `DoNotProcessAfterTime` deadline, `applyToggleCheckWithLogging()` returns false, the transaction request/response path is rejected with a WARNING log ('Insufficient time left to process'), and processing stops. Protects against financial data inconsistencies caused by expired in-flight transactions.

**Field Impact:**
***Internal only*** — no TSPI/ISO/acquirer fields affected. Internal: `Toggles.isToggleOn(DO_NOT_PROCESS_AFTER_TIME_TOGGLE)` at line 103; if ON and time expired: `LOGGER.warn` + return false; `doNotProcessAfterTimeAndToggleControl` logged as 'active'.

**Business Impact (Class: `DoNotProcessAfterTimeHandler.java` · Line 79 · [Orchestrator]):**
***Orchestrator enforces the DoNotProcessAfterTime deadline*** for requests — if time available to process is less than the threshold, the request is rejected (returns false) with a WARNING log. Ensures time-expired requests never reach the acquirer, preventing dual-processing and financial inconsistencies.

**Field Impact:**
***Internal only*** — no TSPI/ISO/acquirer fields affected. Internal: `Toggles.isToggleOn(DO_NOT_PROCESS_AFTER_TIME_TOGGLE)` at line 79; if ON and time expired: `LOGGER.warn(errorMessage)` + return false.

**Business Impact (Class: `DoNotProcessAfterTimeDecorator.java` · Line 84 · [DirectAPI]):**
***The DoNotProcessAfterTime toggle state is read on every inbound DirectAPI payment-bus request*** via `checkToggle()` — primarily to ensure the toggle is registered in the toggle system before the first expired-time scenario occurs. The toggle state is logged at DEBUG level.

**Field Impact:**
***Internal registration/logging only*** — no TSPI/ISO/acquirer fields affected. Internal: `Toggles.isToggleOn(DO_NOT_PROCESS_AFTER_TIME_TOGGLE)` at line 84; result logged as 'enabled' or 'disabled'; ensures toggle is pre-registered so upstream CPE/Orchestrator enforcement works correctly on first encounter.

### 🔴 Toggle OFF Impact

**Business Impact (Class: `DoNotProcessAfterTimeHandler.java` · Line 103 · [CPE]):**
***The DoNotProcessAfterTime check runs in observe-only mode*** — even when insufficient time remains before the deadline, the request is allowed to continue; a warning is logged ('This request would have been rejected if the DoNotProcessAfter toggle was turned on') but processing is not halted.

**Field Impact:**
***Internal only*** — time-expiry condition logged but not enforced; `doNotProcessAfterTimeAndToggleControl` logged as 'inactive'; all requests proceed regardless of time remaining.

**Business Impact (Class: `DoNotProcessAfterTimeHandler.java` · Line 79 · [Orchestrator]):**
***The deadline check in Orchestrator logs a warning but allows the request through*** — 'This request would have been rejected if the DoNotProcessAfter toggle was turned on'. Requests past the DoNotProcessAfterTime deadline are not blocked, risking duplicate or out-of-order processing.

**Field Impact:**
***Internal only*** — deadline not enforced at Orchestrator layer; return true even when time expired.

**Business Impact (Class: `DoNotProcessAfterTimeDecorator.java` · Line 84 · [DirectAPI]):**
***The toggle state logged by DirectAPI reads 'disabled'*** — serving as a signal that the CPE/Orchestrator enforcement layers are in observe-only mode. `DoNotProcessAfterTime` field is still set on the payment-bus request regardless of toggle state; enforcement is controlled by CPE/Orchestrator, not DirectAPI.

**Field Impact:**
***Internal only*** — `DoNotProcessAfterTime` timestamp always populated on `BaseTransactionRequest`; only enforcement differs based on toggle state in CPE/Orchestrator.

### Implementation Details

| Field | Details |
|---|---|
| **Implementation Class** | `DoNotProcessAfterTimeHandler` (CPE), `DoNotProcessAfterTimeHandler` (Orchestrator), `DoNotProcessAfterTimeDecorator` (DirectAPI) |
| **Line Number(s)** | 103, 79, 84 |
| **Repository** | CPE, Orchestrator, DirectAPI |

---

## Toggle 19: System Toggle: Enable Rate Limit For Test Merchants

| Field | Details |
|---|---|
| **Toggle Name** | System Toggle: Enable Rate Limit For Test Merchants |
| **Confluence Page** | [View Page](https://confluence.mastercard.int/spaces/MPGSIOG/pages/2376453107/System+Toggle+Enable+Rate+Limit+For+Test+Merchants) |
| **Team Responsible** | MPGS Hyperloop SDU |
| **Applications Affected** | directApi |
| **Is S2A Toggle** | FALSE |
| **Current Status** | MPGS 21.1.0.1 Release - Currently planning to roll out by 21.1 release |

### Summary
This toggle has been introduced to rate limit on test merchants. Merchant who's MID begins with test, they are limited to one call, per second, per node. This protects production infrastructure from excessive test merchant traffic.

### 🟢 Toggle ON Impact

**Business Impact (Class: `TestingMerchantsRateLimiter.java` · Line 100 · [DirectAPI]):**
***A per-test-merchant rate limiter is enforced*** via `RateLimiter.tryAcquire()` — test merchant requests are throttled to the configured rate limit. If the rate limit is exceeded for a given test merchant, the slot is not acquired and the request is rate-limited, protecting production infrastructure from excessive test merchant traffic.

**Field Impact:**
***Internal only*** — no TSPI/ISO/acquirer fields affected. Internal: `Toggles.isToggleOn(ENABLE_RATE_LIMIT_TEST_MERCHANT_REQUESTS_TOGGLE)` at line 100; if toggle is OFF, `acquireSlot()` returns immediately without throttling; if ON, per-merchant `RateLimiter.tryAcquire()` is called.

### 🔴 Toggle OFF Impact

**Business Impact (Class: `TestingMerchantsRateLimiter.java` · Line 100 · [DirectAPI]):**
***Test merchant requests bypass the rate limiter entirely*** — `acquireSlot()` returns immediately after the toggle check; no rate limiting applied to test merchants.

**Field Impact:**
***Internal only*** — `RateLimiter` not consulted; all test merchant request slots granted unconditionally.

### Implementation Details

| Field | Details |
|---|---|
| **Implementation Class** | `TestingMerchantsRateLimiter` |
| **Line Number(s)** | 100 |
| **Repository** | DirectAPI |

---

## Toggle 20: Apply per-merchant limits for invalid operation rates in WSAPI

| Field | Details |
|---|---|
| **Toggle Name** | Apply per-merchant limits for invalid operation rates in WSAPI |
| **Confluence Page** | [View Page](https://confluence.mastercard.int/spaces/MPGSIOG/pages/2376453406/Apply+per-merchant+limits+for+invalid+operation+rates+in+WSAPI) |
| **Team Responsible** | Team Sixth Sense |
| **Applications Affected** | directApi |
| **Is S2A Toggle** | FALSE |
| **Current Status** | As of 23.4 Release Date - MTF: Disabled for all, Production: Disabled for all |

### Summary
This toggle has been introduced to restrict the number of invalid transactions made per merchant and prevent/mitigate a significant number of production incidents caused due to invalid requests. When enabled, per-merchant invalid operation rate limiting is actively enforced protecting platform stability by cutting off misbehaving merchants.

### 🟢 Toggle ON Impact

**Business Impact (Class: `MerchantInvalidRequestRateLimiter.java` · Line 89 · [DirectAPI]):**
***Per-merchant invalid operation rate limiting is actively enforced*** — if a merchant's invalid/rejected request leaky bucket is exhausted and the bus pool indicates real rejection pressure (`shouldReallyReject()`), the request is hard-rejected with a `MerchantCausedFlowControlRejection`: 'You have submitted an unusually high number of invalid requests.' This protects platform stability by cutting off misbehaving merchants at the operation level.

**Field Impact:**
***Internal only*** — no TSPI/ISO/acquirer fields affected. Internal: `Toggles.isToggleOn(TOGGLE_NAME)` at line 89; on exhausted bucket + pool pressure: `MerchantCausedFlowControlRejection` thrown, `perMerchantMetrics.recordRequest()` called with REJECTED suffix.

### 🔴 Toggle OFF Impact

**Business Impact (Class: `MerchantInvalidRequestRateLimiter.java` · Line 89 · [DirectAPI]):**
***Invalid-operation rate limiting runs in observe/dry-run mode only*** — even when a merchant's bucket is exhausted and pool pressure is high, the request is NOT rejected; a warning log is emitted ('would have been rejected if toggle was on') but processing continues.

**Field Impact:**
***Internal only*** — `MerchantCausedFlowControlRejection` suppressed; metrics not recorded for rejection; all requests pass through regardless of invalid-operation rate.

### Implementation Details

| Field | Details |
|---|---|
| **Implementation Class** | `MerchantInvalidRequestRateLimiter` |
| **Line Number(s)** | 89 |
| **Repository** | DirectAPI |

---

## Toggle 21: Apply per-merchant maximum request rate limits in WSAPI

| Field | Details |
|---|---|
| **Toggle Name** | Apply per-merchant maximum request rate limits in WSAPI |
| **Confluence Page** | [View Page](https://confluence.mastercard.int/spaces/MPGSIOG/pages/2376453407/Apply+per-merchant+maximum+request+rate+limits+in+WSAPI) |
| **Team Responsible** | Team Sixth Sense |
| **Applications Affected** | directApi |
| **Is S2A Toggle** | FALSE |
| **Current Status** | As of 23.4 Release Date - MTF: Disabled for all, Production: Disabled for all |

### Summary
This toggle has been introduced to restrict the number of invalid transactions made per merchant and prevent/mitigate production incidents caused by invalid requests. When enabled, per-merchant maximum request rate limiting is actively enforced, capping total per-merchant throughput at the configured TPS limit to protect the platform from burst abuse.

### 🟢 Toggle ON Impact

**Business Impact (Class: `MerchantPrioritisedRequestRateLimiter.java` · Line 103 · [DirectAPI]):**
***Per-merchant maximum request rate limiting is actively enforced*** — if a merchant's prioritised rate bucket (high-priority or low-priority, determined by `RequestPriorityDeterminer`) is exhausted and the bus pool is under real pressure, the request is hard-rejected with a `MerchantCausedFlowControlRejection`: 'You have submitted an unusually high number of requests.' This caps total per-merchant throughput at the configured TPS limit, protecting the platform from burst abuse.

**Field Impact:**
***Internal only*** — no TSPI/ISO/acquirer fields affected. Internal: `Toggles.isToggleOn(TOGGLE_NAME)` at line 103; on exhausted bucket + pool pressure: `MerchantCausedFlowControlRejection` thrown, `perMerchantMetrics.recordRequest()` called with REJECTED suffix.

### 🔴 Toggle OFF Impact

**Business Impact (Class: `MerchantPrioritisedRequestRateLimiter.java` · Line 103 · [DirectAPI]):**
***Per-merchant maximum rate limiting runs in observe/dry-run mode only*** — even when a merchant's prioritised rate bucket is exhausted and the pool is under pressure, the request is NOT rejected; a warning log is emitted ('would have been rejected if toggle was on') but processing continues normally.

**Field Impact:**
***Internal only*** — `MerchantCausedFlowControlRejection` suppressed; metrics not recorded for rejection; all per-merchant requests granted regardless of rate.

### Implementation Details

| Field | Details |
|---|---|
| **Implementation Class** | `MerchantPrioritisedRequestRateLimiter` |
| **Line Number(s)** | 103 |
| **Repository** | DirectAPI |

---

## Toggle 22: System Toggle: Enable Version Deprecation for Transactions

| Field | Details |
|---|---|
| **Toggle Name** | System Toggle: Enable Version Deprecation for Transactions |
| **Confluence Page** | [View Page](https://confluence.mastercard.int/spaces/MPGSIOG/pages/2376453652/System+toggle+Enable+version+deprecation+for+transactions) |
| **Team Responsible** | Team Breakaway |
| **Applications Affected** | DirectApi |
| **Is S2A Toggle** | FALSE |
| **Current Status** | As of 25.1 Release Date - MTF: Disabled for all, Production: Disabled for all |

### Summary
This toggle is needed so the API request sender could receive an error response when sending a request to a deprecated API version. When enabled, deprecated API version requests for transactions are actively rejected, forcing merchants to upgrade to supported versions.

### 🟢 Toggle ON Impact

**Business Impact (Class: `ApiModelLookup.java` · Line 59 · [DirectAPI]):**
***Deprecated API version requests are actively rejected*** — if a deprecated API version is used for a transaction request, `validateVersion()` throws a `MalformedRequest` exception (`RESOURCE_DOES_NOT_EXIST`), forcing merchants to upgrade to a supported API version.

**Field Impact:**
***Internal validation only*** — no TSPI/ISO/acquirer fields affected. Internal: `Toggles.isToggleOn(ENABLE_VERSION_DEPRECATION_TOGGLE)` at line 59; `MalformedRequest` thrown for deprecated version strings when toggle ON.

### 🔴 Toggle OFF Impact

**Business Impact (Class: `ApiModelLookup.java` · Line 59 · [DirectAPI]):**
***Deprecated API version requests are accepted and processed normally*** — version deprecation check is bypassed; merchants on old/deprecated API versions can continue sending requests without receiving an error or being forced to upgrade.

**Field Impact:**
***Internal only*** — version deprecation check bypassed; all API versions accepted regardless of deprecation status.

### Implementation Details

| Field | Details |
|---|---|
| **Implementation Class** | `ApiModelLookup` |
| **Line Number(s)** | 59 |
| **Repository** | DirectAPI |

---

## Toggle 23: Route Risk Operations via the R-SPI Service and enable Merchant Risk

| Field | Details |
|---|---|
| **Toggle Name** | Route Risk Operations via the R-SPI Service and enable Merchant Risk |
| **Confluence Page** | [View Page](https://confluence.mastercard.int/spaces/MPGSIOG/pages/2376453165/Route+Risk+Operations+via+the+R-SPI+Service+and+enable%C2%A0Merchant+Risk) |
| **Team Responsible** | Team Ragnarok |
| **Applications Affected** | Risk Service V2, RiskSpi, CPE, Orchestrator, Orderservice |
| **Is S2A Toggle** | FALSE |
| **Current Status** | As of 21.4 Release Date - MTF: Disabled for all; Production NA: Disabled for all; Production EU: Disabled for all; Production AP: Disabled for all; Production IN: Disabled for all |

### Summary
This toggle allows enabling Merchant Risk Screening and controlling the fraud services route of WSAPI transactions. When enabled, the existing fraud services use the Risk-SPI as the first point of contact instead of RiskServiceV2, routing both pre-risk and post-risk checks through the R-SPI (Risk Service Provider Interface) service endpoint for richer merchant risk assessment.

### 🟢 Toggle ON Impact

**Business Impact (Class: `RiskAssessmentServiceRemoteHttpClientImpl.java` · Line 72 · [CPE]):**
***Pre-risk checks are routed to the R-SPI service endpoint*** using the `PERFORM_PRE_RISKCHECK_SPI` method — enabling merchant risk assessment via the dedicated SPI service which supports full merchant risk context. Merchants enrolled in R-SPI-based risk receive richer risk decisions.

**Field Impact:**
***Internal only*** — no TSPI/ISO/acquirer fields affected. Internal: `performRequest()` invoked with `method=PERFORM_PRE_RISKCHECK_SPI` and `service=RISKSPI_ASSESSMENT_SERVICE`; risk check routed to R-SPI endpoint.

**Business Impact (Class: `RiskAssessmentServiceRemoteHttpClientImpl.java` · Line 93 · [CPE]):**
***Post-risk checks are routed to the R-SPI service endpoint*** using `PERFORM_POST_RISKCHECK_SPI` — ensuring post-transaction risk assessment flows through the merchant-risk-enabled SPI path.

**Field Impact:**
***Internal only*** — no TSPI/ISO/acquirer fields affected. Internal: `performRequest()` invoked with `method=PERFORM_POST_RISKCHECK_SPI` and `service=RISKSPI_ASSESSMENT_SERVICE` for post-risk check.

### 🔴 Toggle OFF Impact

**Business Impact (Class: `RiskAssessmentServiceRemoteHttpClientImpl.java` · Line 72 · [CPE]):**
***Pre-risk checks fall back to the legacy MEGA JSON risk endpoint*** using `PERFORM_MEGA_JSON_PRE_RISKCHECK` method against `RISK_ASSESSMENT_SERVICE_V2` — merchant risk operates without R-SPI routing.

**Field Impact:**
***Internal only*** — `performRequest()` invoked with `method=PERFORM_MEGA_JSON_PRE_RISKCHECK` and `service=RISK_ASSESSMENT_SERVICE_V2`; R-SPI endpoint not used.

**Business Impact (Class: `RiskAssessmentServiceRemoteHttpClientImpl.java` · Line 93 · [CPE]):**
***Post-risk checks fall back to legacy MEGA JSON risk endpoint*** using `PERFORM_MEGA_JSON_POST_RISKCHECK` against `RISK_ASSESSMENT_SERVICE_V2` — R-SPI post-risk path not used.

**Field Impact:**
***Internal only*** — `performRequest()` invoked with `method=PERFORM_MEGA_JSON_POST_RISKCHECK` and `service=RISK_ASSESSMENT_SERVICE_V2`.

### Implementation Details

| Field | Details |
|---|---|
| **Implementation Class** | `RiskAssessmentServiceRemoteHttpClientImpl` |
| **Line Number(s)** | 72, 93 |
| **Repository** | CPE |

---

## Toggle 24: RSPI Mapping: Send Fields to Risk Provider - SubMerchant

| Field | Details |
|---|---|
| **Toggle Name** | RSPI Mapping: Send Fields to Risk Provider - SubMerchant |
| **Confluence Page** | [View Page](https://confluence.mastercard.int/spaces/MPGSIOG/pages/2376453474/RSPI+Mapping+Send+Fields+to+Risk+Provider+-+SubMerchant) |
| **Team Responsible** | Heimdall |
| **Applications Affected** | RiskProcessingEngine, cardpaymentengine |
| **Is S2A Toggle** | FALSE |
| **Current Status** | Will be rolled out as part of 23.8 Release; MTF: Enable for All Smoke test MSO's; Production NA: Disabled for all; Production EU: Disabled for all; Production AP: Disabled for all; Production IN: Disabled for all |

### Summary
Addition of new fields to R-SPI will allow MPGS to pass on additional information about transactions to the risk provider so that risk providers can create more advanced rules for fraud assessment. This toggle specifically adds sub-merchant data fields (company name and card scheme) to the R-SPI MEGA JSON message, enabling richer sub-merchant context for risk decisions.

### 🟢 Toggle ON Impact

**Business Impact (Class: `JsonMegaMessageRequestBuilder.java` · Line 774 · [CPE]):**
***The sub-merchant Company name field is included in the TSPI/MEGA JSON message*** sent to the risk provider — giving the risk provider full sub-merchant identification context including company name for more accurate risk assessment of aggregated transactions.

**Field Impact:**
***TSPI: `Merchant.SubMerchant` (Company field)*** populated in MEGA JSON message when `subMerchantDetails.getCompany()` is non-blank; sent to risk provider.

**Business Impact (Class: `JsonMegaMessageRequestBuilder.java` · Line 1335 · [CPE]):**
***Card scheme (`CardScheme` enum name) is populated in the TSPI transaction block*** of the MEGA JSON message for standard payment transactions — risk provider receives card scheme information to apply scheme-specific risk rules.

**Field Impact:**
***TSPI: `Transaction` (`CardScheme` field)*** set from `cardTypeDetails.getCardScheme().name()` in MEGA JSON message; enriches risk assessment with card brand data.

**Business Impact (Class: `JsonMegaMessageRequestBuilder.java` · Line 1394 · [CPE]):**
***Card scheme is also populated in the ATC (Authorised Transaction Confirmation) transaction block*** of the MEGA JSON message — risk provider receives card scheme for ATC-type transactions ensuring complete card brand context across all transaction paths.

**Field Impact:**
***TSPI: `Transaction` (`CardScheme` field)*** set from `cardTypeDetails.getCardScheme().name()` in MEGA JSON ATC transaction block.

### 🔴 Toggle OFF Impact

**Business Impact (Class: `JsonMegaMessageRequestBuilder.java` · Line 774 · [CPE]):**
***Sub-merchant Company name is excluded from the TSPI/MEGA JSON message*** to the risk provider — risk provider does not receive the sub-merchant company name for aggregated merchant transactions.

**Field Impact:**
***TSPI: `Merchant.SubMerchant.Company`*** not included in MEGA JSON risk message.

**Business Impact (Class: `JsonMegaMessageRequestBuilder.java` · Line 1335 · [CPE]):**
***Card scheme is not populated in the TSPI transaction block*** — risk provider does not receive card scheme information for standard payment transactions.

**Field Impact:**
***TSPI: `Transaction.CardScheme`*** not included in MEGA JSON risk request.

**Business Impact (Class: `JsonMegaMessageRequestBuilder.java` · Line 1394 · [CPE]):**
***Card scheme not populated in the ATC transaction block*** — risk provider does not receive card brand for ATC-type transactions.

**Field Impact:**
***TSPI: `Transaction.CardScheme`*** absent from MEGA JSON ATC transaction message.

### Implementation Details

| Field | Details |
|---|---|
| **Implementation Class** | `JsonMegaMessageRequestBuilder` |
| **Line Number(s)** | 774, 1335, 1394 |
| **Repository** | CPE |

---

## Toggle 25: Populate payer authentication details on pre-risk RSPI

| Field | Details |
|---|---|
| **Toggle Name** | Populate payer authentication details on pre-risk RSPI |
| **Confluence Page** | [View Page](https://confluence.mastercard.int/spaces/MPGSIOG/pages/2376453181/Populate+payer+authentication+details+on+pre-risk+RSPI) |
| **Team Responsible** | Team Ragnarok |
| **Applications Affected** | CPE |
| **Is S2A Toggle** | FALSE |
| **Current Status** | As of 21.3.1.5 Release Date - MTF: Disabled for all; Production NA: Disabled for all; Production EU: Disabled for all; Production AP: Disabled for all; Production IN: Disabled for all |

### Summary
This toggle allows populating payer authentication details on PRE AUTH WSAPI requests. If the feature toggle is active and enabled, payer authentication details (specifically the authentication ID from the 3DS result) will be populated on the pre-risk RSPI MEGA JSON message, giving the risk provider richer authentication context for pre-risk assessment decisions.

### 🟢 Toggle ON Impact

**Business Impact (Class: `MegaJsonRiskRequest.java` · Line 91 · [CPE]):**
***The authentication ID (`authID`) from the 3DS result is set on the applicable transaction data source*** before the MEGA JSON pre-risk message is built — ensuring the authentication identifier is included in the RSPI (Risk SPI) MEGA JSON message sent to the risk provider for pre-risk assessment. Merchants with 3DS authentication benefit from richer pre-risk context at the risk provider.

**Field Impact:**
***TSPI: `Transaction` (`AuthenticationId` / `authID` field)*** — `applicableTransaction.setAuthenticationId(context.getCardholderAuthenticationResult().getAuthID())` called at line 91 when toggle ON and authResult non-null; `authID` propagated into MEGA JSON risk request via `JsonMegaMessageAdaptor`.

### 🔴 Toggle OFF Impact

**Business Impact (Class: `MegaJsonRiskRequest.java` · Line 91 · [CPE]):**
***The authentication ID is NOT set on the transaction data source*** — even if cardholder authentication details are available, they are not propagated into the pre-risk RSPI MEGA JSON message. The risk provider evaluates the pre-risk check without the 3DS authentication identifier.

**Field Impact:**
***TSPI: `Transaction.AuthenticationId`*** absent from MEGA JSON pre-risk request; `setAuthenticationId()` not called; risk provider receives reduced authentication context.

### Implementation Details

| Field | Details |
|---|---|
| **Implementation Class** | `MegaJsonRiskRequest` |
| **Line Number(s)** | 91 |
| **Repository** | CPE |

---

## Toggle 26: Bypass CSC checks for Scheme Token Transactions

| Field | Details |
|---|---|
| **Toggle Name** | Bypass CSC checks for Scheme Token Transactions |
| **Confluence Page** | [View Page](https://confluence.mastercard.int/spaces/MPGSIOG/pages/2376452988/Bypass+CSC+checks+for+Scheme+Token+Transactions) |
| **Team Responsible** | Team Bergen |
| **Applications Affected** | CPE |
| **Is S2A Toggle** | FALSE |
| **Current Status** | As of 19.4 Release Date - UAT: Disabled for all; Production NA: Disabled for all; Production EU: Disabled for all; Production AP: Disabled for all |

### Summary
The gateway currently handles the case where the merchant submits a device payment with both a full cryptogram as well as a CSC by silently dropping the CSC. This toggle will bypass CSC verification checks for Scheme Token transactions when enabled. It ensures that tokenized digital wallet and contactless payments using cryptograms or DTV pseudo-CSC values are not rejected due to standard CSC enforcement.

### 🟢 Toggle ON Impact

**Business Impact (Class: `CscHelper.java` · Line 61 · [CPE]):**
***For Scheme Token transactions*** (where `mobileWallet.isSchemeToken=true`) CSC/CVV validation is entirely bypassed — tokenized payments using cryptograms or DTV pseudo-CSC values proceed without CSC enforcement, enabling contactless and digital wallet payments to succeed where no real CSC exists.

**Field Impact:**
***`sourceOfFunds.provided.card.securityCode`*** (TSPI/merchant API field) not validated; `isCscProvided()`, `wasCscPreviouslyProvided()` and `validateEmptyCsc()` all bypassed for scheme token transactions — no CSC-required error thrown.

### 🔴 Toggle OFF Impact

**Business Impact (Class: `CscHelper.java` · Line 61 · [CPE]):**
***CSC validation is NOT bypassed*** for scheme token transactions — the gateway applies standard CSC enforcement even for tokenized payments. Scheme token transactions using cryptograms or DTV pseudo-CSC may be incorrectly rejected if no real CSC is present, blocking valid digital wallet and contactless payments.

**Field Impact:**
***`sourceOfFunds.provided.card.securityCode`*** validated; `validateEmptyCsc()` called via `CscValidator` for scheme token transactions same as regular card transactions.

### Implementation Details

| Field | Details |
|---|---|
| **Implementation Class** | `CscHelper` |
| **Line Number(s)** | 61 |
| **Repository** | CPE |

---

## Toggle 27: Retrieve Card Bin Set Id for Subsequent Transactions

| Field | Details |
|---|---|
| **Toggle Name** | Retrieve Card Bin Set Id for Subsequent Transactions |
| **Confluence Page** | [View Page](https://confluence.mastercard.int/spaces/MPGSIOG/pages/2376453781/Retrieve+Card+Bin+Set+Id+for+Subsequent+Transactions) |
| **Team Responsible** | *(not specified)* |
| **Applications Affected** | CPE |
| **Is S2A Toggle** | FALSE |
| **Current Status** | As of 23.4 Release - MTF: Enabled for ALL; EU: Enabled for ALL; NA: Enabled for test MSOs; AP: Enabled for test MSOs; KSA: Enabled for test MSOs; IN: Enabled for test MSOs |

### Summary
The subsequent transactions will retrieve the card bin set id when it is configured for the acquirer link. To make sure that the change will not affect existing merchant integrations the change will be rolled out using a feature toggle. This enables BIN-set-aware acquirer link resolution for subsequent transactions even when BIN Set ID was not initially stored.

### 🟢 Toggle ON Impact

**Business Impact (Class: `MerchantBase.java` · Line 870 · [CPE]):**
***For subsequent transactions where no BIN Set ID was initially stored*** on the transaction, the gateway performs a fresh BIN lookup using `CardBinSetIdDeterminerImpl` — resolving the merchant-configured BIN Set ID by re-running card brand determination against the original card PAN. Enables BIN-set-aware acquirer link resolution for subsequent transactions even when BIN Set ID was absent.

**Field Impact:**
***Internal card identification and acquirer routing only*** — no TSPI/ISO/acquirer fields affected directly. Internal: `CardBinSetIdDeterminerImpl.determineCardBinSetId()` called when `cardBinSetId` is empty; resolved `cardBinSetId` fed into `getSingleRelationshipByCriteriaMatch()` for MAL selection.

### 🔴 Toggle OFF Impact

**Business Impact (Class: `MerchantBase.java` · Line 870 · [CPE]):**
***BIN Set ID is not re-determined*** for subsequent transactions with missing `cardBinSetId` — transactions proceed with empty `cardBinSetId` which may cause MAL resolution to fall back to card-type-only routing. Merchant-configured BIN set routing not applied for subsequent transactions with missing BIN Set ID.

**Field Impact:**
***Internal only*** — `CardBinSetIdDeterminerImpl` not invoked; `cardBinSetId` remains empty for subsequent transactions.

### Implementation Details

| Field | Details |
|---|---|
| **Implementation Class** | `MerchantBase` |
| **Line Number(s)** | 870 |
| **Repository** | CPE |

---

## Toggle 28: Filter out transactions unrelated to current order

| Field | Details |
|---|---|
| **Toggle Name** | Filter out transactions unrelated to current order |
| **Confluence Page** | [View Page](https://confluence.mastercard.int/spaces/MPGSIOG/pages/2376453601/Filter+out+transactions+unrelated+to+current+order) |
| **Team Responsible** | Team Cosmos |
| **Applications Affected** | CPE, RSC |
| **Is S2A Toggle** | FALSE |
| **Current Status** | 24.8.0 Release - Disabled by default |

### Summary
This is a toggle designed to exclude transactions that may not be related to the current order from being included when evaluating the initial successful transaction. This is relevant in cases where the order id has been reused. It prevents stale initial transactions from older same-ID orders from being used in payment flows.

### 🟢 Toggle ON Impact

**Business Impact (Class: `OrderPersistenceService.java` · Line 318 · [CPE]):**
***When loading the most recent successful initial transaction for an order***, the gateway filters out financial transactions belonging to older orders that share the same order ID — using `uniqueOrderId` (`persistentPk` or `transactionNumber`) to exclude transactions from older order instances. This prevents stale initial transactions from older same-ID orders from being used in payment flows.

**Field Impact:**
***Internal persistence lookup only*** — no TSPI/ISO/acquirer fields affected. Internal: `filterTransactionsOnOldOrders(uniqueOrderId, x.getShoppingTransaction())` applied via stream filter; only transactions matching current order instance returned.

### 🔴 Toggle OFF Impact

**Business Impact (Class: `OrderPersistenceService.java` · Line 318 · [CPE]):**
***The legacy `loadSuccessfulInitialTransaction(OrderIdentifier)` path is used*** — no filtering by `uniqueOrderId`; older same-ID order transactions may be returned as the initial transaction.

**Field Impact:**
***Internal only*** — `OrderIdentifier`-based lookup without `uniqueOrderId` filtering; may return stale initial transaction from older order.

### Implementation Details

| Field | Details |
|---|---|
| **Implementation Class** | `OrderPersistenceService` |
| **Line Number(s)** | 318 |
| **Repository** | CPE |

---

## Toggle 29: Use partitioned tables for CPE transaction storage

| Field | Details |
|---|---|
| **Toggle Name** | Use partitioned tables for CPE transaction storage |
| **Confluence Page** | [View Page](https://confluence.mastercard.int/spaces/MPGSIOG/pages/2376453237/Use+partitioned+tables+for+CPE+transaction+storage) |
| **Team Responsible** | Team SDU |
| **Applications Affected** | CPE |
| **Is S2A Toggle** | FALSE |
| **Current Status** | 22.6 Release |

### Summary
This is a toggle designed to enable the gateway functionality of using CPE partitioned tables instead of single tables `cpeorder` and `cpetransaction` to store and retrieve data. The toggle changes storage behaviour to use partitioned tables when enabled, improving performance and enabling data lifecycle management for CPE transaction storage.

### 🟢 Toggle ON Impact

**Business Impact (Class: `OrderPersistenceDelegate.java` · Line 382 · [CPE]):**
***New order transactions and terminal close-batch operations use the partitioned table implementation*** (`partitionTableImplSupplier`) for CPE transaction storage — enabling database partitioning for improved performance and data lifecycle management.

**Field Impact:**
***Internal persistence only*** — no TSPI/ISO/acquirer fields affected. Internal: `partitionTableImplSupplier.get()` returned at line 382 (new orders) and line 484 (terminal batch); partitioned DB tables used for transaction writes.

### 🔴 Toggle OFF Impact

**Business Impact (Class: `OrderPersistenceDelegate.java` · Line 382 · [CPE]):**
***The legacy (non-partitioned) implementation (`legacyImplSupplier`) is used*** for CPE transaction storage — standard unpartitioned table writes apply for both new orders and terminal batch operations.

**Field Impact:**
***Internal only*** — `legacyImplSupplier.get()` returned; legacy DB table structure used.

### Implementation Details

| Field | Details |
|---|---|
| **Implementation Class** | `OrderPersistenceDelegate` |
| **Line Number(s)** | 382 |
| **Repository** | CPE |

---

## Toggle 30: System Toggle: CPE - Recovery actions bypass Shared Memory CPE PersistenceTable to go straight to DB

| Field | Details |
|---|---|
| **Toggle Name** | System Toggle: CPE - Recovery actions bypass Shared Memory CPE PersistenceTable to go straight to DB |
| **Confluence Page** | [View Page](https://confluence.mastercard.int/spaces/MPGSIOG/pages/2376453533/System+Toggle+CPE+-+Recovery+actions+bypass+Shared+Memory+CPE+PersistenceTable+to+go+straight+to+DB) |
| **Team Responsible** | Team CE |
| **Applications Affected** | CPE |
| **Is S2A Toggle** | FALSE |
| **Current Status** | As of 24.2 Release Date - MTF: Disabled for all; Production: Disabled for all |

### Summary
This is an alternative approach to the fix which System Toggle: Allow lenient updates to CPE PersistenceTable based off Shared Memory state sought to address. When the Shared Memory Persistence table is active in CPE not every SQL update is sent to the DB, so this toggle defers to the DB for recovery actions when required. It ensures transaction durability under failure conditions by forcing direct DB persistence during recovery.

### Source Code

#### `StandardTransactionController.java` · Line 463 · [CPE]

##### 🟢 Toggle ON — Business Impact
***Business:*** ***During recovery actions*** (e.g. after a system checkpoint), the transaction controller is forced to write directly to the persistent database — bypassing the in-memory shared memory persistence table. This eliminates recovery failures caused by stale or unavailable shared memory state, ensuring transaction durability under failure conditions.
***Field Impact:*** Internal only — no TSPI/ISO/acquirer fields affected. Internal: `setInSharedMemory(false)` called; `updateRestorable(true)` called so transaction persists exclusively to DB during checkpoint recovery.

##### 🔴 Toggle OFF — Business Impact
***Business:*** ***Recovery actions use the shared memory CPE persistence table first*** — the standard path which can fail if shared memory is stale or corrupted. Transactions may not be durably persisted to DB during recovery scenarios.
***Field Impact:*** Internal only — `setInSharedMemory()` not forced to false; `updateRestorable()` called with false so standard shared memory persistence path used.

#### `PersistenceTable.java` · Line 148 · [CPE]

##### 🟢 Toggle ON — Business Impact
***Business:*** ***During `insertNew()` for a new Restorable transaction***, if shared memory is used and the entry is successfully inserted into the in-memory table, the gateway additionally marks the transaction as `setOriginallyInSharedMemory(true)` — recording that it was originally written to shared memory before any recovery bypass. This tracking flag enables post-recovery reconciliation to know which transactions were initially in shared memory before the bypass took effect.
***Field Impact:*** Internal only — no TSPI/ISO/acquirer fields affected. Internal: `Toggles.isToggleOn(TOGGLE_RECOVERY_ACTIONS_BYPASS_SHARED_MEMORY)` at line 148; `restorable.setOriginallyInSharedMemory(true)` called when toggle ON and shared memory insert succeeded; flag used in downstream recovery reconciliation.

##### 🔴 Toggle OFF — Business Impact
***Business:*** ***The `originallyInSharedMemory` flag is not set*** during `insertNew()` — transactions written to shared memory do not carry the reconciliation marker. Recovery bypass tracking not applied at the PersistenceTable insert layer.
***Field Impact:*** Internal only — `setOriginallyInSharedMemory()` not called; recovery bypass tracking flag absent from newly inserted Restorable entries.

### Implementation Details

| Field | Details |
|---|---|
| **Implementation Class** | `StandardTransactionController`, `PersistenceTable` |
| **Line Number(s)** | 463, 148 |
| **Repository** | CPE |

---

## Toggle 31: Shared Memory CPE PersistenceTable

| Field | Details |
|---|---|
| **Toggle Name** | Shared Memory CPE PersistenceTable |
| **Confluence Page** | [View Page](https://confluence.mastercard.int/spaces/MPGSIOGWIP/pages/1112672829/System+Toggle+Allow+lenient+updates+to+CPE+PersistenceTable+based+off+Shared+Memory+state) |
| **Team Responsible** | Team CE |
| **Applications Affected** | CPE |
| **Is S2A Toggle** | FALSE |
| **Current Status** | As of 24.1 Release Date - MTF: Disabled for all; Production: Disabled for all |

### Summary
Prevent the update SQL for CpePersistenceTable from being needlessly restrictive in its update — specifically the version match now allows equal to or less than the submitted amount. This change allows PersistenceTable updates to succeed when shared memory is in use, reducing unnecessary OptimisticUpdateFailedExceptions for in-flight transactions.

### 🟢 Toggle ON Impact

**Business Impact:**
***When ON***, the CPE PersistenceTable update SQL uses a lenient (less strict) version matching condition — the update succeeds even if the stored version is less than or equal to the submitted version, not only strictly equal. This prevents unnecessary `OptimisticUpdateFailedExceptions` when Shared Memory is active and version numbers may not be in strict sync. Reduces failed transaction recovery actions.

**Field Impact:**
Internal only — no TSPI/ISO/acquirer fields affected. Internal: `UPDATE_RESTORABLE` SQL used (allows `version <= submitted`); prevents `OptimisticUpdateFailedException` for valid in-flight transactions managed by Shared Memory CPE PersistenceTable.

### 🔴 Toggle OFF Impact

**Business Impact:**
***When OFF***, the strict version-matching `UPDATE_RESTORABLE_STRICT_VERSION` SQL is used — the update only succeeds if the stored version exactly matches the expected previous version. In Shared Memory scenarios this can cause unnecessary `OptimisticUpdateFailedExceptions` for valid transactions.

**Field Impact:**
Internal only — `UPDATE_RESTORABLE_STRICT_VERSION` SQL used; stricter optimistic lock version check applied; recovery actions more likely to fail if Shared Memory version is slightly ahead.

### Implementation Details

| Field | Details |
|---|---|
| **Implementation Class** | `PersistenceTableDao` |
| **Line Number(s)** | 283 |
| **Repository** | CPE |

---

## Toggle 32: System Toggle: Reversal Daemon delays remote takeovers

| Field | Details |
|---|---|
| **Toggle Name** | System Toggle: Reversal Daemon delays remote takeovers |
| **Confluence Page** | [View Page](https://confluence.mastercard.int/spaces/MPGSIOG/pages/2376453206/System+Toggle+Reversal+Daemon+delays+remote+takeovers) |
| **Team Responsible** | Team Green |
| **Applications Affected** | CPE, PS |
| **Is S2A Toggle** | FALSE |
| **Current Status** | 22.2 Release - UAT: Disabled for all; Production: Disabled for all |

### Summary
The Reversal Daemon views persistence table entries as being owned by a single instance (recorded by IP address). This toggle introduces a distinction between remote entries and same-site entries and applies longer inactivity timeouts to remote entries, giving same-site processing priority and reducing cross-DC conflicts during abandonment takeover.

### 🟢 Toggle ON Impact

**Business Impact:**
***When ON*** (alone or combined with the replication lag toggle), the Reversal Daemon processes same-site abandoned entries first via `findAndTakeoverRemoteAbandonedEntries(SAME_SITE)`, then determines a configurable remote entry time limit before processing remote abandoned entries — delaying remote takeovers to give same-site processing priority and reduce cross-DC conflicts.

**Field Impact:**
Internal daemon processing only — no TSPI/ISO/acquirer fields affected. Internal: `isRemoteTakeoverToggleOn` drives `SAME_SITE` takeover first then `REMOTE_SITE` with `determineRemoteEntryTimeLimit()`; when OFF, `NON_LOCAL` takeover with `m_sameSiteTimeLimit` used instead.

### 🔴 Toggle OFF Impact

**Business Impact:**
***When OFF*** (and replication lag toggle also OFF), the Reversal Daemon uses the `NON_LOCAL` takeover path with the standard `sameSiteTimeLimit` — no differentiation between same-site and remote abandoned entries; both processed together without the prioritised same-site delay.

**Field Impact:**
Internal only — `findAndTakeoverRemoteAbandonedEntries(NON_LOCAL)` called; remote takeover not delayed; same-site and remote entries processed with the same time limit.

### Implementation Details

| Field | Details |
|---|---|
| **Implementation Class** | `ReversalDaemon` |
| **Line Number(s)** | 448 |
| **Repository** | CPE |

---

## Toggle 33: System Toggle: Use Enhanced Optimistic Lock With Terminal Batch Counters

| Field | Details |
|---|---|
| **Toggle Name** | System Toggle: Use Enhanced Optimistic Lock With Terminal Batch Counters |
| **Confluence Page** | [View Page](https://confluence.mastercard.int/spaces/MPGSIOG/pages/2376453228/System+Toggle+Use+Enhanced+Optimistic+Lock+With+Terminal+Batch+Counters) |
| **Team Responsible** | MPGS Continuing Engineering |
| **Applications Affected** | Card Payment Engine |
| **Is S2A Toggle** | FALSE |
| **Current Status** | MPGS 22.1.1 Release |

### Summary
This toggle is being used to roll out Enhanced Optimistic Lock with Terminal Batch Counters. It introduces the non-key field `stan` to the optimistic lock for Terminal Batch Counters, so that the SQL WHERE clause includes all four fields (terminal, acqBatch, batchSize, and stan), reducing false-update collisions under high-throughput concurrent terminal processing.

### 🟢 Toggle ON Impact

**Business Impact:**
***When updating the acquirer counter*** in the terminal batch counter table, the enhanced optimistic lock SQL is used — the WHERE clause includes all four fields: `terminal`, `acqBatch`, `batchSize` AND `stan`. This tighter lock prevents concurrent updates when the STAN has also changed, reducing false-update collisions for high-throughput terminals.

**Field Impact:**
Internal only — no TSPI/ISO/acquirer fields affected. Internal: `UPDATE_SQL_TOGGLE_ON` executed: `WHERE terminal=? AND acqBatch=? AND batchSize=? AND stan=?`; all four optimistic lock columns checked.

### 🔴 Toggle OFF Impact

**Business Impact:**
***When OFF***, the acqBatch counter update uses the legacy three-field WHERE clause — `terminal`, `acqBatch`, and `batchSize` only; `stan` is excluded from the lock check (`UPDATE_SQL_TOGGLE_OFF`). Less precise optimistic locking; concurrent STAN changes may not be detected under heavy concurrent terminal load.

**Field Impact:**
Internal only — `UPDATE_SQL_TOGGLE_OFF`: `WHERE terminal=? AND acqBatch=? AND batchSize=?` (`stan` not checked); `stan` stripped from `sqlParams`/`sqlTypes` arrays.

### Implementation Details

| Field | Details |
|---|---|
| **Implementation Class** | `TerminalBatchCounterDaoImpl` |
| **Line Number(s)** | 161 |
| **Repository** | CPE |

---

## Toggle 34: Allow Network Data Tag in DE123 for domestic card brand transactions

| Field | Details |
|---|---|
| **Toggle Name** | Allow Network Data Tag in DE123 for domestic card brand transactions |
| **Confluence Page** | [View Page](https://confluence.mastercard.int/spaces/MPGSIOG/pages/2376453669/Allow+Network+Data+Tag+in+DE123+for+domestic+card+brand+transactions) |
| **Team Responsible** | T-Tanuki |
| **Applications Affected** | Card Payment engine |
| **Is S2A Toggle** | FALSE |
| **Current Status** | As of 25.6 Release Date - MTF: Enabled for pilot MSOs; Production: Disabled |

### Summary
As part of this story a new tag (NWD) is introduced to be sent in DE123 in the ISO message to RSC for Jaywan card transactions processed domestically. This feature toggle enables or disables this Network Data field from being sent to RSC in S2I messages for Target, ensuring acquirer networks can correctly identify and process domestic card brand transactions.

### 🟢 Toggle ON Impact

**Business Impact (Class: `IsoDataField123Populator.java` · Line 1434):**
***For Jaywan domestic card brand transactions*** (and standalone refunds with Jaywan parent), the NWD (Network Data) tag is appended to ISO DE123 in the S2I acquirer message — enabling acquirer networks to identify and process domestic card brand transactions with the correct network data identifier.

**Field Impact:**
***ISO DE123*** (Tag Data) field includes NWD tag with `NWD_MCC` value when card brand is `JAYWAN`; appended via `sbDE123.append(format(NWD_TAG, NWD_MCC))`; for standalone refunds, parent `shoppingTransaction` card brand data also checked.

**Business Impact (Class: `PaymentAdaptorImpl.java` · Line 237):**
***For standalone refund transactions***, card brand data is forcibly updated on the shopping transaction before the transaction controller is set up — ensuring Jaywan domestic card brand data is available on the transaction for correct DE123 NWD tag population.

**Field Impact:**
Internal processing only — no direct TSPI/ISO field affected; ensures `cardBrandData` populated on `shoppingTransaction` so `IsoDataField123Populator` can correctly populate ISO DE123 NWD tag for domestic card brand standalone refunds.

### 🔴 Toggle OFF Impact

**Business Impact (Class: `IsoDataField123Populator.java` · Line 1434):**
***NWD tag is not appended*** to ISO DE123 for Jaywan domestic card transactions — domestic card brand network data absent from the S2I acquirer message.

**Field Impact:**
***ISO DE123*** does not contain NWD tag; domestic card brand network routing data not sent to acquirer.

**Business Impact (Class: `PaymentAdaptorImpl.java` · Line 237):**
***Card brand data update for standalone refunds*** with DE123 toggle is skipped — if card brand data was absent on the shopping transaction, the NWD tag may be omitted from ISO DE123.

**Field Impact:**
Internal only — `updateCardBrandDataOnShoppingTransaction()` not forced for standalone refunds; DE123 NWD population depends on pre-existing card brand data only.

### Implementation Details

| Field | Details |
|---|---|
| **Implementation Class** | `IsoDataField123Populator`, `PaymentAdaptorImpl` |
| **Line Number(s)** | 1434, 237 |
| **Repository** | CPE |

---

## Toggle 35: Random Terminal Allocation

| Field | Details |
|---|---|
| **Toggle Name** | Random Terminal Allocation |
| **Confluence Page** | [View Page](https://confluence.mastercard.int/spaces/MPGSIOG/pages/2376453312/Random+Terminal+Allocation) |
| **Team Responsible** | CE |
| **Applications Affected** | Card Payment Engine |
| **Is S2A Toggle** | FALSE |
| **Current Status** | As of 22.6.0 Release Date |

### Summary
This toggle spreads transactions across terminals to avoid delays caused by VOID transactions waiting for the same terminal. When enabled, a terminal is chosen at random from free terminals, reducing contention and improving response times. When disabled, terminals are allocated in deterministic sequential order.

### 🟢 Toggle ON Impact

**Business Impact:**
***When a free terminal needs to be allocated*** for a transaction (and the system is not in DEVELOPMENT mode), the gateway selects a free terminal at random — distributing transaction load evenly across all available terminals and preventing hot-spots where the first terminal in the list always receives disproportionate traffic.

**Field Impact:**
Internal only — no TSPI/ISO/acquirer fields affected. Internal: `allocateRandomFreeTerminal()` called; terminal selected via `m_freeTerminalRandomiser.nextInt(m_freeTerminals.size())` random index rather than `iterator.next()` sequential order.

### 🔴 Toggle OFF Impact

**Business Impact:**
***Terminals are allocated in deterministic sequential order*** (first available in the iterator) — the first free terminal in the list always receives new transactions first, potentially creating load imbalance and hot-spots under high traffic.

**Field Impact:**
Internal only — terminal selection uses `Iterator.next()` sequential first-available logic; no random distribution of transaction load.

### Implementation Details

| Field | Details |
|---|---|
| **Implementation Class** | `CoreTerminalPool` |
| **Line Number(s)** | 119 |
| **Repository** | CPE |

---

## Toggle 36: Use Status Code when calculating if PSD2 Exemption has been granted by Visa

| Field | Details |
|---|---|
| **Toggle Name** | Use Status Code when calculating if PSD2 Exemption has been granted by Visa |
| **Confluence Page** | [View Page](https://confluence.mastercard.int/spaces/MPGSIOG/pages/2376453231/Use+Status+Code+when+calculating+if+PSD2+Exemption+has+been+granted+by+Visa) |
| **Team Responsible** | CE Team (Continuous Engineering) |
| **Applications Affected** | ThreeDSService |
| **Is S2A Toggle** | FALSE |
| **Current Status** | 22.3 Release |

### Summary
This toggle enables a tighter logic which verifies that Visa has sent status code 89 indicating PSD2 exemption. When enabled the gateway will check Visa status code 89 in addition to merchant request.

### 🟢 Toggle ON Impact

**Business Impact:**
⚠️ *Implementation not found in analysed repositories* — Toggle may exist in an external PSD2/authentication service repo not present in this workspace. When enabled, the gateway applies tighter PSD2 exemption validation by requiring Visa status code 89 to be present before granting exemption, in addition to the merchant request signal.

**Field Impact:**
Unknown — toggle likely controls whether HTTP status code from Visa PSD2 exemption response is used to determine if exemption was granted. No constant declaration or `isToggleOn()` call located in CPE, Orchestrator, DirectAPI, BusinessService, MSOUI, or Console.

### 🔴 Toggle OFF Impact

**Business Impact:**
***When OFF or absent, the legacy/default Visa PSD2 exemption determination logic applies*** — status-code-based verification is not enforced; exemption may be granted based on merchant request alone without confirming Visa status code 89.

**Field Impact:**
Unknown — no codebase implementation rows found. Legacy PSD2 exemption path applies.

### Implementation Details

| Field | Details |
|---|---|
| **Implementation Class** | ⚠️ `NOT_FOUND` — confirmed absent from all analysed repositories |
| **Line Number(s)** | N/A |
| **Repository** | UNKNOWN — likely ThreeDSService (external repo not in workspace) |

---

## Toggle 37: Use Authentication Status when performing Transaction Filtering

| Field | Details |
|---|---|
| **Toggle Name** | Use Authentication Status when performing Transaction Filtering |
| **Confluence Page** | [View Page](https://confluence.mastercard.int/spaces/MPGSIOG/pages/2376453370/Use+Authentication+Status+When+Performing+Transaction+Filtering) |
| **Team Responsible** | Heimdall |
| **Applications Affected** | threedsservice, cardpaymentengine |
| **Is S2A Toggle** | FALSE |
| **Current Status** | 23.3.0 Release |

### Summary
This toggle ensures transaction filtering rules are applied to 'unenrolled' EMV 3DS authentication. When enabled, transaction filtering rules are applied to unenrolled authentications to prevent acceptance of risky transactions. When disabled, unenrolled authentications bypass 3DS-aware filtering.

### 🟢 Toggle ON Impact

**Business Impact:**
***The authentication status*** from the 3DS cardholder authentication result is included in the risk assessment request sent to the Risk SPI — giving the risk provider full 3DS authentication outcome context to make more accurate transaction filtering decisions (e.g. distinguish authenticated vs attempted vs failed 3DS).

**Field Impact:**
Internal RSPI request field only — `authentication.authenticationStatus` populated in `RiskAssessmentRequest2` from `cardholderAuthenticationResult.getAuthenticationStatus()`; this field flows into risk provider transaction filtering logic.

### 🔴 Toggle OFF Impact

**Business Impact:**
***Authentication status is NOT included*** in the risk assessment request — the risk provider evaluates transaction filtering without knowing the 3DS authentication outcome. Less context available for risk decisions; authentication status absent from risk request.

**Field Impact:**
`authentication.authenticationStatus` not set in `RiskAssessmentRequest2`; risk provider transaction filtering operates without 3DS status information.

### Implementation Details

| Field | Details |
|---|---|
| **Implementation Class** | `RiskAssessmentRequestBuilder` |
| **Line Number(s)** | 381 |
| **Repository** | CPE |

---

## Toggle 38: Bypass 3DS Transaction Filtering for TAS Passkey transactions

| Field | Details |
|---|---|
| **Toggle Name** | Bypass 3DS Transaction Filtering for TAS Passkey transactions |
| **Confluence Page** | [View Page](https://confluence.mastercard.int/spaces/MPGSIOG/pages/2376453591/Bypass+3DS+Transaction+Filtering+for+TAS+Passkey+transactions) |
| **Team Responsible** | Team Heimdall |
| **Applications Affected** | cardPaymentEngine |
| **Is S2A Toggle** | FALSE |
| **Current Status** | 24.7 Release - MTF: Enabled for test MSOs; Production: Disabled |

### Summary
This feature toggle configures the ability to bypass 3DS Transaction Filtering for TAS Passkey transactions (PAY and AUTHORIZE) when criteria match (SchemeType=MASTERCARD, SCHEME_TOKEN and ECI 02/06). Prevents false-positive transaction filtering rejections for valid Mastercard Passkey-authenticated payments.

### 🟢 Toggle ON Impact

**Business Impact:**
***For TAS Passkey-authenticated transactions*** (Mastercard Scheme Token with `devicePayment.eciIndicator=02/06` and no ACS ECI) the 3DS authentication details are cleared from the risk assessment request — preventing incorrect 3DS-based transaction filtering rejections for passkey-authenticated payments. Merchants accepting Mastercard Passkey tokenized payments can process them without risk filter false positives.

**Field Impact:**
`authenticationDetails` set to `null` in `RiskAssessmentRequest2` for qualifying TAS Passkey transactions (`isTasPasskeyAuthenticatedTransaction()` returns true); authentication block omitted from RSPI risk request.

### 🔴 Toggle OFF Impact

**Business Impact:**
***3DS authentication details are NOT bypassed*** for TAS Passkey transactions — these transactions go through the standard 3DS-based transaction filtering path which may incorrectly reject valid passkey-authenticated payments.

**Field Impact:**
`populateAuthenticationDetails()` continues to set `authentication` and `authenticationDetails` in `RiskAssessmentRequest2` for all transactions including TAS Passkey ones; risk provider applies 3DS filtering rules.

### Implementation Details

| Field | Details |
|---|---|
| **Implementation Class** | `RiskAssessmentRequestBuilder` |
| **Line Number(s)** | 345 |
| **Repository** | CPE |

---

## Toggle 39: Send Authentication fields in RiskSPI and AuthenticationStatusCode field in TSPI

| Field | Details |
|---|---|
| **Toggle Name** | Send Authentication fields in RiskSPI and AuthenticationStatusCode field in TSPI |
| **Confluence Page** | [View Page](https://confluence.mastercard.int/spaces/MPGSIOG/pages/2376453448/Send+Authentication+fields+in+RiskSPI+and+AuthenticationStatusCode+field+in+TSPI) |
| **Team Responsible** | T-Sombrero |
| **Applications Affected** | Target-CPE |
| **Is S2A Toggle** | TRUE |
| **Current Status** | 24.1.0 Release - MTF: Disabled for all |

### Summary
Deprecates `payerAuthenticationEci` and adds `payerAuthentication.statusCode` and other fields for RiskSPI; adds `AuthenticationStatusCode` in TSPI mapped to `transaction.authenticationStatus`. This toggle affects both the MEGA JSON (S2A/RSPI) path and the T-SPI acquirer message path.

### 🟢 Toggle ON Impact

**Business Impact (Class: `JsonMegaMessageRequestBuilder.java` · Line 3810):**
***The AuthenticationStatusCode field*** is included in the MEGA JSON (S2A/RSPI) authentication block — giving the RSPI risk provider and MEGA acquirer full 3DS authentication status code context. Enables risk providers and acquirers to make decisions based on the precise authentication status outcome.

**Field Impact:**
TSPI: `Transaction` (`AuthenticationStatusCode` field) set from `m_authentication.getAuthenticationStatus()` in MEGA JSON message; sent to RSPI/S2A acquirer when authentication data is present.

**Business Impact (Class: `TspiRequestMessageBuilder.java` · Line 2972):**
***The AuthenticationStatusCode field*** is included in the T-SPI acquirer transaction message authentication block — giving T-SPI acquirers full 3DS authentication status code context for authorization decisions.

**Field Impact:**
TSPI: `Transaction.AuthenticationStatusCode` (`AuthenticationStatusCodeEnum`) set from `m_authentication.getAuthenticationStatus()` in T-SPI message; sent to T-SPI acquirer when authentication data is present.

### 🔴 Toggle OFF Impact

**Business Impact (Class: `JsonMegaMessageRequestBuilder.java` · Line 3810):**
***AuthenticationStatusCode is NOT included*** in the MEGA JSON authentication block — risk providers and MEGA acquirers receive authentication data without the status code.

**Field Impact:**
TSPI: `Transaction.AuthenticationStatusCode` absent from MEGA JSON message; authentication status not sent to RSPI/S2A path.

**Business Impact (Class: `TspiRequestMessageBuilder.java` · Line 2972):**
***AuthenticationStatusCode is NOT included*** in the T-SPI message authentication block — T-SPI acquirers receive authentication data without the explicit status code value.

**Field Impact:**
TSPI: `Transaction.AuthenticationStatusCode` absent from T-SPI acquirer message.

### Implementation Details

| Field | Details |
|---|---|
| **Implementation Class** | `JsonMegaMessageRequestBuilder`, `TspiRequestMessageBuilder` |
| **Line Number(s)** | 3810, 2972 |
| **Repository** | CPE |

> ⚠️ *S2A Note: This toggle directly controls the `AuthenticationStatusCode` field in the MEGA JSON (S2A/RSPI) message sent via the `JsonMegaMessageRequestBuilder`. The `AuthenticationStatusCode` is a TSPI-level field mapped from `transaction.authenticationStatus` — it provides the S2A/RSPI acquirer and risk provider with the precise 3DS authentication outcome (e.g. AUTHENTICATED, ATTEMPTED, FAILED). When enabled, this enriches both the S2A MegaMessage flow (via `JsonMegaMessageRequestBuilder`) and the T-SPI acquirer message flow (via `TspiRequestMessageBuilder`) with full authentication status context.*

---

## Toggle 40: Store PARes and VERes in Postgres only

| Field | Details |
|---|---|
| **Toggle Name** | Store PARes and VERes in Postgres only |
| **Confluence Page** | [View Page](https://confluence.mastercard.int/spaces/MPGSIOG/pages/2376452959/Store+PARes+and+VERes+in+Postgres+only) |
| **Team Responsible** | MPGS Team 08 (BERGEN) |
| **Applications Affected** | Card Payment Engine, Merchant manager, Merchant Administrator |
| **Is S2A Toggle** | FALSE |
| **Current Status** | MPGS 19.1.0 Release |

### Summary
Emergency toggle to store ThreeDs PARes/VERes in Postgres only instead of Cassandra. Only to be enabled if issues are found in Cassandra persistence. Enables a clean migration path away from Cassandra for 3DS document storage.

### 🟢 Toggle ON Impact

**Business Impact:**
***When this toggle is ON (Cassandra persistence disabled)*** , PARes/VERes 3DS documents are stored ONLY in Postgres — Cassandra is bypassed entirely. The encrypted PARes/VERes is stored directly in Postgres via `encryptedString.get()`; no Cassandra write is attempted. Enables migration away from Cassandra for 3DS document storage.

**Field Impact:**
Internal persistence only — no TSPI/ISO/acquirer fields affected. Internal: `isCassandraPersistenceUnavailable()` returns true; `isCassandraPersistenceAvailable()` returns false; `storeInCassandra()` not called; full encrypted PARes/VERes written to Postgres.

### 🔴 Toggle OFF Impact

**Business Impact:**
***Cassandra persistence is AVAILABLE (toggle OFF)*** — PARes/VERes are stored in Cassandra (if available) AND potentially also in Postgres depending on the `CASSANDRA_ONLY` toggle state. Standard dual-store behavior applies.

**Field Impact:**
Internal only — `isCassandraPersistenceAvailable()` returns true; `storeInCassandra()` invoked; Cassandra receives PARes/VERes; Postgres receives value based on `persistInCassandraOnly()` flag.

### Implementation Details

| Field | Details |
|---|---|
| **Implementation Class** | `CassandraThreeDsTogglesUtils` |
| **Line Number(s)** | 76 |
| **Repository** | CPE |

---

## Toggle 41: Scheme Transaction Throttle for WS API - Passive Mode

| Field | Details |
|---|---|
| **Toggle Name** | Scheme Transaction Throttle for WS API - Passive Mode |
| **Confluence Page** | [View Page](https://confluence.mastercard.int/spaces/MPGSIOG/pages/2376453092/Scheme+Transaction+Throttle+for+WS+API+-+Passive+Mode) |
| **Team Responsible** | Team Centaurus |
| **Applications Affected** | WS API |
| **Is S2A Toggle** | FALSE |
| **Current Status** | 21.1.1 Release |

### Summary
Functionality added to route S2I Acquirer transactions to Scheme Transaction Throttle service for TPE compliance; feature toggle used to control rollout. The Passive Mode variant allows monitoring of throttle decisions without enforcing them on live traffic.

### 🟢 Toggle ON Impact

**Business Impact:**
***When ON, `getMode()` returns Passive Mode*** — the Scheme Transaction Throttle service is invoked for applicable financial transactions (Visa/Mastercard/Mada/ITMX via S2I acquirer). Mode=Passive Mode is merged into the MEGA JSON request to the STT service; the BLOCK/PROCEED response is observed but NOT enforced — the transaction always proceeds regardless of the throttle decision. Enables monitoring without live traffic impact.

**Field Impact:**
Internal only — no TSPI/ISO/acquirer fields affected externally. Internal: `isToggleOn(SCHEME_TRANSACTION_THROTTLE_FOR_WS_API_PASSIVE_MODE)` at line 378; `getMode()` returns `PASSIVE_MODE`; STT service invoked; Mode field in MEGA JSON set to Passive Mode; BLOCK result from STT does not stop the transaction.

### 🔴 Toggle OFF Impact

**Business Impact:**
***When OFF (and Active Mode toggle also OFF), `getMode()` returns null*** — the STT service is not invoked at all; neither `checkTransactionThrottle()` nor `processBlockingRules()` contacts the STT endpoint. No throttle decisions are made.

**Field Impact:**
Internal only — `mode=null`; `invoke()` exits immediately without calling STT service; no throttle decisions or metrics recorded.

### Implementation Details

| Field | Details |
|---|---|
| **Implementation Class** | `SchemeTransactionThrottleHelper` |
| **Line Number(s)** | 378 |
| **Repository** | CPE |

---

## Toggle 42: Support STRIPE failover using Operations console

| Field | Details |
|---|---|
| **Toggle Name** | Support STRIPE failover using Operations console |
| **Confluence Page** | [View Page](https://confluence.mastercard.int/spaces/MPGSIOG/pages/2376452961/Support+STRIPE+failover+using+Operations+console) |
| **Team Responsible** | Team Bergen |
| **Applications Affected** | All OLTP applications |
| **Is S2A Toggle** | FALSE |
| **Current Status** | Introduced 19.2; target 21.2 usage |

### Summary
System toggle for robust failover rollout allowing Operations console and MCS to orchestrate stripe failovers; must be enabled as part of rollout prerequisites. When enabled, operators gain full control of stripe activation and deactivation via the Operations Console with multi-site awareness.

### 🟢 Toggle ON Impact

**Business Impact (Class: `FailoverController.java` · Line 134 · [Console]):**
***When ON, the Console failover controller allows operators*** to activate/deactivate STRIPE stripe units via the Operations Console UI — `isFailoverToggleOn()` returns true and stripe activation/deactivation requests are forwarded to `multiSiteConsistencyServiceClient`. When OFF, operator attempts to activate/deactivate stripes are blocked with a warning log.

**Field Impact:**
Internal Console admin operation — no TSPI/ISO/acquirer fields affected. Internal: `Toggles.isToggleOn(TOGGLE_SUPPORT_STRIPE_FAILOVER_USING_OPERATIONS_CONSOLE)` at line 134; `activateStripe()` and `deactivateStripe()` request forwarding gated by this toggle.

**Business Impact (Class: `RemoteStripeService.java` · Line 46 · [Console]):**
***When ON, the Console remote stripe service routes `isStripeActive` queries*** to the MultiSiteConsistencyService (multi-site aware) — enabling proper cross-site stripe state determination for Operations Console failover.

**Field Impact:**
Internal Console service routing only — no TSPI/ISO/acquirer fields affected. Internal: `Toggles.isToggleOn(TOGGLE_SUPPORT_STRIPE_FAILOVER_USING_OPERATIONS_CONSOLE)` at line 46; if ON, `rpcClient.sendAndReceive('MultiSiteConsistencyService', 'isStripeActive')` called; returns cross-site consistent stripe status.

### 🔴 Toggle OFF Impact

**Business Impact (Class: `FailoverController.java` · Line 134 · [Console]):**
***When OFF, all stripe activation/deactivation requests*** via the Operations Console are rejected with a warning — failover operations cannot be performed from the console; manual DB intervention required for stripe management.

**Field Impact:**
Internal only — `multiSiteConsistencyServiceClient` not called; stripe state unchanged.

**Business Impact (Class: `RemoteStripeService.java` · Line 46 · [Console]):**
***When OFF, `isStripeActive` queries are routed*** to the legacy `stripeService` (`sendAndReceive('stripeService', 'isStripeActiveForAsyncTasks')`) — legacy non-multi-site stripe status check used; may not reflect cross-site failover state.

**Field Impact:**
Internal only — legacy stripe service consulted instead of MultiSiteConsistencyService.

### Implementation Details

| Field | Details |
|---|---|
| **Implementation Class** | `FailoverController`, `RemoteStripeService` |
| **Line Number(s)** | 134, 46 |
| **Repository** | Console |

---

## Toggle 43: Enable replication lag tracking by MCS

| Field | Details |
|---|---|
| **Toggle Name** | Enable replication lag tracking by MCS |
| **Confluence Page** | [View Page](https://confluence.mastercard.int/spaces/MPGSIOG/pages/2376453137/Enable+replication+lag+tracking+by+MCS) |
| **Team Responsible** | Team Bergen |
| **Applications Affected** | Multi Site Consistency Service |
| **Is S2A Toggle** | FALSE |
| **Current Status** | Originally released 21.2.0; must not be turned on until 22.3.0 |

### Summary
Enables replication lag tracking by the MCS for Payment Engine and VPCM Payment Server; writes to replicationlag table at 1s intervals when enabled. Must not be turned on until the 22.3.0 release window to ensure compatibility with dependent infrastructure.

### 🟢 Toggle ON Impact

**Business Impact:**
Status: CONFIRMED_NOT_FOUND — Toggle display string not found in CPE, Orchestrator, DirectAPI, BusinessService, MSOUI, or Console `src/main/java` after full codebase search and registry keyword scan. Toggle likely resides in the MCS (Multi-site Consistency Service) or replication-specific service repo not present in this workspace.

**Field Impact:**
Unknown — toggle likely enables tracking of database replication lag metrics by the MCS component.

### 🔴 Toggle OFF Impact

**Business Impact:**
Status: CONFIRMED_NOT_FOUND — When OFF or absent, replication lag tracking by MCS is disabled; standard replication monitoring applies.

**Field Impact:**
Unknown.

### Implementation Details

| Field | Details |
|---|---|
| **Implementation Class** | NOT_FOUND |
| **Line Number(s)** | N/A |
| **Repository** | UNKNOWN — likely MCS repo (not in workspace) |

---

## Toggle 44: System Toggle: Enable DC Replication Locks

| Field | Details |
|---|---|
| **Toggle Name** | System Toggle: Enable DC Replication Locks |
| **Confluence Page** | [View Page](https://confluence.mastercard.int/spaces/MPGSIOG/pages/2376453409/System+Toggle+Enable+DC+Replication+Locks) |
| **Team Responsible** | Team Camelot |
| **Applications Affected** | multiSiteConsistencyService |
| **Is S2A Toggle** | FALSE |
| **Current Status** | 23.3 Release |

### Summary
Toggle for generating and replicating order-level locks between sites when enabled; depends on replication lag tracking toggle. Provides data-centre level coordination of order locks to ensure consistency across multi-site deployments.

### 🟢 Toggle ON Impact

**Business Impact:**
Status: CONFIRMED_NOT_FOUND — Toggle display string not found in CPE, Orchestrator, DirectAPI, BusinessService, MSOUI, or Console `src/main/java` after full codebase search and registry keyword scan. Toggle likely resides in the MCS (Multi-site Consistency Service) or DC-level infrastructure repo not present in this workspace.

**Field Impact:**
Unknown — toggle likely controls database replication locking behaviour across data centres.

### 🔴 Toggle OFF Impact

**Business Impact:**
Status: CONFIRMED_NOT_FOUND — When OFF or absent, DC replication locks not applied; standard replication path used.

**Field Impact:**
Unknown.

### Implementation Details

| Field | Details |
|---|---|
| **Implementation Class** | NOT_FOUND |
| **Line Number(s)** | N/A |
| **Repository** | UNKNOWN — likely MCS repo (not in workspace) |

---

## Toggle 45: Allow payment transaction with authentication return surcharge

| Field | Details |
|---|---|
| **Toggle Name** | Allow payment transaction with authentication return surcharge |
| **Confluence Page** | [View Page](https://confluence.mastercard.int/spaces/MPGSIOG/pages/2376453337/Allow+payment+transaction+with+authentication+return+surcharge) |
| **Team Responsible** | CE Team |
| **Applications Affected** | orchestrator |
| **Is S2A Toggle** | FALSE |
| **Current Status** | 22.8 Release |

### Summary
Toggle to control copying surcharge data into response for authenticated PURCHASE transactions when enabled; planned enablement in 22.8. Enables merchants using authentication-first flows to correctly propagate surcharge information from an authentication transaction into a subsequent payment operation.

### 🟢 Toggle ON Impact

**Business Impact:**
***When ON, if the latest transaction with a merchant charge is an AUTHENTICATION operation***, the order details (including surcharge/merchant charge data) from that authentication transaction are returned and applied to a subsequent payment request — enabling merchants to carry surcharge information from an authentication-first flow into a subsequent pay operation. Merchants using authentication-first flows with surcharge can correctly propagate those charges onto the payment.

**Field Impact:**
Internal order details propagation only — no TSPI/ISO/acquirer message fields directly affected. Internal: `Toggles.isToggleOn(ALLOW_PAYMENT_TRANSACTION_WITH_AUTHENTICATION_RETURN_SURCHARGE)` at line 89; if ON and latest transaction is AUTHENTICATION: `order.orderDetails` from that auth transaction returned; surcharge/charge data available to payment request.

### 🔴 Toggle OFF Impact

**Business Impact:**
***When OFF, the order details from an authentication-only transaction are only returned*** if all other transactions in the order are also authentication operations — a more restrictive condition. Mixed-operation orders where an auth transaction holds the surcharge data cannot propagate that surcharge to the payment transaction.

**Field Impact:**
Internal only — `order.orderDetails` from authentication not returned unless all transactions are AUTH type; surcharge from auth-only transactions not propagated to payment.

### Implementation Details

| Field | Details |
|---|---|
| **Implementation Class** | `MerchantChargeHelper` |
| **Line Number(s)** | 89 |
| **Repository** | Orchestrator |

---

## Toggle 46: Use Enhanced Certificate Sets

| Field | Details |
|---|---|
| **Toggle Name** | Use Enhanced Certificate Sets |
| **Confluence Page** | [View Page](https://confluence.mastercard.int/spaces/MPGSIOG/pages/2376453002/Use+Enhanced+Certificate+Sets) |
| **Team Responsible** | CE Team |
| **Applications Affected** | Business Service, MsoUI, MerchantManager |
| **Is S2A Toggle** | FALSE |
| **Current Status** | 20.1 Release |

### Summary
Enables using a new JSON DB field to store Certificate Sets for API authentication. Note: can only be enabled for ALL (global toggle). This toggle controls which certificate set storage path is used for API authentication certificate management across Business Service, MsoUI, and MerchantManager.

### 🟢 Toggle ON Impact

**Business Impact:**
***Enhanced Certificate Sets are used*** for API authentication — the new JSON DB field stores Certificate Sets, enabling improved certificate management and storage for API authentication across all affected applications.

**Field Impact:**
Not found in analysed repositories — toggle likely resides in a certificate management or HSM service repository not present in the workspace. Field impact unknown.

### 🔴 Toggle OFF Impact

**Business Impact:**
***Standard (legacy) Certificate Sets are used*** for API authentication — the existing certificate storage path applies; the new JSON DB field for Certificate Sets is not used.

**Field Impact:**
Not found in analysed repositories — standard certificate sets used for connections. Field impact unknown.

### Implementation Details

| Field | Details |
|---|---|
| **Implementation Class** | NOT_FOUND |
| **Line Number(s)** | N/A |
| **Repository** | UNKNOWN — toggle not found in CPE, Orchestrator, DirectAPI, BusinessService, MSOUI, or Console repositories |

---

## Toggle 47: Derive Amount Variability For CIT And MIT Recurring Transactions

| Field | Details |
|---|---|
| **Toggle Name** | Derive Amount Variability For CIT And MIT Recurring Transactions |
| **Confluence Page** | [View Page](https://confluence.mastercard.int/spaces/MPGSIOGWIP/pages/1108584799/Toggle+Derive+Amount+Variability+For+CIT+And+MIT+Recurring+Transactions) |
| **Team Responsible** | Coen |
| **Applications Affected** | Orchestrator |
| **Is S2A Toggle** | FALSE |
| **Current Status** | 24.4 Release |

### Summary
Toggle to derive and persist amountVariability for historic CIT/MIT recurring agreements (below API version 65); used to reduce processing risk. When enabled, the gateway computes whether a recurring agreement amount is FIXED or VARIABLE by comparing the current transaction amount to the stored agreement amount, and persists this derived value for future MIT transactions in the series.

### 🟢 Toggle ON Impact

**Business Impact (Class: `RecurringPaymentAgreementService.java` · Line 889 · [Orchestrator]):**
***For verify/auth/pay recurring transactions, the gateway derives amount variability*** (FIXED or VARIABLE) by comparing the current transaction amount to the stored agreement amount — enabling merchants and acquirers to receive the computed `amountVariability` indicator in agreement details. This is the CIT/MIT toggle for the payment processing flow.

**Field Impact:**
`agreement.amountVariability` (TSPI/merchant API response field) derived and set in recurring transaction series; `derivedAmountVariability` computed from amount comparison; applies for RECURRING agreement type when toggle is ON.

**Business Impact (Class: `AgreementDataService.java` · Line 327 · [Orchestrator]):**
***When persisting agreement data after a transaction, the derived amount variability value is stored*** in the agreement record — ensuring future transactions in the series have access to the computed FIXED/VARIABLE indicator.

**Field Impact:**
`agreement.amountVariability` (internal agreement scheme DTO field) — `derivedAmountVariability` set via `agreementSchemeDto.setDerivedAmountVariability()` when toggle is ON; persisted to agreement store for future MIT transactions.

**Business Impact (Class: `AgreementDetailsDecorator.java` · Line 62 · [Orchestrator]):**
***For WSAPI response versions 56–61 with RECURRING agreement type, the amount variability in the response is updated*** from the derived response value — ensuring merchants on older API versions receive corrected `amountVariability` in the agreement details section of retrieve responses.

**Field Impact:**
`agreement.amountVariability` (TSPI/merchant API response field) updated in response decorator for API versions 56–61 when request and response values differ; response `amountVariability` takes precedence.

### 🔴 Toggle OFF Impact

**Business Impact (Class: `RecurringPaymentAgreementService.java` · Line 889 · [Orchestrator]):**
***Amount variability is NOT derived*** for verify/auth/pay recurring transactions via this toggle — `canDeriveAmountVariabilityForVerifyAuthPay()` returns false unless the other CIT MIT captures toggle is also on.

**Field Impact:**
`agreement.amountVariability` not derived from this code path; merchants receive `amountVariability` only if supplied explicitly or via other logic.

**Business Impact (Class: `AgreementDataService.java` · Line 327 · [Orchestrator]):**
***Derived amount variability is NOT stored*** in the agreement record — `agreementSchemeDto.setDerivedAmountVariability()` not called; future MIT transactions in the series do not benefit from derived amount variability.

**Field Impact:**
`agreement.derivedAmountVariability` not persisted.

**Business Impact (Class: `AgreementDetailsDecorator.java` · Line 62 · [Orchestrator]):**
***Amount variability in the response is NOT updated*** from the derived response value for API versions 56–61 — merchants on these versions receive the request `amountVariability` unchanged regardless of response.

**Field Impact:**
`agreement.amountVariability` not updated by response decorator for API v56–61.

### Implementation Details

| Field | Details |
|---|---|
| **Implementation Class** | `RecurringPaymentAgreementService`, `AgreementDataService`, `AgreementDetailsDecorator` |
| **Line Number(s)** | 889, 327, 62 |
| **Repository** | Orchestrator |

---

## Toggle 48: Enable CIT MIT indicators for Mastercard

| Field | Details |
|---|---|
| **Toggle Name** | Enable CIT MIT indicators for Mastercard |
| **Confluence Page** | [View Page](https://confluence.mastercard.int/spaces/MPGSIOG/pages/2376453235/Enable+CIT+MIT+indicators+for+Mastercard) |
| **Team Responsible** | MPGS Team Hercules |
| **Applications Affected** | cardPaymentEngine |
| **Is S2A Toggle** | FALSE |
| **Current Status** | Not specified |

### Summary
As part of F416939, new CIT MIT indicators for Mastercard are implemented. The toggle was implemented to enable the functionality to send new indicators in DE61SF4 and DE48SE22SF05 for Mastercard. When enabled, enhanced credential-on-file POS indicators are applied for Mastercard recurring and unscheduled transactions, and specific agreement fields are managed for Mastercard recurring series compliance.

### 🟢 Toggle ON Impact

**Business Impact (Class: `IsoDataField61Populator.java` · Line 411 · [CPE]):**
***Enhanced CIT/MIT credential-on-file indicators are applied for Mastercard recurring/unscheduled transactions*** — the correct POS terminal entry mode (DE61 sub-fields) reflects whether the transaction is a CIT or MIT with COF for Mastercard scheme. Acquirers receive correct CIT/MIT POS indicators in DE61 for compliance with Mastercard COF standards.

**Field Impact:**
ISO ***DE61 SF10*** (Cardholder-activated terminal indicator) and related POS sub-fields updated based on `isMastercardNewCOFIndicatorsTransaction()` result — correctly indicates CIT vs MIT for Mastercard stored/tokenised/to-be-stored transactions in RECURRING or UNSCHEDULED agreement types.

**Business Impact (Class: `RecurringPaymentAgreementDecorator.java` · Line 289 · [Orchestrator]):**
***For Mastercard recurring agreement transactions where agreement type is RECURRING, `amountVariability`, `numberOfPayments`, and `totalNumberOfPayments` are set to null*** in the agreement details decorator — aligning with Mastercard COF indicator requirements for recurring series.

**Field Impact:**
`agreement.amountVariability`, `agreement.numberOfPayments`, `agreement.totalNumberOfPayments` (TSPI/merchant API response fields) explicitly set to null for Mastercard recurring transactions in the decorator when toggle is ON and agreement type is RECURRING.

### 🔴 Toggle OFF Impact

**Business Impact (Class: `IsoDataField61Populator.java` · Line 411 · [CPE]):**
***Legacy CIT/MIT indicator logic applies for Mastercard*** — enhanced COF indicator mapping in DE61 not applied; POS terminal entry mode sub-fields use standard logic without Mastercard-specific COF distinction.

**Field Impact:**
ISO ***DE61 SF10*** and related CIT/MIT sub-fields set using legacy logic; Mastercard COF-specific POS indicator values not applied.

**Business Impact (Class: `RecurringPaymentAgreementDecorator.java` · Line 289 · [Orchestrator]):**
***Standard agreement details population applies*** — `amountVariability`/`numberOfPayments`/`totalNumberOfPayments` not cleared for Mastercard recurring transactions.

**Field Impact:**
`agreement.amountVariability`/`numberOfPayments`/`totalNumberOfPayments` populated with values from agreement DTO as normal; Mastercard-specific nullification not applied.

### Implementation Details

| Field | Details |
|---|---|
| **Implementation Class** | `IsoDataField61Populator`, `RecurringPaymentAgreementDecorator` |
| **Line Number(s)** | 411, 289 |
| **Repository** | CPE (IsoDataField61Populator), Orchestrator (RecurringPaymentAgreementDecorator) |

---

## Toggle 49: Enable Activity Calls to Protection Service

| Field | Details |
|---|---|
| **Toggle Name** | Enable Activity Calls to Protection Service |
| **Confluence Page** | [View Page](https://confluence.mastercard.int/spaces/MPGSIOG/pages/2376453141/Enable+Activity+Calls+To+Protection+Service) |
| **Team Responsible** | MPGS Team Hercules |
| **Applications Affected** | cardPaymentEngine |
| **Is S2A Toggle** | FALSE |
| **Current Status** | Not specified |

### Summary
Functionality has been implemented to detect and block unusual transactions on a merchant. In order to build statistics to determine whether a merchant is candidate of a carding attack, all transaction traffic for all merchants on the payment gateway is submitted via the Activity API. This toggle controls whether activity reporting calls are made to the Transaction Protection Service.

### 🟢 Toggle ON Impact

**Business Impact:**
***Activity calls to the Transaction Protection Service are enabled*** — transaction activity data is submitted to the Protection Service via the Activity API, enabling the service to build statistical baselines for detecting carding attacks and unusual transaction patterns on merchants.

**Field Impact:**
Not found in analysed repositories — toggle likely resides in the Protection Service or a related activity reporting repository not present in the workspace. Note: the related toggle "Enable Unusual Transaction Protection" (which calls `registerActivity()`) IS implemented in CPE `TransactionProtectionServiceImpl`.

### 🔴 Toggle OFF Impact

**Business Impact:**
***Activity calls to the Transaction Protection Service are disabled*** — transaction activity is not submitted to the Protection Service; no statistical data is built for carding attack detection. See also "Enable Unusual Transaction Protection" for related functionality.

**Field Impact:**
Not found in analysed repositories — when OFF or absent, activity calls to the Protection Service are not toggled by this specific toggle. Field impact unknown.

### Implementation Details

| Field | Details |
|---|---|
| **Implementation Class** | NOT_FOUND |
| **Line Number(s)** | N/A |
| **Repository** | UNKNOWN — toggle not found in CPE, Orchestrator, DirectAPI, BusinessService, MSOUI, or Console repositories |

---

## Toggle 50: Enable VISA Account Funding Transactions

| Field | Details |
|---|---|
| **Toggle Name** | Enable VISA Account Funding Transactions |
| **Confluence Page** | [View Page](https://confluence.mastercard.int/spaces/MPGSIOG/pages/2376453280/Enable+VISA+Account+Funding+Transactions) |
| **Team Responsible** | Team Hercules |
| **Applications Affected** | orchestrator, cardPaymentEngine, orderService |
| **Is S2A Toggle** | FALSE |
| **Current Status** | As of 22.8 Release Date |

### Summary
As per Feature F364002, Account Funding functionality for VISA Scheme is being added to the gateway in PI4/2022. This functionality will work as an enabler for supporting account funding for VISA merchants. When enabled, AFT-specific S2I ISO 8583 fields (DE108, DE54, DE48 SE36 SF05) are populated for Visa cards and Visa AFT-specific field validation is applied in the Orchestrator.

### 🟢 Toggle ON Impact

**Business Impact (Class: `S2IAcquirerHelper.java` · Line 752 · [CPE]):**
***The gateway checks whether Visa Account Funding Transactions (AFT) are enabled*** for a given card type — `isAccountFundingEnabledForVisa()` returns true only when toggle is ON and card is Visa. This gates S2I AFT-specific processing (e.g. ***DE108***, ***DE54***, ***DE48 SE36 SF05*** field population) for Visa cards.

**Field Impact:**
ISO ***DE108 SF01*** (Transaction Reference), ISO ***DE54*** (Additional Amounts / FX Fee), ISO ***DE48 SE36 SF05*** (Purpose of Payment) — these fields are populated for Visa AFT only when this toggle is ON and card type is Visa.

**Business Impact (Class: `AccountFundingValidator.java` · Line 208 · [Orchestrator]):**
***The Orchestrator AccountFundingValidator checks whether Visa AFT is enabled*** via `isToggleOn(TOGGLE_FOR_VISA_FUNDING_TRANSACTIONS)` — when ON, AFT-specific validation rules are applied to the `accountFunding` request fields for Visa cards. Merchants submitting Visa AFT requests receive full field validation (`purposeOfPayment`, `reference`, `foreignExchangeFee`).

**Field Impact:**
`accountFunding.purposeOfPayment`, `accountFunding.reference`, `accountFunding.foreignExchangeFee` (TSPI/merchant API request fields) validated against Visa AFT-specific rules when toggle is ON.

### 🔴 Toggle OFF Impact

**Business Impact (Class: `S2IAcquirerHelper.java` · Line 752 · [CPE]):**
***`isAccountFundingEnabledForVisa()` returns false regardless of card type*** — Visa AFT S2I message enrichment not applied; ***DE108***, ***DE54***, ***DE48 SE36 SF05*** not populated for Visa AFT transactions.

**Field Impact:**
ISO ***DE108 SF01***, ISO ***DE54***, ISO ***DE48 SE36 SF05*** absent for Visa AFT; standard S2I message built without AFT-specific fields.

**Business Impact (Class: `AccountFundingValidator.java` · Line 208 · [Orchestrator]):**
***Visa AFT validation not applied*** by this method — `isToggleOn` returns false; `accountFunding` fields not validated against Visa-specific AFT rules.

**Field Impact:**
`accountFunding.purposeOfPayment`/`reference`/`foreignExchangeFee` not validated by Visa AFT rules; validation falls through to generic/MC AFT rules only.

### Implementation Details

| Field | Details |
|---|---|
| **Implementation Class** | `S2IAcquirerHelper`, `AccountFundingValidator` |
| **Line Number(s)** | 752, 208 |
| **Repository** | CPE (S2IAcquirerHelper), Orchestrator (AccountFundingValidator) |

---

## Toggle 51: Return refund authorization data to merchants

| Field | Details |
|---|---|
| **Toggle Name** | Return refund authorization data to merchants |
| **Confluence Page** | [View Page](https://confluence.mastercard.int/spaces/MPGSIOG/pages/2376453113/Return+refund+authorization+data+to+merchants) |
| **Team Responsible** | MPGS Team Tesseract |
| **Applications Affected** | DirectAPI |
| **Is S2A Toggle** | FALSE |
| **Current Status** | As of 20.4 Release Date; MTF: Disabled for all; Production NA: Disabled for all; Production EU: Disabled for all; Production AP: Disabled for all; Production IN: Disabled for all |

### Summary
As a gateway, we want to restrict returning authorization data to merchants in refund response for refund authorization transaction so that if the merchants who are currently have not integrated to receive these data then their integration will not be broken. The authorization data in the refund response are not mandatory to be integrated by merchants.

### 🟢 Toggle ON Impact

**Business Impact (Class: `TransactionDataCommonService.java` · Line 632 · [Orchestrator]):**
***When enabled, refund authorisation code is returned to merchants*** in retrieval responses for transactions processed as online authorisation of refund — merchants can see the acquirer authorisation code for their online refunds.

**Field Impact:**
`transaction.authorizationCode` (TSPI/merchant API response field) returned for online-authorised refund transactions. Internal: `transactionRetrievalResponse.getTransaction().setAuthorisationCode()` not nullified.

### 🔴 Toggle OFF Impact

**Business Impact (Class: `TransactionDataCommonService.java` · Line 632 · [Orchestrator]):**
***When disabled, authorisation code is suppressed*** (set to null) for refund transactions processed as online authorisation — merchants do not receive the authorisation code for online refunds in retrieval responses.

**Field Impact:**
`transaction.authorizationCode` (TSPI/merchant API response field) set to null for online-authorised refund transactions where protocol source is not REPORTING.

### Implementation Details

| Field | Details |
|---|---|
| **Implementation Class** | `TransactionDataCommonService` |
| **Line Number(s)** | 632 |
| **Repository** | Orchestrator |

---

## Toggle 52: Enable Single Tap Transactions

| Field | Details |
|---|---|
| **Toggle Name** | Enable Single Tap Transactions |
| **Confluence Page** | [View Page](https://confluence.mastercard.int/spaces/MPGSIOG/pages/2376453585/System+Toggle+Enable+Single+Tap+Transactions) |
| **Team Responsible** | Team Pegasus |
| **Applications Affected** | Card Payment Engine (CPE) |
| **Is S2A Toggle** | FALSE |
| **Current Status** | From 24.1 Release Date; MTF: Enabled for all; Production NA: Enabled for all; Production EU: Enabled for all; Production AP: Enabled for all |

### Summary
Adding a new field in WS API to enable the merchant to flag the Single tap capability of the PoS terminal. Based on the flag, gateway will appropriately map the data elements for banknet/issuer. This toggle governs Single Tap transaction validation in the Orchestrator (auth and purchase operations) and Single Tap-specific S2I ISO 8583 field population in CPE.

### 🟢 Toggle ON Impact

**Business Impact (Class: `AuthorisationOperation.java` · Line 141 · [Orchestrator]):**
***For authorisation requests, Single Tap transaction validation is performed*** — `requestValidator.validateSingleTapTransaction()` is called to enforce Single Tap-specific business rules (e.g. amount restrictions, merchant eligibility). Merchants enabled for Single Tap transit payments receive proper validation of single-tap authorisation requests.

**Field Impact:**
Internal validation only — no TSPI/ISO/acquirer fields affected directly. Internal: `validateSingleTapTransaction()` invoked for authorisation; Single Tap-specific constraints enforced before request proceeds.

**Business Impact (Class: `PurchaseOperation.java` · Line 187 · [Orchestrator]):**
***For purchase (pay) requests, Single Tap transaction validation is enforced*** — `validateSingleTapTransaction()` called to apply Single Tap business rules for pay operations. Merchants can submit valid Single Tap payment transactions with correct enforcement.

**Field Impact:**
Internal validation only — `validateSingleTapTransaction()` invoked for purchase; Single Tap constraints enforced before pay request proceeds to acquirer.

**Business Impact (Class: `S2IAcquirerV1.java` · Line 2237 · [CPE]):**
***The Single Tap toggle state is captured at S2I message build time*** via `setIsToggleOnForSingleTapTransactions()` — this flag controls Single Tap-specific S2I ISO 8583 field population (e.g. DE61 transit indicators) for Mastercard auth/purchase messages sent to S2I acquirers.

**Field Impact:**
ISO ***DE61*** (Point of Service Data sub-fields) — Single Tap transit indicator sub-fields set based on `isToggleOnForSingleTapTransactions` flag; affects transit transaction type codes in S2I message.

### 🔴 Toggle OFF Impact

**Business Impact (Class: `AuthorisationOperation.java` · Line 141 · [Orchestrator]):**
***Single Tap transaction validation is NOT performed for authorisation requests*** — `validateSingleTapTransaction()` skipped; Single Tap-specific business rules not enforced. Merchants attempting Single Tap authorisations may bypass intended validation.

**Field Impact:**
Internal only — Single Tap validation logic skipped for auth requests.

**Business Impact (Class: `PurchaseOperation.java` · Line 187 · [Orchestrator]):**
***Single Tap validation skipped for pay requests*** — merchants can submit pay requests without Single Tap validation being applied.

**Field Impact:**
Internal only — Single Tap pay validation not applied.

**Business Impact (Class: `S2IAcquirerV1.java` · Line 2237 · [CPE]):**
***Toggle state captured as false*** — Single Tap-specific S2I field population not applied; DE61 transit Single Tap indicator sub-fields use standard logic.

**Field Impact:**
ISO ***DE61*** Single Tap transit sub-fields not set via Single Tap path.

### Implementation Details

| Field | Details |
|---|---|
| **Implementation Class** | `AuthorisationOperation`, `PurchaseOperation`, `S2IAcquirerV1` |
| **Line Number(s)** | 141, 187, 2237 |
| **Repository** | Orchestrator (AuthorisationOperation, PurchaseOperation), CPE (S2IAcquirerV1) |

---

## Toggle 53: Enable known fare transit with transportationMode

| Field | Details |
|---|---|
| **Toggle Name** | Enable known fare transit with transportationMode |
| **Confluence Page** | [View Page](https://confluence.mastercard.int/spaces/MPGSIOG/pages/2376453711/Enable+known+fare+transit+with+transportationMode) |
| **Team Responsible** | Team Pegasus |
| **Applications Affected** | Orchestrator, CPE |
| **Is S2A Toggle** | FALSE |
| **Current Status** | MTF: Enable for All Smoke test MSO's; Production NA: Disabled for all; Production EU: Disabled for all |

### Summary
Mastercard Gateway currently supports the `transportationMode` field only for the aggregated fare transit transactions. As per this feature, `transportationMode` is being added for processing known fare transit transactions starting from API version 100. The toggle governs storage of the transportation mode in the transaction DTO, S2I validation bypass, mandatory field enforcement in the Orchestrator, and inclusion in retrieval responses.

### 🟢 Toggle ON Impact

**Business Impact (Class: `TransactionDtoBuilderImpl.java` · Line 281 · [CPE]):**
***The `transportationMode` field from the transit known fare group is stored as a custom field*** on the transaction DTO during CPE transaction building — enabling downstream S2I message builders to include the transportation mode in the ISO message for known-fare transit transactions.

**Field Impact:**
Internal transaction DTO only — `transit.transportationMode` (TSPI/merchant API field) persisted as custom field in transaction DTO when toggle is ON and `transitGroup.knownFare.transportationMode` is present.

**Business Impact (Class: `S2IAcquirerV1.java` · Line 9970 · [CPE]):**
***During S2I message validation for Mastercard transit transactions, known-fare transactions with a valid transportation mode are allowed to bypass the strict `fareCollection` requirement*** — enabling Mastercard transit known-fare transactions with `transportationMode` to proceed without providing a `fareCollection` type.

**Field Impact:**
ISO message validation only — `transit.fareCollection` (TSPI/merchant API field) not required when toggle ON and `isTransitKnownFareTransaction()` is true; validation bypass allows known-fare messages through to S2I acquirer.

**Business Impact (Class: `RoutedServicesDelegate.java` · Line 479 · [Orchestrator]):**
***In the Orchestrator, when API version >= 100, `transportationMode` becomes a MANDATORY field*** for known-fare transit transactions — merchants on API v100+ must supply `transit.knownFare.transportationMode` or receive a `MissingFieldException`.

**Field Impact:**
`transit.knownFare.transportationMode` (TSPI/merchant API field) validated as mandatory for API version >= 100 known-fare transactions when toggle is ON; `MissingFieldException` thrown if absent.

**Business Impact (Class: `TransactionBuilder.java` · Line 394 · [CPE]):**
***In transaction retrieval responses, the `transportationMode` is included in the `TransitKnownFareGroup`*** returned to the merchant — merchants retrieving known-fare transit transactions see the transportation mode in the response if stored.

**Field Impact:**
`transit.knownFare.transportationMode` (TSPI/merchant API response field) populated in retrieval response when non-null and toggle is ON; `transitKnownFareGroup.setTransportationMode()` called.

### 🔴 Toggle OFF Impact

**Business Impact (Class: `TransactionDtoBuilderImpl.java` · Line 281 · [CPE]):**
***`transportationMode` is NOT stored as a custom field*** even if provided — `setTransitTransportationModeCustomField()` not called for known fare group; transportation mode absent from transaction DTO.

**Field Impact:**
`transit.knownFare.transportationMode` not propagated to transaction DTO; not available for downstream S2I/TSPI message building.

**Business Impact (Class: `S2IAcquirerV1.java` · Line 9970 · [CPE]):**
***Standard Mastercard transit validation applies*** — known-fare transactions are NOT exempt from `fareCollection` requirement; if `isMasterCardTransit()` is true, `fareCollection` and `transportationMode` fields are both mandatory.

**Field Impact:**
`transit.fareCollection` and `transit.transportationMode` (TSPI/merchant API fields) both validated as required; `MissingFieldException` thrown if either is absent.

**Business Impact (Class: `RoutedServicesDelegate.java` · Line 479 · [Orchestrator]):**
***`transportationMode` not enforced as mandatory for API v100+*** — known-fare transactions can proceed without `transportationMode` regardless of API version.

**Field Impact:**
`transit.knownFare.transportationMode` not validated as mandatory by `RoutedServicesDelegate`; merchants can omit it without error.

**Business Impact (Class: `TransactionBuilder.java` · Line 394 · [CPE]):**
***`transportationMode` NOT included in transit retrieval response*** — `transportationMode` absent from `TransitKnownFareGroup` in retrieve transaction/order API response.

**Field Impact:**
`transit.knownFare.transportationMode` absent from retrieval response.

### Implementation Details

| Field | Details |
|---|---|
| **Implementation Class** | `TransactionDtoBuilderImpl`, `S2IAcquirerV1`, `RoutedServicesDelegate`, `TransactionBuilder` |
| **Line Number(s)** | 281, 9970, 479, 394 |
| **Repository** | CPE (TransactionDtoBuilderImpl, S2IAcquirerV1, TransactionBuilder), Orchestrator (RoutedServicesDelegate) |

---

## Toggle 54: Auto reversals on final capture

| Field | Details |
|---|---|
| **Toggle Name** | Auto reversals on final capture |
| **Confluence Page** | [View Page](https://confluence.mastercard.int/spaces/MPGSIOG/pages/2376453158/Auto+reversals+on+final+capture) |
| **Team Responsible** | Team Bifrost |
| **Applications Affected** | CardPaymentEngine, Auth reversal service |
| **Is S2A Toggle** | FALSE |
| **Current Status** | As of 21.2 Release Date; MTF: Disabled for all; Production NA: Disabled for all; Production EU: Disabled for all; Production AP: Disabled for all |

### Summary
The functionality of automatic authorization reversals is currently supported in gateway when merchant wants to reverse the remaining authorization amount upon authorization expiry. This feature toggle is in place to enable following additional auto reversal capabilities — specifically, automatically reversing the original authorization when all expected captures have been completed (final capture scenario).

### 🟢 Toggle ON Impact

**Business Impact (Class: `IsoDataField123Populator.java` · Line 1361 · [CPE]):**
***Enables the gateway to automatically reverse the original authorization when all expected captures have been completed*** (final capture scenario) — `isFinalCapture()` returns true when toggle is ON AND acquirer expects gateway to reverse AND acquirer supports void-auth of partial capture AND `expectedNumberOfCaptures` is met. Merchants with acquirers configured for auto-reversal on final capture benefit from automatic authorization cleanup.

**Field Impact:**
Internal processing only — no ISO field affected directly by this check; `isFinalCapture()` result gates ISO ***DE123*** tag population for auto-reversal data and triggers the reversal flow. Internal: `acquirer.doesAcquirerExpectsGatewayToReverseOnFinalCapture()` and `supportsVoidAuthOfPartialCapture()` and `merchant.hasPrivilege(AUTO_AUTH_REVERSAL_ON_PARTIAL_CAPTURE_PRIVILEGE)` all evaluated.

### 🔴 Toggle OFF Impact

**Business Impact (Class: `IsoDataField123Populator.java` · Line 1361 · [CPE]):**
***`isFinalCapture()` always returns false*** — auto-reversal on final capture is disabled; gateway never automatically triggers authorization reversal after final capture completion regardless of acquirer and merchant configuration.

**Field Impact:**
Internal only — no auto-reversal processing; ISO ***DE123*** auto-reversal tag not populated; authorization not reversed after final capture.

### Implementation Details

| Field | Details |
|---|---|
| **Implementation Class** | `IsoDataField123Populator` |
| **Line Number(s)** | 1361 |
| **Repository** | CPE |

---

## Toggle 55: Set approvedAmount only when the transaction is approved

| Field | Details |
|---|---|
| **Toggle Name** | Set approvedAmount only when the transaction is approved |
| **Confluence Page** | [View Page](https://confluence.mastercard.int/spaces/MPGSIOG/pages/2376453518/Set+approvedAmount+only+when+the+transaction+is+approved) |
| **Team Responsible** | CE |
| **Applications Affected** | Orchestrator |
| **Is S2A Toggle** | FALSE |
| **Current Status** | Will be rolled out as part of 24.1.0.1 Release |

### Summary
This feature toggle was created to enable the fix applied for DE404023 (PBI000000114715). The fix will avoid setting `approvedAmount` when the transaction is not approved, preventing merchants from seeing a misleading non-zero `approvedAmount` for declined or errored S2A transactions.

### 🟢 Toggle ON Impact

**Business Impact (Class: `JsonMessageParserImpl.java` · Line 338 · [CPE]):**
***When ON, the `approvedAmount` returned in the MEGA JSON acquirer response is only populated when the transaction is actually approved*** — `isApproved()` checks `TransactionResponse.ResponseCode` via `QsiResponseExtent.getResponseByName(responseCode).isApproved()`; if not approved, `approvedAmount` remains null even when `TransactionResponse.AuthorizedAmount > 0` (a warning is logged). Prevents merchants from seeing a misleading non-zero `approvedAmount` for declined or errored S2A transactions.

**Field Impact:**
TSPI/response: `transaction.approvedAmount` (acquirer response field from MEGA JSON) — set from `TransactionResponse.AuthorizedAmount` (or fallback to `TransactionResponse.Amount`) only when `ResponseCode` is approved; null returned for non-approved transactions even when `AuthorizedAmount` is present.

### 🔴 Toggle OFF Impact

**Business Impact (Class: `JsonMessageParserImpl.java` · Line 338 · [CPE]):**
***When OFF, `approvedAmount` is always populated from `TransactionResponse.AuthorizedAmount`*** (or Amount fallback) regardless of approval status — declined or errored transactions may carry a non-zero `approvedAmount` in the S2A acquirer response.

**Field Impact:**
`transaction.approvedAmount` set unconditionally from `TransactionResponse.AuthorizedAmount`/`Amount`; approval status not checked; potentially misleading approved amount in declined S2A responses.

### Implementation Details

| Field | Details |
|---|---|
| **Implementation Class** | `JsonMessageParserImpl` |
| **Line Number(s)** | 338 |
| **Repository** | CPE |

---

## Toggle 56: Mastercard QR Transaction Identifiers

| Field | Details |
|---|---|
| **Toggle Name** | Mastercard QR Transaction Identifiers |
| **Confluence Page** | [View Page](https://confluence.mastercard.int/spaces/MPGSIOG/pages/2376453757/Mastercard+QR+Transaction+Identifiers) |
| **Team Responsible** | T-Bamboo |
| **Applications Affected** | WSAPI, CardPaymentEngine |
| **Is S2A Toggle** | FALSE |
| **Current Status** | As of 25.7.0 Release Date |

### Summary
Mastercard is enhancing its QR product offerings with two solutions: MCQR (Pay by Link) — a QR code that links to a payment page, used in face-to-face or in-store settings. XQR — integration with major digital wallets (like PayTM, Mercado Pago, Alipay) to support Mastercard payments. This toggle gates the population of Mastercard QR transaction identifiers in the S2I ISO 8583 message.

### 🟢 Toggle ON Impact

**Business Impact (Class: `S2IAcquirerHelper.java` · Line 748 · [CPE]):**
***`isQrInitiatedEnabledForMastercard()` returns true only when toggle is ON and card type is Mastercard*** — this gates the population of QR-initiated Mastercard transaction identifiers in the S2I ISO message. Acquirers receive the correct Mastercard QR transaction identifier sub-elements for QR-initiated payments.

**Field Impact:**
ISO ***DE48*** (Additional Data) sub-elements for Mastercard QR Transaction Identifiers populated when `isQrInitiatedEnabledForMastercard()` returns true; specific ***DE48*** SE/SF values for QR-initiated transactions included in S2I acquirer message.

### 🔴 Toggle OFF Impact

**Business Impact (Class: `S2IAcquirerHelper.java` · Line 748 · [CPE]):**
***`isQrInitiatedEnabledForMastercard()` returns false regardless of card type*** — QR transaction identifier fields not populated in S2I ISO message for Mastercard QR transactions.

**Field Impact:**
ISO ***DE48*** QR Transaction Identifier sub-elements absent from S2I acquirer message; QR-initiated Mastercard transactions not identified via ISO 8583.

### Implementation Details

| Field | Details |
|---|---|
| **Implementation Class** | `S2IAcquirerHelper` |
| **Line Number(s)** | 748 |
| **Repository** | CPE |

---

## Toggle 57: Enable New COF Token Value for T-SPI

| Field | Details |
|---|---|
| **Toggle Name** | Enable New COF Token Value for T-SPI |
| **Confluence Page** | [View Page](https://confluence.mastercard.int/spaces/MPGSIOG/pages/2376453223/Feature+Toggle+-+Enable+New+COF+Token+Value+for+T-SPI) |
| **Team Responsible** | T-Sombrero |
| **Applications Affected** | T-SPI |
| **Is S2A Toggle** | TRUE |
| **Current Status** | Post 22.2.0.6 release - MTF: Enabled for SYSTEST_MSO_DASH; AP/IN/NA/EU: Enabled for SYSTEST_MSO_DASH; To be enabled for all after non-test MSO verification |

### Summary
This toggle has been implemented to cater to the logic of rectifying the COF token value for T-SPI transactions. Current behaviour: for transactions using Gateway Tokens, Scheme Tokens or Scheme Tokens backed by Gateway Tokens, the T-SPI field `Transaction.CredentialOnFile` in the response currently displays incorrect values. When enabled, the enhanced merchant transaction source logic is applied for accurate COF indicator mapping.

### 🟢 Toggle ON Impact

**Business Impact (Class: `TspiRequestMessageBuilder.java` · Line 2463 · [CPE]):**
***When determining the StoredOnFile indicator for T-SPI acquirer messages for auth/purchase/refund transactions, the enhanced COF token logic is applied*** — `getCardOnFileForMerchantTransactionSource()` determines `StoredOnFile=STORED` when `CardOnFile=YES` based on merchant transaction source (token retrieval, scheme token, tokenisation privilege). Merchants benefit from accurate COF indicator mapping that aligns with merchant-initiated transaction source rules.

**Field Impact:**
TSPI: ***`Transaction.CredentialOnFile`*** (`StoredOnFile` field) set to `STORED` when `getCardOnFileForMerchantTransactionSource()` returns `CardOnFile.YES` — accurate COF indicator sent to T-SPI acquirer for auth/purchase/refund.

**Business Impact (Class: `TspiRequestMessageBuilder.java` · Line 2865 · [CPE]):**
***The CardOnFile indicator for T-SPI messages is determined using the enhanced merchant transaction source logic*** — `getCardOnFileForMerchantTransactionSource()` returns YES/NO based on token retrieval, scheme token, and tokenisation privilege rules aligned to merchant-initiated transaction source. Correct CardOnFile value flows into credential-on-file indicator in TSPI acquirer message.

**Field Impact:**
TSPI: ***`Transaction.CredentialOnFile`*** (`CardOnFile` field) set via `getCardOnFileForMerchantTransactionSource()`; returns `CardOnFile.YES` for merchant-source tokenised transactions; improves accuracy for all T-SPI transaction types.

### 🔴 Toggle OFF Impact

**Business Impact (Class: `TspiRequestMessageBuilder.java` · Line 2463 · [CPE]):**
***Legacy StoredOnFile logic applies*** — `StoredOnFile` set to `STORED` only when `isCardRetrievedFromToken()` or `isStoredExternally()` are true; `TO_BE_STORED` set for tokenisation-enabled merchants with empty `storedOnFile`. Enhanced merchant transaction source logic not applied.

**Field Impact:**
TSPI: ***`Transaction.CredentialOnFile`*** (`StoredOnFile`) determined by legacy `isCardRetrievedFromToken()`/`isStoredExternally()` checks; less granular COF indicator mapping to T-SPI.

**Business Impact (Class: `TspiRequestMessageBuilder.java` · Line 2865 · [CPE]):**
***Legacy CardOnFile logic used*** — returns `CardOnFile.YES` only when `isCardRetrievedFromToken()` or `isStoredExternally()` are true; enhanced merchant transaction source rules not applied.

**Field Impact:**
TSPI: ***`Transaction.CredentialOnFile`*** (`CardOnFile`) determined by simpler legacy token/external-storage checks only; `CardOnFile` may be NO for some tokenised transactions that should qualify.

### Implementation Details

| Field | Details |
|---|---|
| **Implementation Class** | `TspiRequestMessageBuilder` |
| **Line Number(s)** | 2463, 2865 |
| **Repository** | CPE |

> ⚠️ *S2A Note: This toggle is marked as S2A-impacting (`is_s2a=TRUE`). The implementation rows are in `TspiRequestMessageBuilder` — T-SPI (TSPI) acquirer message builder. Changes to `Transaction.CredentialOnFile` (StoredOnFile / CardOnFile) directly affect the TSPI acquirer message sent for T-SPI transactions.*

---

## Toggle 58: Revised Standards to Introduce BPSP Category to Support B2B

| Field | Details |
|---|---|
| **Toggle Name** | Revised Standards to Introduce BPSP Category to Support B2B |
| **Confluence Page** | [View Page](https://confluence.mastercard.int/spaces/MPGSIOG/pages/2376453729/Revised+Standards+to+Introduce+BPSP+Category+to+Support+B2B) |
| **Team Responsible** | T-Bamboo |
| **Applications Affected** | WSAPI, CardPaymentEngine |
| **Is S2A Toggle** | FALSE |
| **Current Status** | As of 25.5.0 Release Date - MTF: Enabled; Production NA/KSA/IN/EU/AP: Enabled for Some |

### Summary
A Business Payment Service Provider (BPSP) is a service provider who facilitates commercial business-to-business payments between buyers and suppliers. The BPSP construct allows buyers to pay their bills with a Mastercard commercial card even if the supplier is not a Mastercard accepting merchant, thereby providing more payment options for buyers. This toggle controls propagation of the `purchaseType` field through the 3DS authentication flow and B2B BPSP category compound name formatting in ISO DE43.

### 🟢 Toggle ON Impact

**Business Impact (Class: `AuthenticationRequestFieldsHandler.java` · Line 43 · [Orchestrator]):**
***During 3D Secure authentication data persistence, the `purchaseType` field is stored in the authentication request data when provided*** — enabling B2B BPSP category to be captured and associated with authentication for 3DS transactions. Merchants submitting B2B payment transactions receive correct `purchaseType` propagation through the authentication flow.

**Field Impact:**
***`order.purchaseType`*** (TSPI/merchant API field) persisted in authentication request fields data via `data.setPurchaseType(request.getPurchaseType())` when toggle is ON and `purchaseType` is non-null.

**Business Impact (Class: `AuthenticationAPI.java` · Line 332 · [Orchestrator]):**
***In the Orchestrator authentication API response, the `purchaseType` from the order is included in the response payload*** — merchants and operators querying authentication status receive the B2B BPSP purchase type in the authentication response.

**Field Impact:**
***`order.purchaseType`*** (TSPI/merchant API response field) included via `response.mergeObject(ORDER_PURCHASE_TYPE, ...)` when toggle is ON; `purchaseType` returned in authentication query response.

**Business Impact (Class: `IsoDataField43Populator.java` · Line 107 · [CPE]):**
***For Mastercard B2B BPSP transactions with MCC 9999 (`BPSP_MERCHANT_CATEGORY_CODE`), the ISO DE43 merchant name field is formatted as `merchantName*supplierName`*** (truncated to 9 chars + asterisk + supplierName) — enabling acquirers to identify BPSP transactions and their supplier in the S2I message.

**Field Impact:**
ISO ***DE43*** (Card Acceptor Name/Location) formatted as BPSP compound name (`merchantName*supplierName`) for Mastercard `purchaseType=B2B_PAYMENT` transactions with MCC 9999 when toggle is ON.

### 🔴 Toggle OFF Impact

**Business Impact (Class: `AuthenticationRequestFieldsHandler.java` · Line 43 · [Orchestrator]):**
***`purchaseType` is NOT stored in the authentication request data*** — BPSP B2B category not propagated through the 3DS authentication persistence path.

**Field Impact:**
***`order.purchaseType`*** absent from authentication request data store; B2B BPSP category not associated with 3DS authentication.

**Business Impact (Class: `AuthenticationAPI.java` · Line 332 · [Orchestrator]):**
***`purchaseType` NOT included in authentication API response*** — order purchase type absent from authentication status response.

**Field Impact:**
***`order.purchaseType`*** absent from authentication response payload.

**Business Impact (Class: `IsoDataField43Populator.java` · Line 107 · [CPE]):**
***Standard DE43 merchant name logic applies*** — BPSP compound name format not used; DE43 populated with standard merchant name without `supplierName` suffix.

**Field Impact:**
ISO ***DE43*** uses standard merchant name only; BPSP B2B supplier name context absent from S2I acquirer message.

### Implementation Details

| Field | Details |
|---|---|
| **Implementation Class** | `AuthenticationRequestFieldsHandler`, `AuthenticationAPI`, `IsoDataField43Populator` |
| **Line Number(s)** | 43 (Orchestrator), 332 (Orchestrator), 107 (CPE) |
| **Repository** | Orchestrator, CPE |

---

## Toggle 59: Enable Exclusion Rule in Merchant Acquirer Link Resolution

| Field | Details |
|---|---|
| **Toggle Name** | Enable Exclusion Rule in Merchant Acquirer Link Resolution |
| **Confluence Page** | [View Page](https://confluence.mastercard.int/spaces/MPGSIOG/pages/2376453132/Enable+Exclusion+Rule+in+Merchant+Acquirer+Link+Resolution) |
| **Team Responsible** | MPGS Team Bifrost |
| **Applications Affected** | msoui, cardPaymentEngine |
| **Is S2A Toggle** | FALSE |
| **Current Status** | Currently planning to roll out by 21.2 release |

### Summary
CITI wants to launch in Canada using the gateway and the Global Payments S2I Acquirer. The gateway must comply with Mastercard and Visa regulations for Canadian merchants for the acceptance of Visa and Mastercard Debit cards issued in Canada. This toggle enables configured exclusion rules to be enforced during merchant-acquirer link resolution, preventing specific card types from being routed to a particular acquirer link.

### 🟢 Toggle ON Impact

**Business Impact (Class: `MerchantAcquirerRelationship.java` · Line 1054 · [CPE]):**
***When resolving which acquirer link is eligible for a transaction, configured exclusion rules are evaluated*** — if any exclusion rule matches the card type and card meta information, that merchant-acquirer relationship is excluded from the eligible candidates. Merchants with specific card exclusion rules (e.g. exclude certain co-branded or domestic card types from a particular acquirer) have those rules enforced during acquirer link resolution.

**Field Impact:**
Internal routing only — no TSPI/ISO/acquirer fields affected directly. Internal: `isTransactionSupportedAfterApplyingExclusionRules()` returns false (transaction excluded) when `checkIfExclusionRuleApplicable(exclusionRules, cardType, cardMetaInfo)` is true; affects which acquirer link is selected for the transaction.

### 🔴 Toggle OFF Impact

**Business Impact (Class: `MerchantAcquirerRelationship.java` · Line 1054 · [CPE]):**
***Exclusion rules on merchant-acquirer relationships are ignored*** — all configured acquirer links are considered eligible regardless of any exclusion rule configuration. Transactions with card types that should be excluded from a particular acquirer may still be routed there.

**Field Impact:**
Internal routing only — `isTransactionSupportedAfterApplyingExclusionRules()` always returns true; `exclusionRules` not evaluated; all merchant-acquirer links treated as eligible for any card type.

### Implementation Details

| Field | Details |
|---|---|
| **Implementation Class** | `MerchantAcquirerRelationship` |
| **Line Number(s)** | 1054 |
| **Repository** | CPE |

---

## Toggle 60: Enable Card Identification Service

| Field | Details |
|---|---|
| **Toggle Name** | Enable Card Identification Service |
| **Confluence Page** | [View Page](https://confluence.mastercard.int/spaces/MPGSIOG/pages/2376453014/Enable+Card+Identification+Service) |
| **Team Responsible** | Team Bifrost; Team Tesseract |
| **Applications Affected** | CPE, MSO UI |
| **Is S2A Toggle** | FALSE |
| **Current Status** | As of 27 Oct 2025 |

### Summary
This toggle was introduced to resolve card details from Card Identification Service on top of the existing sources (Binbase.csv, CardBrand.xml, tns_override.json). When the toggle is on, the gateway looks for a BIN along with Card Bin Set ID (if present) in the card identification service and overrides the existing information if any matching details are found, enabling more precise BIN-set-aware transaction routing.

### 🟢 Toggle ON Impact

**Business Impact (Class: `CardBinSetIdDeterminerImpl.java` · Line 19 · [CPE]):**
***When either the Card Identification Service toggle or the Merchant BinSet Lookup toggle is active, the gateway resolves the matched Card BIN Set ID for the transaction*** — allowing card routing and acquirer link resolution to use the merchant-configured BIN set identifier for more precise card identification. Merchants with configured BIN sets benefit from BIN-set-aware transaction routing.

**Field Impact:**
Internal card identification and routing only — no TSPI/ISO/acquirer fields affected directly. Internal: `determineCardBinSetId()` returns `Optional.of(matchedCardBinSetId)` when `merchantConfiguredBinSets` has a valid matched BIN set ID; result used in downstream acquirer link resolution (`cardBinSetId` for MAL matching).

### 🔴 Toggle OFF Impact

**Business Impact (Class: `CardBinSetIdDeterminerImpl.java` · Line 19 · [CPE]):**
***Card BIN Set ID is never resolved*** — `determineCardBinSetId()` always returns `Optional.empty()` regardless of merchant BIN set configuration. Merchant-configured BIN set routing not applied; transactions fall through to standard card type routing.

**Field Impact:**
Internal only — `matchedCardBinSetId` not returned; BIN-set-based acquirer link resolution path skipped; merchant BIN set configuration has no effect on transaction routing.

### Implementation Details

| Field | Details |
|---|---|
| **Implementation Class** | `CardBinSetIdDeterminerImpl` |
| **Line Number(s)** | 19 |
| **Repository** | CPE |

---

## Toggle 61: Optimize loading of terminal batch counters

| Field | Details |
|---|---|
| **Toggle Name** | Optimize loading of terminal batch counters |
| **Confluence Page** | [View Page](https://confluence.mastercard.int/spaces/MPGSIOG/pages/2376453602/Optimize+loading+of+terminal+batch+counters) |
| **Team Responsible** | Team Bifrost |
| **Applications Affected** | CPE |
| **Is S2A Toggle** | FALSE |
| **Current Status** | 24.9.0 |

### Summary
This toggle controls the enablement of efficient loading of terminal batch counters, allowing it to be enabled for specific merchants first for monitoring before a wider rollout. A performance issue was identified during site failover when merchants with a high number of configured terminals caused excessive database round-trips during terminal pool initialisation.

### 🟢 Toggle ON Impact

**Business Impact (Class: `BlockingTerminal.java` · Line 92 · [CPE]):**
***During terminal initialisation, the acquirer batch counter is loaded without triggering a full DB load*** — `getTerminalBatchCounterWithoutLoading()` retrieves the counter object and immediately injects the pre-fetched `TransactionNumber` (`acqBatch`, `STAN`, `batchSize`) from the SQL join result. This eliminates a separate DB round-trip per terminal for counter initialisation, reducing startup overhead for merchant-acquirer terminal pools.

**Field Impact:**
Internal only — no TSPI/ISO/acquirer fields affected. Internal: `isToggleOn(TOGGLE_OPTIMIZE_ACQ_COUNTER_LOAD)` at line 92; `TerminalBatchCounter` populated via `setTerminalBatchCounter(transactionNumber)` directly; `getTerminalBatchCounter()` call avoided.

**Business Impact (Class: `TerminalPoolDao.java` · Line 171 · [CPE]):**
***`loadTerminals()` routes to the optimised `loadTerminalsAndAcqCounter()` implementation*** — a single SQL query with a `LEFT JOIN` on `AcqCounter` fetches both terminal configuration and acquirer counter values (`acqBatch`, `stan`, `batchSize`) in one pass, with `TransactionNumber` pre-populated per terminal. Eliminates multiple DB round-trips when building terminal pools for a merchant-acquirer link.

**Field Impact:**
Internal only — no TSPI/ISO/acquirer fields affected. Internal: `Toggles.isToggleOn(TOGGLE_OPTIMIZE_ACQ_COUNTER_LOAD)` at line 171; `GET_LINK_TERMINALS_AND_ACQCOUNTER_SQL` (Terminal `LEFT JOIN` AcqCounter) executed; `TransactionNumber` passed to `BlockingTerminal` constructor; `coalesce(0)` defaults used when `AcqCounter` row absent.

### 🔴 Toggle OFF Impact

**Business Impact (Class: `BlockingTerminal.java` · Line 92 · [CPE]):**
***Standard `getTerminalBatchCounter()` path is used*** — the batch counter is loaded from the DB individually for each terminal during initialisation; additional DB calls performed per terminal.

**Field Impact:**
Internal only — `TerminalBatchLocator.getTerminalBatchCounter()` called; separate counter DB fetch per terminal during pool initialisation.

**Business Impact (Class: `TerminalPoolDao.java` · Line 171 · [CPE]):**
***Legacy `loadTerminals(MerchantAcquirerSystemId)` path executes*** — only terminal configuration is fetched; `AcqCounter` values are NOT pre-fetched; each terminal loads its batch counter separately on demand.

**Field Impact:**
Internal only — `GET_LINK_TERMINALS_SQL` used (no `AcqCounter` join); `TransactionNumber` is null in `BlockingTerminal` constructor; batch counters loaded lazily per-terminal.

### Implementation Details

| Field | Details |
|---|---|
| **Implementation Class** | `BlockingTerminal`, `TerminalPoolDao` |
| **Line Number(s)** | 92, 171 |
| **Repository** | CPE |

---

## Toggle 62: Submit EDQP Phase 3 fields in standalone transactions to WSAPI

| Field | Details |
|---|---|
| **Toggle Name** | Submit EDQP Phase 3 fields in standalone transactions to WSAPI |
| **Confluence Page** | [View Page](https://confluence.mastercard.int/spaces/MPGSIOG/pages/2376453696/Submit+EDQP+Phase+3+fields+in+standalone+transactions+to+WSAPI) |
| **Team Responsible** | T-Bamboo |
| **Applications Affected** | WSAPI, CardPaymentEngine |
| **Is S2A Toggle** | FALSE |
| **Current Status** | Not specified |

### Summary
Visa introduced the Electronic Data Quality Program (EDQP) to improve data integrity across the transaction lifecycle. Phase 3 extends EDQP support to Target Standalone Captures and Standalone Refunds, adding 18 Visa EDQP fields. This toggle controls whether Phase 3 fields are submitted in standalone capture transactions to WSAPI/RSC.

### 🟢 Toggle ON Impact

**Business Impact (Class: `S2IToggleHelper.java` · Line 17 · [CPE]):**
***`isToggleOnEDQPPhase3StandaloneCapture()` returns true*** — EDQP Phase 3 fields are submitted in standalone capture transactions to the WSAPI/RSC. Enables Phase 3 enhanced data fields (account funding source, product platform code, cardholder ID method) to be included in standalone capture S2I messages.

**Field Impact:**
***ISO DE48 SE05 SF04*** (AccountFundingSource), ***SF05*** (AppliedProductPlatformCode), ***SF06*** (AppliedCardholderIdMethod) included in standalone capture S2I acquirer message when toggle is ON.

### 🔴 Toggle OFF Impact

**Business Impact (Class: `S2IToggleHelper.java` · Line 17 · [CPE]):**
***EDQP Phase 3 fields NOT submitted in standalone capture transactions*** — `isToggleOnEDQPPhase3StandaloneCapture()` returns false; enhanced data fields absent from standalone capture S2I message.

**Field Impact:**
***ISO DE48 SE05 SF04***/***SF05***/***SF06*** absent from standalone capture S2I acquirer message.

### Implementation Details

| Field | Details |
|---|---|
| **Implementation Class** | `S2IToggleHelper` |
| **Line Number(s)** | 17 |
| **Repository** | CPE |

---

## Toggle 63: Enable MC Account Funding Transactions

| Field | Details |
|---|---|
| **Toggle Name** | Enable MC Account Funding Transactions |
| **Confluence Page** | [View Page](https://confluence.mastercard.int/spaces/MPGSIOG/pages/2376453234/Enable+MC+Account+Funding+Transactions) |
| **Team Responsible** | MPGS Team Hercules |
| **Applications Affected** | cardPaymentEngine |
| **Is S2A Toggle** | FALSE |
| **Current Status** | 22.3.0 Release |

### Summary
As part of Feature F372863, Account Funding Transaction (AFT) support for Mastercard merchants was implemented in the gateway. This toggle enables the AFT functionality for MC merchants, gating the enrichment of S2I ISO messages with AFT-specific fields (DE108, DE54, DE48 SE36 SF05) and applying Mastercard-specific AFT validation rules in the Orchestrator.

### 🟢 Toggle ON Impact

**Business Impact (Class: `S2IAcquirerHelper.java` · Line 744 · [CPE]):**
***`isAccountFundingEnabledForMastercard()` returns true only when toggle is ON and card is Mastercard*** — gates S2I AFT-specific processing (`DE108`, `DE54`, `DE48 SE36 SF05` field population) for MC Account Funding Transactions. Merchants submitting Mastercard AFT receive correct S2I message enrichment.

**Field Impact:**
***ISO DE108 SF01*** (Transaction Reference set to `accountFunding.reference`), ***ISO DE54*** (FX Fee for MC AFT), ***ISO DE48 SE36 SF05*** (Payment Purpose) — populated for MC AFT when this toggle is ON and card type is Mastercard.

**Business Impact (Class: `AccountFundingValidator.java` · Line 204 · [Orchestrator]):**
***The Orchestrator `AccountFundingValidator` checks whether MC AFT is enabled via `isToggleOn(TOGGLE_FOR_MC_FUNDING_TRANSACTIONS)`*** — when ON, AFT-specific validation rules are applied for Mastercard cards (`purposeOfPayment`, `reference`, `foreignExchangeFee` field validation).

**Field Impact:**
***`accountFunding.purposeOfPayment`***, ***`accountFunding.reference`***, ***`accountFunding.foreignExchangeFee`*** (TSPI/merchant API request fields) validated against Mastercard AFT-specific rules when toggle is ON.

### 🔴 Toggle OFF Impact

**Business Impact (Class: `S2IAcquirerHelper.java` · Line 744 · [CPE]):**
***`isAccountFundingEnabledForMastercard()` returns false*** — MC AFT S2I message enrichment not applied; `DE108`, `DE54`, `DE48 SE36 SF05` not populated for Mastercard AFT.

**Field Impact:**
***ISO DE108 SF01***, ***ISO DE54***, ***ISO DE48 SE36 SF05*** absent for Mastercard AFT.

**Business Impact (Class: `AccountFundingValidator.java` · Line 204 · [Orchestrator]):**
***MC AFT validation not applied by this method*** — `accountFunding` fields not validated against Mastercard-specific AFT rules. Validation falls through to generic/Visa AFT rules only.

**Field Impact:**
`accountFunding` fields not validated by Mastercard AFT path; validation falls through to generic/Visa AFT rules only.

### Implementation Details

| Field | Details |
|---|---|
| **Implementation Class** | `S2IAcquirerHelper`, `AccountFundingValidator` |
| **Line Number(s)** | 744 (CPE), 204 (Orchestrator) |
| **Repository** | CPE, Orchestrator |

---

## Toggle 64: Submit EDQP Phase 3 fields to RSC for Standalone Refunds

| Field | Details |
|---|---|
| **Toggle Name** | Submit EDQP Phase 3 fields to RSC for Standalone Refunds |
| **Confluence Page** | [View Page](https://confluence.mastercard.int/spaces/MPGSIOG/pages/2376453726/Submit+EDQP+Phase+3+fields+to+RSC+for+Standalone+Refunds) |
| **Team Responsible** | T-Bamboo |
| **Applications Affected** | WSAPI, CardPaymentEngine |
| **Is S2A Toggle** | FALSE |
| **Current Status** | As of 25.6.0 Release Date - MTF: Disabled for all; Production NA/KSA/IN/EU/AP: Disabled for all |

### Summary
Visa's Electronic Data Quality Program (EDQP) Phase 3 extends enhanced data field support to Standalone Refunds in the Target platform. This toggle controls whether Phase 3 sub-fields (AccountFundingSource, AppliedProductPlatformCode, AppliedCardholderIdMethod) are submitted to RSC in standalone refund S2I messages, and also governs related authorisation code and ACS ECI propagation for standalone refunds.

### 🟢 Toggle ON Impact

**Business Impact (Class: `IsoDataField48SE05Populator.java` · Line 79 · [CPE]):**
***EDQP Phase 3 sub-fields (`SF04`=AccountFundingSource, `SF05`=AppliedProductPlatformCode, `SF06`=AppliedCardholderIdMethod) are populated in ISO DE48 SE05 for Visa standalone refund transactions*** — enabling the RSC acquirer to receive enhanced Phase 3 data for standalone refunds. Visa standalone refunds sent to RSC include full EDQP Phase 3 compliance data.

**Field Impact:**
***ISO DE48 SE05 SF04*** (AccountFundingSource), ***SF05*** (AppliedProductPlatformCode), ***SF06*** (AppliedCardholderIdMethod) included in standalone refund S2I message for Visa card transactions when toggle ON.

**Business Impact (Class: `TransactionBuilder.java` · Line 282 · [CPE]):**
***For standalone refund transactions with manual auth flag, the authorisation code in the retrieval response is sourced from the order authorisation ID*** — ensuring the correct manual authorisation code is returned to merchants for EDQP Phase 3 standalone refunds.

**Field Impact:**
***`transaction.authorizationCode`*** (TSPI/merchant API response field) set from `order.getAuthorisationId()` for standalone refunds with `manualAuthFlag` when toggle is ON; overrides default `authId` source.

**Business Impact (Class: `RefundServiceImpl.java` · Line 656 · [CPE]):**
***When building the cardholder authentication DTO for a standalone refund, the ACS ECI value from `authentication.threeDSecure.acsEci` is included*** — enabling the standalone refund to carry 3DS authentication data (ACS ECI) to the acquirer as part of EDQP Phase 3 compliance.

**Field Impact:**
***`authentication.threeDSecure.acsEci`*** (TSPI/merchant API request field) propagated into `CardholderAuthenticationDTO.acsEci` for standalone refund; ACS ECI sent to acquirer in standalone refund message.

### 🔴 Toggle OFF Impact

**Business Impact (Class: `IsoDataField48SE05Populator.java` · Line 79 · [CPE]):**
***EDQP Phase 3 sub-fields NOT populated in DE48 SE05 for standalone Visa refunds*** — `buildFieldSF04SF05SF06()` not called; enhanced data absent from standalone refund S2I message.

**Field Impact:**
***ISO DE48 SE05 SF04***/***SF05***/***SF06*** absent from standalone Visa refund S2I acquirer message.

**Business Impact (Class: `TransactionBuilder.java` · Line 282 · [CPE]):**
***Standard authorisation code logic applies for standalone refunds*** — `authorizationCode` sourced from `financialTransaction.getAuthorisationId()` or order `containsValidAuthorization` path.

**Field Impact:**
`transaction.authorizationCode` set using standard logic; manual auth path for standalone refunds not applied.

**Business Impact (Class: `RefundServiceImpl.java` · Line 656 · [CPE]):**
***`CardholderAuthenticationDTO` is returned as null for standalone refunds*** — no authentication data (including ACS ECI) is included in the standalone refund acquirer message.

**Field Impact:**
`authentication.threeDSecure.acsEci` not propagated to acquirer for standalone refunds; ACS ECI absent from standalone refund.

### Implementation Details

| Field | Details |
|---|---|
| **Implementation Class** | `IsoDataField48SE05Populator`, `TransactionBuilder`, `RefundServiceImpl` |
| **Line Number(s)** | 79, 282, 656 |
| **Repository** | CPE |

---

## Toggle 65: Enable Account Funding enhanced functionality for Mastercard and Visa

| Field | Details |
|---|---|
| **Toggle Name** | Enable Account Funding enhanced functionality for Mastercard and Visa |
| **Confluence Page** | [View Page](https://confluence.mastercard.int/spaces/MPGSIOG/pages/2376453795/Enable+Account+Funding+enhanced+functionality+for+Mastercard+and+Visa) |
| **Team Responsible** | Team Pegasus |
| **Applications Affected** | CardPaymentEngine, Orchestrator |
| **Is S2A Toggle** | TRUE |
| **Current Status** | MTF: Enable for All test MSOs; UAT: Disabled for all; Production NA/EU/AP: Disabled for all |

### Summary
This toggle enables enhanced Account Funding functionality that builds on top of the existing AFT (Account Funding Transaction) feature for both Mastercard and Visa. When enabled, the gateway automatically derives and populates a default `purposeOfPayment` for Visa AFT transactions at API v1.0.0+ where the merchant has omitted the field, ensuring downstream Visa network compliance without requiring merchant action.

### 🟢 Toggle ON Impact

**Business Impact (Class: `AccountFundingValidator.java` · Line 596 · [Orchestrator]):**
***For Visa AFT at API v1.0.0+ where no `purposeOfPayment` has been supplied by the merchant, the gateway automatically determines and populates a default `purposeOfPayment` based on the card scheme*** — merchants do not need to supply this Visa-mandatory field manually; the gateway derives it from `CardTypeDetails.getCardScheme()`.

**Field Impact:**
***`accountFunding.purposeOfPayment`*** (TSPI/merchant API request field) auto-defaulted via `setPurposeOfPayment(accountFunding, cardScheme)` when merchant omits it for Visa AFT at API version >= 1.0.0; ensures downstream Visa network compliance without merchant action.

### 🔴 Toggle OFF Impact

**Business Impact (Class: `AccountFundingValidator.java` · Line 596 · [Orchestrator]):**
***`purposeOfPayment` is NOT auto-populated for Visa AFT*** — the field is only present if the merchant explicitly provides it. Merchants omitting `purposeOfPayment` for Visa AFT at API v1.0.0+ receive no default and the field is absent from the transaction, risking downstream Visa network rejection.

**Field Impact:**
`accountFunding.purposeOfPayment` not auto-defaulted; `setPurposeOfPayment()` not called; field absent unless merchant supplies it explicitly.

### Implementation Details

| Field | Details |
|---|---|
| **Implementation Class** | `AccountFundingValidator` |
| **Line Number(s)** | 596 |
| **Repository** | Orchestrator |

> ⚠️ *S2A Note: This toggle is flagged as S2A-impacting (is_s2a=TRUE). The enhanced Account Funding functionality for Mastercard and Visa may intersect with S2A transaction flows. Review with the S2A/TSPI team before enabling in production.*

---

## Toggle 66: Enable Protection Blocking Of Unusual Transactions

| Field | Details |
|---|---|
| **Toggle Name** | Enable Protection Blocking Of Unusual Transactions |
| **Confluence Page** | [View Page](https://confluence.mastercard.int/spaces/MPGSIOG/pages/2376453144/Enable+Protection+Blocking+Of+Unusual+Transactions) |
| **Team Responsible** | Team Green |
| **Applications Affected** | Transaction Protection Service |
| **Is S2A Toggle** | FALSE |
| **Current Status** | *(not specified)* |

### Summary
Functionality has been implemented to detect and block unusual transactions on a merchant. Merchant transaction data will be submitted to the protection service which will respond whether the transaction should 'proceed to' or 'be blocked from' processing by the acquirer.

### 🟢 Toggle ON Impact

**Business Impact:**
⚠️ *NOT_FOUND — Toggle implementation not located in the analysed repositories (CPE, Orchestrator, DirectAPI, BusinessService, MSOUI, Console). Toggle likely resides in the Transaction Protection Service repository which is not present in this workspace. When ON, the gateway is expected to enforce blocking of unusual transactions as flagged by the Transaction Protection Service before acquirer processing.*

**Field Impact:**
Unknown — toggle likely controls whether CPE blocks unusual transactions flagged by the Transaction Protection Service. Field-level detail unavailable without access to the Protection Service repository.

### 🔴 Toggle OFF Impact

**Business Impact:**
⚠️ *NOT_FOUND — When OFF or absent, Protection Service blocking of unusual transactions is not enforced by this toggle. Transactions that would otherwise be blocked proceed to the acquirer without the protection service intercept.*

**Field Impact:**
Unknown — field impact unavailable; toggle not found in analysed codebase.

### Implementation Details

| Field | Details |
|---|---|
| **Implementation Class** | NOT_FOUND |
| **Line Number(s)** | N/A |
| **Repository** | UNKNOWN — likely Transaction Protection Service (not in workspace) |

---

## Toggle 67: System Toggle: Enable Activity Analyzer in Protection Service

| Field | Details |
|---|---|
| **Toggle Name** | System Toggle: Enable Activity Analyzer in Protection Service |
| **Confluence Page** | [View Page](https://confluence.mastercard.int/spaces/MPGSIOG/pages/2376453145/System+Toggle+Enable+Activity+Analyzer+in+Protection+Service) |
| **Team Responsible** | Team Green |
| **Applications Affected** | Transaction Protection Service |
| **Is S2A Toggle** | FALSE |
| **Current Status** | *(not specified)* |

### Summary
Functionality has been implemented to detect and block unusual transactions on a merchant. Transaction data provided to the Protection Service via the Activity API is used to build statistical data for both a gateway baseline and per merchant.

### 🟢 Toggle ON Impact

**Business Impact:**
⚠️ *NOT_FOUND — Toggle implementation not located in the analysed repositories (CPE, Orchestrator, DirectAPI, BusinessService, MSOUI, Console). Toggle likely resides in the Transaction Protection Service repository which is not present in this workspace. When ON, the Activity Analyzer component within the Protection Service is expected to be enabled, analysing submitted transaction activity data to build anomaly-detection statistics at both gateway-baseline and per-merchant level.*

**Field Impact:**
Unknown — toggle likely enables the Activity Analyzer component within the Protection Service for anomaly detection on submitted transaction activity. Field-level detail unavailable without access to the Protection Service repository.

### 🔴 Toggle OFF Impact

**Business Impact:**
⚠️ *NOT_FOUND — When OFF or absent, the Activity Analyzer within the Protection Service is not enabled by this toggle. Statistical data for anomaly detection is not computed from incoming activity submissions.*

**Field Impact:**
Unknown — field impact unavailable; toggle not found in analysed codebase.

### Implementation Details

| Field | Details |
|---|---|
| **Implementation Class** | NOT_FOUND |
| **Line Number(s)** | N/A |
| **Repository** | UNKNOWN — likely Transaction Protection Service (not in workspace) |

---

## Toggle 68: Enable Transaction Filtering BIN Range White listing

| Field | Details |
|---|---|
| **Toggle Name** | Enable Transaction Filtering BIN Range White listing |
| **Confluence Page** | [View Page](https://confluence.mastercard.int/spaces/MPGSIOG/pages/2376453111/Enable+Transaction+Filtering+BIN+Range+White+listing) |
| **Team Responsible** | Team Effision 3 |
| **Applications Affected** | MM portal, MA portal, WSAPI- UPDATE_MERCHANT_PAYMENT_DETAILS |
| **Is S2A Toggle** | FALSE |
| **Current Status** | 20.3 Release |

### Summary
⚠️ **DO NOT USE** — This functionality should not be enabled for customers due to various defects that make it unsuitable for production. A toggle to allow MSOs and Merchants to configure White list BIN Transaction Filtering Rules in addition to existing ability to configure Blocking BIN rules, with a capability to upload bulk BINs via a CSV file.

### 🟢 Toggle ON Impact

**Business Impact:**
⚠️ *NOT_FOUND — Toggle implementation not located in the analysed repositories (CPE, Orchestrator, DirectAPI, BusinessService, MSOUI, Console). Toggle may reside in an R-SPI or transaction filtering service repository not present in this workspace. When ON, BIN Range whitelisting for transaction filtering is expected to be enabled — MSOs and merchants can configure whitelist BIN ranges that are excluded from transaction filtering blocking rules.*

**Field Impact:**
Unknown — toggle likely enables a BIN Range whitelist exclusion from transaction filtering rules in the Risk SPI. Field-level detail unavailable without access to the relevant repository.

### 🔴 Toggle OFF Impact

**Business Impact:**
⚠️ *NOT_FOUND — When OFF or absent, BIN Range whitelisting for transaction filtering is not applied. All BIN ranges are subject to standard transaction filtering blocking rules without whitelist exclusions.*

**Field Impact:**
Unknown — field impact unavailable; toggle not found in analysed codebase.

### Implementation Details

| Field | Details |
|---|---|
| **Implementation Class** | NOT_FOUND |
| **Line Number(s)** | N/A |
| **Repository** | UNKNOWN — likely R-SPI or Transaction Filtering Service (not in workspace) |

---

## Toggle 69: Allow both auth and purchase operations for the merchant

| Field | Details |
|---|---|
| **Toggle Name** | Allow both auth and purchase operations for the merchant |
| **Confluence Page** | [View Page](https://confluence.mastercard.int/spaces/MPGSIOG/pages/2376452966/Allow+both+auth+and+purchase+operations+for+the+merchant) |
| **Team Responsible** | Team Bifrost |
| **Applications Affected** | CardPaymentEngine, Hosted Checkout, MSO UI, Merchant Manager, Merchant Admin, Console |
| **Is S2A Toggle** | FALSE |
| **Current Status** | As of 13 Jul 2022 - MTF: Enabled for all (except TESTSMOKE-RPT), Production NA/EU/AP: Enabled for all (except TESTSMK_RPT series) |

### Summary
The restriction in the gateway that previously prevented the same merchant profile from being able to do both Authorize/Capture and Purchase transactions has been removed. Merchants are able to perform both transaction types via WS API and Merchant Administration based on their privileges, with access controlled by merchant privilege checks rather than the legacy `transactionMode` field.

### 🟢 Toggle ON Impact

**Business Impact:**
***When toggle is ON, merchants can be enabled for both authorization (auth-then-capture) and purchase (single-step) transaction modes simultaneously*** — access is controlled by merchant privilege checks (`hasPrivilege`) rather than the legacy `transactionMode` field. `MerchantAgent` agent-level authorization privilege is also checked for internal INTERNAL-domain clients.

**Field Impact:**
***Internal only*** — no TSPI/ISO/acquirer fields affected. Internal: `merchant.hasPrivilege(AUTHORIZATION_PRIVILEGE_NAME)` and `AUTH_THEN_CAPTURE.equals(merchant.getTransactionMode())` condition logic changes; `merchantAgent` privilege check enforced for INTERNAL domain.

### 🔴 Toggle OFF Impact

**Business Impact:**
***When toggle is OFF, authorization eligibility reverts to the legacy `transactionMode`-based check*** — a merchant's `transactionMode` must be `AUTH_THEN_CAPTURE` (or the merchant must have the authorization privilege) to authorize. Merchants configured as PURCHASE-mode only cannot perform authorization, and agent-level privilege checks are not enforced.

**Field Impact:**
***Internal only*** — `isAllowedToPerformAuthorization` falls back to `AUTH_THEN_CAPTURE` `transactionMode` match; `isAllowedToPerformPurchase` falls back to `PURCHASE` `transactionMode` match.

### Implementation Details

| Field | Details |
|---|---|
| **Implementation Class** | `TransactionModeChecker` |
| **Line Number(s)** | 38 |
| **Repository** | CPE |

---

## Toggle 70: Allow tokenization with referenceOrderId

| Field | Details |
|---|---|
| **Toggle Name** | Allow tokenization with referenceOrderId |
| **Confluence Page** | [View Page](https://confluence.mastercard.int/spaces/MPGSIOG/pages/2376453405/Allow+tokenization+with+referenceOrderId) |
| **Team Responsible** | Team Phoenix |
| **Applications Affected** | Orchestrator, SCT |
| **Is S2A Toggle** | FALSE |
| **Current Status** | Disabled |

### Summary
The 'Allow tokenization with referenceOrderId' toggle is a feature toggle that can be enabled/disabled for specific merchants and/or MSOs. By default, the feature toggle is disabled for all merchants/MSOs and will be enabled only in specific regions after pilot merchant testing.

### 🟢 Toggle ON Impact

**Business Impact:**
***When ON, a tokenization (Save Card) request that includes a `referenceOrderId` is decorated with source-of-funds data from the referenced order*** — the gateway retrieves the previous order and populates card details, wallet type, currency, and PAN type from it, enabling tokenization without the merchant re-supplying card details. Only supported for Google Pay and Apple Pay wallet transactions.

**Field Impact:**
***`sourceOfFunds`*** (device-specific card number, wallet type, currency) and PAN type inherited from referenced order; TSPI: `SaveCardRequest.referenceOrderId` (API field) is processed when toggle ON; otherwise `request.setReferenceOrderId(null)` is called.

### 🔴 Toggle OFF Impact

**Business Impact:**
***When OFF, the `referenceOrderId` is nulled out and the tokenization request proceeds without referencing any prior order*** — merchants must supply source of funds directly in the tokenization request.

**Field Impact:**
`request.referenceOrderId` set to null; no order retrieval performed; source of funds not decorated from prior order.

### Implementation Details

| Field | Details |
|---|---|
| **Implementation Class** | `ReferenceOrderDecorator` |
| **Line Number(s)** | 78 |
| **Repository** | Orchestrator |

---

## Toggle 71: Batch Settlement Service use Base32 ID Generator

| Field | Details |
|---|---|
| **Toggle Name** | Batch Settlement Service use Base32 ID Generator |
| **Confluence Page** | [View Page](https://confluence.mastercard.int/spaces/MPGSIOGWIP/pages/585792649/Batch+Settlement+Service+use+Base32+ID+Generator) |
| **Team Responsible** | CE |
| **Applications Affected** | Batch Settlement Service |
| **Is S2A Toggle** | FALSE |
| **Current Status** | As of 27 Feb 2026 - MTF: Enabled, EU: Enabled, NA: Enabled, KS: Disabled, IN: Disabled, AP: Disabled |

### Summary
This is a System Toggle that must be turned on for All. This toggle allows the fix for DE265798 to be toggled off/on. The fix changes how the Internal Transaction ID values are generated to use Base32 instead of Base64.

### 🟢 Toggle ON Impact

**Business Impact:**
***When ON, internal transaction IDs assigned to batch settlement transactions are generated using Base32 encoding*** (`idGenerator_32.generateId(8)`) — producing 8-character Base32-encoded identifiers. Base32 IDs use a character set that avoids ambiguous characters, improving readability and reducing misidentification errors in settlement logs and reconciliation.

**Field Impact:**
Internal only — no TSPI/ISO/acquirer fields affected. Internal: `InternalTransactionId.getInternalTransactionId(idGenerator_32.generateId(8))` returned; Base32 character set used for all new BSS internal transaction ID assignments.

### 🔴 Toggle OFF Impact

**Business Impact:**
***When OFF, internal transaction IDs are generated using the legacy Base64 encoder*** (`idGenerator_64.generateId(8)`) — 8-character Base64-encoded identifiers produced. Base64 IDs may contain characters (`+`, `/`, `=`) that can cause issues in URL or log contexts.

**Field Impact:**
Internal only — `InternalTransactionId.getInternalTransactionId(idGenerator_64.generateId(8))` returned; legacy Base64 character set used for BSS internal transaction ID generation.

### Implementation Details

| Field | Details |
|---|---|
| **Implementation Class** | `InternalTransactionIdGenerator` |
| **Line Number(s)** | 33 |
| **Repository** | BatchSettlementService |

---

## Toggle 72: Derive MASTERCARD FinancialNetworkTransactionId from authorizing txn for FIRSTDATA_2

| Field | Details |
|---|---|
| **Toggle Name** | Derive MASTERCARD FinancialNetworkTransactionId from authorizing txn for FIRSTDATA_2 |
| **Confluence Page** | [View Page](https://confluence.mastercard.int/spaces/MPGSIOG/pages/2376453738/Derive+MASTERCARD+FinancialNetworkTransactionId+from+authorizing+txn+for+FIRSTDATA_2) |
| **Team Responsible** | Team CE |
| **Applications Affected** | CardPaymentEngine |
| **Is S2A Toggle** | FALSE |
| **Current Status** | As of 25.6 Release Date - MTF: Disabled for all, Production NA/EU/AP: Disabled for all |

### Summary
For MASTERCARD transactions with FIRSTDATA_2, they always require the value associated with the initiating transaction (i.e. an AUTH or PURCHASE), even for later transactions. The toggle can be set per MSO and/or merchant.

### 🟢 Toggle ON Impact

**Business Impact:**
***For Mastercard transactions processed via FIRSTDATA_2 acquirer, when there is an associated initiating transaction (initial auth/purchase), the Financial Network Transaction ID is derived from the authorizing transaction's `acquirerResponse.transactionIdentifier`*** — ensuring Mastercard FNT consistency rules are met for subsequent transactions. Merchants with FIRSTDATA_2 receive correct FNTID linkage for all subsequent Mastercard transactions.

**Field Impact:**
***`TSPI: Acquirer.FinancialNetworkTransactionId`*** — populated from associated initiating transaction's `transactionIdentifier` (not the current transaction's own value) via `getAcquirerResponseField('transactionIdentifier', associatedTransaction)` for FIRSTDATA_2 Mastercard.

### 🔴 Toggle OFF Impact

**Business Impact:**
***When OFF, FNTID defaults to the current transaction's own `acquirerResponse.transactionIdentifier`*** — may cause Mastercard network FNTID mismatch for subsequent transactions at FIRSTDATA_2 where the initiating transaction ID is required.

**Field Impact:**
***`TSPI: Acquirer.FinancialNetworkTransactionId`*** — sourced from current transaction only, not from associated initial auth/purchase.

### Implementation Details

| Field | Details |
|---|---|
| **Implementation Class** | `JsonMegaMessageRequestBuilder` |
| **Line Number(s)** | 1861 |
| **Repository** | CPE |

---

## Toggle 73: Derive VISA FinancialNetworkTransactionId from authorizing txn for FIRSTDATA_2

| Field | Details |
|---|---|
| **Toggle Name** | Derive VISA FinancialNetworkTransactionId from authorizing txn for FIRSTDATA_2 |
| **Confluence Page** | [View Page](https://confluence.mastercard.int/spaces/MPGSIOG/pages/2376453695/Derive+VISA+FinancialNetworkTransactionId+from+authorizing+txn+for+FIRSTDATA_2) |
| **Team Responsible** | Team CE |
| **Applications Affected** | CardPaymentEngine |
| **Is S2A Toggle** | FALSE |
| **Current Status** | As of 25.3 Release Date - MTF: Disabled for all, Production NA/EU/AP: Disabled for all |

### Summary
For VISA transactions with FIRSTDATA_2, they always require the value associated with the initiating transaction (i.e. an AUTH or PURCHASE), even for later transactions. The toggle can be set per MSO and/or merchant.

### 🟢 Toggle ON Impact

**Business Impact:**
***For Visa transactions processed via FIRSTDATA_2 acquirer, when there is an associated initiating transaction (initial auth/purchase), the Financial Network Transaction ID is derived from that initiating transaction's `transactionIdentifier`*** — ensuring Visa FNTID consistency rules are met for subsequent (MIT/capture) transactions at FIRSTDATA_2. Merchants with FIRSTDATA_2 receive correct Visa FNTID linkage for subsequent transactions.

**Field Impact:**
***`TSPI: Acquirer.FinancialNetworkTransactionId`*** — populated from associated initiating transaction's `acquirerResponse.transactionIdentifier` via `isVisaTxnForFirstData2WithAssociatedInitiatingTxn()` check for FIRSTDATA_2 Visa.

### 🔴 Toggle OFF Impact

**Business Impact:**
***When OFF, Visa FNTID defaults to the current transaction's own `acquirerResponse.transactionIdentifier`*** — may break Visa network FNTID chaining requirements for subsequent transactions at FIRSTDATA_2.

**Field Impact:**
***`TSPI: Acquirer.FinancialNetworkTransactionId`*** — sourced from current transaction only; not derived from associated initiating transaction.

### Implementation Details

| Field | Details |
|---|---|
| **Implementation Class** | `JsonMegaMessageRequestBuilder` |
| **Line Number(s)** | 1858 |
| **Repository** | CPE |

---

## Toggle 74: Enable Merchant configured BinSet Lookup

| Field | Details |
|---|---|
| **Toggle Name** | Enable Merchant configured BinSet Lookup |
| **Confluence Page** | [View Page](https://confluence.mastercard.int/spaces/MPGSIOG/pages/2376453620/Enable+Merchant+configured+BinSet+Lookup) |
| **Team Responsible** | Team Bifrost |
| **Applications Affected** | Gateway Processing of BIN Files, CPE, Card Identification Service |
| **Is S2A Toggle** | FALSE |
| **Current Status** | Rollout targeted for 24.9 release - Enabled in QA for few merchants/msos |

### Summary
This feature toggle will ensure that during card resolution, local binsets are checked early before checking global binsets. When enabled, Card resolution logic checks localbinsets for enabled merchants first.

### 🟢 Toggle ON Impact

**Business Impact:**
***When ON (combined with or independently from Enable Card Identification Service toggle), the gateway checks merchant-configured BIN sets during card resolution*** — if a matched `CardBinSetId` and configured `CardBinSetIds` are found for the merchant, the matched `BinSetId` is returned, enabling merchant-specific BIN routing overrides.

**Field Impact:**
Internal card identification only — `matchedCardBinSetId` returned from `determineCardBinSetId()` when merchant BIN sets are configured and match; influences downstream acquirer link resolution and card brand routing; no direct TSPI API field but affects card routing path.

### 🔴 Toggle OFF Impact

**Business Impact:**
***When OFF, merchant-configured BIN set lookup is not applied*** — the gateway uses only the global BIN sets for card identification; merchant-specific BIN overrides are ignored.

**Field Impact:**
Internal only — `Optional.empty()` returned from `determineCardBinSetId()`; global BIN resolution used.

### Implementation Details

| Field | Details |
|---|---|
| **Implementation Class** | `CardBinSetIdDeterminerImpl` |
| **Line Number(s)** | 19 |
| **Repository** | CPE |

---

## Toggle 75: Enable MerchantAdvice and MerchantAdviceCode mapping in response for S2A

| Field | Details |
|---|---|
| **Toggle Name** | Enable MerchantAdvice and MerchantAdviceCode mapping in response for S2A |
| **Confluence Page** | [View Page](https://confluence.mastercard.int/spaces/MPGSIOG/pages/2376453284/Enable+MerchantAdvice+and+MerchantAdviceCode+mapping+in+response+for+S2A) |
| **Team Responsible** | MPGS Team Hercules |
| **Applications Affected** | cardPaymentEngine |
| **Is S2A Toggle** | TRUE |
| **Current Status** | 22.5.0 Release - Initially disabled, to be enabled after deployment in higher environment |

### Summary
The toggle was implemented to control behavior of newly added fields (MerchantAdvice and MerchantAdviceCode). GatewayRecommendation should be derived based on MerchantAdvice and MerchantAdviceCode values when enabled.

### 🟢 Toggle ON Impact

**Business Impact:**
***When ON, the MerchantAdvice and MerchantAdviceCode from the S2A acquirer response are mapped into the acquirer response JSON*** — for recurring payment agreements, the `acquirerCode` is set under `response.recurringPaymentAdvice.acquirerCode`, and for all transactions, `merchantAdviceCode` is set under `response.merchantAdviceCode`. Merchants receive actionable retry advice from the S2A network in the gateway response.

**Field Impact:**
***`TSPI/response JSON: response.merchantAdviceCode`*** and (for recurring) ***`response.recurringPaymentAdvice.acquirerCode`*** populated in acquirer response JSON merged into transaction response; `GatewayRecommendation` derived from `MerchantAdvice` and `MerchantAdviceCode` values.

### 🔴 Toggle OFF Impact

**Business Impact:**
***When OFF, `getMerchantAdviceCodeJson()` returns null*** — the S2A `MerchantAdvice` and `MerchantAdviceCode` are not included in the acquirer response JSON. Merchants do not receive retry advice from S2A responses.

**Field Impact:**
`response.merchantAdviceCode` and `response.recurringPaymentAdvice.acquirerCode` not populated in acquirer response JSON.

### Implementation Details

| Field | Details |
|---|---|
| **Implementation Class** | `MegaMessageMap` |
| **Line Number(s)** | 1316 |
| **Repository** | CPE |

> ⚠️ *S2A Note: This toggle is marked as S2A-impacting (`is_s2a=TRUE`). The implementation class `MegaMessageMap` is a true S2A class — it handles `MerchantAdvice` and `MerchantAdviceCode` mapping within the S2A acquirer response JSON, directly influencing `GatewayRecommendation` derived from S2A network responses. This toggle has a direct impact on S2A transaction processing flows.*

---

## Toggle 76: Enable Payment Token in TFTO Block

| Field | Details |
|---|---|
| **Toggle Name** | Enable Payment Token in TFTO Block |
| **Confluence Page** | [View Page](https://confluence.mastercard.int/spaces/MPGSIOG/pages/2376453702/Enable+Payment+Token+in+TFTO+Block) |
| **Team Responsible** | T-Draco |
| **Applications Affected** | CardPaymentEngine |
| **Is S2A Toggle** | FALSE |
| **Current Status** | 25.4 Release - MTF: Not Yet Available, Production NA/EU/AP/IN: Not Yet Available |

### Summary
This toggle controls the population of the PaymentToken field in the TFTO (Transaction For This Order) block of the S2A MEGA JSON message. When enabled, the acquirer payment token is populated for Auth and Purchase transactions in the TFTO response block, specifically controlling the population of payment token for acqChasePaymentech.

### 🟢 Toggle ON Impact

**Business Impact (Class: `JsonMegaMessageRequestBuilder.java` · Line 3728 · [CPE]):**
***When ON, for Auth or Purchase transactions in the TFTO block within the S2A MEGA JSON message, the PaymentToken (`acquirerPaymentToken`) is populated*** — enabling the acquirer to receive the payment token associated with the transaction.

**Field Impact:**
***`TSPI: Transaction (TFTO block) PaymentToken`*** — populated with `transaction.acquirerPaymentToken` value via `addFieldNullSafe('PaymentToken', transaction.getAcquirerPaymentToken())` for Auth/Purchase transactions when toggle ON; included in MEGA JSON `TransactionResponse` block.

### 🔴 Toggle OFF Impact

**Business Impact (Class: `JsonMegaMessageRequestBuilder.java` · Line 3728 · [CPE]):**
***When OFF, PaymentToken is not added to the TFTO `TransactionResponse` block*** — the acquirer payment token is absent from the MEGA JSON response for Auth/Purchase transactions.

**Field Impact:**
`TSPI: Transaction (TFTO block) PaymentToken` absent from MEGA JSON `TransactionResponse`.

### Implementation Details

| Field | Details |
|---|---|
| **Implementation Class** | `JsonMegaMessageRequestBuilder` |
| **Line Number(s)** | 3728 |
| **Repository** | CPE |

---

## Toggle 77: Enable Transaction Identifier and Financial Network Info in Verify Response

| Field | Details |
|---|---|
| **Toggle Name** | Enable Transaction Identifier and Financial Network Info in Verify Response |
| **Confluence Page** | [View Page](https://confluence.mastercard.int/spaces/MPGSIOG/pages/2376453758/Enable+Transaction+Identifier+and+Financial+Network+Info+in+Verify+Response) |
| **Team Responsible** | Team Musang King |
| **Applications Affected** | Card Payment Engine, Direct API |
| **Is S2A Toggle** | FALSE |
| **Current Status** | 25.6 Release - In end stage of development, pending QA completion |

### Summary
The toggle enables returning `authorizationResponse` in WSAPI (v80+) response for VERIFICATION transactions processed via S2I, which currently is not normally being returned. Returns different data based on card scheme — enabling merchants on API version 80 and above to receive financial network information and transaction identifiers in VERIFY responses.

### 🟢 Toggle ON Impact

**Business Impact (Class: `VerificationAuthorisationResponseDecorator.java` · Line 57 · [CPE]):**
***When ON, for VERIFY transactions via S2I acquirer at WSAPI v80+, the gateway populates `financialNetworkCode` in the `authorisationResponse`*** from the transaction's `financialNetworkCode` — enabling merchants (at API version 80 and above) to receive network-level financial network information in VERIFY responses that was previously absent.

**Field Impact:**
***`authorizationResponse.financialNetworkCode`*** (TSPI/merchant API response field) populated from `copyFrom.getFinancialNetworkCode()` for VERIFY transactions at API v80+ when toggle ON; previously always null for VERIFY.

### 🔴 Toggle OFF Impact

**Business Impact (Class: `VerificationAuthorisationResponseDecorator.java` · Line 57 · [CPE]):**
***When OFF, `financialNetworkCode` is not populated in the VERIFY transaction `authorisationResponse`*** — merchants do not receive Financial Network Info in VERIFY responses regardless of API version.

**Field Impact:**
`authorizationResponse.financialNetworkCode` absent from VERIFY response.

### Implementation Details

| Field | Details |
|---|---|
| **Implementation Class** | `VerificationAuthorisationResponseDecorator` |
| **Line Number(s)** | 57 |
| **Repository** | CPE |

---

## Toggle 78: Enable Update Authorization for Card Payments

| Field | Details |
|---|---|
| **Toggle Name** | Enable Update Authorization for Card Payments |
| **Confluence Page** | [View Page](https://confluence.mastercard.int/spaces/MPGSIOG/pages/2376452957/Enable+Update+Authorization+for+Card+Payments) |
| **Team Responsible** | Continuous Engineering |
| **Applications Affected** | CardPaymentEngine |
| **Is S2A Toggle** | FALSE |
| **Current Status** | TBD |

### Summary
The functionality for Updating an Authorization for a card payment was added to the 19.1 Release but is incomplete and must not be used until acquirer support is available. A feature toggle was added to allow switching off the functionality until completed. This toggle spans multiple classes across CPE and Orchestrator, controlling the entire Update Authorization for Card Payments flow including routing, validation, execution, and acquirer-specific logic.

### 🟢 Toggle ON Impact

**Business Impact (Class: `CaptureExecutorFactory.java` · Line 55 · [CPE]):**
***When ON, if a capture operation is classified as an excessive capture AND update-auth-then-capture logic is applicable, the `CaptureExecutorFactory` returns the `UpdateAuthorisationThenCaptureExecutor`*** — automatically triggering an Update Authorization before the capture to raise the authorization amount to cover the excess. Merchants can perform excessive captures (capture amount > authorised amount) by having the gateway automatically increment the authorization.

**Field Impact:**
Internal routing only — no TSPI/ISO/acquirer fields affected directly. Internal: `Toggles.isOn(ENABLE_UPDATE_AUTHORIZATION_FOR_CARD_PAYMENTS)` at line 55; `transaction.authorizationAdjustmentActions` set to `INCREMENT`; `m_updateAuthorisationThenCaptureExecutor` returned for excessive capture + update-auth flow.

**Business Impact (Class: `AuthCaptureModeHelper.java` · Line 454 · [CPE]):**
***When ON, during excessive capture validation in CPE, the gateway uses the updated authorization amount from the latest Update Authorization transaction*** (if available and greater than the outstanding auth amount) — allowing the capture to succeed against the incremented authorization ceiling rather than the original outstanding amount.

**Field Impact:**
Internal only — no TSPI/ISO/acquirer fields affected. Internal: `Toggles.isOn(ENABLE_UPDATE_AUTHORIZATION_FOR_CARD_PAYMENTS)` at line 454; `outstandingAmount` overridden with `updatedOutstandingAmount` from `lastestAuthAmount` minus `capturedAmount` if the updated amount is larger.

**Business Impact (Class: `MerchantAcquirerRelationshipLookup.java` · Line 325 · [CPE]):**
***When ON, `UpdateAuthorisation` transaction type is treated as a supported transaction type for merchant-acquirer relationship matching*** — ensuring Update Authorization transactions can be routed to the correct acquirer link even if `UpdateAuthorisationTransaction` is not explicitly listed in the acquirer supported transactions.

**Field Impact:**
Internal routing only — no TSPI/ISO/acquirer fields affected. Internal: `Toggles.isOn(ENABLE_UPDATE_AUTHORIZATION_FOR_CARD_PAYMENTS)` at line 325; `isTransactionTypeMatch()` returns true for `UpdateAuthorisationTransaction` type code when toggle ON.

**Business Impact (Class: `UpdateAuthorisationThenCaptureExecutor.java` · Line 160 · [CPE]):**
***When ON (combined with `ENABLE_INCREMENTAL_AUTHORIZATION` and `SYSTEM_TOGGLE_SUPPORT_AUTO_INCREMENTAL_AUTHORIZATION_FOR_EXCESSIVE_CAPTURE`), `shouldPopulateInitialAuthorizationForUpdateAuthorizationTransaction()` returns true*** for Mastercard/Visa captures with ESTIMATED order certainty where acquirer and merchant support incremental auth — enabling the executor to populate initial authorization data for Update Auth then Capture flows.

**Field Impact:**
Internal execution only — no TSPI/ISO/acquirer fields affected directly. Internal: `isIncrementalAuthorizationSupportTogglesEnabled()` at line 160 requires all three toggles ON; enables incremental authorization population in the update-auth-then-capture execution path.

**Business Impact (Class: `UpdateAuthorisationRequestValidator.java` · Line 326 · [Orchestrator]):**
***When ON, card payment Update Authorization requests at API version 50+ are accepted for processing*** — `validateWSAPIVersion()` allows card payments to proceed through Update Authorization flow.

**Field Impact:**
Internal validation only — no TSPI/ISO/acquirer fields affected. Internal: `Toggles.isToggleOn(ENABLE_UPDATE_AUTHORIZATION_FOR_CARD_PAYMENTS)` at line 326; card payment update auth allowed when toggle ON and version >= 50; exception thrown when OFF.

**Business Impact (Class: `OnBehalfUpdateAuthorizationValidator.java` · Line 179 · [Orchestrator]):**
***When ON, the on-behalf Update Authorization validator is active*** — `onBehalfUpdateAuthSupportedInVersion()` checks whether the capture request is at API version 51+ or is an MA integration, enabling automatic on-behalf Update Auth for excessive captures via the On Behalf path.

**Field Impact:**
Internal routing and validation only — no TSPI/ISO/acquirer fields affected. Internal: `Toggles.isOn(ENABLE_UPDATE_AUTHORIZATION_FOR_CARD_PAYMENTS)` at line 179; false immediately returned when toggle OFF; protocol version and MA integration type checked when toggle ON.

**Business Impact (Class: `S2IAcquirerHelper.java` · Line 661 · [CPE]):**
***When ON (combined with `ENABLE_INCREMENTAL_AUTHORIZATION`), `isLastUpdatedAuthorizeTxnMadaDMS()` returns true for MADA acquirer DMS transactions*** — enabling special MADA DMS processing in the S2I Update Authorization flow.

**Field Impact:**
Internal S2I message building decision — no direct TSPI/ISO field affected. Internal: `isToggleOn(ENABLE_INCREMENTAL_AUTHORIZATION)` AND `isToggleOn(ENABLE_UPDATE_AUTHORIZATION_FOR_CARD_PAYMENTS)` both required at line 661; gates MADA DMS-specific logic in `S2IAcquirerHelper`.

### 🔴 Toggle OFF Impact

**Business Impact (Class: `CaptureExecutorFactory.java` · Line 55 · [CPE]):**
***When OFF, the `UpdateAuthorisationThenCaptureExecutor` is never returned*** — all captures use `m_captureExecutor` regardless of excessive capture status. No automatic Update Authorization is triggered before capture.

**Field Impact:**
Internal only — `UPDATE_AUTH_THEN_CAPTURE` path not available; excessive capture proceeds to standard `captureExecutor` only.

**Business Impact (Class: `AuthCaptureModeHelper.java` · Line 454 · [CPE]):**
***When OFF, the outstanding authorization amount is not augmented from Update Authorization*** — excessive capture validation uses only the original outstanding amount. Captures above the original authorized amount are more likely to be rejected.

**Field Impact:**
Internal only — `outstandingAmount` not recalculated from `lastestAuthAmount`; standard `outstandingAuthorisedAmount` used.

**Business Impact (Class: `MerchantAcquirerRelationshipLookup.java` · Line 325 · [CPE]):**
***When OFF, `UpdateAuthorisation` transaction type is not explicitly handled in acquirer link matching*** — UpdateAuth transactions must match the acquirer supported transactions list or fall through to other criteria.

**Field Impact:**
Internal only — `UpdateAuthorisationTransaction` type code not whitelisted in `isTransactionTypeMatch()`; acquirer link resolution depends on other criteria.

**Business Impact (Class: `UpdateAuthorisationThenCaptureExecutor.java` · Line 160 · [CPE]):**
***When OFF, `shouldPopulateInitialAuthorizationForUpdateAuthorizationTransaction()` returns false*** — incremental authorization data not populated for update-auth-then-capture; initial auth data absent from UpdateAuth execution path.

**Field Impact:**
Internal only — initial authorization not set in `UpdateAuthorisationThenCaptureExecutor`.

**Business Impact (Class: `UpdateAuthorisationRequestValidator.java` · Line 326 · [Orchestrator]):**
***When OFF, all card payment Update Authorization requests are rejected with `InvalidStateException`*** — merchants cannot perform Update Authorization on card payments regardless of API version. "Update Authorization for a card payment is not supported."

**Field Impact:**
Internal only — Update Authorization for card payments blocked at validation layer; request not forwarded to CPE.

**Business Impact (Class: `OnBehalfUpdateAuthorizationValidator.java` · Line 179 · [Orchestrator]):**
***When OFF, `onBehalfUpdateAuthSupportedInVersion()` always returns false*** — the on-behalf Update Authorization path for excessive captures is disabled; excessive captures do not trigger automatic Update Auth via the On Behalf path.

**Field Impact:**
Internal only — on-behalf Update Auth for excessive capture not activated.

**Business Impact (Class: `S2IAcquirerHelper.java` · Line 661 · [CPE]):**
***When OFF, `isLastUpdatedAuthorizeTxnMadaDMS()` returns false regardless of acquirer type*** — MADA DMS-specific Update Auth processing in S2I not applied.

**Field Impact:**
Internal only — `isMadaAcquirerWithDmsTransaction` check not reached; standard S2I flow used for MADA DMS transactions.

### Implementation Details

| Field | Details |
|---|---|
| **Implementation Class** | `CaptureExecutorFactory`, `AuthCaptureModeHelper`, `MerchantAcquirerRelationshipLookup`, `UpdateAuthorisationThenCaptureExecutor`, `S2IAcquirerHelper` (CPE); `UpdateAuthorisationRequestValidator`, `OnBehalfUpdateAuthorizationValidator` (Orchestrator) |
| **Line Number(s)** | 55, 454, 325, 160, 661 (CPE); 326, 179 (Orchestrator) |
| **Repository** | CPE, Orchestrator |

---

## Toggle 79: Enable first ride risk for transit

| Field | Details |
|---|---|
| **Toggle Name** | Enable first ride risk for transit |
| **Confluence Page** | [View Page](https://confluence.mastercard.int/spaces/MPGSIOG/pages/2376453590/Enable+first+ride+risk+for+transit) |
| **Team Responsible** | Team Pegasus |
| **Applications Affected** | CardPaymentEngine |
| **Is S2A Toggle** | FALSE |
| **Current Status** | TBD |

### Summary
First Ride Risk Framework allows a Transit merchant to capture a failed authorization below 8 Dollars AU. When enabled, allows merchant to submit transit transaction with `FIRST_RIDE_RISK` enum and Merchant Initiated Debt recovery with amount 0 for Mastercard. This toggle spans CPE (S2I message building) and Orchestrator (routing validation and authorisation operation).

### 🟢 Toggle ON Impact

**Business Impact (Class: `S2IAcquirerV1.java` · Line 2849 · [CPE]):**
***For S2I transit transactions, when toggle is ON, First Ride Risk (FRR) processing is enabled*** — for Mastercard standalone captures with `FIRST_RIDE_RISK` known fare or aggregated fare type, a special F60 reserved private value (`200+1400`) is set in the ISO message indicating FRR transit.

**Field Impact:**
***`ISO DE60 (Reserved Private)`*** — value set to `'2001400'` for Mastercard FRR transit standalone captures (S2I message field populated); affects acquirer routing and processing for FRR transit transactions.

**Business Impact (Class: `RoutedServicesDelegate.java` · Line 1049 · [Orchestrator]):**
***When ON, transit capture requests with `FIRST_RIDE_RISK` aggregated or known fare types are allowed to proceed*** — the gateway validates that transaction source is `CARD_PRESENT` and deferred auth flag rules are met for FRR captures.

**Field Impact:**
Internal validation only — `TRANSIT_AGGREGATED_FARE_TYPE` and `TRANSIT_KNOWN_FARE_TYPE` fields validated for FRR captures; no TSPI/ISO fields directly affected.

**Business Impact (Class: `AuthorisationOperation.java` · Line 233 · [Orchestrator]):**
***When ON, `isMerchantInitiatedDebtRecovery()` returns true for transit authorisations where `transactionSource=MERCHANT`, `amount=0`, and transit group contains `DEBT_RECOVERY` type*** (known or aggregated fare) — enabling zero-amount MIT debt recovery for FRR transit.

**Field Impact:**
Internal routing decision — `isMerchantInitiatedDebtRecovery()` affects how Orchestrator processes FRR debt recovery authorisations; `transit.group.knownFare.type` or `transit.group.aggregatedFare.type` evaluated.

### 🔴 Toggle OFF Impact

**Business Impact (Class: `S2IAcquirerV1.java` · Line 2849 · [CPE]):**
***When OFF, `isFirstRideRiskKFT()` and `isFirstRideRiskAFT()` both return false*** — FRR transit handling not applied; ISO DE60 reserved private value not set for transit FRR transactions.

**Field Impact:**
`ISO DE60` not populated with FRR value for transit transactions.

**Business Impact (Class: `RoutedServicesDelegate.java` · Line 1049 · [Orchestrator]):**
***When OFF, transit capture requests containing FRR fare types throw `InvalidFieldException`*** — FRR type captures are rejected as invalid, merchants cannot submit FRR transit captures.

**Field Impact:**
Internal validation — `InvalidFieldException` thrown for `TRANSIT_AGGREGATED_FARE_TYPE` or `TRANSIT_KNOWN_FARE_TYPE`; transaction rejected.

**Business Impact (Class: `AuthorisationOperation.java` · Line 233 · [Orchestrator]):**
***When OFF, `isMerchantInitiatedDebtRecovery()` always returns false*** — zero-amount transit debt recovery authorisations are not treated as merchant-initiated debt recovery; standard auth flow applied instead.

**Field Impact:**
Internal only — FRR debt recovery path not entered.

### Implementation Details

| Field | Details |
|---|---|
| **Implementation Class** | `S2IAcquirerV1` (CPE); `RoutedServicesDelegate`, `AuthorisationOperation` (Orchestrator) |
| **Line Number(s)** | 2849 (CPE); 1049, 233 (Orchestrator) |
| **Repository** | CPE, Orchestrator |

---

## Toggle 80: Enable pay operation for EMV Request

| Field | Details |
|---|---|
| **Toggle Name** | Enable pay operation for EMV Request |
| **Confluence Page** | [View Page](https://confluence.mastercard.int/spaces/MPGSIOG/pages/2376452970/Enable+pay+operation+for+EMV+Request) |
| **Team Responsible** | Team CBA |
| **Applications Affected** | CardPaymentEngine |
| **Is S2A Toggle** | FALSE |
| **Current Status** | Enabled for CBA merchants as of 19.3 |

### Summary
Enables merchants to submit a single Pay request with EMV request data in `sourceOfFunds.provided.card.emvRequest` for S2I and S2A, rather than separate Authorization and Capture transactions. Without the toggle the EMV Pay request is rejected with an `InvalidFieldException`. This toggle was originally enabled for CBA merchants and controls whether EMV ICC request data is accepted on Pay (purchase) operations.

### 🟢 Toggle ON Impact

**Business Impact (Class: `EmvRequestValidator.java` · Line 33 · [Orchestrator]):**
***When toggle is ON, EMV ICC request data submitted with a PAY (purchase) operation is accepted*** — the `InvalidFieldException` guard is not triggered, allowing merchants with EMV-capable terminals to submit `emvRequest` data alongside Pay operations for S2I and S2A acquirers.

**Field Impact:**
***`sourceOfFunds.provided.card.emvRequest`*** (TSPI/merchant API request field) — accepted for PAY operations when toggle ON; `PaymentBusField.CARD_EMV_ICC_REQUEST` `InvalidFieldException` not thrown.

### 🔴 Toggle OFF Impact

**Business Impact (Class: `EmvRequestValidator.java` · Line 33 · [Orchestrator]):**
***When toggle is OFF (evaluated negatively — `!isOn(TOGGLE)`), EMV ICC request data submitted with a PAY (purchase) operation causes an `InvalidFieldException` to be thrown*** — protecting against unsupported EMV data on Pay operations. Merchants using EMV-capable terminals for purchase operations cannot submit EMV data with Pay requests.

**Field Impact:**
***`sourceOfFunds.provided.card.emvRequest`*** rejected for `PAYMENT` transaction type; `PaymentBusField.CARD_EMV_ICC_REQUEST` `InvalidFieldException` thrown with message: "EMV Request Data is not supported for Pay operations".

### Implementation Details

| Field | Details |
|---|---|
| **Implementation Class** | `EmvRequestValidator` |
| **Line Number(s)** | 33 |
| **Repository** | Orchestrator |

---

## Toggle 81: Enable transit transaction without sourceOfFunds

| Field | Details |
|---|---|
| **Toggle Name** | Enable transit transaction without sourceOfFunds |
| **Confluence Page** | [View Page](https://confluence.mastercard.int/spaces/MPGSIOG/pages/2376453638/Enable+transit+transaction+without+sourceOfFunds) |
| **Team Responsible** | Team Pegasus |
| **Applications Affected** | Orchestrator, CardPaymentEngine |
| **Is S2A Toggle** | FALSE |
| **Current Status** | 24.10 Release - Disabled for all on release; enabled for single merchant thereafter |

### Summary
Allows merchants to submit MERCHANT-initiated debt recovery transit transactions without card details, fetching card details from a `referenceOrderId` instead. When the toggle is disabled, an error is thrown if card details are absent. This toggle enables the First Ride Risk (FRR) transit use case where card details are deferred to a subsequent debt recovery transaction.

### 🟢 Toggle ON Impact

**Business Impact (Class: `S2IAcquirerV1.java` · Line 8305 · [CPE]):**
***When ON, the S2I acquirer processes transit debt recovery transactions (`isTransitDebtRecovery`) correctly*** — `isTransitDebtRecovery()` returns true, allowing debt recovery transactions (transit fare collection with deferred auth where no live auth was performed) to proceed through the S2I acquirer message building path without a source of funds error.

**Field Impact:**
Internal S2I message routing — `ENABLE_TRANSIT_WITHOUT_SOURCE_OF_FUNDS` gates `isTransitDebtRecovery()` at line 8305; transit debt recovery transactions proceed through S2I ISO message building without `sourceOfFunds` mandatory check; no direct TSPI/ISO field added but the S2I message is allowed to be built for this transit transaction type.

**Business Impact (Class: `AuthorisationOperation.java` · Line 120 · [Orchestrator]):**
***When ON, before authorisation validation for transit transactions, the gateway calls `decorateAndValidateSourceOfFundsForTransit()`*** — which handles the special case where a transit transaction may proceed without a card `sourceOfFunds` by deriving it from a reference order or debt recovery context. Merchants submitting transit FRR/debt recovery authorisations without card source of funds can proceed.

**Field Impact:**
***`sourceOfFunds`*** (TSPI/merchant API request field) — `decorateAndValidateSourceOfFundsForTransit()` called for transit auth; `sourceOfFunds` may be derived from `referenceOrderId` or validated as absent for MIT debt recovery transit; field not rejected as mandatory for qualifying transit transactions.

**Business Impact (Class: `PurchaseOperation.java` · Line 166 · [Orchestrator]):**
***When ON, the same `decorateAndValidateSourceOfFundsForTransit()` call is made for purchase (pay) operations*** — transit purchases (including FRR/debt recovery pay operations) can proceed without a standard card `sourceOfFunds` when conditions are met.

**Field Impact:**
***`sourceOfFunds`*** (TSPI/merchant API request field) — `decorateAndValidateSourceOfFundsForTransit()` invoked for transit pay; `sourceOfFunds` derived from `referenceOrderId` for FRR debt recovery pay; field not mandatory for qualifying transit pay operations when toggle ON.

**Business Impact (Class: `CaptureRequestValidator.java` · Line 555 · [Orchestrator]):**
***When ON, for FRR (First Ride Risk) capture requests, the validator enforces strict rules*** — must provide either `sourceOfFunds` OR a `referenceOrderId` (not both); if `referenceOrderId` provided, the referenced order must exist and card details must be absent. This enables transit captures referencing a prior order instead of supplying card details directly.

**Field Impact:**
***`sourceOfFunds`*** and ***`order.referenceOrderId`*** (TSPI/merchant API request fields) — for FRR transit captures, either `sourceOfFunds` or `referenceOrderId` required (not both); `referenceOrderId` validated as existing order; card details with `referenceOrderId` rejected as conflicting.

### 🔴 Toggle OFF Impact

**Business Impact (Class: `S2IAcquirerV1.java` · Line 8305 · [CPE]):**
***When OFF, `isTransitDebtRecovery()` always returns false*** — transit debt recovery transactions that lack source of funds are not recognized as valid and cannot proceed through S2I acquirer processing. Transit debt recovery use case blocked at S2I message level.

**Field Impact:**
Internal only — `isTransitDebtRecovery()` returns false; transit debt recovery S2I path not entered; transaction may fail validation.

**Business Impact (Class: `AuthorisationOperation.java` · Line 120 · [Orchestrator]):**
***When OFF, `decorateAndValidateSourceOfFundsForTransit()` is not called for authorisation*** — transit requests must provide standard `sourceOfFunds` or fail the normal validation. Transit debt recovery/FRR authorisations without `sourceOfFunds` are rejected.

**Field Impact:**
`sourceOfFunds` required for all authorisations; no transit-specific `sourceOfFunds` bypass applied.

**Business Impact (Class: `PurchaseOperation.java` · Line 166 · [Orchestrator]):**
***When OFF, no `sourceOfFunds` transit decoration/bypass applied for pay operations*** — all pay requests must provide standard `sourceOfFunds`; transit FRR/debt recovery pay operations without `sourceOfFunds` are rejected.

**Field Impact:**
`sourceOfFunds` required for all pay operations; transit `sourceOfFunds` exception not applied.

**Business Impact (Class: `CaptureRequestValidator.java` · Line 555 · [Orchestrator]):**
***When OFF, FRR transit capture `sourceOfFunds` validation is not applied via this path*** — captures proceed without the special FRR `sourceOfFunds`/`referenceOrderId` logic; transit captures must follow standard validation rules for `sourceOfFunds`.

**Field Impact:**
`sourceOfFunds` standard validation applies; `referenceOrderId`-based `sourceOfFunds` derivation for FRR captures not triggered.

### Implementation Details

| Field | Details |
|---|---|
| **Implementation Class** | `S2IAcquirerV1` (CPE); `AuthorisationOperation`, `PurchaseOperation`, `CaptureRequestValidator` (Orchestrator) |
| **Line Number(s)** | 8305 (CPE); 120, 166, 555 (Orchestrator) |
| **Repository** | CPE, Orchestrator |

---

## Toggle 82: Industry Practice Partial Shipment support for 3RI Authentication transactions

| Field | Details |
|---|---|
| **Toggle Name** | Industry Practice Partial Shipment support for 3RI Authentication transactions |
| **Confluence Page** | [View Page](https://confluence.mastercard.int/spaces/MPGSIOG/pages/2376453701/Industry+Practice+Partial+Shipment+support+for+3RI+Authentication+transactions) |
| **Team Responsible** | T-Pyxis |
| **Applications Affected** | CardPaymentEngine |
| **Is S2A Toggle** | FALSE |
| **Current Status** | TBD |

### Summary
When `authentication.channel=MERCHANT_REQUESTED` and `authentication.purpose=PAYMENT_TRANSACTION` (3RI device channel), prior authentication data fields are mapped to 3DS server fields. The toggle controls this mapping behaviour for 3RI partial shipment Industry Practice — enabling prior authentication transaction IDs and agreement payment reasons to be correctly linked for Mastercard partial shipment scenarios.

### 🟢 Toggle ON Impact

**Business Impact (Class: `CardholderAuthenticationDTOBuilderImpl.java` · Line 86 · [CPE]):**
***When ON and for 3RI (3DS2 Requestor Initiated) auth/purchase transactions, the `payerAuthenticationTransactionId` from the original authentication is set in the `CardholderAuthenticationDTO`*** — enabling partial shipment Industry Practice linking. Subsequent Mastercard partial shipments reference the original 3DS authentication.

**Field Impact:**
Internal DTO population — `cardholderAuthenticationDTO.setPayerAuthenticationTransactionId()` set from authentication data when `INDUSTRY_PRACTICE_PARTIAL_SHIPMENT_SUPPORT_FOR_3RI` enabled; used in downstream S2I/TSPI message building.

**Business Impact (Class: `BaseAuthorisationPayRequestDecorator.java` · Line 107 · [Orchestrator]):**
***When ON, for Auth/Pay transactions the decorator calls `decorateAgreementPaymentReasonAndReferenceOrderIdFor3RIPartialShipment()`*** — populating `agreementPaymentReason` and `referenceOrderId` on the request from the 3DS payer authentication transaction context, enabling correct Industry Practice partial shipment 3RI linkage.

**Field Impact:**
***`agreement.paymentReason`*** (TSPI/merchant API field) and ***`order.referenceOrderId`*** populated from 3DS authentication context for 3RI partial shipment when toggle ON.

### 🔴 Toggle OFF Impact

**Business Impact (Class: `CardholderAuthenticationDTOBuilderImpl.java` · Line 86 · [CPE]):**
***When OFF, the payer authentication transaction ID is not set in the `CardholderAuthenticationDTO` for 3RI transactions*** — partial shipment Industry Practice 3RI linking is absent.

**Field Impact:**
Internal only — `cardholderAuthenticationDTO.payerAuthenticationTransactionId` not populated for 3RI partial shipment transactions.

**Business Impact (Class: `BaseAuthorisationPayRequestDecorator.java` · Line 107 · [Orchestrator]):**
***When OFF, the decoration for 3RI partial shipment is skipped*** — `agreementPaymentReason` and `referenceOrderId` are not populated from the authentication context; Industry Practice 3RI partial shipment linking is absent.

**Field Impact:**
***`agreement.paymentReason`*** and ***`order.referenceOrderId`*** not decorated from 3DS authentication for 3RI partial shipments.

### Implementation Details

| Field | Details |
|---|---|
| **Implementation Class** | `CardholderAuthenticationDTOBuilderImpl` (CPE); `BaseAuthorisationPayRequestDecorator` (Orchestrator) |
| **Line Number(s)** | 86 (CPE); 107 (Orchestrator) |
| **Repository** | CPE, Orchestrator |

---

## Toggle 83: Merchant Initiated Industry Practice Phase 2 Transactions- TSPI

| Field | Details |
|---|---|
| **Toggle Name** | Merchant Initiated Industry Practice Phase 2 Transactions- TSPI |
| **Confluence Page** | [View Page](https://confluence.mastercard.int/spaces/MPGSIOG/pages/2376453377/Merchant+Initiated+Industry+Practice+Phase+2+Transactions-+TSPI) |
| **Team Responsible** | Ulhas Nagose |
| **Applications Affected** | CardPaymentEngine |
| **Is S2A Toggle** | TRUE |
| **Current Status** | TBD |

### Summary
Adds support for Industry Practice Merchant-Initiated Transactions (MIT) for Mastercard TSPI acquirers including Related/Delayed Charge and No Show Charge transaction types. The toggle controls availability of these new MIT industry practice types, enabling the Phase 2 TSPI flow where `resubmission` flag and `industryTransactionType` fields are set on the TSPI acquirer message for Mastercard.

### 🟢 Toggle ON Impact

**Business Impact (Class: `FinancialTransactionUtil.java` · Line 595 · [CPE]):**
***When ON, for Mastercard transactions with an agreement ID or agreement type, `shouldNotPopulateAgreementData()` returns true when the transaction is a resubmission OR has an `agreementPaymentReason`*** — preventing legacy agreement data population, enabling the new Industry Practice Phase 2 flow where resubmission and `industryTransactionType` (TSPI Phase 2) data are used instead.

**Field Impact:**
Internal TSPI message building logic — `TOGGLE_MERCHANT_INITIATED_INDUSTRY_PRACTICE_TRANSACTIONS_TSPI_PHASE_2` gates TSPI `Transaction.industryTransactionType` and `Transaction.resubmission` population; enables Phase 2 MIT transaction categorization.

**Business Impact (Class: `TspiRequestMessageBuilder.java` · Line 1287 · [CPE]):**
***When ON, for Mastercard TSPI transactions the `resubmission` flag and `industryTransactionType` (derived from `agreementPaymentReason`) are set on the TSPI Transaction message*** — enabling Phase 2 Industry Practice MIT categorization in the TSPI acquirer message for Mastercard.

**Field Impact:**
***TSPI: `Transaction.Resubmission`*** — set from `transaction.getResubmission()`; ***TSPI: `Transaction.IndustryTransactionType`*** — set via `IndustryTransactionTypeEnum.fromValue(transaction.getAgreementPaymentReason())` for Mastercard TSPI transactions when toggle ON.

### 🔴 Toggle OFF Impact

**Business Impact (Class: `FinancialTransactionUtil.java` · Line 595 · [CPE]):**
***When OFF, `shouldNotPopulateAgreementData()` uses legacy conditions*** — resubmission and `agreementPaymentReason` checks for Mastercard MIT are not applied; TSPI Phase 2 data not used for Mastercard MIT transactions.

**Field Impact:**
TSPI `Transaction.industryTransactionType` and `Transaction.resubmission` not set for Mastercard MIT via Phase 2 path.

**Business Impact (Class: `TspiRequestMessageBuilder.java` · Line 1287 · [CPE]):**
***When OFF, `Transaction.Resubmission` and `Transaction.IndustryTransactionType` are not set on the TSPI message for Mastercard*** — Phase 2 MIT categorization absent; legacy TSPI message format used for Mastercard MIT transactions.

**Field Impact:**
***TSPI: `Transaction.Resubmission`*** and ***`Transaction.IndustryTransactionType`*** absent for Mastercard in TSPI message.

### Implementation Details

| Field | Details |
|---|---|
| **Implementation Class** | `FinancialTransactionUtil`, `TspiRequestMessageBuilder` (CPE) |
| **Line Number(s)** | 595, 1287 |
| **Repository** | CPE |

> ⚠️ *S2A Note: This toggle is marked `is_s2a=TRUE`. The `TspiRequestMessageBuilder` implementation row confirms TSPI/S2A acquirer message impact — `Transaction.Resubmission` and `Transaction.IndustryTransactionType` are set directly in the TSPI acquirer message for Mastercard MIT Phase 2 transactions.*

---

## Toggle 84: Remove Orchestrator Session Merge

| Field | Details |
|---|---|
| **Toggle Name** | Remove Orchestrator Session Merge |
| **Confluence Page** | [View Page](https://confluence.mastercard.int/spaces/MPGSIOG/pages/2376452912/Remove+Orchestrator+Session+Merge) |
| **Team Responsible** | Continuous Engineering |
| **Applications Affected** | Orchestrator |
| **Is S2A Toggle** | FALSE |
| **Current Status** | TNSPay 6.1 - must be enabled for all MSOs once rolled out |

### Summary
Removes HPF session merge functionality from Orchestrator which causes failures when a session is provided by the merchant. Session details are now merged in WS API so Orchestrator merge is redundant. The toggle controls whether the legacy Orchestrator session merge applies — when enabled, only session validation occurs in Orchestrator without overlaying session card data onto the transaction.

### 🟢 Toggle ON Impact

**Business Impact (Class: `CardDetailsDecorator.java` · Line 167 · [Orchestrator]):**
***When ON, during card details decoration in Orchestrator, the session is only validated (`validateSession()`)*** — the gateway confirms the session exists and is valid for the merchant but does NOT merge/overlay the card details from the session into the transaction's `CardDetails` object. This removes the session merge step, preventing session card data from overwriting token/raw card data already resolved during decoration.

**Field Impact:**
`sourceOfFunds` (session-sourced card fields) — NOT merged into `CardDetails`; session card data not overlaid; only session existence validated via `m_sessionValidator.validateSession()`; card details remain as resolved from token/raw source.

### 🔴 Toggle OFF Impact

**Business Impact (Class: `CardDetailsDecorator.java` · Line 167 · [Orchestrator]):**
***When OFF, full session merge (`overlaySession()`) is applied*** — card details are retrieved from the session (`retrieveCardDetails()`) and overlaid onto the `CardDetails` object via `overlay()`. Session-sourced card number, expiry, and other card fields are merged into the decoration result, which may override token-resolved card data.

**Field Impact:**
`sourceOfFunds` card fields — session card details overlaid via `overlay(targetCardDetails, sessionCardDetails)`; session data may override token data in the decorated `CardDetails` result.

### Implementation Details

| Field | Details |
|---|---|
| **Implementation Class** | `CardDetailsDecorator` |
| **Line Number(s)** | 167 |
| **Repository** | Orchestrator |

---

## Toggle 85: Support Additional TSPI Mappings for COF Transactions

| Field | Details |
|---|---|
| **Toggle Name** | Support Additional TSPI Mappings for COF Transactions |
| **Confluence Page** | [View Page](https://confluence.mastercard.int/spaces/MPGSIOG/pages/2376453536/Support+Additional+TSPI+Mappings+for+COF+Transactions) |
| **Team Responsible** | Anup Ambesange [C] |
| **Applications Affected** | CardPaymentEngine |
| **Is S2A Toggle** | TRUE |
| **Current Status** | TBD |

### Summary
Controls multiple TSPI mapping fixes: `agreement.amountVariability` and `agreement.noOfPayments` for Pay operations, `financialNetworkTransactionId` for `referenceOrderId`, and `traceId` mapping for Maestro card scheme. All fixes are applied atomically via this single toggle, enabling correct COF (Credential-on-File) transaction chaining for S2A acquirers.

### 🟢 Toggle ON Impact

**Business Impact (Class: `VerificationAuthorisationResponseDecorator.java` · Line 51 · [CPE]):**
***When ON, for VERIFY transactions processed via an S2A acquirer (`JsonMegaMessageMap`), the `transactionIdentifier` from the acquirer response is set on `authResponse.transactionIdentifier`*** — enabling merchants to receive the COF transaction identifier in the VERIFY response for S2A acquirers, enabling proper COF chaining.

**Field Impact:**
***`authorizationResponse.transactionIdentifier`*** (TSPI/merchant API response field) populated from `copyFrom.getExternalTransactionId()` for S2A VERIFY transactions when toggle ON.

**Business Impact (Class: `FinancialTransactionUtil.java` · Line 870 · [CPE]):**
***When ON, `isS2AMessageMapSupported()` returns true only if both the toggle is ON AND the acquirer supports `JsonMegaMessageMap`*** — gates all S2A COF additional mappings (e.g., Financial Network Transaction ID from `referenceOrderId`).

**Field Impact:**
Internal gate for TSPI COF flow — `TOGGLE_TO_SUPPORT_ADDITIONAL_TSPI_MAPPINGS_FOR_COF_TRANSACTIONS` must be ON for `shouldSetFinancialNTIDUsingReferenceOIDForMastercardOrMaestro()` and `shouldSetFinancialNTIDUsingReferenceOIDForOtherCards()` to trigger.

### 🔴 Toggle OFF Impact

**Business Impact (Class: `VerificationAuthorisationResponseDecorator.java` · Line 51 · [CPE]):**
***When OFF, `transactionIdentifier` is only set for Elavon S2A VERIFY with 3DS auth*** — S2A COF VERIFY transactions at non-Elavon acquirers do not receive `transactionIdentifier` in the response.

**Field Impact:**
***`authorizationResponse.transactionIdentifier`*** absent for non-Elavon S2A VERIFY transactions.

**Business Impact (Class: `FinancialTransactionUtil.java` · Line 870 · [CPE]):**
***When OFF, `isS2AMessageMapSupported()` returns false*** — all additional TSPI COF mappings (FNTID from `referenceOrderId`, COF `transactionIdentifier`) are suppressed.

**Field Impact:**
***TSPI: `Acquirer.FinancialNetworkTransactionId`*** and ***`authorizationResponse.transactionIdentifier`*** not populated from COF reference order path.

### Implementation Details

| Field | Details |
|---|---|
| **Implementation Class** | `VerificationAuthorisationResponseDecorator`, `FinancialTransactionUtil` (CPE) |
| **Line Number(s)** | 51, 870 |
| **Repository** | CPE |

> ⚠️ *S2A Note: This toggle is marked `is_s2a=TRUE`. Both implementation rows are in CPE and directly affect S2A (`JsonMegaMessageMap`) acquirer flows — `authorizationResponse.transactionIdentifier` and `Acquirer.FinancialNetworkTransactionId` population for COF transactions are gated by this toggle for S2A acquirers.*

---

## Toggle 86: System Toggle: Enable BCI Pagos Custom Payment Plans

| Field | Details |
|---|---|
| **Toggle Name** | System Toggle: Enable BCI Pagos Custom Payment Plans |
| **Confluence Page** | [View Page](https://confluence.mastercard.int/spaces/MPGSIOG/pages/2376453785/System+Toggle+Enable+BCI+Pagos+Custom+Payment+Plans) |
| **Team Responsible** | T-Draco |
| **Applications Affected** | BusinessService |
| **Is S2A Toggle** | FALSE |
| **Current Status** | TBD |

### Summary
Enables custom BCI Pagos payment plans in BusinessService. When enabled and the issuer country is in the allowed list, BCI Pagos plans are included in the WSAPI POI response for customer checkout. AUTH/PURCHASE transactions are blocked if Pagos Plan Offer IDs are present and the BIN issuer country is not in the allowed list.

### 🟢 Toggle ON Impact

**Business Impact (Class: `PaymentPlanServiceHelper.java` · Line 208 · [CPE]):**
***When ON, the BCI Pagos installment payment plan validates that the card issuer country is in the configured list of allowed issuer countries*** — if the issuer country does not match, an `InvalidRequestException` is thrown (`'Payment Plan is not supported for the card issuer country.'`), preventing unsupported BCI Pagos card country combinations.

**Field Impact:**
Internal payment plan eligibility check — card issuer country validated against `allowedIssuerCountries` configuration; no direct TSPI/ISO acquirer fields, but controls whether BCI Pagos payment plan request is accepted or rejected.

### 🔴 Toggle OFF Impact

**Business Impact (Class: `PaymentPlanServiceHelper.java` · Line 208 · [CPE]):**
***When OFF, the card issuer country restriction for BCI Pagos is not applied*** — any card issuer country is accepted for BCI Pagos payment plans regardless of `allowedIssuerCountries` configuration.

**Field Impact:**
Internal only — card issuer country validation skipped; all countries accepted for BCI Pagos plans.

### Implementation Details

| Field | Details |
|---|---|
| **Implementation Class** | `PaymentPlanServiceHelper` |
| **Line Number(s)** | 208 |
| **Repository** | CPE |

---

## Toggle 87: System Toggle: Enable Cross Region Routing

| Field | Details |
|---|---|
| **Toggle Name** | System Toggle: Enable Cross Region Routing |
| **Confluence Page** | [View Page](https://confluence.mastercard.int/spaces/MPGSIOGWIP/pages/1086049014/System+Toggle+Enable+Cross+Region+Routing) |
| **Team Responsible** | Bifrost |
| **Applications Affected** | Orchestrator |
| **Is S2A Toggle** | FALSE |
| **Current Status** | 24.1.0 - MTF: Enabled for all, AP: Enabled for all |

### Summary
Controls cross-region request routing behaviour. When enabled, eligible orders are routed from NA to AP based on order details rather than being processed in NA. Part of the 24.1.0 release X-region routing initiative for multi-region Mastercard Gateway deployments.

### 🟢 Toggle ON Impact

**Business Impact (Class: `CrossRegionRoutingDecisionMaker.java` · Line 390 · [Orchestrator]):**
***When ON (`CROSS_REGION_SWITCH` — for AP and NA regions), cross-region transaction routing is enabled for configured merchants*** — transactions for merchants with a remote region set to AP or NA are routed to the appropriate remote region instead of being processed locally. Supports multi-region Mastercard Gateway deployments.

**Field Impact:**
Internal routing only — `isAnyCrossRegionSwitchesOnWithRegionSet()` returns true for AP/NA merchants when toggle ON; transaction forwarded to remote region endpoint instead of local processing; no TSPI/ISO acquirer fields affected.

### 🔴 Toggle OFF Impact

**Business Impact (Class: `CrossRegionRoutingDecisionMaker.java` · Line 390 · [Orchestrator]):**
***When OFF, cross-region routing for AP/NA is disabled*** — all transactions are processed locally regardless of the merchant's configured remote region; cross-region routing not applied for AP/NA merchants.

**Field Impact:**
Internal only — transaction processed locally; no cross-region forwarding.

### Implementation Details

| Field | Details |
|---|---|
| **Implementation Class** | `CrossRegionRoutingDecisionMaker` |
| **Line Number(s)** | 390 |
| **Repository** | Orchestrator |

---

## Toggle 88: System Toggle: Enable SCOF as a Network Token Provider

| Field | Details |
|---|---|
| **Toggle Name** | System Toggle: Enable SCOF as a Network Token Provider |
| **Confluence Page** | [View Page](https://confluence.mastercard.int/spaces/MPGSIOG/pages/2376453584/System+Toggle+Enable+SCOF+as+a+Network+Token+Provider) |
| **Team Responsible** | T-Draco |
| **Applications Affected** | CardPaymentEngine |
| **Is S2A Toggle** | FALSE |
| **Current Status** | DELIVERED IN 24.2 |

### Summary
Controls whether SCOF (Secure Card On File) or M4M (MDES for Merchants) is used for Mastercard network tokenization. When enabled, tokenization flows for Mastercard go via SCOF; when disabled the existing M4M process applies. Delivered in 24.2.

### 🟢 Toggle ON Impact

**Business Impact:**
⚠️ *Implementation class not found in the analysed repositories. Toggle likely resides in the SCOF (Stored Card On File) token service or network token provisioning repo not present in this workspace.*

**Field Impact:**
Unknown — toggle likely enables the SCOF service to act as a Network Token Provider for Mastercard card tokenisation flows, directing tokenisation requests through SCOF instead of M4M.

### 🔴 Toggle OFF Impact

**Business Impact:**
⚠️ *Implementation class not found in the analysed repositories.*

**Field Impact:**
When OFF or absent, the existing M4M (MDES for Merchants) process applies for Mastercard network tokenisation; SCOF network token provider role not activated.

### Implementation Details

| Field | Details |
|---|---|
| **Implementation Class** | NOT_FOUND — likely in SCOF/network token provisioning service repo (not in analysed workspace) |
| **Line Number(s)** | N/A |
| **Repository** | UNKNOWN |

---

## Toggle 89: System Toggle: Enable timeout on merchant cache load

| Field | Details |
|---|---|
| **Toggle Name** | System Toggle: Enable timeout on merchant cache load |
| **Confluence Page** | [View Page](https://confluence.mastercard.int/spaces/MPGSIOG/pages/2376453538/System+Toggle+Enable+timeout+on+merchant+cache+load) |
| **Team Responsible** | Team CE |
| **Applications Affected** | BusinessService |
| **Is S2A Toggle** | FALSE |
| **Current Status** | 24.5 Release |

### Summary
When ehCache loads merchant data from DB, this toggle enforces shorter wait-times for the loading thread so it is ejected and retried, allowing 6 attempts in a 60s window instead of 1. Mitigates DB latency-induced thread queue timeouts in the BusinessService merchant cache.

### 🟢 Toggle ON Impact

**Business Impact (Class: `MerchantCacheEntryFactory.java` · Line 57 · [BusinessService]):**
***When ON, merchant data cache load operations (`updateEntryValue` and `loadMerchantFromDb`) are executed with a configurable time limit using an executor service*** — if the DB retrieval exceeds the timeout (`cacheLoadWaitTimeInSeconds`), a `TimeoutException` is thrown and logged, preventing indefinite blocking of the cache loading thread.

**Field Impact:**
Internal only — no TSPI/ISO/acquirer fields affected. Internal: cache loading wrapped in a time-bounded `Future`; timeout event logged with warning; `MerchantCacheEntryFactory` operation cancelled and rethrown.

### 🔴 Toggle OFF Impact

**Business Impact (Class: `MerchantCacheEntryFactory.java` · Line 57 · [BusinessService]):**
***When OFF, merchant cache loading has no time limit*** — DB retrieval may block indefinitely; merchant cache update waits for DB response regardless of how long it takes. Risk of thread blocking under DB performance degradation.

**Field Impact:**
Internal only — `Callable` task executed directly without timeout; `ExecutorService` not used.

### Implementation Details

| Field | Details |
|---|---|
| **Implementation Class** | `MerchantCacheEntryFactory` |
| **Line Number(s)** | 57 |
| **Repository** | BusinessService |

---

## Toggle 90: System Toggle: Extend SCT token DB locking behaviour

| Field | Details |
|---|---|
| **Toggle Name** | System Toggle: Extend SCT token DB locking behaviour |
| **Confluence Page** | [View Page](https://confluence.mastercard.int/spaces/MPGSIOG/pages/2376453429/System+Toggle+Extend+SCT+token+DB+locking+behaviour) |
| **Team Responsible** | Team CE |
| **Applications Affected** | CardPaymentEngine |
| **Is S2A Toggle** | FALSE |
| **Current Status** | 23.7 Release |

### Summary
Extends DB locking in SCT to cover the token fetch as well as subsequent updates, preventing a race condition where an MDES activation thread can overwrite a token between read and save. Fixes the niche race condition for near-immediate post-tokenise payments.

### 🟢 Toggle ON Impact

**Business Impact:**
⚠️ *Implementation class not found in the analysed repositories. Toggle likely resides in the SCT (Stored Card Token) service repo not present in this workspace.*

**Field Impact:**
Unknown — toggle likely extends the database row locking strategy for SCT token operations, applying a lock on the token fetch step as well as subsequent update steps to prevent concurrent MDES activation thread overwrites.

### 🔴 Toggle OFF Impact

**Business Impact:**
⚠️ *Implementation class not found in the analysed repositories.*

**Field Impact:**
When OFF or absent, existing SCT token DB locking behaviour applies — only subsequent update steps are locked; a race condition remains possible where an MDES activation thread can overwrite a token between read and save.

### Implementation Details

| Field | Details |
|---|---|
| **Implementation Class** | NOT_FOUND — likely in SCT (Stored Card Token) service repo (not in analysed workspace) |
| **Line Number(s)** | N/A |
| **Repository** | UNKNOWN |

---

## Toggle 91: System Toggle: Streamline SQL update for token use

| Field | Details |
|---|---|
| **Toggle Name** | System Toggle: Streamline SQL update for token use |
| **Confluence Page** | [View Page](https://confluence.mastercard.int/spaces/MPGSIOG/pages/2376453430/System+Toggle+Streamline+SQL+update+for+token+use) |
| **Team Responsible** | Team CE |
| **Applications Affected** | CardPaymentEngine |
| **Is S2A Toggle** | FALSE |
| **Current Status** | 23.6 Release |

### Summary
Limits the SCT DB update call to only update columns liable to change rather than every column, preventing an older thread from overwriting a newer token update. Companion fix to the Extend SCT token DB locking behaviour toggle.

### 🟢 Toggle ON Impact

**Business Impact:**
⚠️ *Implementation class not found in the analysed repositories. Toggle likely resides in the SCT (Stored Card Token) service repo not present in this workspace.*

**Field Impact:**
Unknown — toggle likely replaces a full-column token use SQL update with a streamlined partial-update targeting only columns liable to change, preventing an older in-flight thread from overwriting a more recent token update.

### 🔴 Toggle OFF Impact

**Business Impact:**
⚠️ *Implementation class not found in the analysed repositories.*

**Field Impact:**
When OFF or absent, the standard (non-streamlined) SQL update for token use is applied — all columns are updated on each token use write, allowing an older thread to potentially overwrite a newer token state.

### Implementation Details

| Field | Details |
|---|---|
| **Implementation Class** | NOT_FOUND — likely in SCT (Stored Card Token) service repo (not in analysed workspace) |
| **Line Number(s)** | N/A |
| **Repository** | UNKNOWN |

---

## Toggle 92: System Toggle: Update AssociatedTransaction For Excessive Capture

| Field | Details |
|---|---|
| **Toggle Name** | System Toggle: Update AssociatedTransaction For Excessive Capture |
| **Confluence Page** | [View Page](https://confluence.mastercard.int/spaces/MPGSIOG/pages/2376453618/System+Toggle+Update+AssociatedTransaction+For+Excessive+Capture) |
| **Team Responsible** | Team CE |
| **Applications Affected** | CardPaymentEngine |
| **Is S2A Toggle** | FALSE |
| **Current Status** | 24.9 Release - MTF/Production: Disabled for all |

### Summary
For Excessive Capture, the Associated Transaction element in acquirer response currently contains initial Authorization details. Toggle corrects this so it contains Update Authorization details for external acquirers that do not support TFTO block.

### 🟢 Toggle ON Impact

**Business Impact (Class: `MegaMessageMap.java` · Line 1944 · [CPE]):**
***For CAPT (capture) transactions*** where the previous transaction is an `UpdateAuthorisationTransaction` AND the acquirer does not support TFTO (all-transactions-for-this-order), the associated transaction is set to the UpdateAuthorisation transaction — ensuring the capture message uses the updated auth as the base for calculating the associated transaction amount in the S2A MEGA message, supporting excessive capture via Update Authorization flows.

**Field Impact:**
Internal S2A message building — associated transaction set to `UpdateAuthorisationTransaction` for CAPT; affects base amount and transaction linkage in MEGA message; no direct external TSPI/ISO fields but changes S2A message structure for `UPDATE_AUTH+CAPT` sequences.

### 🔴 Toggle OFF Impact

**Business Impact (Class: `MegaMessageMap.java` · Line 1944 · [CPE]):**
***When OFF, the UpdateAuthorisationTransaction*** is not used as the associated transaction for captures — standard previous-transaction lookup applies; excessive capture via Update Authorization may not be correctly supported in the S2A MEGA message.

**Field Impact:**
Internal — associated transaction for CAPT remains standard previous transaction; `UpdateAuthorisation` not used as CAPT base.

### Implementation Details

| Field | Details |
|---|---|
| **Implementation Class** | `MegaMessageMap` |
| **Line Number(s)** | 1944 |
| **Repository** | CPE |

---

## Toggle 93: System Toggle:Enable HSM Encryption For BatchSettlementService and PTS

| Field | Details |
|---|---|
| **Toggle Name** | System Toggle:Enable HSM Encryption For BatchSettlementService and PTS |
| **Confluence Page** | [View Page](https://confluence.mastercard.int/spaces/MPGSIOG/pages/2376453256/System+Toggle+Enable+HSM+Encryption+For+BatchSettlementService+and+PTS) |
| **Team Responsible** | Tadpole |
| **Applications Affected** | BatchSettlementService, PTS |
| **Is S2A Toggle** | FALSE |
| **Current Status** | 22.5 Release - enabled after one week of production deployment |

### Summary
Switches between in-memory AES encryption and HSM encryption for PCI data storage in Batch Settlement Service and PTS. When disabled: existing AES encryption used. When enabled: HSM encryption used. Created as part of Store PCI data securely features.

### 🟢 Toggle ON Impact

**Business Impact (Class: `CryptoServiceClient.java` · Line 185 · [BatchSettlementService]):**
***Sensitive data*** (e.g. PAN, bank account numbers) submitted in settlement request messages is decrypted from its internal `SensitiveData` wrapper and re-encrypted using HSM-backed cryptographic key via `encryptWithCryptoRole()` before being stored or forwarded — ensuring all sensitive financial data in BSS is protected at rest and in transit using HSM-grade encryption from the PTS crypto service.

**Field Impact:**
Internal encryption only — no TSPI/ISO/acquirer protocol fields affected externally. Internal: `SensitiveData.getSensitiveData(SensitiveDataDecrypterFactory.getDefault())` decrypted then `encryptWithCryptoRole(decryptedText)` called in `transformSensitiveDataForRequestMessage()`; HSM-encrypted ciphertext stored in place of plaintext or application-encoded value.

**Business Impact (Class: `CryptoServiceClient.java` · Line 201 · [BatchSettlementService]):**
***Sensitive data being persisted*** to the database (in `transformToDB()`) is decrypted from its `SensitiveData` wrapper then re-encrypted with the HSM crypto role via `encryptWithCryptoRole()` — guaranteeing HSM-encrypted ciphertext is written to the BSS database for PAN and bank account data fields. Protects all stored sensitive financial data with HSM-level encryption managed by the PTS crypto service.

**Field Impact:**
Internal persistence only — no TSPI/ISO/acquirer fields affected. Internal: `Toggles.isToggleOn(ENABLE_HSM_ENCRYPTION_FOR_BSS_PTS)` at line 201; if ON: `getSensitiveData()` then `encryptWithCryptoRole()` then HSM ciphertext written to DB.

### 🔴 Toggle OFF Impact

**Business Impact (Class: `CryptoServiceClient.java` · Line 185 · [BatchSettlementService]):**
***When OFF, `transformSensitiveDataForRequestMessage()` returns null*** for sensitive data — the sensitive data is not re-encrypted via HSM; the gateway does not apply HSM-grade encryption to settlement request message fields. Sensitive data in request messages handled without HSM protection.

**Field Impact:**
Internal only — `encryptWithCryptoRole()` not called; method returns null; no HSM encryption applied to sensitive request message fields.

**Business Impact (Class: `CryptoServiceClient.java` · Line 201 · [BatchSettlementService]):**
***When OFF, sensitive data*** written to the BSS database uses only the application-layer encoded format (`sensitiveData.toEncodedString()`) — HSM encryption NOT applied; data at rest protected only by application encoding, not HSM-backed key management.

**Field Impact:**
Internal only — `toEncodedString()` value persisted; database records contain application-encoded sensitive data without HSM crypto role protection.

### Implementation Details

| Field | Details |
|---|---|
| **Implementation Class** | `CryptoServiceClient`, `CryptoServiceClient` |
| **Line Number(s)** | 185, 201 |
| **Repository** | BatchSettlementService |

---

## Toggle 94: Account Updater

| Field | Details |
|---|---|
| **Toggle Name** | Account Updater |
| **Confluence Page** | [View Page](https://confluence.mastercard.int/spaces/MPGSIOG/pages/2376452891/Account+Updater) |
| **Team Responsible** | Continuous Engineering |
| **Applications Affected** | CardPaymentEngine |
| **Is S2A Toggle** | FALSE |
| **Current Status** | TBD - enabled once Account Updater functionality certified |

### Summary
Controls availability of Account Updater functionality for the Paymentech Salem acquirer. When disabled, Account Updater cannot be enabled on a merchant acquirer link and token submission/update components are not activated. Toggle used until functionality is certified.

### 🟢 Toggle ON Impact

**Business Impact (Class: `TokenFinaliser.java` · Line 466 · [Orchestrator]):**
***The gateway checks*** whether the merchant is eligible for Account Updater — the gateway activates Token Maintenance Service (`isTokenMaintenanceServiceEnabled()`) for the stored card, allowing card details to be automatically updated via Account Updater schemes (ABU, VAU) when the card number changes. Merchants must have `tokenMaintenanceServiceEnabled` configured to benefit.

**Field Impact:**
Internal token maintenance gate — `isRequestEligibleForAccountUpdater()` returns true when toggle ON AND `business.storedCardTokenDetails.isTokenMaintenanceServiceEnabled()`; no direct TSPI API field but controls whether Account Updater token refresh is triggered.

**Business Impact (Class: `CardSourceOfFundsUtil.java` · Line 56 · [Orchestrator]):**
***`hasNoSourceOfFundsWithValidRequest()` returns false*** only for non-account-updater token update requests (i.e., `ACCOUNT_UPDATER` verification strategy with destination token is valid) — allowing Account Updater requests to proceed without source of funds. When OFF, the toggle-guarded condition causes `hasNoSourceOfFundsWithValidRequest()` to return true immediately (toggle is checked with negation: `!isToggleOn`), blocking Account Updater flows.

**Field Impact:**
`sourceOfFunds` (TSPI/merchant API field) — not required for `ACCOUNT_UPDATER` verification strategy when toggle ON; required or validation bypassed based on toggle state.

### 🔴 Toggle OFF Impact

**Business Impact (Class: `TokenFinaliser.java` · Line 466 · [Orchestrator]):**
***When OFF, `isRequestEligibleForAccountUpdater()` returns false*** regardless of merchant configuration — Account Updater (Token Maintenance Service) is not activated; card details are not refreshed via ABU/VAU schemes.

**Field Impact:**
Internal only — token maintenance check bypassed; account updater flow not entered.

**Business Impact (Class: `CardSourceOfFundsUtil.java` · Line 56 · [Orchestrator]):**
***When OFF, `hasNoSourceOfFundsWithValidRequest()` returns true immediately*** regardless of verification strategy — Account Updater save-card flows are blocked from proceeding without source of funds.

**Field Impact:**
`sourceOfFunds` required; `ACCOUNT_UPDATER` verification strategy with destination token not permitted.

### Implementation Details

| Field | Details |
|---|---|
| **Implementation Class** | `TokenFinaliser`, `CardSourceOfFundsUtil` |
| **Line Number(s)** | 466, 56 |
| **Repository** | Orchestrator |

---

## Toggle 95: Apply overrideCardStoredOnFileIndicator

| Field | Details |
|---|---|
| **Toggle Name** | Apply overrideCardStoredOnFileIndicator |
| **Confluence Page** | [View Page](https://confluence.mastercard.int/spaces/MPGSIOG/pages/2376453184/Apply+overrideCardStoredOnFileIndicator) |
| **Team Responsible** | Luis Franco Marin |
| **Applications Affected** | CardPaymentEngine |
| **Is S2A Toggle** | FALSE |
| **Current Status** | TBD |

### Summary
Allows merchants to override gateway COF flagging behaviour via `transaction.acquirer.customData` `overrideCardStoredOnFileIndicator` tag. When toggle and tag enabled, gateway sets stored payment details indicator to not-stored and returns `sourceOfFunds.provided.card.storedOnFile=NOT_STORED`.

### 🟢 Toggle ON Impact

**Business Impact (Class: `CommonRequestHelper.java` · Line 703 · [CPE]):**
***The gateway checks*** `acquirerDetails.customData` for an `overrideCardStoredOnFileIndicator` = TRUE value — if found, card payment's `storedOnFile` is forcibly set to `NOT_STORED`, overriding the merchant-supplied value. Enables acquirer-level override of the Card Stored On File indicator for specific transactions (e.g., Carnival use case).

**Field Impact:**
***`sourceOfFunds.provided.card.storedOnFile`*** (TSPI/merchant API request field) — overridden to `NOT_STORED` when toggle ON and `acquirerDetails` customData contains `overrideCardStoredOnFileIndicator=TRUE`.

**Business Impact (Class: `SourceOfFundsHandler.java` · Line 64 · [Orchestrator]):**
***For Orchestrator-layer processing***, the `overrideCardStoredOnFileForCarnival()` method checks `acquirerDetails.customData` for `overrideCardStoredOnFileIndicator` = TRUE and sets `data.sourceOfFunds.storedOnFile` to `NOT_STORED` — applying the same acquirer-level override at the Orchestrator persistence layer as CPE does at the processing layer.

**Field Impact:**
***`sourceOfFunds.provided.card.storedOnFile`*** (TSPI/merchant API field) — overridden to `NOT_STORED` in `TransactionData` when toggle ON and `acquirerDetails` customData `overrideCardStoredOnFileIndicator=TRUE`.

### 🔴 Toggle OFF Impact

**Business Impact (Class: `CommonRequestHelper.java` · Line 703 · [CPE]):**
***When OFF, the `storedOnFile` override*** from `acquirerDetails` is not applied — merchant-supplied `storedOnFile` value is used as-is; no acquirer-level customData override of `CardStoredOnFile`.

**Field Impact:**
`sourceOfFunds.provided.card.storedOnFile` — uses merchant-provided value; acquirer customData override not applied.

**Business Impact (Class: `SourceOfFundsHandler.java` · Line 64 · [Orchestrator]):**
***When OFF, `overrideCardStoredOnFileForCarnival()` returns immediately*** without modifying `storedOnFile` — the Orchestrator persistence layer does not override the Card Stored On File indicator from acquirer customData.

**Field Impact:**
`sourceOfFunds.provided.card.storedOnFile` — not modified by Orchestrator; merchant-provided value persisted.

### Implementation Details

| Field | Details |
|---|---|
| **Implementation Class** | `CommonRequestHelper`, `SourceOfFundsHandler` |
| **Line Number(s)** | 703, 64 |
| **Repository** | CPE, Orchestrator |

---

---

## Toggle 96: Do not persist verification authorisation codes

| Field | Details |
|---|---|
| **Toggle Name** | Do not persist verification authorisation codes |
| **Confluence Page** | [View Page](https://confluence.mastercard.int/spaces/MPGSIOG/pages/2376452955/Do+not+persist+verification+authorisation+codes) |
| **Team Responsible** | Continuous Engineering |
| **Applications Affected** | CardPaymentEngine |
| **Is S2A Toggle** | FALSE |
| **Current Status** | 19.1 Release - disabled by default on release |

### Summary
Prevents authorisation codes returned by issuer for Verification transactions from being stored in the gateway shoptrans table. Fixes issue where subsequent authorisations were declined because the verification authorisation code was incorrectly submitted. Toggle was introduced in the 19.1 Release and is disabled by default on release.

### 🟢 Toggle ON Impact
**Business Impact:**
***When ON, for VERIFY (Address Verification) transactions*** the `authId` (authorisation code) is NOT persisted — it is replaced with `null` before calling the parent `setResult()` method. This prevents verification authorisation codes from being stored in the transaction record, improving data minimization for verify-only transactions.

**Field Impact:**
Internal only — `authId` parameter passed as `null` to `super.setResult()` when toggle ON; authorisation code not stored in the verification transaction record; `transaction.authorizationCode` absent for VERIFY transactions.

### 🔴 Toggle OFF Impact
**Business Impact:**
***When OFF, the standard `setResult()` logic applies*** — `authId` is persisted normally in the VERIFY transaction record alongside the other result fields.

**Field Impact:**
Internal only — `authId` stored in transaction record for VERIFY transactions; `transaction.authorizationCode` populated.

### Implementation Details
| Field | Details |
|---|---|
| **Implementation Class** | `AddressVerificationRequest` |
| **Line Number(s)** | 415 |
| **Repository** | CPE |

---

## Toggle 97: Populate payer authentication details on pre-risk RSPI

| Field | Details |
|---|---|
| **Toggle Name** | Populate payer authentication details on pre-risk RSPI |
| **Confluence Page** | [View Page](https://confluence.mastercard.int/spaces/MPGSIOG/pages/2376453181/Populate+payer+authentication+details+on+pre-risk+RSPI) |
| **Team Responsible** | Team Ragnarok |
| **Applications Affected** | CPE |
| **Is S2A Toggle** | FALSE |
| **Current Status** | As of 21.3.1.5 Release Date - MTF: Disabled for all; Production NA: Disabled for all; Production EU: Disabled for all; Production AP: Disabled for all; Production IN: Disabled for all |

### Summary
This toggle allows to populate payer authentication details on PRE AUTH WSAPI request. If the feature toggle is active and enabled, payer authentication details will be populated on pre-risk RSPI. Introduced to enrich the pre-risk context supplied to the Risk SPI with 3DS authentication data.

### 🟢 Toggle ON Impact
**Business Impact:**
***When ON and the cardholder authentication result is non-null***, the authentication ID (`authID`) from the 3DS result is set on the applicable transaction data source before the MEGA JSON pre-risk message is built — ensuring the authentication identifier is included in the RSPI (Risk SPI) MEGA JSON message sent to the risk provider for pre-risk assessment. Merchants with 3DS authentication benefit from richer pre-risk context at the risk provider.

**Field Impact:**
TSPI: `Transaction` (`AuthenticationId` / `authID` field) — `applicableTransaction.setAuthenticationId(context.getCardholderAuthenticationResult().getAuthID())` called at line 91 when toggle ON and authResult non-null; `authID` propagated into MEGA JSON risk request via `JsonMegaMessageAdaptor`.

### 🔴 Toggle OFF Impact
**Business Impact:**
***When OFF, the authentication ID is NOT set*** on the transaction data source — even if cardholder authentication details are available, they are not propagated into the pre-risk RSPI MEGA JSON message. The risk provider evaluates the pre-risk check without the 3DS authentication identifier.

**Field Impact:**
TSPI: `Transaction.AuthenticationId` absent from MEGA JSON pre-risk request; `setAuthenticationId()` not called; risk provider receives reduced authentication context.

### Implementation Details
| Field | Details |
|---|---|
| **Implementation Class** | `MegaJsonRiskRequest` |
| **Line Number(s)** | 91 |
| **Repository** | CPE |

---

## Toggle 98: System Toggle:Enable DPG New Mapping

| Field | Details |
|---|---|
| **Toggle Name** | System Toggle:Enable DPG New Mapping |
| **Confluence Page** | [View Page](https://confluence.mastercard.int/spaces/MPGSIOG/pages/2376453147/System+Toggle+Enable+DPG+New+Mapping) |
| **Team Responsible** | MPGS Team Andromeda |
| **Applications Affected** | CardPaymentEngine, OrderService |
| **Is S2A Toggle** | FALSE |
| **Current Status** | The toggle will be released in disabled state. |

### Summary
This toggle is introduced as part of TPRG sunset plan. While testing DPG pipe for CHP functionality, there are gaps identified. The toggle enables a new DPG-to-CPE entity mapping path for both acquirer response processing and MEGA JSON parsing, ensuring the `authorizingEntity` field from DPG/TPRG responses is correctly captured and stored in the transaction record.

### 🟢 Toggle ON Impact — `AcquirerResponseJsonProcessor.java` · Line 126 · [CPE]
**Business Impact:**
***When ON, after parsing the acquirer response JSON*** the gateway reads the `authorizingEntity` field from the DPG/TPRG response JSON and sets it on the transaction DTO — enabling the new DPG-to-CPE entity mapping path introduced in TPRG sunset work. Merchants processed via DPG acquirers see the `authorizingEntity` correctly reflected in the transaction record.

**Field Impact:**
Internal only — no TSPI/ISO/acquirer protocol fields affected. Internal: `setAuthorizingEntity()` called; `authorizingEntity` JSON field from DPG response mapped to `transactionDto.authorizingEntity` via `AuthorizingEntity.valueOf()`.

### 🔴 Toggle OFF Impact — `AcquirerResponseJsonProcessor.java` · Line 126 · [CPE]
**Business Impact:**
***When OFF, `setAuthorizingEntity()` is not called*** — the `authorizingEntity` value from the DPG response JSON is silently discarded. The transaction DTO does not carry the authorizing entity from DPG/TPRG responses.

**Field Impact:**
Internal only — `transactionDto.authorizingEntity` not populated; DPG `authorizingEntity` field ignored in response processing.

### 🟢 Toggle ON Impact — `JsonMessageParserImpl.java` · Line 119 · [CPE]
**Business Impact:**
***When ON, after parsing the S2A/MEGA JSON message*** the gateway reads the `authorizingEntity` field from the MEGA JSON response and includes it in the acquirer response JSON stored for the transaction — enabling full DPG new mapping for MEGA/TSPI responses.

**Field Impact:**
Internal only — no TSPI/ISO/acquirer protocol fields affected externally. Internal: `addAuthorizingEntity()` called; `authorizingEntity` field from MEGA JSON bean appended to the acquirer response JSON root before it is stored in `dto.acquirerResponseJson`.

### 🔴 Toggle OFF Impact — `JsonMessageParserImpl.java` · Line 119 · [CPE]
**Business Impact:**
***When OFF, `addAuthorizingEntity()` is not called*** — the `authorizingEntity` field from the MEGA JSON response is not added to the stored acquirer response JSON.

**Field Impact:**
Internal only — `dto.acquirerResponseJson` does not include `authorizingEntity`; DPG new mapping field absent from stored transaction response data.

### Implementation Details
| Field | Details |
|---|---|
| **Implementation Class** | `AcquirerResponseJsonProcessor`, `JsonMessageParserImpl` |
| **Line Number(s)** | 126, 119 |
| **Repository** | CPE |

---

## Toggle 99: Enable Unusual Transaction Protection

| Field | Details |
|---|---|
| **Toggle Name** | Enable Unusual Transaction Protection |
| **Confluence Page** | [View Page](https://confluence.mastercard.int/spaces/MPGSIOG/pages/2376453148/Enable+Unusual+Transaction+Protection) |
| **Team Responsible** | Team Catalyst |
| **Applications Affected** | CPE, Orchestrator |
| **Is S2A Toggle** | FALSE |
| **Current Status** | Original release: 21.2.2; Modified functionality: 21.4.x |

### Summary
To detect and block attacks against merchants who process their transactions through MPGS interfaces a new Unusual Transaction Protection Service is being developed. When enabled, the gateway submits transaction activity to an external Transaction Protection Service which analyses merchant transaction patterns to detect and block unusual or anomalous transactions (e.g. carding attacks).

### 🟢 Toggle ON Impact
**Business Impact:**
***When enabled, unusual transaction protection is activated*** — the gateway submits transaction activity (merchant ID, currency, PAN, MITstatus, arrival time, response code) to the external Transaction Protection Service which analyzes merchant transaction patterns to detect and block unusual/anomalous transactions.

**Field Impact:**
Internal only — no TSPI/ISO/acquirer fields affected. Internal: `registerActivity()` invoked if toggle and `doNotProcessAfterTimeHandler` allow; activity details submitted to `transactionProtectionServiceRemotingClient`.

### 🔴 Toggle OFF Impact
**Business Impact:**
***When disabled, unusual transaction protection is not invoked*** — transaction activity is not submitted to the protection service and no pattern analysis for unusual transactions occurs. Merchants lose the protection against carding attacks and anomalous transaction detection.

**Field Impact:**
Internal only — `registerActivity()` method not called; protection service does not receive transaction activity data.

### Implementation Details
| Field | Details |
|---|---|
| **Implementation Class** | `TransactionProtectionServiceImpl` |
| **Line Number(s)** | 50 |
| **Repository** | CPE |

---

## 📊 Report Summary

| Metric | Value |
|---|---|
| **Total Toggles Documented** | 99 |
| **Report Generated** | 2026-04-11 |
| **Total Batches** | 20 |
| **S2A Toggles** | 7 |
| **NOT_FOUND Toggles** | 12 |
| **Repositories Covered** | CPE, Orchestrator, DirectAPI, BusinessService, Console, BatchSettlementService, MSOUI |

### S2A Toggle Summary
| Toggle Name | Team | Repository |
|---|---|---|
| Send Authentication fields in RiskSPI and AuthenticationStatusCode field in TSPI | T-Sombrero | CPE |
| Enable New COF Token Value for T-SPI | T-Sombrero | CPE |
| Enable MerchantAdvice and MerchantAdviceCode mapping in response for S2A | MPGS Team Hercules | CPE |
| Enable Account Funding enhanced functionality for Mastercard and Visa | Team Pegasus | Orchestrator |
| Merchant Initiated Industry Practice Phase 2 Transactions- TSPI | Ulhas Nagose | CPE |
| Support Additional TSPI Mappings for COF Transactions | Anup Ambesange [C] | CPE |
| Enable New COF Token Value for Target | T-Sombrero | CPE |

### NOT_FOUND Toggles Summary
*(Toggles where no implementation was found in the analysed repositories — likely reside in external service repos not present in the workspace)*

| Toggle Name | Suspected Repository |
|---|---|
| Use Status Code when calculating if PSD2 Exemption has been granted by Visa | ThreeDSService |
| Enable replication lag tracking by MCS | Multi-site Consistency Service |
| System Toggle: Enable DC Replication Locks | Multi-site Consistency Service |
| Use Enhanced Certificate Sets | HSM/Certificate Management Service |
| Enable Activity Calls to Protection Service | Transaction Protection Service |
| Enable Protection Blocking Of Unusual Transactions | Transaction Protection Service |
| System Toggle: Enable Activity Analyzer in Protection Service | Transaction Protection Service |
| Enable Transaction Filtering BIN Range White listing | R-SPI/Transaction Filtering Service |
| System Toggle: Enable SCOF as a Network Token Provider | SCOF Token Service |
| System Toggle: Extend SCT token DB locking behaviour | SCT Token Service |
| System Toggle: Streamline SQL update for token use | SCT Token Service |
| Get Most Recent Transaction as Initial Transaction If Auto-Capture Failed in Settlement Transaction | Unknown |

---

*Report generated by the MPGS Feature Toggle Management System — toggle-polished-report-writer (SA-11)*  
*Data sources: feature-toggle-confluence-page-enquiry-results.csv + toggle-codebase-usage-analysis.csv*  
*Generated: 2026-04-11*

