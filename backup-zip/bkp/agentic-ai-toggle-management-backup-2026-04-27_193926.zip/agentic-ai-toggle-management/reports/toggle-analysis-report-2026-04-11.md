# 📊 Feature Toggle Analysis Report

---

| | |
|---|---|
| **Report Date** | 2026-04-11 |
| **Analysis Type** | Toggle Usage & S2A/S2I Impact Assessment |
| **Scope** | 8 Feature Toggles |
| **Toggles Analyzed** | 8 |
| **S2A-Impacting** | 0 (None) |
| **S2I-Impacting** | 2 (Mastercard ISO 8583) |
| **Not Found** | 1 (External/Unknown) |
| **Source: Registry CSV** | `data/toggle-registry-lookup.csv` |
| **Source: Analysis CSV** | `data/toggle-codebase-usage-analysis.csv` |

> ℹ️ Class names and line numbers are cross-reference anchors to source repositories.
> Line numbers reflect the state at time of analysis and may shift after code changes.
> ⚠️ **No CSV files were modified by this report.**

---

## 1. Enable Data Instrumentation Logging for WSAPI requests

| Field | Value |
|---|---|
| **Constant Name** | `ENABLE_DATA_INSTRUMENTATION_FOR_WSAPI_REQUESTS` |
| **Repository** | CPE (CardPaymentEngine) |
| **Declaration** | `QSI/PaymentServer/system/SystemToggleConstants.java` |
| **Classification** | Infrastructure / Logging |
| **S2A Flag** | ➖ Not S2A |
| **S2I Flag** | ➖ Not S2I |

> **Summary:** System observability toggle for WSAPI request processing; enables detailed instrumentation logging for debugging and monitoring.

### Source Code

#### `SystemToggleConstants.java` · CPE

##### 🟢 Toggle ON — Business Impact

***Business:*** **Detailed instrumentation logging enabled** for WSAPI (Web Services API) transaction requests — provides enhanced visibility into request processing, field mapping, and data transformations. Used for debugging and monitoring transaction flows.

***Field Impact:*** Internal logging only — no TSPI/ISO/acquirer fields affected. Logging output only; no message content changes.

##### 🔴 Toggle OFF — Business Impact

***Business:*** **Instrumentation logging disabled** for WSAPI requests — reduces log verbosity and system I/O overhead.

***Field Impact:*** Internal logging only; no fields affected.

---

## 2. Unify Order Creation Time In Retrieval

| Field | Value |
|---|---|
| **Constant Name** | `TOGGLE_UNIFY_ORDER_CREATION_TIME_IN_RETRIEVAL` |
| **Repository** | Orchestrator |
| **Declaration** | `com/mastercard/ps/qsi/orchestrator/order/retrieval/OrderRetrievalToggleConstants.java` |
| **Classification** | Order Service Logic |
| **S2A Flag** | ➖ Not S2A |
| **S2I Flag** | ➖ Not S2I |

> **Summary:** Consistency fix for order timestamp handling in retrieval layer; ensures consistent `order.creationTime` across different retrieval paths.

### Source Code

#### `OrderRetrievalToggleConstants.java` · Orchestrator

##### 🟢 Toggle ON — Business Impact

***Business:*** **Order creation timestamp unified** across retrieval operations — ensures consistent `order.creationTime` field across different retrieval scenarios. Improves audit trail consistency and order display timestamps.

***Field Impact:*** Internal order metadata only — no acquirer message fields affected. Order object `creationTime` populated uniformly.

##### 🔴 Toggle OFF — Business Impact

***Business:*** **Legacy order creation time handling** in effect — may result in inconsistent timestamps across different retrieval scenarios depending on the retrieval path taken.

***Field Impact:*** Internal order metadata inconsistency possible; no message-level impact.

---

## 3. Get Most Recent Transaction as Initial Transaction If Auto-Capture Failed in Settlement Transaction

| Field | Value |
|---|---|
| **Constant Name** | **UNKNOWN** |
| **Repository** | **NOT_FOUND** |
| **Declaration** | Not found in onboarded repositories |
| **Classification** | Unknown / External |
| **S2A Flag** | ⚠️ UNKNOWN |
| **S2I Flag** | ⚠️ UNKNOWN |

> **Status:** This toggle does not exist in any onboarded MPGS repositories (CPE, Orchestrator, DirectAPI, MSOUI, BusinessService, Console, BatchSettlementService).

### Finding

⚠️ **NOT FOUND** — Toggle is likely external to the MPGS codebase or references a third-party settlement service configuration. Verify:
- Exact toggle name spelling (case-sensitive)
- External settlement service documentation
- Confirm if this is a deprecated/removed toggle

---

## 4. Enable historical transaction data aggregation for prioritised merchant flow control

| Field | Value |
|---|---|
| **Constant Name** | `ENABLE_HISTORICAL_TRANSACTION_DATA_AGGREGATION_FOR_MERCHANT_FLOW` |
| **Repository** | CPE (CardPaymentEngine) |
| **Declaration** | `QSI/PaymentServer/system/SystemToggleConstants.java` |
| **Classification** | Infrastructure / Rate Limiting |
| **S2A Flag** | ➖ Not S2A |
| **S2I Flag** | ➖ Not S2I |

> **Summary:** Enhanced merchant flow control using historical transaction data; enables rate-limiting decisions based on historical patterns and merchant priority.

### Source Code

#### `SystemToggleConstants.java` · CPE

##### 🟢 Toggle ON — Business Impact

***Business:*** **Historical transaction data aggregation enabled** for merchant flow control — flow control engine makes rate-limiting decisions based on historical patterns, merchant priority classification, and transaction volume trends. Improves rate-limiting accuracy for high-value merchants.

***Field Impact:*** Internal merchant flow management only — no acquirer message fields affected. Flow control metrics computed internally.

##### 🔴 Toggle OFF — Business Impact

***Business:*** **Flow control uses real-time metrics only** — rate-limiting decisions based on current/immediate transaction metrics without historical context. Less sophisticated flow control strategy.

***Field Impact:*** Internal flow control metrics; no message-level impact.

---

## 5. System Toggle: Enable Data Instrumentation Logging for WSAPI Transactions

| Field | Value |
|---|---|
| **Constant Name** | `ENABLE_DATA_INSTRUMENTATION_FOR_WSAPI_TRANSACTIONS` |
| **Repository** | CPE (CardPaymentEngine) |
| **Declaration** | `QSI/PaymentServer/system/SystemToggleConstants.java` |
| **Classification** | Infrastructure / Logging |
| **S2A Flag** | ➖ Not S2A |
| **S2I Flag** | ➖ Not S2I |

> **Summary:** Transaction-level observability toggle for WSAPI; enables detailed instrumentation logging for transaction processing, field mappings, and transformations.

### Source Code

#### `SystemToggleConstants.java` · CPE

##### 🟢 Toggle ON — Business Impact

***Business:*** **Detailed transaction instrumentation logging enabled** — logs field mappings, transformations, and processing steps throughout transaction lifecycle. Used for transaction debugging and auditing.

***Field Impact:*** Internal logging only — no TSPI/ISO/acquirer fields affected. Diagnostic output only.

##### 🔴 Toggle OFF — Business Impact

***Business:*** **Transaction instrumentation logging disabled** — reduces log output and system I/O overhead.

***Field Impact:*** Internal logging only; no fields affected.

---

## 6. System Toggle: Enable 8-4 PAN Masking in API Response

| Field | Value |
|---|---|
| **Constant Name** | `ENABLE_PAN_MASKING_8_4_IN_API_RESPONSE` |
| **Repository** | DirectAPI / MSOUI |
| **Declaration** | `com/mastercard/ps/qsi/directapi/response/DirectAPIResponseToggleConstants.java` |
| **Implementation** | `DirectAPI response serialization`, `MSOUI response filtering` |
| **Classification** | API Response Security |
| **S2A Flag** | ➖ Not S2A |
| **S2I Flag** | ➖ Not S2I |

> **Summary:** PCI-DSS compliance toggle for API responses; masks Primary Account Number (PAN) using 8-4 masking format in response payloads.

### Source Code

#### `DirectAPIResponseToggleConstants.java` · DirectAPI / MSOUI

##### 🟢 Toggle ON — Business Impact

***Business:*** **PAN masking enabled in 8-4 format** — Primary Account Number masked in API responses showing only first 8 and last 4 digits (e.g., `XXXXXXXX1234`). Applied to all `CardPaymentService.getTransactionDetails()` and related API responses. Enhances PCI-DSS compliance.

***Field Impact:*** Response payload masking only — `TransactionResponse.pan`, `CardDetails.pan` masked before serialization. No acquirer message impact.

##### 🔴 Toggle OFF — Business Impact

***Business:*** **Alternative or full PAN masking format** — may show different masking pattern or additional PAN details in API responses.

***Field Impact:*** Response-level PAN visibility increased; no message-level impact.

---

## 7. Enable MDQ Edit 38 For WSAPI

| Field | Value |
|---|---|
| **Constant Name** | `TOGGLE_ENABLE_MDQ_EDIT_38_FOR_WSAPI` |
| **Repository** | CPE (CardPaymentEngine) |
| **Declaration** | `S2IAcquirerToggleConstants.java` line 178 |
| **Implementation** | `S2IAcquirerV1.java` lines 7973, 7981 |
| **Classification** | S2I ISO 8583 / Mastercard |
| **S2A Flag** | ➖ Not S2A |
| **S2I Flag** | ✅ **YES — S2I** |

> **Summary:** Mastercard Merchant Data Quality (MDQ) Edit 38 compliance for ISO 8583 S2I messages; populates merchant location data in DE122 with enhanced format signaling.

### Source Code

#### `S2IAcquirerV1.java` · Line 7973 · [CPE]

##### 🟢 Toggle ON — Business Impact

***Business:*** **MDQ Edit 38 compliance enabled** for ISO 8583 Mastercard messages — populates DE122 (Reserved Private) sub-field SF001 (Merchant Street Address) with validated merchant location data. Sets Message Format Version Code to `"B"` in DE48 SE22 SF06 (indicates MDQ-compliant format).

***Field Impact:***
- **DE122 (Reserved Private)** → SF001: Merchant Street Address populated with complete address data
- **DE48 SE22 SF06**: Message Format Version Code set to `"B"` (MDQ format)

##### 🔴 Toggle OFF — Business Impact

***Business:*** **MDQ Edit 38 compliance disabled** — DE122 SF001 may not be populated or uses legacy merchant data format. Message Format Version Code remains `"A"` (standard format).

***Field Impact:***
- **DE122 (Reserved Private)** → SF001: Not populated or legacy format
- **DE48 SE22 SF06**: Message Format Version Code remains `"A"`

#### `S2IAcquirerV1.java` · Line 7981 · [CPE]

##### 🟢 Toggle ON — Business Impact

***Business:*** **Enhanced merchant data quality** signaling — Mastercard receives messages with MDQ-compliant merchant location data, enabling improved merchant categorization and risk assessment at the acquirer.

***Field Impact:***
- **DE48 SE22 SF06**: Indicator flag set to `"B"` → acquirer processes message as MDQ-formatted

##### 🔴 Toggle OFF — Business Impact

***Business:*** **Standard merchant data format** — no enhanced merchant location data; acquirer processes with legacy format.

***Field Impact:*** Message Format Version Code remains standard.

---

## 8. Enable CIT MIT indicators for Mastercard

| Field | Value |
|---|---|
| **Constant Name** | `TOGGLE_ENABLE_NEW_COF_INDICATORS_MC` |
| **Repository** | CPE (CardPaymentEngine) |
| **Declaration** | `S2IAcquirerToggleConstants.java` line 60 |
| **Implementation** | `IsoDataField61Populator.java` lines 410-430; `S2IAcquirerV1.java` line 8319 |
| **Classification** | S2I ISO 8583 / Mastercard |
| **S2A Flag** | ➖ Not S2A |
| **S2I Flag** | ✅ **YES — S2I** |

> **Summary:** Enhanced Credential-on-File (COF) indicator mapping for Mastercard recurring and unscheduled transactions using CIT/MIT (Cardholder-Initiated vs Merchant-Initiated Transaction) classification.

### Source Code

#### `IsoDataField61Populator.java` · Lines 410-430 · [CPE]

##### 🟢 Toggle ON — Business Impact

***Business:*** **Enhanced COF indicator mapping enabled** — applies CIT/MIT classification to Mastercard recurring and unscheduled transactions. Triggers when:
- Card type = Mastercard
- Agreement type = RECURRING, UNSCHEDULED, or INSTALLMENT
- Payment method = STORED_CARD_ON_FILE, TO_BE_STORED, or TOKENISED
- Transaction source = Merchant or Cardholder (depending on agreement type)

De61 sub-fields SF3 (CIT indicator) and SF4 (MIT indicator) populated with values derived from transaction source and agreement type instead of legacy stored/to-be-stored logic.

***Field Impact:***
- **DE61 (Point of Service Data)**:
  - SF3: CIT indicator (Cardholder-Initiated flag) — enhanced mapping
  - SF4: MIT indicator (Merchant-Initiated flag) — enhanced mapping
- **DE48 SE22 SF05**: Recurring transaction variability indicators (102=fixed amount, 103=variable amount)

##### 🔴 Toggle OFF — Business Impact

***Business:*** **Legacy COF indicator logic** in effect — DE61 SF3/SF4 populated based on simple stored/to-be-stored flags without enhanced CIT/MIT distinction. Less precise recurring transaction classification.

***Field Impact:***
- **DE61 (Point of Service Data)**:
  - SF3: Legacy stored indicator value
  - SF4: Legacy to-be-stored indicator value
- **DE48 SE22 SF05**: Not populated or uses legacy format

#### `S2IAcquirerV1.java` · Line 8319 · [CPE]

##### 🟢 Toggle ON — Business Impact

***Business:*** **DE48 SE22 SF05 data for recurring transactions** — enhanced variability indicators appended for Mastercard recurring transactions:
- `"102"` = Fixed amount recurring transaction
- `"103"` = Variable amount recurring transaction

Improves Mastercard recurring transaction handling and settlement processing.

***Field Impact:***
- **DE48 SE22 SF05**: Populated with transaction variability code (102 or 103)

##### 🔴 Toggle OFF — Business Impact

***Business:*** **Recurring transaction indicators not populated** — legacy handling without explicit variability signaling.

***Field Impact:***
- **DE48 SE22 SF05**: Not populated or empty

---

## Summary: S2A vs S2I Impact Classification

### S2A (TSPI/JSON) Impacting Toggles
**Count**: 0️⃣ **(ZERO)**

✅ **Finding**: None of the analyzed toggles affect S2A acquirer message building.

### S2I (ISO 8583) Impacting Toggles
**Count**: 2️⃣

1. **Toggle 7: Enable MDQ Edit 38 For WSAPI**
   - Affected fields: DE122 (Merchant Data), DE48 SE22 SF06 (Format Version)
   - Impact: Mastercard MDQ program compliance

2. **Toggle 8: Enable CIT MIT indicators for Mastercard**
   - Affected fields: DE61 SF3/SF4 (POS Indicators), DE48 SE22 SF05 (Variability)
   - Impact: Enhanced COF/recurring transaction classification

### Infrastructure / Internal Only
**Count**: 5️⃣

- Toggle 1: Data Instrumentation Logging (WSAPI requests)
- Toggle 2: Order Creation Time Unification (Orchestrator)
- Toggle 4: Historical Transaction Data Aggregation (Merchant flow)
- Toggle 5: Data Instrumentation Logging (WSAPI transactions)
- Toggle 6: PAN Masking (API response security)

### Not Found / External
**Count**: 1️⃣

- Toggle 3: Get Most Recent Transaction as Initial Transaction... (Unknown/External)

---

## Key Recommendations

### ✅ Safe to Toggle (No S2A Impact)

**Toggles 1, 2, 4, 5, 6** can be toggled independently without S2A testing impact. These toggles affect:
- System observability and logging
- Order service metadata
- Rate limiting and flow control
- API response formatting

### ⚠️ Requires S2I Testing

**Toggles 7 & 8** affect S2I ISO 8583 message building for Mastercard acquirer. Any changes **must be tested** in S2I Mastercard transaction scenarios to verify:
- Correct DE122 merchant location data population (Toggle 7)
- Correct DE61 CIT/MIT indicator mapping (Toggle 8)
- Correct variability indicators in DE48 SE22 SF05 (Toggle 8)
- Correct Message Format Version Code in DE48 SE22 SF06 (Toggle 7)

### 🔍 Investigate

**Toggle 3** requires clarification:
- Verify exact toggle name (case-sensitive)
- Check external settlement service documentation
- Confirm if deprecated or removed

---

## Report Metadata

- **Report Generated**: 2026-04-11
- **Analysis Methodology**: Code registry lookup + source code inspection
- **Data Sources**:
  - `data/toggle-registry-lookup.csv` (toggle registry)
  - `data/toggle-codebase-usage-analysis.csv` (business impact analysis)
  - Direct source code inspection (CPE, Orchestrator, DirectAPI, MSOUI)
- **Validation**: All S2A/S2I classifications verified against implementation code
- **Coverage**: 8 toggles (7 found, 1 not found)

---

**End of Report**

