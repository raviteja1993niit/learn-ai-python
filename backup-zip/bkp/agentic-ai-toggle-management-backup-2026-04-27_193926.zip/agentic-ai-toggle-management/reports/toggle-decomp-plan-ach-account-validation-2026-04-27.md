# Toggle Decomposition Plan

| Field | Value |
|---|---|
| **Toggle** | `ACH Account Validation for Paymentech Salem ACH Acquirer` |
| **Constant** | `ACCOUNT_VALIDATION_TOGGLE_NAME` |
| **Repository** | BatchSettlementService |
| **Date** | 2026-04-27 |
| **Author** | toggle-advisor (SA-4 / Skill A) |
| **Status** | READ-ONLY PLAN — no source files modified |

---

## 1. Toggle Overview

| Field | Detail |
|---|---|
| **Declared in** | `AccountValidationToggleHelper.java`, line 29 |
| **TODO note** | *"remove this class as part of S2386744"* (class Javadoc, line 24) |
| **Purpose** | Gates advanced ACH account validation (`VALIDATION_FOR_INTERNET_TRANSACTIONS` flag on the MEGA JSON bean) for the `PAYMENTECH_SALEM_ACH` acquirer when the merchant/MSO satisfies the per-merchant toggle evaluation. |

---

## 2. Branch Decision — Keep Toggle-ON Behaviour

> **Decision: KEEP THE TOGGLE-ON PATH — remove the toggle guard entirely.**

### Justification

- The TODO Javadoc on `AccountValidationToggleHelper` explicitly flags this class for removal as part of story **S2386744**, indicating the feature is considered permanently enabled.
- The toggle-ON path is the value-delivering path: it sets `VALIDATION_FOR_INTERNET_TRANSACTIONS = true` for qualifying WEB ACH transactions — the correct production behaviour for the `PAYMENTECH_SALEM_ACH` acquirer.
- Removing the toggle guard makes the advanced-validation call unconditional for `PAYMENTECH_SALEM_ACH`, which aligns with the stated product intent.

### Net Result After Decomposition

- For `PAYMENTECH_SALEM_ACH` acquirer: `processAdvancedValidationFlagForPaymentechSalemAch()` is **always** called (no toggle check).
- `AccountValidationToggleHelper` class is **deleted** entirely.
- Toggle infrastructure (`ToggleContext` injection, `Toggles.isToggleOn()` call, per-merchant context registration) is **removed**.

---

## 3. Complete Reference Map

| File | Line(s) | Role |
|---|---|---|
| `AccountValidationToggleHelper.java` | ALL | Declaration / Implementation |
| `AccountValidationToggleHelper.java` | 29 | `ACCOUNT_VALIDATION_TOGGLE_NAME` constant |
| `AccountValidationToggleHelper.java` | 46 | `Toggles.isToggleOn()` call |
| `RequestConverter.java` | 19 | `import` statement |
| `RequestConverter.java` | 42 | `@Resource` injected field |
| `RequestConverter.java` | 82 | Toggle guard `if`-condition |
| `RequestConverter.java` | 83 | Call to `processAdvancedValidationFlagForPaymentechSalemAch()` |
| `AccountValidationToggleHelperTest.java` | ALL | Toggle-ON/OFF test cases |
| `AccountValidationToggleHelperTest.java` | 44 | `switchToggleOn(ACCOUNT_VALIDATION_TOGGLE_NAME)` |
| `AccountValidationToggleHelperTest.java` | 55 | `switchToggleOff(ACCOUNT_VALIDATION_TOGGLE_NAME)` |
| `RequestConverterTest.java` | 37 | `import` statement |
| `RequestConverterTest.java` | 54 | `@Mock AccountValidationToggleHelper` |
| `RequestConverterTest.java` | 75 | `when(..isToggleOn(any())).thenReturn(false)` |
| `RequestConverterTest.java` | 130 | `when(..isToggleOn(any())).thenReturn(true)` |
| `RequestConverterTest.java` | 160 | `when(..isToggleOn(any())).thenReturn(true)` |

> **Config/XML:** No Spring XML bean definitions found referencing this toggle helper. The bean is Spring component-scanned (`@Component`).

---

## 4. Files to Delete

### FILE-DEL-1 — `AccountValidationToggleHelper.java`

```
src/main/java/com/tnsi/batchsettle/utility/toggle/AccountValidationToggleHelper.java
```

**Reason:** Entire class exists solely to wrap the toggle check. Once the toggle guard is removed from `RequestConverter`, this class has no callers and no purpose. The Javadoc TODO (line 24) already mandates deletion.

---

### FILE-DEL-2 — `AccountValidationToggleHelperTest.java`

```
src/test/java/com/tnsi/batchsettle/utility/toggle/AccountValidationToggleHelperTest.java
```

**Reason:** Dedicated test for the deleted helper class. Both test methods (`isToggleOn_true` / `isToggleOn_false`) test behaviour that no longer exists. Retaining dead tests creates confusion and future CI noise.

---

## 5. Files to Modify

### FILE-MOD-1 — `RequestConverter.java`

```
src/main/java/com/tnsi/batchsettle/messaging/conversion/RequestConverter.java
```

#### Change 1 — Remove import (line 19)

**Before:**
```java
import com.tnsi.batchsettle.utility.toggle.AccountValidationToggleHelper;
```
**After:** *(line deleted entirely)*

---

#### Change 2 — Remove injected field (lines 41–42)

**Before:**
```java
@Resource
private AccountValidationToggleHelper accountValidationToggleHelper;
```
**After:** *(both lines deleted entirely)*

---

#### Change 3 — Replace toggle-guarded call with unconditional call (lines 82–84)

**Before:**
```java
if (PAYMENTECH_SALEM_ACH.equals(acquirerId) && accountValidationToggleHelper.isToggleOn(convertedBean)) {
    processAdvancedValidationFlagForPaymentechSalemAch(convertedBean);
}
```
**After:**
```java
if (PAYMENTECH_SALEM_ACH.equals(acquirerId)) {
    processAdvancedValidationFlagForPaymentechSalemAch(convertedBean);
}
```

> **Note:** The acquirer-ID null-safety of the existing `PAYMENTECH_SALEM_ACH.equals()` call is preserved unchanged. The private method `processAdvancedValidationFlagForPaymentechSalemAch()` is **kept unchanged**.

---

### FILE-MOD-2 — `RequestConverterTest.java`

```
src/test/java/com/tnsi/batchsettle/messaging/conversion/RequestConverterTest.java
```

#### Change 1 — Remove import (line 37)

**Before:**
```java
import com.tnsi.batchsettle.utility.toggle.AccountValidationToggleHelper;
```
**After:** *(line deleted entirely)*

---

#### Change 2 — Remove `@Mock` field (lines 53–54)

**Before:**
```java
@Mock
private AccountValidationToggleHelper accountValidationToggleHelper;
```
**After:** *(both lines deleted entirely)*

---

#### Change 3 — Update test: `convertRequestMessage_AchTransaction_ToggleOff` (line 75)

Remove stub:
```java
when(accountValidationToggleHelper.isToggleOn(any())).thenReturn(false);
```

⚠️ **This test requires a fixture inspection decision.** Inspect `AchPurchase.json` to choose one of the following options:

| Option | Condition | Action |
|---|---|---|
| **A** (preferred) | `AchPurchase.json` is `PAYMENTECH_SALEM_ACH` + meets advanced-validation conditions (non-MERCHANT source, WEB auth, `CONSUMER_CHECKING`/`SAVINGS`) | Rename test; change `assertNull` → `assertTrue` on `VALIDATION_FOR_INTERNET_TRANSACTIONS` |
| **B** | `AchPurchase.json` is `PAYMENTECH_SALEM_ACH` but conditions evaluate false (e.g. MERCHANT source or non-WEB) | Remove stub only; `assertNull` remains valid — method called but flag not set |
| **C** | `AchPurchase.json` is **not** `PAYMENTECH_SALEM_ACH` | Remove stub only; all assertions remain valid — acquirer guard prevents any call |

---

#### Change 4 — Update test: `convertRequestMessage_AchTransaction_ToggleOn_ConditionsTrue` (line 130)

Remove stub:
```java
when(accountValidationToggleHelper.isToggleOn(any())).thenReturn(true);
```
Test body and assertions remain unchanged — they validate `VALIDATION_FOR_INTERNET_TRANSACTIONS` is `true`, which is still the expected outcome after decomposition.

---

#### Change 5 — Update test: `convertRequestMessage_AchTransaction_ToggleOn_ConditionsFalse` (line 160)

Remove stub:
```java
when(accountValidationToggleHelper.isToggleOn(any())).thenReturn(true);
```
Test body and assertions remain unchanged — the test overrides ACH account type to `CORPORATE_CHECKING` so `usingAdvancedValidation` is `false`; `assertFalse` on the flag remains valid.

> **Note:** The `StubbedToggleRegistry` field (line 58) and its `setUp` usage (lines 69–70) are unrelated to this toggle — they manage `"Batch Settlement Service use Base32 ID Generator"`. Do **NOT** remove them.

---

## 6. Ripple-Effect Analysis

### a) Spring DI Graph
`AccountValidationToggleHelper` is a `@Component` injected via `@Resource` in `RequestConverter` only. Deleting the class removes it from the Spring context. No other bean depends on it. No XML bean definition to clean up.

### b) ToggleContext Usage
`AccountValidationToggleHelper` is the **only** class that calls `toggleContext.registerMerchant()` + `toggleContext.registerSequenceNumber()` + `toggleContext.deregisterContext()` as a bundle for this toggle. After deletion, these `ToggleContext` interactions are gone entirely. No residual side-effect.

### c) Toggle Registry CSV
Rows 2–3 of `toggle-registry-batch-settlement-service.csv` reference this toggle. These rows should be marked as `DECOMPOSED` or removed as part of registry maintenance.

### d) `AccountValidationFeatureToggleOffConverter`
Referenced in the Javadoc of `AccountValidationToggleHelper` (line 23). Perform a targeted search — if this class exists in the repo, review it for any continued dependency. No such class was found in the current search scope; confirm before proceeding.

### e) `processAdvancedValidationFlagForPaymentechSalemAch()`
This private method in `RequestConverter` is **kept** and continues to function normally. Its logic is unchanged; only the toggle guard around its invocation is removed.

### f) Other Repositories
The toggle name string could theoretically be referenced in sibling repos (`businessservice`, `directapi`, etc.). Run the cross-repo grep below before executing the actual run:

```powershell
Get-ChildItem -Path "C:\Users\e135408\IdeaProjects\MPGS\SourceCode" `
  -Recurse -Filter "*.java" | `
  Select-String "ACH Account Validation for Paymentech Salem ACH Acquirer"
```

---

## 7. Step-by-Step Execution Order

### Phase 1 — Dry Run

| Step | Action |
|---|---|
| 1 | In `AccountValidationToggleHelper.java` — comment out entire class body with `// [TOGGLE-DECOMP]` markers |
| 2a | In `RequestConverter.java` — comment out import line 19 → `// [TOGGLE-DECOMP]` |
| 2b | In `RequestConverter.java` — comment out `@Resource` + field lines 41–42 → `// [TOGGLE-DECOMP]` |
| 2c | In `RequestConverter.java` — replace if-condition (line 82) with unconditional form → `// [TOGGLE-DECOMP]` |
| 3 | In `AccountValidationToggleHelperTest.java` — comment out entire test class body with `// [TOGGLE-OFF-TEST]` markers |
| 4a | In `RequestConverterTest.java` — comment out import line 37 → `// [TOGGLE-DECOMP]` |
| 4b | In `RequestConverterTest.java` — comment out `@Mock` + field lines 53–54 → `// [TOGGLE-DECOMP]` |
| 4c | In `RequestConverterTest.java` — comment out stub at line 75 → `// [TOGGLE-OFF-TEST]` |
| 4d | In `RequestConverterTest.java` — comment out stub at line 130 → `// [TOGGLE-DECOMP]` |
| 4e | In `RequestConverterTest.java` — comment out stub at line 160 → `// [TOGGLE-DECOMP]` |
| 5 | Run compile check → **must be zero errors** |

### Phase 2 — Actual Run *(requires explicit user confirmation)*

| Step | Action |
|---|---|
| 6 | Delete `AccountValidationToggleHelper.java` |
| 7 | Delete `AccountValidationToggleHelperTest.java` |
| 8 | Remove all `// [TOGGLE-DECOMP]` and `// [TOGGLE-OFF-TEST]` markers and their commented lines from `RequestConverter.java` and `RequestConverterTest.java` |
| 9 | Re-verify with compile check → **must be zero errors** |
| 10 | Update `toggle-registry-batch-settlement-service.csv` — mark toggle rows as `DECOMPOSED` or remove them |
| 11 | Write change log to `logs/toggle-decomp-changes-batch-settlement-service-2026-04-27.md` |

---

## 8. Risk Assessment

| Risk | Likelihood | Severity | Mitigation |
|---|---|---|---|
| `AchPurchase.json` acquirer is NOT `PAYMENTECH_SALEM_ACH` — tests pass for wrong reason | Low | High | Inspect fixture before test edits (see Section 5, Change 3 Options A/B/C) |
| `AccountValidationFeatureToggleOffConverter` exists and depends on removed class | Low | Medium | Cross-repo grep before actual run |
| Per-merchant toggle semantics differ per MSO — some MSOs may still be toggle-OFF in production | Low | High | Confirm with PO that toggle is globally ON for all MSOs before unconditional promotion |
| Other repos reference toggle name string | Low | Medium | Run cross-repo grep (see Section 6f) |
| Toggle still enabled in production toggle registry after code removal | Low | Low | Toggle config retirement ticket (ops task) |

**Overall Risk: LOW-MEDIUM**
The code change itself is minimal and localised. The main risk is behavioural: per-merchant toggle evaluation is removed in favour of always-on behaviour; this requires product/ops confirmation that the feature is globally enabled for all `PAYMENTECH_SALEM_ACH` merchants before the actual run is executed.

---

## 9. Pre-Flight Checklist

Before issuing `confirm actual run for BatchSettlementService`, verify all items below:

- [ ] Confirm with PO/ops: toggle is globally ON for all `PAYMENTECH_SALEM_ACH` merchants in production
- [ ] Run cross-repo grep for `"ACH Account Validation for Paymentech Salem ACH Acquirer"` across all MPGS source repos
- [ ] Inspect `AchPurchase.json` to determine correct test-update option (A, B, or C)
- [ ] Confirm `AccountValidationFeatureToggleOffConverter` does not exist in codebase
- [ ] Dry run completes with zero compile errors
- [ ] PR reviewer confirms no downstream services depend on `VALIDATION_FOR_INTERNET_TRANSACTIONS` being absent for any `PAYMENTECH_SALEM_ACH` merchant

---

## Next Steps

| Step | Command |
|---|---|
| Dry run (safe — no permanent source edits) | `decompose toggles BatchSettlementService dry run` |
| Actual run (requires explicit confirmation) | `confirm actual run for BatchSettlementService` |
| Review plan quality | `review batch quality for batch 1` |

> ⚠️ The actual decomposition run will **not** be triggered until you explicitly confirm with `confirm actual run for BatchSettlementService`.

---

> **⚠️ AI-Generated Output Disclaimer**
> This document was produced by an AI agent system.
> It is provided as an example and decision-support material **only**.
> **Human review and validation is mandatory** before acting on any
> recommendation, data, or analysis contained in this file.
> This output does not constitute professional or legal advice of any kind.
> Classification: Internal Use Only — Do Not Distribute Without Review.

---
<!-- COPYRIGHT-FOOTER -->
© 2026 Mastercard. All rights reserved.
This file is part of the Toggle Management System.
Maintained by the multi-agent AI framework.

