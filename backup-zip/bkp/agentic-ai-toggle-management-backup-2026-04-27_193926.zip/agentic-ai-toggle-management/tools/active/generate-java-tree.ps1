﻿param(
    [Parameter(Position=0)]
    [string]
    $TargetPath = '.',
    [ValidateSet('main', 'test', 'all')]
    [string]
    $SourceType = 'main',
    [string]
    $OutFile = '',
    [switch]
    $IncludePackageInfo = $true
)
$ErrorActionPreference = 'Continue'
function Write-Log {
    param([string]$Message, [string]$Level = 'INFO')
    $timestamp = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
    Write-Host "[$timestamp] [$Level] $Message"
}
function Resolve-RepoPath {
    param([string]$Path)
    try {
        $resolved = Resolve-Path -LiteralPath $Path -ErrorAction Stop
        return $resolved.Path
    } catch {
        Write-Log "Failed to resolve path: $Path" 'ERROR'
        exit 1
    }
}
function Get-RepoName {
    param([string]$Path)
    return (Split-Path -Leaf $Path)
}
function Extract-Package-From-File {
    param([string]$FilePath)
    try {
        $content = Get-Content -Path $FilePath -Raw -ErrorAction SilentlyContinue
        $match = $content | Select-String 'package\s+([\w.]+);' -AllMatches
        if ($match) {
            return $match.Matches[0].Groups[1].Value
        }
    } catch { }
    return ''
}
function Generate-Java-Tree {
    param([string]$Path, [string]$SourceType, [bool]$IncludePackageInfo)
    Write-Log "Starting Java tree generation: $Path"
    $lines = @()
    $repoName = Get-RepoName -Path $Path
    $lines += "Java Class Structure - $repoName"
    $lines += "=" * 60
    $lines += ""
    $srcPath = Join-Path $Path 'src'
    $javaFiles = @()
    $totalFiles = 0
    if ($SourceType -eq 'main' -or $SourceType -eq 'all') {
        $mainPath = Join-Path $srcPath 'main\java'
        if (Test-Path $mainPath) {
            Write-Log "Scanning main source: $mainPath"
            $mainFiles = @(Get-ChildItem -Path $mainPath -Filter '*.java' -Recurse -ErrorAction SilentlyContinue)
            $javaFiles += $mainFiles
            $totalFiles += $mainFiles.Count
        }
    }
    if ($SourceType -eq 'test' -or $SourceType -eq 'all') {
        $testPath = Join-Path $srcPath 'test\java'
        if (Test-Path $testPath) {
            Write-Log "Scanning test source: $testPath"
            $testFiles = @(Get-ChildItem -Path $testPath -Filter '*.java' -Recurse -ErrorAction SilentlyContinue)
            $javaFiles += $testFiles
            $totalFiles += $testFiles.Count
        }
    }
    Write-Log "Found $totalFiles Java files"
    if ($totalFiles -eq 0) {
        $lines += "No Java files found."
        return $lines
    }
    $groupedByPackage = @{}
    foreach ($file in $javaFiles) {
        $package = Extract-Package-From-File -FilePath $file.FullName
        if (-not $groupedByPackage.ContainsKey($package)) {
            $groupedByPackage[$package] = @()
        }
        $groupedByPackage[$package] += $file
    }
    $sortedPackages = $groupedByPackage.Keys | Sort-Object
    $lines += "Total Java Classes: $totalFiles"
    $lines += "Total Packages: $($sortedPackages.Count)"
    $lines += ""
    $lines += "=" * 60
    $lines += ""
    foreach ($package in $sortedPackages) {
        if ($package) {
            $lines += "Package: $package"
        } else {
            $lines += "Package: (default)"
        }
        $classesInPackage = $groupedByPackage[$package] | Sort-Object -Property BaseName
        for ($i = 0; $i -lt $classesInPackage.Count; $i++) {
            $file = $classesInPackage[$i]
            $isLast = ($i -eq $classesInPackage.Count - 1)
            $connector = if ($isLast) { '  +-- ' } else { '  |-- ' }
            $className = $file.BaseName
            if ($IncludePackageInfo -and $package) {
                $fullyQualifiedName = "$package.$className"
                $lines += "$connector$className  ($fullyQualifiedName)"
            } else {
                $lines += "$connector$className"
            }
        }
        $lines += ""
    }
    return $lines
}
$resolvedPath = Resolve-RepoPath -Path $TargetPath
$repoName = Get-RepoName -Path $resolvedPath
if (-not $OutFile -or $OutFile.Trim() -eq '') {
    $OutFile = Join-Path $resolvedPath "$repoName-java-tree.txt"
} else {
    if (-not (Split-Path -Path $OutFile -Parent)) {
        $OutFile = Join-Path $resolvedPath $OutFile
    }
}
Write-Log "Repository Path: $resolvedPath"
Write-Log "Repository Name: $repoName"
Write-Log "Source Type: $SourceType"
Write-Log "Output File: $OutFile"
Write-Log ""
$treeLines = Generate-Java-Tree -Path $resolvedPath -SourceType $SourceType -IncludePackageInfo $IncludePackageInfo
if ($OutFile -and $OutFile.Trim() -ne '') {
    try {
        $outDir = Split-Path -Path $OutFile -Parent
        if ($outDir -and -not (Test-Path -LiteralPath $outDir)) {
            New-Item -ItemType Directory -Path $outDir -Force | Out-Null
        }
        $treeLines | Out-File -FilePath $OutFile -Encoding utf8 -Force
        Write-Log "Java tree written to: $OutFile"
        exit 0
    } catch {
        Write-Log "Failed to write output file: $_" 'ERROR'
        exit 3
    }
} else {
    foreach ($line in $treeLines) {
        Write-Host $line
    }
    exit 0
}
