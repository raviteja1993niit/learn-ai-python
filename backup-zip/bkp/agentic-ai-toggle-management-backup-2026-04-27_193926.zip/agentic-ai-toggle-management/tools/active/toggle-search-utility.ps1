﻿param(
    [Parameter(Mandatory=$true)]
    [string]$ToggleName,
    [Parameter(Mandatory=$false)]
    [string]$ConstantName = "",
    [Parameter(Mandatory=$false)]
    [ValidateSet("CPE", "Orchestrator", "Both")]
    [string]$Repository = "Both",
    [Parameter(Mandatory=$false)]
    [switch]$ExcludeDeclarations,
    [Parameter(Mandatory=$false)]
    [string]$ConfigFile = "",
    [Parameter(Mandatory=$false)]
    [string]$RegistryPath = "",
    [Parameter(Mandatory=$false)]
    [string]$CPEPath = "",
    [Parameter(Mandatory=$false)]
    [string]$OrchestratorPath = ""
)

# ── Resolve paths from config.yml if not provided as arguments ────────────────
$scriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$projectRoot = (Get-Item "$scriptRoot\..\.." ).FullName

if ($ConfigFile -eq "") { $ConfigFile = "$projectRoot\knowledge\config.yml" }

if ((Test-Path $ConfigFile) -and ($RegistryPath -eq "" -or $CPEPath -eq "" -or $OrchestratorPath -eq "")) {
    $cfg = Get-Content $ConfigFile -Raw
    if ($RegistryPath -eq "") {
        if ($cfg -match 'registry_combined:\s+"?([^"\r\n]+)"?') {
            $RegistryPath = "$projectRoot\$($Matches[1].Trim().Replace('/','\'))"
        } else {
            $RegistryPath = "$projectRoot\data\toggle-registry-lookup.csv"
        }
    }
    if ($CPEPath -eq "") {
        # Extract CPE java_root — first java_root after "name: CPE"
        if ($cfg -match '(?s)name:\s+"?CPE"?.*?java_root:\s+"?([^"\r\n]+)"?') {
            $CPEPath = $Matches[1].Trim()
        }
    }
    if ($OrchestratorPath -eq "") {
        if ($cfg -match '(?s)name:\s+"?Orchestrator"?.*?java_root:\s+"?([^"\r\n]+)"?') {
            $OrchestratorPath = $Matches[1].Trim()
        }
    }
}
$registryDeclarations = @{}
$constantNames = @()
if (Test-Path $RegistryPath) {
    $registry = @(Import-Csv -Path $RegistryPath)
    foreach ($reg in $registry) {
        if ($reg.toggle_name -eq $ToggleName) {
            $declKey = "$($reg.registry_file_path):$($reg.registry_class_name)"
            $registryDeclarations[$declKey] = $true
            if ($reg.constant_name -and $reg.constant_name.Trim() -ne "" -and
                    $constantNames -notcontains $reg.constant_name.Trim()) {
                $constantNames += $reg.constant_name.Trim()
            }
        }
    }
}
if ($ConstantName -and $ConstantName.Trim() -ne "" -and $constantNames -notcontains $ConstantName.Trim()) {
    $constantNames += $ConstantName.Trim()
}
function Get-BlockBoundaries {
    param(
        [string[]]$Lines,
        [int]$MatchIndex
    )
    $blockStart = $MatchIndex
    $depth = 0
    for ($i = $MatchIndex; $i -ge 0; $i--) {
        $line = $Lines[$i]
        $depth += ($line.ToCharArray() | Where-Object { $_ -eq '}' }).Count
        $depth -= ($line.ToCharArray() | Where-Object { $_ -eq '{' }).Count
        if ($depth -lt 0) {
            $blockStart = $i
            break
        }
        if ($i -eq 0) { $blockStart = 0 }
    }
    $blockEnd = $MatchIndex
    $depth = 0
    for ($i = $blockStart; $i -lt $Lines.Count; $i++) {
        $line = $Lines[$i]
        $depth += ($line.ToCharArray() | Where-Object { $_ -eq '{' }).Count
        $depth -= ($line.ToCharArray() | Where-Object { $_ -eq '}' }).Count
        if ($depth -le 0 -and $i -gt $blockStart) {
            $blockEnd = $i
            break
        }
        if ($i -eq $Lines.Count - 1) { $blockEnd = $i }
    }
    return @{ blockStart = $blockStart + 1; blockEnd = $blockEnd + 1 }
}
function Test-IsDeclarationLine {
    param([string]$Line)
    return $Line -match '^\s*(public\s+)?static\s+final\s+String\s+\w+\s*='
}
function Search-Directory {
    param(
        [string]$SearchPath,
        [string]$RepositoryName,
        [string[]]$Patterns
    )
    $hits = @()
    try {
        $javaFiles = Get-ChildItem -Path $SearchPath -Recurse -Include "*.java" -File | Where-Object {
            $_.FullName -notmatch "[\\/]test[\\/]" -and
                    $_.BaseName -notmatch "Test$|Tests$|Spec$|IT$|ITest$"
        }
        foreach ($file in $javaFiles) {
            try {
                $content = [System.IO.File]::ReadAllText($file.FullName, [System.Text.Encoding]::UTF8)
                $anyMatch = $false
                foreach ($pat in $Patterns) {
                    if ($content.Contains($pat)) { $anyMatch = $true; break }
                }
                if (-not $anyMatch) { continue }
                $lines = $content -split "`n"
                $className = $file.BaseName
                $relPath = $file.FullName.Replace($SearchPath, "").Replace("\", "/").TrimStart("/")
                for ($i = 0; $i -lt $lines.Count; $i++) {
                    $lineText = $lines[$i]
                    $patternMatched = $false
                    foreach ($pat in $Patterns) {
                        if ($lineText.Contains($pat)) { $patternMatched = $true; break }
                    }
                    if (-not $patternMatched) { continue }
                    if ($lineText -match "^\s*//" -and $lineText -notmatch "isToggle|isOn|Toggles\.") {
                        continue
                    }
                    $lineNum = $i + 1
                    if ($ExcludeDeclarations -and (Test-IsDeclarationLine -Line $lineText)) {
                        continue
                    }
                    $declKey = "$relPath`:$className"
                    if ($ExcludeDeclarations -and $registryDeclarations.ContainsKey($declKey)) {
                        if (Test-IsDeclarationLine -Line $lineText) { continue }
                    }
                    $bounds = Get-BlockBoundaries -Lines $lines -MatchIndex $i
                    $hits += @{
                        repository  = $RepositoryName
                        className   = $className
                        filePath    = $relPath
                        fullPath    = $file.FullName
                        lineNumber  = $lineNum
                        blockStart  = $bounds.blockStart
                        blockEnd    = $bounds.blockEnd
                        matchLine   = $lineText.Trim()
                        isDeclaration = (Test-IsDeclarationLine -Line $lineText)
                    }
                }
            }
            catch {
            }
        }
    }
    catch {
        Write-Error "Error searching $RepositoryName`: $_"
    }
    return $hits
}
$searchPatterns = @($ToggleName)
foreach ($cn in $constantNames) {
    if ($searchPatterns -notcontains $cn) {
        $searchPatterns += $cn
    }
}
Write-Host "Search patterns: $($searchPatterns -join ', ')" -ForegroundColor DarkGray
$results = @()
if ($Repository -eq "CPE" -or $Repository -eq "Both") {
    Write-Host "Searching CPE repository..." -ForegroundColor Cyan
    $cpeMatches = Search-Directory -SearchPath $CPEPath -RepositoryName "CPE" -Patterns $searchPatterns
    $results += $cpeMatches
    Write-Host "Found $($cpeMatches.Count) matches in CPE" -ForegroundColor Green
}
if ($Repository -eq "Orchestrator" -or $Repository -eq "Both") {
    Write-Host "Searching Orchestrator repository..." -ForegroundColor Cyan
    $orchMatches = Search-Directory -SearchPath $OrchestratorPath -RepositoryName "Orchestrator" -Patterns $searchPatterns
    $results += $orchMatches
    Write-Host "Found $($orchMatches.Count) matches in Orchestrator" -ForegroundColor Green
}
$uniqueResults = @{}
foreach ($result in $results) {
    $key = "$($result.repository):$($result.filePath):$($result.lineNumber)"
    if (-not $uniqueResults.ContainsKey($key)) {
        $uniqueResults[$key] = $result
    }
}
$output = @{
    toggleName      = $ToggleName
    totalMatches    = $uniqueResults.Count
    searchPatterns  = $searchPatterns
    searchParameters = @{
        repository          = $Repository
        excludeDeclarations = $ExcludeDeclarations.IsPresent
    }
    results = @($uniqueResults.Values | ForEach-Object {
        @{
            repository    = $_.repository
            className     = $_.className
            filePath      = $_.filePath
            fullPath      = $_.fullPath
            lineNumber    = $_.lineNumber
            blockStart    = $_.blockStart
            blockEnd      = $_.blockEnd
            matchLine     = $_.matchLine
            isDeclaration = $_.isDeclaration
        }
    })
}
$output | ConvertTo-Json -Depth 10 | Write-Output
Write-Host ""
Write-Host "=== SEARCH SUMMARY ===" -ForegroundColor Yellow
Write-Host "Toggle: $ToggleName"
Write-Host "Total Usage Locations Found: $($uniqueResults.Count)"
foreach ($result in $uniqueResults.Values) {
    $declTag = if ($result.isDeclaration) { " [DECLARATION]" } else { "" }
    Write-Host "  [$($result.repository)] $($result.className).java:$($result.lineNumber) (block $($result.blockStart)-$($result.blockEnd))$declTag"
}