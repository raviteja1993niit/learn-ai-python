﻿#!/usr/bin/env powershell
<#
.DESCRIPTION
Build Toggle Registry Lookup CSV --- TWO-PASS architecture.

PASS 1 (Declaration Harvest):
  Scan every repository for  public static final String <TOGGLE_*|ENABLE_*|FEATURE*|DO_NOT_*|_TOGGLE|...> = "<value>"
  Build an in-memory map:  toggleValue  ---  list of { constant_name, declaringClass, declaringFile, repo, declLineNo }

PASS 2 (Usage Harvest --- ALL files):
  Scan EVERY .java file in every repository.
  For each file check, in priority order:
    (A) IMPLEMENTATION --- file calls  isToggleOn(...)  /  .isEnabled(...)  /  ToggleHelper.
        and the toggle value string or its constant identifier appears within --5 lines.
    (B) IMPORT --- file has a static import of the declaring class that references this constant
        (e.g.  import static com.dialect.orchestrator.constants.ToggleConstants.ENABLE_NETWORK_TRANSACTION_ID)
    Only record one row per (toggleValue, file, repo) --- highest priority wins.
  NOTE: Hybrid classes (declare AND call isToggleOn in same file) are now correctly recorded
        as IMPLEMENTATION (Bug 1 fix --- removed the $isDeclaringFile guard that blocked them).

Final CSV columns (7):
  toggle_name | registry_file_path | registry_class_name | repository | constant_name | usage_type | line_number

usage_type values (priority: IMPLEMENTATION=3 > IMPORT=2 > DECLARATION=1):
  IMPLEMENTATION  --- actual isToggleOn / isEnabled / ToggleHelper call; line_number = that call's line
  IMPORT          --- static import of the constant in a consumer class; line_number = import line
  DECLARATION     --- declaring class only (no usages found elsewhere); line_number = declaration line

Repositories scanned:
  - CPE                    : cardpaymentengine/src/main/java        (full scan both passes)
  - Orchestrator           : orchestrator/src/main/java             (full scan both passes)
  - BusinessService        : businessservice/src/main/java          (full scan both passes)
  - Console                : console/console/src/main/java          (full scan both passes)
  - MSOUI                  : msoui/src/main/java                    (full scan both passes)
  - DirectAPI              : directapi/src/main/java                (targeted: 23 known files, Pass 1 only)
                                                                     (Pass 2 uses same 23 known files for speed)
  - BatchSettlementService : batchsettlementservice/src/main/java   (full scan both passes)

Output files (all in $FrameworkRoot/data/registry/):
  toggle-registry-lookup.csv                    combined all-repos registry
  toggle-registry-cpe.csv                       CPE only
  toggle-registry-orchestrator.csv              Orchestrator only
  toggle-registry-business-service.csv          BusinessService only
  toggle-registry-console.csv                   Console only
  toggle-registry-msoui.csv                     MSOUI only
  toggle-registry-direct-api.csv                DirectAPI only
  toggle-registry-batch-settlement-service.csv  BatchSettlementService only

Usage:
  # Normal run (auto-resolves paths from default $FrameworkRoot)
  .\build-toggle-registry-lookup.ps1

  # Custom framework root
  .\build-toggle-registry-lookup.ps1 -FrameworkRoot "C:\path\to\agentic-ai-toggle-management"

  # Force full DirectAPI rescan (rebuilds targeted file list, ~5 min)
  .\build-toggle-registry-lookup.ps1 -RefreshDirectAPIFileList

  # Combined only -- skip per-repo split files
  .\build-toggle-registry-lookup.ps1 -SkipPerRepoSplit

BUG FIXES (2026-04-11):
  Bug 1 (RCA): Pass 2 $isDeclaringFile guard at line ~405 blocked IMPLEMENTATION detection for
               "hybrid" classes -- those that both DECLARE a toggle constant AND call isToggleOn()
               in the same file.  Examples: DoNotProcessAfterTimeHandler (CPE & Orchestrator),
               SanctionHelper, CardTypeDetailsDecorator, TransactionDataCommonService.
               FIX: Removed the `-not $isDeclaringFile` condition so hybrid classes are recorded
               as IMPLEMENTATION.  The Merge phase already suppresses the DECLARATION fallback
               row via $coveredKeys, so no duplicates are introduced.

  Bug 2 (RCA): DirectAPI DoNotProcessAfterTimeDecorator.java was absent from the 23-file targeted
               list.  The original 22-file list was built only for TOGGLE_* / ENABLE_* / FEATURE*
               prefixed constants; DO_NOT_PROCESS_AFTER_TIME_TOGGLE uses the DO_NOT_ prefix and
               _TOGGLE suffix, so it was never found during the refresh scan that built the list.
               FIX: Added DoNotProcessAfterTimeDecorator.java explicitly to the targeted list.

   Bug 3 (RCA): Pass 1 declaration harvest regex only matched constant names starting with
                TOGGLE_ | ENABLE_ | ENABLE[A-Z] | FEATURE.  Any constant using a different
                naming convention (DO_NOT_*, _TOGGLE suffix, ALLOW_*, USE_*, SET_*, etc.)
                was completely invisible to both passes -- never entered $declMap, never found
                in Pass 2 implementation scan.
                FIX: Expanded the $isToggle pattern to also match _TOGGLE suffix and common
                action-verb prefixes: DO_NOT_ | ALLOW_ | USE_ | SET_ | REMOVE_ | OPTIMIZE_ |
                POPULATE_ | APPLY_ | GET_.

   Bug 4 (RCA): $excludedConstantNames included the literal string "TOGGLE_NAME", blanket-blocking
                 every class that uses TOGGLE_NAME as its constant identifier -- regardless of the
                 toggle value it holds.  The exclusion list is meant for generic utility flags like
                 ENABLED, not for valid toggle constant names.
                 Affected classes (DirectAPI -- both HYBRID: declare AND call isToggleOn in same file):
                   - MerchantInvalidRequestRateLimiter   → TOGGLE_NAME = "Apply per-merchant limits
                     for invalid operation rates in WSAPI"
                   - MerchantPrioritisedRequestRateLimiter → TOGGLE_NAME = "Apply per-merchant
                     maximum request rate limits in WSAPI"
                 Both corresponded to NOT_FOUND stub rows in ToggleCodebaseUsageAnalysis.csv
                 (lines 29-30 of that file).
                 FIX: Removed "TOGGLE_NAME" from $excludedConstantNames.  TOGGLE_NAME passes
                 the ^TOGGLE_ prefix filter legitimately and must reach $declMap.

   Bug 5a (RCA): REMOVE_PRIVILEGE = "-" in BulkMerchantPrivilegeUpdateServiceImpl.java was
                 harvested by Pass 1 because Bug 3's fix added REMOVE_ as a valid prefix.  The
                 toggle VALUE "-" (a single dash) is NOT a real toggle display name.  When Pass 2
                 builds $allToggleValuesRegex, the escaped "-" matches the literal hyphen character
                 which appears on virtually every Java source line (method signatures, generics,
                 operators, comments).  This caused Pass 2 to emit a spurious IMPLEMENTATION row
                 with toggle_name="-" for EVERY isToggleOn() call in EVERY file -- producing 53+
                 bogus registry entries that overwrite real toggle information.
                 FIX 1: Add REMOVE_PRIVILEGE to $excludedConstantNames.
                 FIX 2: Add a minimum toggle-value validation guard in Harvest-Declarations:
                         toggle values must be ≥ 5 characters AND contain at least one space
                         (real toggle names are human-readable phrases, never single words or
                         punctuation).  This prevents any future short/symbol-only value from
                         poisoning the regex.

   Bug 5b (RCA): Pass 1 Harvest-Declarations regex only matched "public static final String".
                 Toggle constants declared as "private static final String" or
                 "protected static final String" are completely invisible to Pass 1, so their
                 toggle_name never enters $declMap.  Pass 2 then detects the isToggleOn() call
                 via window matching but cannot resolve the toggle_name.
                 Affected examples:
                   - SchemeTokenValidator (Orchestrator): private ACCEPT_CSC_IN_SCHEME_TOKEN_TRANSACTIONS
                   - RefundServiceImpl (CPE): private TOGGLE_SUPPORT_TRANSACTION_LEVEL_...
                   - StripeServiceImpl (BusinessService): private TOGGLE_SUPPORT_STRIPE_FAILOVER_...
                   - MerchantAcquirerFilterFactory, CreditCardPaymentTypeBuilder (BusinessService):
                     private ENABLE_ALLOW_CONSUMER_CHOICE_ROUTING_FOR_CO_BRANDED_CARDS
                 FIX: Expand Harvest-Declarations regex to match any "static final String"
                      declaration regardless of access modifier visibility.

   Bug 5c (RCA): The $isToggle prefix filter (also fixed in Bug 3) was still too narrow --
                 several valid toggle constant naming prefixes used in the codebase were absent:
                   ACCEPT_  → ACCEPT_CSC_IN_SCHEME_TOKEN_TRANSACTIONS (SchemeTokenValidator)
                   PREVENT_ → PREVENT_FORMAT_4_PIN_BLOCK_PASSTHROUGH_IN_DE_110[_FOR_AMEX]
                              (S2IAcquirerConstants, used in IsoDataField110Populator)
                   FIX_     → FIX_CREDENTIAL_ON_FILE_FOR_STANDALONE_REFUND
                              (JsonMegaMessageRequestBuilder)
                   SUPPORT_ → SUPPORT_POS_ENTRY_MODE_FOR_INCREMENTAL_AUTHORIZATION_PER_VISA_MANDATE
                              (S2IAcquirerConstants)
                   INDUSTRY_→ INDUSTRY_PRACTICE_PARTIAL_SHIPMENT_SUPPORT_FOR_3RI_AUTHENTICATION_TRANSACTIONS
                              (S2IAcquirerToggleConstants)
                 FIX: Added ACCEPT_ | PREVENT_ | FIX_ | SUPPORT_ | INDUSTRY_ to both the
                 $isToggle regex in Harvest-Declarations and the $refreshPattern for DirectAPI.
#>

param(
    # ── Primary: path to config.yml (all other paths come from here) ─────────
    # Auto-resolved relative to this script's own location if not supplied.
    [string]$ConfigFile            = "",

    # ── Override: framework root (used only when -ConfigFile is NOT given) ───
    # Walks up from the script to find the repo root automatically; only
    # supply this if the auto-detection fails on your machine.
    [string]$FrameworkRoot         = "",

    # ── Single-repo targeted rebuild ─────────────────────────────────────────
    # When supplied, ONLY this repository is scanned (Pass 1 + Pass 2).
    # All other repos are preserved in the combined registry as-is (read from
    # the existing toggle-registry-lookup.csv and merged back in).
    # Value must match the "name" field in config.yml (case-insensitive).
    # Examples: "BatchSettlementService", "CPE", "Orchestrator"
    [string]$TargetRepo            = "",

    # ── Output control switches ───────────────────────────────────────────────
    [switch]$RefreshDirectAPIFileList,  # force full DirectAPI rescan (~5 min)
    [switch]$SkipPerRepoSplit,          # write combined CSV only, skip per-repo files
    [switch]$DryRun                     # parse config + print plan, do not scan or write
)

# ===========================================================================
# SECTION 1 -- Locate and parse config.yml
# All repository paths, output paths, and scan settings come from config.yml.
# No path is hard-coded below this section.
# ===========================================================================

# ── Step 1a: Resolve config file path ──────────────────────────────────────
# Priority: -ConfigFile arg > auto-detect from script location > -FrameworkRoot fallback
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path

if (-not [string]::IsNullOrWhiteSpace($ConfigFile)) {
    # Explicit path supplied
    $resolvedConfig = $ConfigFile
} else {
    # Auto-detect: walk up from script dir looking for knowledge/config.yml
    # Script lives at: <FrameworkRoot>/tools/active/build-toggle-registry-lookup.ps1
    # Config lives at: <FrameworkRoot>/knowledge/config.yml
    $autoRoot = Split-Path (Split-Path $scriptDir -Parent) -Parent
    $autoConfig = Join-Path $autoRoot "knowledge\config.yml"

    if (Test-Path $autoConfig) {
        $resolvedConfig = $autoConfig
        Write-Host "  [Config] Auto-detected: $resolvedConfig"
    } elseif (-not [string]::IsNullOrWhiteSpace($FrameworkRoot)) {
        $resolvedConfig = Join-Path $FrameworkRoot "knowledge\config.yml"
        Write-Host "  [Config] Using -FrameworkRoot: $resolvedConfig"
    } else {
        Write-Error @"
Cannot locate config.yml. Tried:
  Auto-detect : $autoConfig
Supply one of:
  -ConfigFile   'C:\path\to\agentic-ai-toggle-management\knowledge\config.yml'
  -FrameworkRoot 'C:\path\to\agentic-ai-toggle-management'
"@
        exit 1
    }
}

if (-not (Test-Path $resolvedConfig)) {
    Write-Error "Config file not found: $resolvedConfig"
    exit 1
}

# ── Step 1b: Parse config.yml (simple line-by-line YAML reader) ────────────
# Supports only the flat key: "value" pattern used in this project's config.
# Full YAML parser not required -- config format is controlled and predictable.
function Read-ConfigYaml {
    param([string]$Path)
    $cfg = @{}
    $currentSection = ""
    $repoList = [System.Collections.Generic.List[hashtable]]::new()
    $inRepositories = $false
    $currentRepo = $null

    foreach ($rawLine in (Get-Content $Path -Encoding UTF8)) {
        $line = $rawLine.TrimEnd()
        if ($line -match '^\s*#' -or [string]::IsNullOrWhiteSpace($line)) { continue }

        # Top-level section header: no leading whitespace, ends with ":"
        if ($line -match '^([a-z_]+)\s*:\s*$') {
            # Flush any in-progress repo before switching sections
            if ($currentRepo) { $repoList.Add($currentRepo); $currentRepo = $null }
            $currentSection = $Matches[1]
            $inRepositories = ($currentSection -eq 'repositories')
            continue
        }

        # Inside repositories list
        if ($inRepositories) {
            # New repo entry: "  - name: ..."
            if ($line -match '^\s+-\s+name:\s+"?([^"#\s][^"#]*?)"?\s*$') {
                if ($currentRepo) { $repoList.Add($currentRepo) }
                $currentRepo = @{ name = $Matches[1].Trim().Trim('"') }
                continue
            }
            # Field inside a repo entry: "    key: value"
            if ($currentRepo -and $line -match '^\s{2,}([a-z_]+):\s+"?([^"#]+?)"?\s*$') {
                $currentRepo[$Matches[1]] = $Matches[2].Trim().Trim('"')
                continue
            }
            # Commented-out pending repo: skip silently
            if ($line -match '^\s*#') { continue }
        }

        # Flat key: value under any non-repo section (2+ leading spaces)
        if (-not $inRepositories -and $line -match '^\s{2,}([a-z_]+):\s+"?([^"#\[\]]+?)"?\s*$') {
            $k = "$currentSection.$($Matches[1])"
            $cfg[$k] = $Matches[2].Trim().Trim('"')
        }
    }
    # Flush last repo (no trailing section header to trigger it)
    if ($currentRepo) { $repoList.Add($currentRepo) }
    $cfg['__repositories'] = $repoList
    return $cfg
}

$cfg = Read-ConfigYaml -Path $resolvedConfig
$cfgRepos = $cfg['__repositories']

# ── Step 1b-ext: Resolve and validate -TargetRepo if supplied ───────────────
# Normalise to the exact name stored in config.yml for all downstream comparisons.
$resolvedTargetRepo = ""
if (-not [string]::IsNullOrWhiteSpace($TargetRepo)) {
    $matchedRepo = $cfgRepos | Where-Object { $_.name -ieq $TargetRepo.Trim() } | Select-Object -First 1
    if (-not $matchedRepo) {
        $available = ($cfgRepos | ForEach-Object { "  - $($_.name)" }) -join "`n"
        Write-Error @"
-TargetRepo '$TargetRepo' not found in config.yml.
Available repositories:
$available
"@
        exit 1
    }
    $resolvedTargetRepo = $matchedRepo.name
    Write-Host "  [TargetRepo] Single-repo mode: only '$resolvedTargetRepo' will be scanned."
    Write-Host "               All other repos will be preserved from the existing combined registry."
}

# ── Step 1c: Resolve framework root from config ─────────────────────────────
# config.yml sets workspace.framework_root: "." (relative marker).
# If the value is "." or relative, resolve it as an absolute path based on
# the config file's parent directory (knowledge/../ = framework root).
# This ensures output paths are always absolute regardless of CWD.
$rawFrameworkRoot = $cfg['workspace.framework_root'] -replace '/', '\'
if ([string]::IsNullOrWhiteSpace($rawFrameworkRoot) -or $rawFrameworkRoot -eq '.') {
    # "." means "relative to config file" -- resolve to absolute
    $resolvedFrameworkRoot = Split-Path (Split-Path $resolvedConfig -Parent) -Parent
    Write-Host "  [Config] framework_root='.' -- resolved to absolute: $resolvedFrameworkRoot"
} elseif (-not [System.IO.Path]::IsPathRooted($rawFrameworkRoot)) {
    # Relative path -- resolve against config file's parent directory
    $resolvedFrameworkRoot = Join-Path (Split-Path (Split-Path $resolvedConfig -Parent) -Parent) $rawFrameworkRoot
    Write-Host "  [Config] framework_root relative path resolved to: $resolvedFrameworkRoot"
} else {
    $resolvedFrameworkRoot = $rawFrameworkRoot
}
$resolvedFrameworkRoot = $resolvedFrameworkRoot.TrimEnd('\')

# ── Step 1d: Resolve data directory and output paths ────────────────────────
# Drive the combined output path from config (registry.combined_output or data.registry_combined)
# rather than hardcoding "data/toggle-registry-lookup.csv".
$cfgCombinedRelPath = $cfg['registry.combined_output']
if ([string]::IsNullOrWhiteSpace($cfgCombinedRelPath)) {
    $cfgCombinedRelPath = $cfg['data.registry_combined']
}
if ([string]::IsNullOrWhiteSpace($cfgCombinedRelPath)) {
    # Last-resort fallback -- same path as before (data/registry/toggle-registry-lookup.csv)
    $cfgCombinedRelPath = 'data/registry/toggle-registry-lookup.csv'
}
$OutputPath = Join-Path $resolvedFrameworkRoot ($cfgCombinedRelPath -replace '/', '\')
$dataDir    = Split-Path $OutputPath -Parent
Write-Host "  [Config] Combined registry output: $OutputPath"

# Build per-repo output map from config repositories[*].registry_file
# config.yml stores them as "data/registry/toggle-registry-<repo>.csv" (relative to framework_root)
$perRepoOutputMap = @{}
foreach ($repo in $cfgRepos) {
    if ($repo.registry_file) {
        $absPath = Join-Path $resolvedFrameworkRoot ($repo.registry_file -replace '/', '\')
        $perRepoOutputMap[$repo.name] = $absPath
    }
}

# ── Step 1e: Build repository scan list from config ─────────────────────────
# Config provides: name, java_root (absolute), scan_strategy, targeted_file_list
# When -TargetRepo is set, only that repo is added to the scan list.
$repositories       = [System.Collections.Generic.List[hashtable]]::new()
$directAPIConfig    = $null   # handled separately (targeted scan)

foreach ($repo in $cfgRepos) {
    # Single-repo mode: skip all repos that are not the target
    if ($resolvedTargetRepo -and $repo.name -ne $resolvedTargetRepo) { continue }

    $javaRoot = ($repo.java_root -replace '/', '\').TrimEnd('\')
    # java_root in config already includes /src/main/java -- strip it for BasePath
    # BasePath = everything before /src/main/java
    # SourceSubPath = src\main\java
    if ($javaRoot -match '^(.+)\\src\\main\\java$') {
        $basePath = $Matches[1]
        $subPath  = "src\main\java"
    } else {
        # java_root is the repo root itself -- append src\main\java
        $basePath = $javaRoot
        $subPath  = "src\main\java"
    }

    if ($repo.scan_strategy -eq 'targeted') {
        # Store DirectAPI config separately -- handled by targeted scan logic below
        $directAPIConfig = @{
            Label          = $repo.name
            BasePath       = $basePath
            SourceSubPath  = $subPath
            TargetListFile = if ($repo.targeted_file_list) {
                                 Join-Path $resolvedFrameworkRoot ($repo.targeted_file_list -replace '/', '\')
                             } else { "" }
        }
    } else {
        $repositories.Add(@{
            Label         = $repo.name
            BasePath      = $basePath
            SourceSubPath = $subPath
        })
    }
}

# ── Step 1f: Load targeted file list for DirectAPI from data/ if available ──
$directAPIPath            = if ($directAPIConfig) { $directAPIConfig.BasePath } else { "" }
$directAPITargetRelPaths  = @()   # populated below from file or embedded fallback

if ($directAPIConfig) {
    $targetListFile = $directAPIConfig.TargetListFile
    if (-not [string]::IsNullOrWhiteSpace($targetListFile) -and (Test-Path $targetListFile)) {
        $directAPITargetRelPaths = Get-Content $targetListFile -Encoding UTF8 |
            Where-Object { -not [string]::IsNullOrWhiteSpace($_) -and $_ -notmatch '^\s*#' }
        Write-Host "  [Config] DirectAPI targeted list loaded from: $targetListFile ($($directAPITargetRelPaths.Count) files)"
    } else {
        Write-Host "  [Config] DirectAPI targeted list file not found - using embedded fallback list"
        # Embedded fallback (last-resort; run -RefreshDirectAPIFileList to rebuild from source)
        $directAPITargetRelPaths = @(
            "src/main/java/com/dialect/gateway/merchant/utility/api/converter/common/JsonWithJweEncryptedContentToPlainStringConverter.java",
            "src/main/java/com/dialect/gateway/merchant/utility/api/documentation/api/ProtocolPathTemplate.java",
            "src/main/java/com/dialect/gateway/merchant/utility/api/protocol/rest/RestOperation.java",
            "src/main/java/com/dialect/gateway/merchant/utility/internal/common/execute/concurrent/permerchant/historical/HistoricalTransactionDataConfiguration.java",
            "src/main/java/com/dialect/gateway/merchant/utility/internal/common/execute/concurrent/permerchant/MerchantInvalidRequestRateLimiter.java",
            "src/main/java/com/dialect/gateway/merchant/utility/internal/common/execute/concurrent/permerchant/MerchantPrioritisedRequestRateLimiter.java",
            "src/main/java/com/dialect/gateway/merchant/utility/internal/common/execute/concurrent/permerchant/TestingMerchantsRateLimiter.java",
            "src/main/java/com/dialect/gateway/merchant/utility/internal/common/execute/concurrent/permerchant/UnauthenticatedPaymentRateLimiter.java",
            "src/main/java/com/dialect/gateway/merchant/utility/internal/common/execute/AkamaiDecorator.java",
            "src/main/java/com/dialect/gateway/merchant/utility/internal/common/execute/PANMaskingHelper.java",
            "src/main/java/com/dialect/gateway/merchant/utility/internal/common/execute/RequestExecutor.java",
            "src/main/java/com/dialect/gateway/merchant/utility/internal/common/execute/ResponseFieldLogHandler.java",
            "src/main/java/com/dialect/gateway/merchant/v64/utility/AuthorizationPayGatewayRecommendationConverter.java",
            "src/main/java/com/dialect/gateway/merchant/v67/utility/AuthorizationPayGatewayRecommendationConverter.java",
            "src/main/java/com/dialect/gateway/merchant/v69/utility/AuthorizationPayGatewayRecommendationConverter.java",
            "src/main/java/com/dialect/gateway/merchant/v70/utility/AuthorizationPayGatewayRecommendationConverter.java",
            "src/main/java/com/dialect/gateway/merchant/v71/canon/CreateOrUpdateMerchantRequestCanon.java",
            "src/main/java/com/dialect/gateway/merchant/v72/canon/CreateOrUpdateMerchantRequestCanon.java",
            "src/main/java/com/dialect/gateway/merchant/v73/canon/CreateOrUpdateMerchantRequestCanon.java",
            "src/main/java/com/dialect/gateway/merchant/v73/utility/AuthorizationPayGatewayRecommendationConverter.java",
            "src/main/java/com/dialect/gateway/merchant/v74/utility/AuthorizationPayGatewayRecommendationConverter.java",
            "src/main/java/com/dialect/gateway/merchant/v77/utility/AuthorizationPayGatewayRecommendationConverter.java",
            "src/main/java/com/dialect/gateway/merchant/utility/internal/common/execute/concurrent/DoNotProcessAfterTimeDecorator.java"
        )
    }
}

# ── Step 1g: Ensure data/registry/ directory exists ─────────────────────────
# $dataDir is now the parent of the combined output (data/registry/), not just data/.
# Also ensure the top-level data/ dir exists for other outputs.
if (-not (Test-Path $dataDir)) { New-Item -ItemType Directory -Force -Path $dataDir | Out-Null }
$topDataDir = Join-Path $resolvedFrameworkRoot "data"
if (-not (Test-Path $topDataDir)) { New-Item -ItemType Directory -Force -Path $topDataDir | Out-Null }

# ── Step 1h: Load preserved rows from other repos (single-repo mode only) ───
# When -TargetRepo is set, read the existing combined registry and retain all
# rows that belong to OTHER repositories unchanged.  The target repo rows will
# be fully replaced by the new scan output.
$preservedRows = [System.Collections.Generic.List[hashtable]]::new()
if ($resolvedTargetRepo -and (Test-Path $OutputPath)) {
    Write-Host "  [TargetRepo] Loading existing combined registry to preserve other-repo rows..."
    $existingRows = Import-Csv -Path $OutputPath -Encoding UTF8
    foreach ($row in $existingRows) {
        if ($row.repository -ne $resolvedTargetRepo) {
            $preservedRows.Add(@{
                toggle_name         = $row.toggle_name
                registry_file_path  = $row.registry_file_path
                registry_class_name = $row.registry_class_name
                repository          = $row.repository
                constant_name       = $row.constant_name
                usage_type          = $row.usage_type
                line_number         = $row.line_number
            })
        }
    }
    Write-Host "  [TargetRepo] Preserved $($preservedRows.Count) rows from other repos."
}

# ── DryRun: print resolved plan and exit ────────────────────────────────────
if ($DryRun) {
    Write-Host ""
    Write-Host "=== DRY RUN -- Resolved configuration ===" -ForegroundColor Cyan
    Write-Host "  Config file      : $resolvedConfig"
    Write-Host "  Framework root   : $resolvedFrameworkRoot"
    Write-Host "  Registry dir     : $dataDir"
    Write-Host "  Combined output  : $OutputPath"
    if ($resolvedTargetRepo) {
        Write-Host "  Mode             : SINGLE-REPO  ($resolvedTargetRepo only)"
        Write-Host "  Preserved rows   : $($preservedRows.Count) rows from other repos retained"
    } else {
        Write-Host "  Mode             : FULL (all repositories)"
    }
    Write-Host ""
    Write-Host "  Repositories to scan ($($repositories.Count) full-scan + $(if($directAPIConfig){1}else{0}) targeted):"
    foreach ($r in $repositories) {
        $srcPath = Join-Path $r.BasePath $r.SourceSubPath
        $exists  = if (Test-Path $srcPath) { "EXISTS" } else { "NOT FOUND" }
        Write-Host "    $($r.Label.PadRight(16)) $srcPath  [$exists]"
    }
    if ($directAPIConfig) {
        $daPath  = Join-Path $directAPIConfig.BasePath $directAPIConfig.SourceSubPath
        $daEx    = if (Test-Path $daPath) { "EXISTS" } else { "NOT FOUND" }
        $daCount = $directAPITargetRelPaths.Count
        Write-Host "    $($directAPIConfig.Label.PadRight(16)) $daPath  [$daEx]  (targeted: $daCount files)"
    }
    Write-Host ""
    Write-Host "  Per-repo output files ($($perRepoOutputMap.Count)):"
    foreach ($k in ($perRepoOutputMap.Keys | Sort-Object)) {
        Write-Host "    $($k.PadRight(16)) -> $($perRepoOutputMap[$k])"
    }
    Write-Host ""
    Write-Host "  DryRun complete - no files written."
    exit 0
}


# Generic non-toggle constants to exclude.
# RCA-FIX Bug 4 (2026-04-11): Removed "TOGGLE_NAME" from this list.
#   Root cause: TOGGLE_NAME was blanket-excluded by identifier, silently killing ALL classes that
#   use TOGGLE_NAME as their constant name -- regardless of the toggle value string it holds.
#   Affected classes (DirectAPI):
#     - MerchantInvalidRequestRateLimiter   (TOGGLE_NAME = "Apply per-merchant limits for invalid operation rates in WSAPI")
#     - MerchantPrioritisedRequestRateLimiter (TOGGLE_NAME = "Apply per-merchant maximum request rate limits in WSAPI")
#   Both are HYBRID classes (declare TOGGLE_NAME AND call Toggles.isToggleOn(TOGGLE_NAME) in the
#   same file), so they were doubly invisible: excluded before the prefix-filter even ran.
#   Fix: The exclusion list is ONLY for truly generic non-toggle utility constants (ENABLED, etc.).
#   TOGGLE_NAME passes the ^TOGGLE_ prefix filter legitimately -- let it through.
#
# RCA-FIX Bug 5a (2026-04-11): Added REMOVE_PRIVILEGE to this list.
#   Root cause: BulkMerchantPrivilegeUpdateServiceImpl.java declares:
#     public static final String REMOVE_PRIVILEGE = "-"
#   The constant name passes the REMOVE_ prefix filter (added by Bug 3 fix), but its VALUE is
#   just a single dash "-".  When $allToggleValuesRegex is compiled in Pass 2, the escaped "-"
#   matches the literal hyphen character which appears on virtually every Java source line.
#   This caused Pass 2 to emit a spurious IMPLEMENTATION row with toggle_name="-" for EVERY
#   isToggleOn() call in every file -- 53+ bogus entries corrupting the registry.
#   Fix: Add REMOVE_PRIVILEGE to the exclusion list. The exclusion runs BEFORE the prefix filter,
#   so REMOVE_PRIVILEGE is blocked before it can enter $declMap.
$excludedConstantNames = @("ENABLED","ENABLED_TO_UPPER","ENABLED_FOR_MERCHANTS","REMOVE_PRIVILEGE")

# Priority map
$PRIORITY = @{ IMPLEMENTATION = 3; IMPORT = 2; DECLARATION = 1 }

# =========================================================================
# PASS 1 --- Declaration Harvest
# Build:  $declMap[toggleValue] = list of declaration records
#         $constMap[constantName] = list of declaration records  (for import matching)
# =========================================================================
Write-Host ""
Write-Host "=== PASS 1: Harvesting toggle declarations ==="

# declMap:  key = toggle value string  ---  value = List of hashtable records
$declMap  = [System.Collections.Generic.Dictionary[string, System.Collections.Generic.List[hashtable]]]::new()
# constMap: key = CONSTANT_IDENTIFIER  ---  value = List of hashtable records (same objects as declMap)
$constMap = [System.Collections.Generic.Dictionary[string, System.Collections.Generic.List[hashtable]]]::new()

function Add-Declaration {
    param($record)
    $key = $record.toggle_name
    if (-not $declMap.ContainsKey($key)) {
        $declMap[$key] = [System.Collections.Generic.List[hashtable]]::new()
    }
    $declMap[$key].Add($record)

    $ckey = $record.constant_name
    if (-not $constMap.ContainsKey($ckey)) {
        $constMap[$ckey] = [System.Collections.Generic.List[hashtable]]::new()
    }
    $constMap[$ckey].Add($record)
}

function Harvest-Declarations {
    param([string]$JavaFilePath, [string]$Repository, [string]$BasePath)

    $lines    = Get-Content -Path $JavaFilePath -Encoding UTF8
    $content  = $lines -join "`n"
    $className = [System.IO.Path]::GetFileNameWithoutExtension($JavaFilePath)
    $relPath   = ($JavaFilePath -replace [regex]::Escape($BasePath), "").TrimStart("\").Replace("\", "/")

    # RCA-FIX Bug 5b (2026-04-11): Expanded regex to match private/protected/public/package-private
    # access modifiers.  Original regex required "public" which missed many toggle constants declared
    # as "private static final String" or "protected static final String" within their own class
    # (e.g. SchemeTokenValidator.ACCEPT_CSC_IN_SCHEME_TOKEN_TRANSACTIONS = "Accept CSC in scheme
    # token transactions" was private, invisible to Pass 1, so toggle_name stayed "-" in registry).
    # Fix: Use optional access-modifier prefix -- match any "static final String" declaration
    # regardless of visibility, which is correct since all are valid toggle name sources.
    $regex = [regex]'(?m)(?:public|private|protected)?\s*static\s+final\s+String\s+(\w+)\s*=\s*"([^"]+)"'
    foreach ($m in $regex.Matches($content)) {
        $constantName = $m.Groups[1].Value
        $toggleValue  = $m.Groups[2].Value

        if ($excludedConstantNames -contains $constantName) { continue }

        # RCA-FIX Bug 5a (2026-04-11): Guard against short/symbol-only toggle values that would
        # corrupt $allToggleValuesRegex in Pass 2.  Real toggle display names are human-readable
        # phrases (≥ 5 characters and contain at least one space).  A value like "-" (REMOVE_PRIVILEGE)
        # matches virtually every Java line when used in a regex alternation.
        # This guard is a safety net in addition to the REMOVE_PRIVILEGE exclusion above.
        if ($toggleValue.Length -lt 5 -or $toggleValue -notmatch '\s') { continue }

        # Additional value content guard: reject obvious non-toggle strings.
        # Toggle display names are human-readable English phrases.  They never start with SQL
        # keywords, JPQL clauses, Java class path segments, or URL-like strings.
        # This prevents GET_*-prefixed SQL/JPQL constants from polluting $declMap.
        if ($toggleValue -match '^\s*(SELECT|INSERT|UPDATE|DELETE|FROM|WHERE|JOIN|CREATE|DROP|ALTER)\s' `
            -or $toggleValue -match '^(com\.|QSI\.|java\.|org\.|net\.)' `
            -or $toggleValue -match '^https?://' `
            -or $toggleValue -match '^[A-Z][A-Z_]+\s*:') { continue }

        # RCA-FIX Bug 3: expanded prefix filter to also catch constants whose name
        # encodes the toggle purpose directly (e.g. DO_NOT_PROCESS_AFTER_TIME_TOGGLE,
        # ALLOW_*, USE_*, SET_*, REMOVE_*, OPTIMIZE_*, POPULATE_*, APPLY_*, GET_*)
        # while still excluding generic non-toggle names caught by $excludedConstantNames.
        #
        # RCA-FIX Bug 5c (2026-04-11): Added further missing prefixes found via analysis of
        # isToggleOn() calls in CPE and Orchestrator whose constants were not entering $declMap:
        #   ACCEPT_  -> ACCEPT_CSC_IN_SCHEME_TOKEN_TRANSACTIONS (SchemeTokenValidator)
        #   PREVENT_ -> PREVENT_FORMAT_4_PIN_BLOCK_PASSTHROUGH_IN_DE_110[_FOR_AMEX]
        #               (S2IAcquirerConstants, used in IsoDataField110Populator)
        #   FIX_     -> FIX_CREDENTIAL_ON_FILE_FOR_STANDALONE_REFUND (JsonMegaMessageRequestBuilder)
        #   SUPPORT_ -> SUPPORT_POS_ENTRY_MODE_FOR_INCREMENTAL_AUTHORIZATION_PER_VISA_MANDATE
        #               (S2IAcquirerConstants)
        #   INDUSTRY_-> INDUSTRY_PRACTICE_PARTIAL_SHIPMENT_SUPPORT_FOR_3RI_AUTHENTICATION_TRANSACTIONS
        #               (S2IAcquirerToggleConstants, used in RoutedServicesDelegate)
        # These were all valid toggle display names used via isToggleOn() but invisible to Pass 1
        # because their constant-name prefix wasn't in the filter -- producing toggle_name="-" rows
        # in the registry after the Bug 5a fix removed the REMOVE_PRIVILEGE poison.
        #
        # RCA-FIX Bug 6 (2026-04-12): Four more BSS toggle constants missed -- root cause analysis:
        #   ACCOUNT_VALIDATION_TOGGLE_NAME / ACQUIRER_TRANSACTION_ID_TOGGLE_NAME
        #     -> Suffix is _TOGGLE_NAME (not _TOGGLE). The _TOGGLE$ check only matches constants
        #        ending exactly in "_TOGGLE". Added _TOGGLE_NAME$ to the suffix list.
        #   SYSTEM_TOGGLE_ENABLE_TO_READ_ACQUIRER_CONFIG_FROM_DB
        #     -> Prefix SYSTEM_TOGGLE_ not in filter. Added ^SYSTEM_TOGGLE prefix.
        #   ACQ_SUBSYSTEM_SWITCH_SETTLEMENT_TXNS_TO_NEW_VM_FOR
        #     -> Prefix ACQ_ not in filter, BUT its value starts with "System Toggle:".
        #        Added value-based guard: any constant whose toggle VALUE starts with
        #        "System Toggle" or "Feature Toggle" is unconditionally treated as a toggle,
        #        regardless of constant name prefix. This is the most reliable signal.
        #   BSS_USE_BASE32_ID_GENERATOR
        #     -> Prefix BSS_ not in filter. Added ^BSS_ prefix.
        $isToggle = ($constantName -match '^TOGGLE_|^ENABLE_|^ENABLE[A-Z]|^FEATURE|_TOGGLE$|_TOGGLE_NAME$|^DO_NOT_|^ALLOW_|^USE_|^SET_|^REMOVE_|^OPTIMIZE_|^POPULATE_|^APPLY_|^GET_|^ACCEPT_|^PREVENT_|^FIX_|^SUPPORT_|^INDUSTRY_|^SYSTEM_TOGGLE|^BSS_')
        # Value-based override: "System Toggle:" and "Feature Toggle:" prefixed values are
        # definitively toggles regardless of the constant name convention used.
        $isToggleByValue = ($toggleValue -match '^(System Toggle|Feature Toggle)\s*[:\-]')
        if (-not $isToggle -and -not $isToggleByValue) { continue }

        # Compute 1-based declaration line number
        $charsBefore = $content.Substring(0, $m.Index)
        $declLineNo  = ($charsBefore -split "`n").Count

        Add-Declaration @{
            toggle_name         = $toggleValue
            constant_name       = $constantName
            registry_class_name = $className
            registry_file_path  = $relPath
            repository          = $Repository
            decl_line_no        = $declLineNo
        }
    }
}

# Scan full-scan repos
foreach ($repo in $repositories) {
    $srcPath = Join-Path $repo.BasePath $repo.SourceSubPath
    if (-not (Test-Path $srcPath)) { Write-Host "  [SKIP] $($repo.Label): $srcPath"; continue }
    Write-Host "  Pass 1 - $($repo.Label)..."
    $javaFiles = Get-ChildItem -Path $srcPath -Recurse -Include "*.java" -File
    foreach ($f in $javaFiles) { Harvest-Declarations -JavaFilePath $f.FullName -Repository $repo.Label -BasePath $repo.BasePath }
}

# DirectAPI --- targeted files (Pass 1)
$daSourcePath = if ($directAPIPath) { Join-Path $directAPIPath "src\main\java" } else { "" }
if ($daSourcePath -and (Test-Path $daSourcePath)) {
    if ($RefreshDirectAPIFileList) {
        Write-Host "  DirectAPI REFRESH MODE --- full scan, rebuilding targeted file list..."
        $allDAFiles = Get-ChildItem -Path $daSourcePath -Recurse -Include "*.java" -File
        $refreshPattern = '(?:public|private|protected)?\s*static\s+final\s+String\s+(\w+TOGGLE\w*|TOGGLE_\w+|ENABLE_\w+|ENABLE[A-Z]\w+|FEATURE\w*|DO_NOT_\w+|ALLOW_\w+|USE_\w+|SET_\w+|REMOVE_\w+|OPTIMIZE_\w+|POPULATE_\w+|APPLY_\w+|GET_\w+|ACCEPT_\w+|PREVENT_\w+|FIX_\w+|SUPPORT_\w+|INDUSTRY_\w+|SYSTEM_TOGGLE\w*|BSS_\w+)\s*='
        $daTargetFiles = $allDAFiles | Where-Object { (Get-Content $_.FullName -Raw) -match $refreshPattern }
        # Persist the refreshed list to data/ so future runs use the fast path
        if ($directAPIConfig -and $directAPIConfig.TargetListFile) {
            $refreshedRelPaths = $daTargetFiles | ForEach-Object {
                ($_.FullName -replace [regex]::Escape($directAPIPath), "").TrimStart("\").Replace("\", "/")
            }
            $refreshedRelPaths | Out-File -FilePath $directAPIConfig.TargetListFile -Encoding UTF8 -Force
            Write-Host "  [Config] DirectAPI targeted list saved: $($directAPIConfig.TargetListFile) ($($daTargetFiles.Count) files)"
        }
    } else {
        Write-Host "  Pass 1 - DirectAPI ($($directAPITargetRelPaths.Count) targeted files)..."
        $daTargetFiles = $directAPITargetRelPaths | ForEach-Object {
            $fp = Join-Path $directAPIPath ($_ -replace '/', '\')
            if (Test-Path $fp) { Get-Item $fp } else { Write-Host "  [WARN] Not found: $_" }
        } | Where-Object { $_ -ne $null }
    }
    foreach ($f in $daTargetFiles) { Harvest-Declarations -JavaFilePath $f.FullName -Repository $directAPIConfig.Label -BasePath $directAPIPath }
}

$totalDeclarations = ($declMap.Values | ForEach-Object { $_.Count } | Measure-Object -Sum).Sum
Write-Host "  Pass 1 complete: $($declMap.Count) unique toggle names, $totalDeclarations declaration entries"

# =========================================================================
# POST PASS 1: Build optimized lookup structures for Pass 2
#
# $allToggleValuesRegex  - single compiled alternation regex of all toggle
#                          value strings; used for fast per-file pre-filter
# $toggleValueToInfo     - map: toggleValue -> first declMap record (fast lookup)
# =========================================================================
Write-Host "  Building fast-lookup structures for Pass 2..."

# Sorted longest-first so longer matches win over substrings
$sortedValues = $declMap.Keys | Sort-Object { $_.Length } -Descending
$escapedParts = $sortedValues | ForEach-Object { [regex]::Escape($_) }
$allToggleValuesRegex = [regex]("(" + ($escapedParts -join "|") + ")")

# toggleValue -> first declaration record (for quick info lookup)
$toggleValueToInfo = @{}
foreach ($tv in $declMap.Keys) { $toggleValueToInfo[$tv] = $declMap[$tv][0] }

# =========================================================================
# PASS 2 --- Usage Harvest (scan ALL files in all repos)
# For every .java file: find IMPLEMENTATION and IMPORT usages of known toggles
# Output: one record per (toggleValue, usageFile, repo) --- best priority per pair
# =========================================================================
Write-Host ""
Write-Host "=== PASS 2: Harvesting toggle usages across all files ==="

# usageRegistry: key = "toggleValue|||relFilePath|||repo"  ---  best record so far
$usageRegistry = [System.Collections.Generic.Dictionary[string, hashtable]]::new()

function Upsert-Usage {
    param($record)
    # Key includes class name so every implementation class keeps its own row
    $key = "$($record.toggle_name)|||$($record.registry_file_path)|||$($record.repository)|||$($record.registry_class_name)"
    if ($usageRegistry.ContainsKey($key)) {
        $existing = $usageRegistry[$key]
        $existingPri = $PRIORITY[$existing.usage_type]
        $newPri      = $PRIORITY[$record.usage_type]
        # Keep higher priority; on tie keep lower line number
        if ($newPri -gt $existingPri -or
            ($newPri -eq $existingPri -and $record.line_number -lt $existing.line_number)) {
            $usageRegistry[$key] = $record
        }
    } else {
        $usageRegistry[$key] = $record
    }
}

function Harvest-Usages {
    param([string]$JavaFilePath, [string]$Repository, [string]$BasePath)

    $lines      = Get-Content -Path $JavaFilePath -Encoding UTF8
    $totalLines = $lines.Count
    $className  = [System.IO.Path]::GetFileNameWithoutExtension($JavaFilePath)
    $relPath    = ($JavaFilePath -replace [regex]::Escape($BasePath), "").TrimStart("\").Replace("\", "/")

    # -----------------------------------------------------------------------
    # (A) Static imports - three sub-patterns:
    #   A1. Named:    import static pkg.ClassName.CONSTANT_NAME;
    #   A2. Wildcard: import static pkg.ClassName.*;  -> expand all constants from that class
    #
    # Map: constantName -> import line number (1-based)
    # -----------------------------------------------------------------------
    $importedConstants = @{}
    $wildcardClasses   = @{}

    for ($i = 0; $i -lt $totalLines; $i++) {
        $line = $lines[$i]
        if ($line -notmatch '^\s*import\s+static\s+') { continue }

        if ($line -match '\.\*\s*;') {
            # Wildcard: extract ClassName (last segment before .*)
            if ($line -match '\.([A-Za-z][A-Za-z0-9_]+)\.\*\s*;') {
                $wc = $Matches[1]
                if (-not $wildcardClasses.ContainsKey($wc)) { $wildcardClasses[$wc] = $i + 1 }
            }
        } elseif ($line -match '\.([A-Z][A-Z0-9_]+)\s*;') {
            # Named constant import
            $cname = $Matches[1]
            if ($constMap.ContainsKey($cname) -and -not $importedConstants.ContainsKey($cname)) {
                $importedConstants[$cname] = $i + 1
            }
        }
    }

    # Expand wildcard imports: add ALL known constants from those declaring classes
    foreach ($wc in $wildcardClasses.Keys) {
        foreach ($cname in @($constMap.Keys)) {
            if ($importedConstants.ContainsKey($cname)) { continue }
            foreach ($dr in $constMap[$cname]) {
                if ($dr.registry_class_name -eq $wc) {
                    $importedConstants[$cname] = $wildcardClasses[$wc]
                    break
                }
            }
        }
    }

    # -----------------------------------------------------------------------
    # (B) Inline toggle-value strings (fast single-regex scan)
    #     Map: toggleValue -> first appearance line (1-based)
    # -----------------------------------------------------------------------
    $inlineValues = @{}
    $rawContent = $lines -join "`n"
    if ($rawContent -match '"') {
        $lineIndex = 0
        foreach ($line in $lines) {
            $lineIndex++
            if ($line -notmatch '"') { continue }
            $regexMatches = $allToggleValuesRegex.Matches($line)
            foreach ($m in $regexMatches) {
                $tv = $m.Value
                if (-not $inlineValues.ContainsKey($tv)) { $inlineValues[$tv] = $lineIndex }
            }
        }
    }

    # -----------------------------------------------------------------------
    # (C) Fully-qualified usage: ClassName.CONSTANT_NAME in body (no static import)
    #     Covers: isToggleOn(S2IAcquirerToggleConstants.TOGGLE_X)
    #     Adds missing constants to $importedConstants so they flow through normally
    # -----------------------------------------------------------------------
    for ($i = 0; $i -lt $totalLines; $i++) {
        $line = $lines[$i]
        if ($line -match '^\s*(import|//|/\*|\*)') { continue }
        # Find all ClassName.CONSTANT_NAME occurrences on this line
        $qMatches = [regex]::Matches($line, '([A-Za-z][A-Za-z0-9_]*)\.([A-Z][A-Z0-9_]+)')
        foreach ($qm in $qMatches) {
            $qClass = $qm.Groups[1].Value
            $qConst = $qm.Groups[2].Value
            if (-not $constMap.ContainsKey($qConst)) { continue }
            if ($importedConstants.ContainsKey($qConst)) { continue }
            # Verify the class name matches a known declaring class for this constant
            foreach ($dr in $constMap[$qConst]) {
                if ($dr.registry_class_name -eq $qClass) {
                    $importedConstants[$qConst] = $i + 1
                    break
                }
            }
        }
    }

    # Early exit if nothing relevant found
    if ($importedConstants.Count -eq 0 -and $inlineValues.Count -eq 0) { return }

    # -----------------------------------------------------------------------
    # Build relevantToggles: all toggles visible in this file
    # -----------------------------------------------------------------------
    $relevantToggles = @{}

    foreach ($cname in $importedConstants.Keys) {
        foreach ($dr in $constMap[$cname]) {
            $tv = $dr.toggle_name
            if (-not $relevantToggles.ContainsKey($tv)) {
                $relevantToggles[$tv] = @{ constName = $cname; declRecords = @() }
            }
            $relevantToggles[$tv].declRecords += $dr
        }
    }
    foreach ($tv in $inlineValues.Keys) {
        if (-not $relevantToggles.ContainsKey($tv)) {
            $dr0 = $toggleValueToInfo[$tv]
            $cn0 = if ($dr0) { $dr0.constant_name } else { "" }
            $relevantToggles[$tv] = @{ constName = $cn0; declRecords = if ($dr0) { @($dr0) } else { @() } }
        }
    }

    if ($relevantToggles.Count -eq 0) { return }

    # -----------------------------------------------------------------------
    # Implementation scan: isToggleOn / .isEnabled / ToggleHelper. lines
    # Window: +-5 lines. Match bare CONSTANT_NAME, ClassName.CONSTANT_NAME, or toggle value string.
    # -----------------------------------------------------------------------
    $implPatterns = @('isToggleOn\s*\(', '\.isEnabled\s*\(', '\.isOn\s*\(', 'ToggleHelper\.')

    $implLines = [System.Collections.Generic.List[hashtable]]::new()
    for ($i = 0; $i -lt $totalLines; $i++) {
        $line = $lines[$i]
        if ($line -match '^\s*(//|/\*|\*)') { continue }
        $isImpl = $false
        foreach ($pat in $implPatterns) { if ($line -match $pat) { $isImpl = $true; break } }
        if (-not $isImpl) { continue }
        $ws = [Math]::Max(0, $i - 5)
        $we = [Math]::Min($totalLines - 1, $i + 5)
        $window = $lines[$ws..$we] -join " "
        $implLines.Add(@{ lineNo = $i + 1; window = $window })
    }

    # -----------------------------------------------------------------------
    # For each relevant toggle, determine the best usage in this file
    # -----------------------------------------------------------------------
    foreach ($tv in $relevantToggles.Keys) {
        $info      = $relevantToggles[$tv]
        $constName = $info.constName
        $declRecs  = $info.declRecords

        $sameRepoDecls = $declRecs | Where-Object { $_.repository -eq $Repository }
        $chosenDecls   = if ($sameRepoDecls) { $sameRepoDecls } elseif ($declRecs.Count -gt 0) { $declRecs } else { @() }

        if ($chosenDecls.Count -eq 0) {
            $chosenDecl = @{ toggle_name = $tv; constant_name = $constName; registry_class_name = $className; registry_file_path = $relPath; repository = $Repository; decl_line_no = 0 }
        } else {
            $chosenDecl = $chosenDecls[0]
        }

        $declaringClassName = $chosenDecl.registry_class_name
        $isDeclaringFile    = ($relPath -eq $chosenDecl.registry_file_path)

        # --- Try IMPLEMENTATION ---
        $implLineNo = $null
        foreach ($il in $implLines) {
            $w = $il.window
            # Match: bare constant, OR ClassName.CONSTANT (fully qualified), OR string literal value
            if (($constName -and ($w -match [regex]::Escape($constName))) -or
                ($declaringClassName -and $constName -and ($w -match ([regex]::Escape($declaringClassName) + '\.' + [regex]::Escape($constName)))) -or
                ($tv -and ($w -match [regex]::Escape($tv)))) {
                $implLineNo = $il.lineNo
                break
            }
        }

        # RCA-FIX Bug 1: Hybrid classes declare AND use their own toggle constant in the
        # same file (e.g. DoNotProcessAfterTimeHandler, SanctionHelper, CardTypeDetailsDecorator).
        # Previously the $isDeclaringFile guard unconditionally blocked IMPLEMENTATION detection
        # for these files.  Fix: allow IMPLEMENTATION rows for declaring files too -- Pass 1 already
        # recorded a DECLARATION row, so the Merge phase will keep only the higher-priority
        # IMPLEMENTATION row via $coveredKeys suppression of the DECLARATION fallback.
        if ($null -ne $implLineNo) {
            Upsert-Usage @{
                toggle_name         = $tv
                registry_class_name = $className
                registry_file_path  = $relPath
                constant_name       = $chosenDecl.constant_name
                repository          = $Repository
                usage_type          = "IMPLEMENTATION"
                line_number         = $implLineNo
            }
            continue
        }

        # --- Try IMPORT ---
        if ($importedConstants.ContainsKey($constName) -and -not $isDeclaringFile) {
            Upsert-Usage @{
                toggle_name         = $tv
                registry_class_name = $className
                registry_file_path  = $relPath
                constant_name       = $chosenDecl.constant_name
                repository          = $Repository
                usage_type          = "IMPORT"
                line_number         = $importedConstants[$constName]
            }
        }
    }

}

# Scan full-scan repos --- ALL files
foreach ($repo in $repositories) {
    $srcPath = Join-Path $repo.BasePath $repo.SourceSubPath
    if (-not (Test-Path $srcPath)) { continue }
    Write-Host "  Pass 2 - $($repo.Label)..."
    $javaFiles = Get-ChildItem -Path $srcPath -Recurse -Include "*.java" -File
    $fc = 0
    foreach ($f in $javaFiles) {
        $fc++
        if ($fc % 500 -eq 0) { Write-Host "    $fc / $($javaFiles.Count) files..." }
        Harvest-Usages -JavaFilePath $f.FullName -Repository $repo.Label -BasePath $repo.BasePath
    }
    Write-Host "    $($repo.Label): $fc files scanned"
}

# DirectAPI --- Pass 2 (same targeted files resolved above)
if ($daSourcePath -and (Test-Path $daSourcePath)) {
    Write-Host "  Pass 2 - $($directAPIConfig.Label) ($($daTargetFiles.Count) targeted files)..."
    foreach ($f in $daTargetFiles) {
        Harvest-Usages -JavaFilePath $f.FullName -Repository $directAPIConfig.Label -BasePath $directAPIPath
    }
}

Write-Host "  Pass 2 complete: $($usageRegistry.Count) usage entries found"

# =========================================================================
# MERGE: Combine declarations + usages into the final output list.
#
# Rules:
#  1. Every IMPLEMENTATION and IMPORT row from usageRegistry is kept as-is
#     (one row per usage class per toggle per repo).
#  2. A DECLARATION row is only included when there is NO IMPLEMENTATION
#     and NO IMPORT row for the same (toggle_name + repo + constant_name)
#     combination -- i.e. the toggle is genuinely unused in the codebase.
#
# Key for deduplication within usageRegistry rows (same file, same toggle):
#   toggle_name + repo + constant_name + registry_class_name
# =========================================================================
Write-Host ""
Write-Host "=== Merging declarations and usages ==="

# Collect all IMPLEMENTATION and IMPORT usage rows keyed by
# "toggle|||repo|||constant|||class"  (one row per usage location)
$allUsageRows = [System.Collections.Generic.List[hashtable]]::new()

# Track which (toggle_name + repo + constant_name) combos have at least one
# IMPLEMENTATION or IMPORT entry so we can suppress redundant DECLARATIONs
$coveredKeys = [System.Collections.Generic.HashSet[string]]::new()

foreach ($rec in $usageRegistry.Values) {
    $allUsageRows.Add($rec)
    if ($rec.usage_type -eq "IMPLEMENTATION" -or $rec.usage_type -eq "IMPORT") {
        $ck = "$($rec.toggle_name)|||$($rec.repository)|||$($rec.constant_name)"
        [void]$coveredKeys.Add($ck)
    }
}

# Add DECLARATION rows only for toggles with no implementation/import usage found
foreach ($tv in $declMap.Keys) {
    foreach ($dr in $declMap[$tv]) {
        $ck = "$($dr.toggle_name)|||$($dr.repository)|||$($dr.constant_name)"
        if (-not $coveredKeys.Contains($ck)) {
            $allUsageRows.Add(@{
                toggle_name         = $dr.toggle_name
                registry_class_name = $dr.registry_class_name
                registry_file_path  = $dr.registry_file_path
                constant_name       = $dr.constant_name
                repository          = $dr.repository
                usage_type          = "DECLARATION"
                line_number         = $dr.decl_line_no
            })
        }
    }
}

# =========================================================================
# OUTPUT -- Step 1: Write combined registry (all repos)
# In single-repo mode: merge new scan rows with the preserved other-repo rows.
# In full mode: write all rows from this scan only.
# =========================================================================
# Merge: new scan rows + preserved rows from other repos (single-repo mode)
if ($resolvedTargetRepo -and $preservedRows.Count -gt 0) {
    Write-Host "  [TargetRepo] Merging $($allUsageRows.Count) new '$resolvedTargetRepo' rows with $($preservedRows.Count) preserved rows..."
    foreach ($pr in $preservedRows) { $allUsageRows.Add($pr) }
}

$sorted = $allUsageRows | Sort-Object { $_.toggle_name }

Write-Host "Total entries in final registry: $($sorted.Count)"
Write-Host "Writing combined registry -> $OutputPath ..."

$csvProps = @(
    @{Name='toggle_name';         Expression={$_['toggle_name']}},
    @{Name='registry_file_path';  Expression={$_['registry_file_path']}},
    @{Name='registry_class_name'; Expression={$_['registry_class_name']}},
    @{Name='repository';          Expression={$_['repository']}},
    @{Name='constant_name';       Expression={$_['constant_name']}},
    @{Name='usage_type';          Expression={$_['usage_type']}},
    @{Name='line_number';         Expression={$_['line_number']}}
)

$sorted | Select-Object $csvProps |
    Export-Csv -Path $OutputPath -NoTypeInformation -Encoding UTF8 -Force

# =========================================================================
# OUTPUT - Step 2: Write per-repo split files
# Each repo gets its own  data/toggle-registry-<repo>.csv  in kebab-case.
# Agents (SA-1, SA-2a) use these for faster per-repo lookups.
# =========================================================================
if (-not $SkipPerRepoSplit) {
    Write-Host ""
    Write-Host "=== Writing per-repo split files ==="

    foreach ($repoLabel in ($perRepoOutputMap.Keys | Sort-Object)) {
        # Single-repo mode: only update the target repo's per-repo file.
        # Other repos' files are already correct -- skip writing them to save time.
        if ($resolvedTargetRepo -and $repoLabel -ne $resolvedTargetRepo) {
            Write-Host "  --  $($repoLabel.PadRight(16)) -> (skipped -- not target repo)"
            continue
        }

        $repoRows = @($sorted | Where-Object { $_['repository'] -eq $repoLabel })
        $repoOut  = $perRepoOutputMap[$repoLabel]

        if ($repoRows.Count -gt 0) {
            $repoRows | Select-Object $csvProps |
                Export-Csv -Path $repoOut -NoTypeInformation -Encoding UTF8 -Force
            Write-Host "  OK  $($repoLabel.PadRight(16)) -> $(Split-Path $repoOut -Leaf)  ($($repoRows.Count) rows)"
        } else {
            # Write header-only file so agents can always expect the file to exist
            "toggle_name,registry_file_path,registry_class_name,repository,constant_name,usage_type,line_number" |
                Out-File -FilePath $repoOut -Encoding UTF8 -Force
            Write-Host "  --  $($repoLabel.PadRight(16)) -> $(Split-Path $repoOut -Leaf)  (0 rows - header only)"
        }
    }
}

# =========================================================================
# SUMMARY
# =========================================================================
Write-Host ""
Write-Host "=============================================="
Write-Host "  Toggle Registry Build -- Complete"
Write-Host "=============================================="
if ($resolvedTargetRepo) {
    Write-Host "  Mode               : SINGLE-REPO ($resolvedTargetRepo)"
    Write-Host "  Preserved rows     : $($preservedRows.Count) (other repos, unchanged)"
} else {
    Write-Host "  Mode               : FULL (all repositories)"
}
Write-Host "  Combined registry  : $OutputPath"
Write-Host "  Total entries      : $($sorted.Count)"
Write-Host "  Unique toggle names: $($declMap.Count)"
Write-Host ""

$sorted | Group-Object { $_['repository'] } | Sort-Object Name | ForEach-Object {
    $impl        = ($_.Group | Where-Object { $_['usage_type'] -eq "IMPLEMENTATION" }).Count
    $import      = ($_.Group | Where-Object { $_['usage_type'] -eq "IMPORT"         }).Count
    $decl        = ($_.Group | Where-Object { $_['usage_type'] -eq "DECLARATION"    }).Count
    $perFileName = if ($perRepoOutputMap.ContainsKey($_.Name)) { Split-Path $perRepoOutputMap[$_.Name] -Leaf } else { "n/a" }
    Write-Host "  $($_.Name.PadRight(16)) : $($_.Count.ToString().PadLeft(4)) entries  ($impl IMPL / $import IMPORT / $decl DECL)  -> $perFileName"
}

Write-Host ""
if (-not $SkipPerRepoSplit) {
    Write-Host "  Per-repo files written to: $dataDir"
}
Write-Host "=============================================="





