#!/usr/bin/env python3
"""
Agent Response Banner Renderer

Dynamically renders response banners based on agent-branding.yml configuration.
Called by the orchestrator at the start of every response.
"""

import yaml
import os
from enum import Enum
from datetime import datetime

class ResponseType(Enum):
    STANDARD = "standard"
    SUCCESS = "success"
    ERROR = "error"
    WARNING = "warning"
    INFO = "info"
    PROGRESS = "progress"
    BATCH = "batch"

class BannerRenderer:
    def __init__(self, branding_config_path: str):
        """Load branding configuration from YAML file."""
        with open(branding_config_path, 'r') as f:
            self.config = yaml.safe_load(f)
        self.branding = self.config.get('branding', {})
        self.footer = self.config.get('footer', {})
        self.batch = self.config.get('batch', {})
        self.completion = self.config.get('completion', {})
        self.errors = self.config.get('errors', {})
    
    def render_banner(self, response_type: ResponseType = ResponseType.STANDARD, 
                     title: str = None, session_id: str = None) -> str:
        """
        Render a banner for the response.
        
        Args:
            response_type: Type of response (determines icon/styling)
            title: Optional subtitle/operation name
            session_id: Optional session ID to display
            
        Returns:
            Formatted banner string ready for display
        """
        icon = self._get_icon(response_type)
        style = self.branding.get('banner', {}).get('style', 'full')
        system_name = self.branding.get('system_name', 'MPGS Toggle Agent')
        
        if style == 'minimal':
            return self._render_minimal(icon, system_name, title)
        elif style == 'compact':
            return self._render_compact(icon, system_name, title)
        else:  # 'full' is default
            return self._render_full(icon, system_name, title, session_id)
    
    def _get_icon(self, response_type: ResponseType) -> str:
        """Get the appropriate icon based on response type."""
        icon_map = {
            ResponseType.STANDARD: self.branding.get('icon', '🤖'),
            ResponseType.SUCCESS: self.branding.get('icon_success', '✅'),
            ResponseType.ERROR: self.errors.get('icon', '❌'),
            ResponseType.WARNING: self.branding.get('icon_critical', '⚠️'),
            ResponseType.INFO: self.branding.get('icon_info', 'ℹ️'),
            ResponseType.PROGRESS: self.branding.get('icon_progress', '⏳'),
            ResponseType.BATCH: self.batch.get('icon', '📦'),
        }
        return icon_map.get(response_type, self.branding.get('icon', '🤖'))
    
    def _render_full(self, icon: str, system_name: str, title: str = None, 
                     session_id: str = None) -> str:
        """Render a full-width banner with boxes."""
        width = self.branding.get('banner', {}).get('width', 80)
        if width == 0:
            width = 80
        
        if self.branding.get('banner', {}).get('include_separators', True):
            separator = "═" * (width - 2)
            top = f"╔{separator}╗"
            bottom = f"╚{separator}╝"
        else:
            top = "─" * width
            bottom = "─" * width
        
        content = f"{icon}  {system_name}"
        if title:
            content += f" — {title}"
        
        # Pad content to fit width
        content_padded = content.ljust(width - 2)
        middle = f"║{content_padded}║" if "║" in top else content_padded
        
        banner = f"{top}\n{middle}\n{bottom}"
        return banner
    
    def _render_minimal(self, icon: str, system_name: str, title: str = None) -> str:
        """Render a minimal text-only banner."""
        content = f"{icon} {system_name}"
        if title:
            content += f" — {title}"
        return content
    
    def _render_compact(self, icon: str, system_name: str, title: str = None) -> str:
        """Render a compact single-line banner."""
        system_short = self.branding.get('system_name_short', 'Toggle Agent')
        content = f"{icon} {system_short}"
        if title:
            content += f" | {title}"
        return content
    
    def render_footer(self, session_id: str = None) -> str:
        """Render response footer disclaimer."""
        if not self.footer.get('enabled', True):
            return ""
        
        text = self.footer.get('text', 'AI-Generated. Human review required.')
        footer = f"\n─────────────────────────────────────────────────────────────────\n{text}"
        
        if self.footer.get('include_timestamp', False):
            timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S UTC")
            footer += f"\nGenerated: {timestamp}"
        
        if self.footer.get('include_session_id', False) and session_id:
            footer += f"\nSession: {session_id}"
        
        footer += "\n─────────────────────────────────────────────────────────────────"
        return footer
    
    def render_batch_progress(self, completed: int, total: int) -> str:
        """Render a progress indicator for batch operations."""
        if not self.batch.get('show_progress_bar', True):
            return ""
        
        icon = self.batch.get('icon', '📦')
        percent = int((completed / total) * 100) if total > 0 else 0
        format_str = self.batch.get('progress_format', '[{completed}/{total}] {percent}%')
        
        progress_text = format_str.format(
            completed=completed,
            total=total,
            percent=percent
        )
        
        return f"{icon} {progress_text}"
    
    def render_completion(self, elapsed_seconds: int = None) -> str:
        """Render completion message for batch operations."""
        if not self.completion.get('show_summary', True):
            return ""
        
        icon = self.completion.get('icon', '🏁')
        message = f"{icon} Operation Complete"
        
        if self.completion.get('show_time_elapsed', True) and elapsed_seconds:
            mins, secs = divmod(elapsed_seconds, 60)
            message += f" ({mins}m {secs}s)"
        
        return message


def example_usage():
    """Example showing how to use the BannerRenderer."""
    branding_path = "knowledge/agent-branding.yml"
    
    if os.path.exists(branding_path):
        renderer = BannerRenderer(branding_path)
        
        # Standard banner
        print(renderer.render_banner(ResponseType.STANDARD, title="Analyzing Toggles"))
        print()
        
        # Success banner
        print(renderer.render_banner(ResponseType.SUCCESS, title="Analysis Complete"))
        print()
        
        # Batch progress
        print(renderer.render_batch_progress(5, 10))
        print()
        
        # Completion
        print(renderer.render_completion(elapsed_seconds=125))
        print()
        
        # Footer
        print(renderer.render_footer(session_id="SES-20260412-143022"))


if __name__ == "__main__":
    example_usage()

