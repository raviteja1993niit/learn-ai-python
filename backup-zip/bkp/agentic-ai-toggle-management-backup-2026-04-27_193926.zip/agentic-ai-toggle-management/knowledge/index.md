﻿# AI-Driven Toggle Management System — Agent & Data Quick Reference
# Maintained by: toggle-workspace-manager (SA-5)
# Source of truth for paths: knowledge/config.yml
# Source of truth for agents: .github/agent-registry.yml

## Agents
| ID   | Agent                     | Owns |
|------|---------------------------|------|
| main | toggle-orchestrator       | Routes commands, batch control, stuck detection |
| SA-1 | toggle-analysis-engine    | Registry · Java search · ON/OFF impact · S2A · CSV |
| SA-2 | toggle-report-writer      | Structured + polished reports (writes to reports/) |
| SA-3 | toggle-confluence-enquiry | Confluence 4-tier search, metadata CSV |
| SA-4 | toggle-advisor            | ON-REQUEST: decomp · stuck recovery · QA · optimizer |
| SA-5 | toggle-workspace-manager  | Session state · checkpoints · onboarding · cleanup |

## Key Data Files
| File | Purpose |
|------|---------|
| `data/registry/toggle-registry-lookup.csv`                          | PRIMARY toggle registry (all repos combined) |
| `data/registry/toggle-registry-{repo}.csv`                          | Per-repo registry (CPE, Orchestrator, BusinessService, Console, MSOUI, DirectAPI, BatchSettlementService) |
| `data/analysis/toggle-codebase-usage-analysis.csv`                  | PRIMARY analysis output (ON/OFF impact per class) |
| `data/analysis/toggle-codebase-usage-analysis-{repo}.csv`           | Per-repo analysis output |
| `data/enquiry/feature-toggle-confluence-page-enquiry.csv`           | Input list of toggles to analyse (73 toggles) |
| `data/enquiry/feature-toggle-confluence-page-enquiry-v2.csv`        | Extended input list (334 toggles — future use) |
| `data/enquiry/feature-toggle-confluence-page-enquiry-results.csv`   | Confluence metadata results |
| `knowledge/session-state.yml`                                        | Current batch progress and session status |
| `logs/changelog.md`                                                  | Audit log of all file writes |

## Registered Repositories (7)
| Repo | Strategy | Java Files | Registry File |
|------|----------|-----------|---------------|
| CPE | full | 2420 | `data/registry/toggle-registry-cpe.csv` |
| Orchestrator | full | 751 | `data/registry/toggle-registry-orchestrator.csv` |
| BusinessService | full | 581 | `data/registry/toggle-registry-business-service.csv` |
| Console | full | 749 | `data/registry/toggle-registry-console.csv` |
| MSOUI | full | 1065 | `data/registry/toggle-registry-msoui.csv` |
| DirectAPI | targeted | 10367 | `data/registry/toggle-registry-direct-api.csv` |
| BatchSettlementService | full | 285 | `data/registry/toggle-registry-batch-settlement-service.csv` |

---
<!-- COPYRIGHT-FOOTER -->
© 2026 Mastercard. All rights reserved.
This file is part of the AI-Driven Toggle Management System.
Maintained by the multi-agent AI framework.
