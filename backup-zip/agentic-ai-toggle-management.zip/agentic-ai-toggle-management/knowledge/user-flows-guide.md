<!--
  Copyright (c) 2026 Mastercard. All rights reserved.
-->

# Toggle Management System — User Flows Guide

| Field | Value |
|---|---|
| **Author** | Ravi Teja Thota (raviteja.thota@mastercard.com) |
| **Version** | 2.0 |
| **Date** | April 11, 2026 |
| **Classification** | Internal Use Only |
| **System** | Toggle Management Multi-Agent AI System |
| **Organisation** | Mastercard Payment Gateway Services (MPGS) |

---

## Overview

This document contains detailed sequence diagrams and flow diagrams for all workflows (A-L) supported by the Toggle Management System. Workflow I is the new Analysis Gap Auto-Backfill workflow (auto-internal + on-request). Workflows J and K cover toggle decomposition planning and implementation (on-request only). For each workflow you will find: a plain-English step-by-step description, a Mermaid sequence diagram showing every agent interaction, the expected output files, and sample prompts to copy-paste.

For a quick-reference summary of each workflow and friendly examples, see `knowledge/user-guide.md`.

---

## How to Read These Diagrams

All sequence diagrams use [Mermaid](https://mermaid.js.org/) notation and render natively in JetBrains IDEs, GitHub, and Confluence.

| Symbol | Meaning |
|---|---|
| `actor User` | The developer or engineer typing commands |
| `participant X as Label` | A named agent in the system |
| `X->>Y: message` | X sends a synchronous message to Y |
| `X-->>Y: message` | Y sends a reply back to X |
| `loop ... end` | A repeated block (e.g. for each toggle in a batch) |
| `alt ... else ... end` | A conditional branch |
| `Note over X,Y: text` | An explanatory note spanning agents X and Y |

---

## Workflow A — Analyse Toggles

**Trigger:** `analyze toggles batch <N>` *(or range, list, file, or "all remaining")*

**Agents:** Orchestrator -> SA-1 -> SA-2a -> SA-2b -> [SA-2c -> SA-12] -> SA-5

**Step-by-step:**
0. Orchestrator receives the user command and runs the **Input Resolver**:
   - If batch number given (e.g. `batch 3`): reads execution guide to get the 5 toggles in that batch
   - If range given (e.g. `1 to 20` or `batch 3 to 7`): resolves the full list from the queue, splits into sub-batches of 5
   - If toggle names given in chat: uses those names directly, groups in sub-batches of 5
   - If file path given: reads the CSV/file, extracts toggle names, groups in sub-batches of 5
   - If "all remaining": reads the full PENDING queue from the execution guide
0a. Orchestrator iterates over sub-batches. For each sub-batch of up to 5 toggles, runs steps 1-11 below. SA-5 creates a checkpoint after each sub-batch.
1. Orchestrator reads `knowledge/new-session-execution-guide.md` to identify which 5 toggles belong to batch N.
2. For each toggle, Orchestrator asks SA-1 to look up the constant name, declaring class, and repository.
3. SA-1 returns the registry row for that toggle.
4. Orchestrator asks SA-2a to search Java source in all registered repositories for both the display string and the constant name.
5. SA-2a returns a list of hits: class name, file path, line number, block start/end, and repository.
6. For each non-declaration hit, Orchestrator asks SA-2b to read the surrounding `if/else` block and derive ON/OFF impact.
7. SA-2b reads the complete block via `read_file`, writes a two-part `Business:` + `Field Impact:` description for both states, and appends one row to the per-repo CSV and the combined CSV.
8. If the toggle is S2A-flagged or matches an S2A class pattern, SA-2b calls SA-2c to enrich the row with TSPI JSON field notation.
9. SA-2c loads `data/s2a-keywords-lookup.csv` and returns enriched impact text plus an `s2a_toggle_type` classification to SA-12.
10. SA-12 performs a safe in-place array-index row update in both the per-repo CSV and the combined CSV, then reports SUCCESS or FAILED back to SA-2b.
11. After all 5 toggles are processed, Orchestrator calls SA-5 to update the execution guide and create a batch checkpoint file.

```mermaid
sequenceDiagram
    actor User
    participant Orch as toggle-orchestrator
    participant SA1 as SA-1 Registry Manager
    participant SA2a as SA-2a Search Locator
    participant SA2b as SA-2b Impact Analyzer
    participant SA2c as SA-2c S2A Specialist
    participant SA12 as SA-12 CSV Updater
    participant SA5 as SA-5 Knowledge Keeper

    User->>Orch: analyze toggles batch 3 (OR range OR list OR file OR all remaining)
    Orch->>Orch: Input Resolver -- determine toggle list from source
    Note over Orch: Source options: batch number from queue,\nrange from queue, names from chat,\nCSV file path, or all remaining PENDING
    Orch->>Orch: Split resolved list into sub-batches of 5

    loop For each sub-batch of 5 toggles
        loop For each toggle in sub-batch
            Orch->>SA1: Lookup toggle constant name + declaring class
            SA1-->>Orch: constant_name, usage_type, file_path, repo
            Orch->>SA2a: Search Java source (display string + constant name)
            SA2a-->>Orch: className, filePath, lineNumber, blockStart, blockEnd, repo
            loop For each non-declaration hit
                Orch->>SA2b: Read block + derive ON/OFF impact
                SA2b->>SA2b: Read complete if/else block via read_file
                SA2b->>SA2b: Write Business + Field Impact (2-part format)
                SA2b-->>SA2b: Append row to per-repo CSV + combined CSV
                alt is_s2a=TRUE OR S2A class pattern matched
                    SA2b->>SA2c: Enrich with TSPI field notation
                    SA2c-->>SA2c: Load s2a-keywords-lookup.csv
                    SA2c-->>SA12: enriched_on_impact, enriched_off_impact, s2a_toggle_type
                    SA12-->>SA12: In-place row update in per-repo CSV + combined CSV
                    SA12-->>SA2b: Write status SUCCESS or FAILED
                end
            end
        end
        Orch->>SA5: Update execution guide + create sub-batch checkpoint
        SA5-->>Orch: Checkpoint written
    end
    Orch-->>User: Processing complete -- N total toggles, M rows written
```

**Expected Output:**
- New rows appended to `data/toggle-codebase-usage-analysis.csv` and the matching per-repo file
- `logs/toggle-batch-3-checkpoint.txt` created with toggle names, row counts, and status=COMPLETE
- `knowledge/new-session-execution-guide.md` updated to mark batch 3 as COMPLETE
- `logs/changelog.md` appended with all file write events

**Sample Prompts:**
> `analyze toggles batch 1`
> `analyze toggles batch 3 to 7`
> `analyze toggles 1 to 20`
> `analyze all remaining toggles`
> `analyze toggle "Enable VISA Account Funding Transactions"`
> `analyze toggles from file data/my-toggle-list.csv`
> `resume batch 2 from checkpoint`

---

## Workflow B — Rebuild Registry

**Trigger:** `rebuild registry`

**Agents:** Orchestrator -> SA-1

**Step-by-step:**
1. Orchestrator delegates the full registry rebuild to SA-1.
2. SA-1 reads `knowledge/config.yml` to resolve the script path and all repository roots.
3. SA-1 runs `tools/active/build-toggle-registry-lookup.ps1` via terminal.
4. The script scans all registered repositories using the configured strategy (full or targeted per repo).
5. SA-1 validates: exactly 7 columns, no reject names (`"-"`, `"SQL"`, `"TODO"`), row counts match expectations.
6. SA-1 writes the combined registry and one per-repo split file for each registered repository.
7. SA-1 appends a changelog entry.
8. SA-1 reports the final counts back to the Orchestrator.

```mermaid
sequenceDiagram
    actor User
    participant Orch as toggle-orchestrator
    participant SA1 as SA-1 Registry Manager

    User->>Orch: "rebuild registry"
    Orch->>SA1: Delegate registry rebuild
    SA1->>SA1: Read knowledge/config.yml -- resolve script path + all repo roots
    SA1->>SA1: Run build-toggle-registry-lookup.ps1
    SA1->>SA1: Scan all repositories (full or targeted strategy per config)
    SA1->>SA1: Validate 7 columns, no reject names, row counts
    SA1->>SA1: Write combined registry + per-repo split files
    SA1->>SA1: Append changelog entry
    SA1-->>Orch: Registry built -- X unique toggles, Y total rows, Z repos
    Orch-->>User: Registry rebuilt successfully
```

**Expected Output:**
- `data/toggle-registry-lookup.csv` -- combined registry, all repos
- `data/toggle-registry-cpe.csv`, `data/toggle-registry-orchestrator.csv`, and one file per additional registered repo
- `logs/changelog.md` appended

**Sample Prompts:**
> `rebuild registry`
> `rebuild registry and refresh the DirectAPI file list`
> `validate the registry -- check row counts across all 7 repos`
> `dry run registry build to confirm all 7 repo paths resolve`

---

## Workflow C — Fetch Confluence Data for Batch N

**Trigger:** `fetch confluence data for batch <N>`

**Agents:** Orchestrator -> SA-3

**Step-by-step:**
1. Orchestrator identifies the 5 toggles in batch N from the execution guide and delegates to SA-3.
2. For each toggle, SA-3 attempts a **Tier 1** search: exact title match in priority Confluence spaces (`MPGSIOG`, `MPGSIOGWIP`).
3. If not found, SA-3 attempts **Tier 2**: exact title match across all Confluence spaces.
4. If not found, SA-3 attempts **Tier 3**: fuzzy title match in priority spaces.
5. If not found, SA-3 attempts **Tier 4**: full-text search across all spaces.
6. If all tiers exhausted, the toggle is marked `NOT_FOUND` in the results.
7. SA-3 extracts metadata from the found page: `page_link`, `summary`, `is_s2a`, `team_responsible`, `applications_affected`, `status`.
8. SA-3 appends one row to `data/feature-toggle-confluence-page-enquiry-results.csv` and performs a mandatory `read_file` persistence verification.
9. SA-3 appends a changelog entry after completing all toggles in the batch.

```mermaid
sequenceDiagram
    actor User
    participant Orch as toggle-orchestrator
    participant SA3 as SA-3 Confluence Enquiry

    User->>Orch: "fetch confluence data for batch 5"
    Orch->>SA3: Delegate Confluence fetch for batch 5 toggles
    loop For each toggle in batch
        SA3->>SA3: Tier 1 -- exact title in MPGSIOG or MPGSIOGWIP
        alt Found
            SA3->>SA3: Extract page_link, summary, is_s2a, team, apps, status
        else Not found
            SA3->>SA3: Tier 2 -- exact title all spaces
            alt Found
                SA3->>SA3: Extract metadata
            else Not found
                SA3->>SA3: Tier 3 -- fuzzy title in priority spaces
                alt Found
                    SA3->>SA3: Extract metadata
                else Not found
                    SA3->>SA3: Tier 4 -- full-text all spaces
                    SA3->>SA3: Mark NOT_FOUND if all tiers exhausted
                end
            end
        end
        SA3->>SA3: Append row to feature-toggle-confluence-page-enquiry-results.csv
        SA3->>SA3: Mandatory read_file persistence verification
    end
    SA3->>SA3: Append changelog entry
    SA3-->>Orch: Confluence fetch complete -- N toggles processed
    Orch-->>User: Confluence data fetched
```

**Expected Output:**
- New rows appended to `data/feature-toggle-confluence-page-enquiry-results.csv`
- `logs/changelog.md` appended

**Sample Prompts:**
> `fetch confluence data for batch 5`
> `fetch confluence data for batch 9 -- includes is_s2a=TRUE toggles, pay extra attention to those`
> `re-fetch Confluence data for the toggle "Send Authentication fields in RiskSPI and AuthenticationStatusCode field in TSPI"`
> `fetch confluence data for all remaining batches in the queue`

---

## Workflow D — Generate Report

**Trigger:** `generate report`, `generate S2A report for <repo>`, `generate polished report`, `show toggle profile for <name>`

**Agents:**
- Structured reports: Orchestrator -> SA-4
- Polished Markdown report: Orchestrator -> SA-11 (⚡ on-request only) -> optionally SA-2c

**Step-by-step (Structured Reports via SA-4):**
1. Orchestrator identifies the report type from the user command.
2. SA-4 reads the relevant CSV files (`toggle-codebase-usage-analysis.csv` and/or `feature-toggle-confluence-page-enquiry-results.csv`).
3. SA-4 filters, sorts, and formats the data for the requested report type.
4. SA-4 writes the report to `reports/` with a date suffix.
5. SA-4 appends a changelog entry.

**Step-by-step (Polished Markdown Report via SA-11 -- on-request only):**
1. Orchestrator identifies `generate polished report` command and delegates to SA-11.
2. SA-11 reads both `data/feature-toggle-confluence-page-enquiry-results.csv` and `data/toggle-codebase-usage-analysis.csv`.
3. SA-11 builds a `confluenceMap` and `usageMap` keyed by toggle name.
4. For each toggle in alphabetical order, SA-11 merges the metadata with usage rows, renders a rich section with Confluence link, team, status, S2A flag, and ON/OFF impact text.
5. SA-11 writes `reports/toggle-polished-usage-report-(date).md`.
6. If `with S2A context` was requested: SA-11 additionally calls SA-2c for supplementary TSPI field context per S2A toggle; this appears in the report only -- CSVs are never modified.
7. SA-11 appends a changelog entry.

```mermaid
sequenceDiagram
    actor User
    participant Orch as toggle-orchestrator
    participant SA4 as SA-4 Report Generator
    participant SA11 as SA-11 Polished Report Writer
    participant SA2c as SA-2c S2A Specialist

    User->>Orch: generate S2A report for CPE OR generate polished report
    alt Structured report requested
        Orch->>SA4: Delegate report generation
        SA4->>SA4: Read relevant CSV files
        SA4->>SA4: Filter and format data for report type
        SA4->>SA4: Write reports/(report-type)-(date).txt
        SA4->>SA4: Append changelog entry
        SA4-->>Orch: Report written
        Orch-->>User: Report available at reports/
    else Polished Markdown requested (on-request only)
        Orch->>SA11: Delegate polished report generation
        SA11->>SA11: Read feature-toggle-confluence-page-enquiry-results.csv
        SA11->>SA11: Read toggle-codebase-usage-analysis.csv
        SA11->>SA11: Build confluenceMap + usageMap
        loop For each toggle in alphabetical order
            SA11->>SA11: Merge metadata + usage rows
            SA11->>SA11: Render toggle section (metadata table + ON/OFF impact blocks)
            SA11->>SA11: Apply S2A Note where applicable
        end
        SA11->>SA11: Write reports/toggle-polished-usage-report-(date).md
        SA11->>SA11: Append changelog entry
        SA11-->>Orch: Polished report written -- N toggles, M S2A-impacting
        Orch-->>User: Report available at reports/toggle-polished-usage-report-(date).md

        Note over SA11,SA2c: Additional step -- only if "with S2A context" was requested
        SA11->>SA2c: Request supplementary TSPI field context for S2A toggles
        SA2c-->>SA11: on_impact_enriched, off_impact_enriched, s2a_toggle_type
        SA11->>SA11: Render S2A Context subsection (report only -- CSVs not modified)
    end
```

**Report types and output files:**

| Report Type | Trigger | Agent | Output File |
|---|---|---|---|
| Per-toggle detail | `show toggle profile for "..."` | SA-4 | `reports/per-toggle-detail-(date).txt` |
| Per-repo summary | `generate per-repo summary for <repo>` | SA-4 | `reports/per-repo-summary-(date).txt` |
| S2A report | `generate S2A report for CPE` | SA-4 | `reports/s2a-report-(repo)-(date).txt` |
| Missing toggles | `generate missing toggle report` | SA-4 | `reports/missing-toggle-report-(date).txt` |
| Status dashboard | `generate toggle status dashboard` | SA-4 | `reports/toggle-status-dashboard-(date).txt` |
| Polished Markdown | `generate polished report` | SA-11 ⚡ | `reports/toggle-polished-usage-report-(date).md` |

**Sample Prompts:**
> `generate report`
> `generate S2A report for CPE`
> `generate S2A report for Orchestrator`
> `show toggle profile for "Enable Account Funding enhanced functionality for Mastercard and Visa"`
> `generate missing toggle report`
> `generate per-repo summary for BusinessService`
> `generate toggle status dashboard`
> `generate polished report`
> `generate polished report for CPE`
> `generate polished report with S2A context`

---

## Workflow E — Check for Missing Toggles

**Trigger:** `check for missing toggles`, `what's not analyzed yet?`

**Agents:** Orchestrator -> SA-1

**Step-by-step:**
1. Orchestrator delegates the missing toggle check to SA-1.
2. SA-1 loads all three data files: the registry, the analysis CSV, and the Confluence results CSV.
3. SA-1 computes **Set 1**: toggles in the registry that have no rows in the analysis CSV -- these are queued for Workflow A.
4. SA-1 computes **Set 2**: toggles in the analysis CSV with a `NOT_FOUND` classification -- these are candidates for SA-2a re-search.
5. SA-1 computes **Set 3**: toggles in the Confluence results CSV that have no matching row in the registry -- no codebase trace found.
6. SA-1 returns the three-set gap report to the Orchestrator.

```mermaid
sequenceDiagram
    actor User
    participant Orch as toggle-orchestrator
    participant SA1 as SA-1 Registry Manager

    User->>Orch: "check for missing toggles"
    Orch->>SA1: Delegate missing toggle check
    SA1->>SA1: Load toggle-registry-lookup.csv
    SA1->>SA1: Load toggle-codebase-usage-analysis.csv
    SA1->>SA1: Load feature-toggle-confluence-page-enquiry-results.csv
    SA1->>SA1: Set 1 -- in registry, NOT in analysis -- queue for Workflow A
    SA1->>SA1: Set 2 -- in analysis as NOT_FOUND -- queue for SA-2a re-search
    SA1->>SA1: Set 3 -- in Confluence, NOT in registry -- no codebase trace
    SA1-->>Orch: Three-set gap report
    Orch-->>User: Missing toggle report displayed
```

**Expected Output:**
- Three-set gap report printed to session (no file written unless requested)
- Toggle names in each set available for copy-paste into Workflow A or Workflow C prompts

**Sample Prompts:**
> `check for missing toggles`
> `what's not analyzed yet?`
> `show me which toggles in the registry have not been analyzed`

---

## Workflow F — Onboard New Repository

**Trigger:** `onboard repo <path>`, `onboard BatchSettlementService`

**Agents:** Orchestrator -> SA-6 -> SA-5

**Step-by-step:**
1. Orchestrator delegates onboarding of the new repository to SA-6.
2. SA-6 resolves the repository path and counts Java files in `src/main/java`.
3. SA-6 decides the scan strategy: FULL SCAN if fewer than 2,000 Java files, TARGETED SCAN if 2,000 or more.
4. SA-6 runs toggle discovery by grepping for `isToggleOn` and toggle constant patterns across the repository.
5. SA-6 builds a new per-repo registry CSV at `data/toggle-registry-<repo>.csv`.
6. SA-6 adds a new entry to `knowledge/config.yml` under the `repositories:` block.
7. SA-6 updates `.github/agents/docs/01-repositories.md` with the new repo details.
8. SA-6 runs a sample search to validate that at least 3 toggles are found correctly.
9. SA-6 writes an onboarding audit log to `logs/onboarding-(repo)-(date).txt`.
10. SA-6 hands off to SA-5, which archives the log and updates `knowledge/index.md`.
11. SA-5 appends a changelog entry.

```mermaid
sequenceDiagram
    actor User
    participant Orch as toggle-orchestrator
    participant SA6 as SA-6 Codebase Onboarding
    participant SA5 as SA-5 Knowledge Keeper

    User->>Orch: "onboard repo BatchSettlementService"
    Orch->>SA6: Delegate onboarding for BatchSettlementService
    SA6->>SA6: Scan repo -- count Java files in src/main/java
    SA6->>SA6: Decide scan strategy (FULL if <2000 files, TARGETED if >=2000)
    SA6->>SA6: Run toggle discovery (grep isToggleOn + constant patterns)
    SA6->>SA6: Build per-repo registry CSV
    SA6->>SA6: Update knowledge/config.yml with new repo entry
    SA6->>SA6: Update .github/agents/docs/01-repositories.md
    SA6->>SA6: Run sample search to validate 3+ toggles found
    SA6->>SA6: Write logs/onboarding-(repo)-(date).txt
    SA6->>SA5: Archive onboarding report to logs/
    SA5->>SA5: Update knowledge/index.md
    SA5->>SA5: Append changelog entry
    SA5-->>Orch: Onboarding complete
    Orch-->>User: Repository onboarded successfully
```

**Expected Output:**
- New repo entry added to `knowledge/config.yml`
- `data/toggle-registry-batch-settlement-service.csv` (per-repo registry)
- `data/toggle-registry-lookup.csv` (combined registry, updated)
- `logs/onboarding-BatchSettlementService-(date).txt`
- `knowledge/index.md` updated

**Sample Prompts:**
> `onboard repo BatchSettlementService`
> `onboard repo C:\Users\e135408\IdeaProjects\MPGS\SourceCode\tokenservice`
> `onboard repo ThreeDSService -- use targeted scan strategy`
> `check how many Java files are in the new repo before onboarding`

---

## Workflow G — Detect Toggle Changes

**Trigger:** `check for toggle changes`, `refresh after code release`

**Agents:** Orchestrator -> SA-7 -> [SA-1, SA-2a, SA-3]

**Step-by-step:**
1. Orchestrator delegates change detection to SA-7.
2. SA-7 asks SA-1 to rebuild the registry and returns a diff against the current registry.
3. SA-1 returns: list of new toggles added, list of removed toggles, and any possible renames (toggle removed in one class, added in another with a similar name).
4. SA-7 performs a stale row check: verifies that every class/line reference in the analysis CSV still exists in source.
5. SA-7 asks SA-2a to re-run the search for all rows currently marked `NOT_FOUND` to check if they are now implemented.
6. SA-2a returns any toggles that now have implementation hits.
7. SA-7 asks SA-3 to do a sampled Confluence status re-fetch for recently changed toggles.
8. SA-3 returns any status changes detected.
9. SA-7 writes the structured change report with all six change type categories.
10. SA-7 appends a changelog entry.

```mermaid
sequenceDiagram
    actor User
    participant Orch as toggle-orchestrator
    participant SA7 as SA-7 Change Notifier
    participant SA1 as SA-1 Registry Manager
    participant SA2a as SA-2a Search Locator
    participant SA3 as SA-3 Confluence Enquiry

    User->>Orch: "check for toggle changes"
    Orch->>SA7: Delegate change detection
    SA7->>SA1: Rebuild registry -- diff against current
    SA1-->>SA7: New toggles + removed toggles + possible renames
    SA7->>SA7: Stale row check -- verify class/line still valid in source
    SA7->>SA2a: Re-run search for all NOT_FOUND rows
    SA2a-->>SA7: NOT_FOUND now implemented (if any found)
    SA7->>SA3: Sampled Confluence status re-fetch
    SA3-->>SA7: Status changes (if any)
    SA7->>SA7: Write logs/toggle-change-report-(date).txt
    SA7->>SA7: Append changelog entry
    SA7-->>Orch: Change report ready -- N new, M removed, P stale
    Orch-->>User: Toggle change report written
```

**Change types detected:**

| Change Type | Meaning |
|---|---|
| `NEW_TOGGLE` | Toggle constant added since last registry build |
| `REMOVED_TOGGLE` | Toggle constant removed from codebase |
| `POSSIBLE_RENAME` | Toggle removed in one class, similar name added in another |
| `STALE_ANALYSIS_ROW` | Class still exists but line number has changed |
| `NOT_FOUND_NOW_IMPLEMENTED` | Previously NOT_FOUND toggle now has usage hits |
| `CONFLUENCE_STATUS_CHANGED` | Confluence page status changed since last fetch |

**Expected Output:**
- `logs/toggle-change-report-(date).txt`
- `logs/changelog.md` appended

**Sample Prompts:**
> `check for toggle changes`
> `refresh after code release`
> `check staleness before generating a report`
> `re-run SA-2a for all NOT_FOUND rows from the last change report`

---

## Workflow H — Clean Up Files

**Trigger:** `clean up files`, `organize workspace`  *(also auto-triggers every 5th batch)*

**Agents:** Orchestrator -> SA-8 -> SA-5

**Step-by-step:**
1. Orchestrator delegates file organisation to SA-8 (either from explicit user command or after every 5th completed batch).
2. SA-8 **Task 1**: Deduplicates `data/toggle-codebase-usage-analysis.csv` -- takes a backup first, then removes exact duplicate rows.
3. SA-8 **Task 2**: Removes stale `NOT_FOUND` stub rows where the toggle has since been found.
4. SA-8 **Task 3**: Validates UTF-8 BOM (`0xEF 0xBB 0xBF`) on all CSV files in `data/`; re-encodes any that are missing the BOM using `tools/active/fix-csv-encoding.py`.
5. SA-8 **Task 4**: Archives checkpoint files in `logs/` older than 30 days to `logs/archive/`.
6. SA-8 **Task 5**: Archives report files in `reports/` older than 30 days to `reports/archive/`.
7. SA-8 **Task 6**: Deletes leftover temp files from `C:/Temp/` created by toggle tools.
8. SA-8 **Task 7**: Reports any file naming violations of the kebab-case standard (no auto-rename, report only).
9. SA-8 **Task 8**: Verifies expected folder structure exists: `data/archive/`, `logs/archive/`, `reports/archive/`.
10. SA-8 calls SA-5 to refresh `knowledge/index.md` with current file counts.
11. SA-5 appends a changelog entry.

```mermaid
sequenceDiagram
    actor User
    participant Orch as toggle-orchestrator
    participant SA8 as SA-8 File Organizer
    participant SA5 as SA-5 Knowledge Keeper

    User->>Orch: "clean up files"
    Orch->>SA8: Delegate file organization
    SA8->>SA8: Task 1 -- Deduplicate toggle-codebase-usage-analysis.csv (backup first)
    SA8->>SA8: Task 2 -- Remove stale NOT_FOUND stub rows
    SA8->>SA8: Task 3 -- Validate UTF-8 BOM on all CSVs, re-encode if needed
    SA8->>SA8: Task 4 -- Archive checkpoint files older than 30 days to logs/archive/
    SA8->>SA8: Task 5 -- Archive report files older than 30 days to reports/archive/
    SA8->>SA8: Task 6 -- Delete C:/Temp/ toggle tool leftover files
    SA8->>SA8: Task 7 -- Report kebab-case naming violations (no auto-rename)
    SA8->>SA8: Task 8 -- Verify folder structure (data/archive/, logs/archive/, etc.)
    SA8->>SA5: Refresh knowledge/index.md
    SA5->>SA5: Update index.md with current file counts and state
    SA5->>SA5: Append changelog entry
    SA5-->>Orch: Cleanup complete
    Orch-->>User: Workspace organized
```

**Expected Output:**
- Deduplicated `data/toggle-codebase-usage-analysis.csv`
- All CSVs re-encoded with UTF-8 BOM where needed
- Old checkpoint and report files moved to archive folders
- `knowledge/index.md` refreshed
- `logs/changelog.md` appended

**Sample Prompts:**
> `clean up files`
> `organize workspace`
> `archive old checkpoint files`
> `validate CSV encoding on all data files`
> `deduplicate the analysis CSV`
> `check naming standards across data/, logs/, and reports/`

---

## Workflow I — Backfill Missing Analysis Rows *(Auto-Internal + On-Request)*

**Trigger:** `plan toggle decomposition for <repo>`, `plan toggle removal for <toggle_name> in <repo>`

> ⚠️ **On-request only.** SA-9 is never auto-invoked. This workflow produces a **plan only** -- no source files are modified.

**Agents:** Orchestrator -> SA-9

**Step-by-step:**
1. Orchestrator delegates decomposition planning for the target repository to SA-9.
2. SA-9 reads `data/toggle-registry-<repo>.csv` to get all toggle constant names for the repo.
3. SA-9 reads `data/toggle-codebase-usage-analysis.csv` filtered to the target repo.
4. For each toggle, SA-9 greps declaration sites in `src/main/java`.
5. SA-9 greps `isToggleOn` and implementation usage sites.
6. SA-9 greps test class usages in `src/test/java`.
7. SA-9 reads the surrounding blocks for each hit.
8. SA-9 classifies each change site: `DECLARATION`, `IMPLEMENTATION_IF_ON`, `IMPLEMENTATION_IF_OFF`, `TEST_TOGGLE_ON`, `TEST_TOGGLE_OFF`.
9. SA-9 builds a per-toggle change plan section describing exactly which lines to remove, promote inline, or comment out.
10. SA-9 assigns a compile risk level: `LOW`, `MEDIUM`, or `HIGH`.
11. SA-9 writes the complete plan to `logs/toggle-decomp-plan-<repo>-(date).txt`.
12. SA-9 appends a changelog entry.

```mermaid
sequenceDiagram
    actor User
    participant Orch as toggle-orchestrator
    participant SA9 as SA-9 Decomposition Planner

    User->>Orch: "plan toggle decomposition for CPE"
    Orch->>SA9: Delegate decomposition planning for CPE
    SA9->>SA9: Read data/toggle-registry-cpe.csv
    SA9->>SA9: Read data/toggle-codebase-usage-analysis.csv (filter CPE)
    loop For each toggle
        SA9->>SA9: Step 3a -- grep declaration sites in src/main/java
        SA9->>SA9: Step 3b -- grep isToggleOn and implementation usages
        SA9->>SA9: Step 3c -- grep test class usages in src/test/java
        SA9->>SA9: Read surrounding blocks for each hit
        SA9->>SA9: Classify DECLARATION, IMPLEMENTATION_IF_ON, IMPLEMENTATION_IF_OFF, TEST_TOGGLE_ON, TEST_TOGGLE_OFF
        SA9->>SA9: Build per-toggle change plan section
        SA9->>SA9: Assign compile risk LOW, MEDIUM, or HIGH
    end
    SA9->>SA9: Write logs/toggle-decomp-plan-CPE-(date).txt
    SA9->>SA9: Append changelog entry
    SA9-->>Orch: Plan written -- N toggles, P LOW, Q MEDIUM, R HIGH risk
    Orch-->>User: Decomposition plan ready at logs/toggle-decomp-plan-CPE-(date).txt
```

**Expected Output:**
- `logs/toggle-decomp-plan-CPE-(date).txt` with a section per toggle, change instructions, and risk classification
- `logs/changelog.md` appended

**Sample Prompts:**
> `plan toggle decomposition for CPE`
> `plan toggle decomposition for Orchestrator`
> `plan toggle removal for "Bypass CSC checks for Scheme Token Transactions" in CPE`
> `plan decomposition for all repos`
> `plan decomposition for BusinessService -- include risk assessment`

---

## Workflow J — Plan Toggle Decomposition *(On-Request Only)*

**Trigger:** `decompose toggles in <repo> dry run` | `confirm actual run for <repo>`

> ⚠️ **On-request only.** SA-10 is never auto-invoked. **A plan from SA-9 must exist first.** Actual run requires explicit user confirmation.

**Agents:** Orchestrator -> SA-10

**Step-by-step (Dry Run):**
1. Orchestrator delegates dry-run decomposition for the target repository to SA-10.
2. SA-10 performs a pre-flight check: verifies the plan file exists and confirms DRY RUN mode is active.
3. SA-10 reads the plan file produced by SA-9.
4. For each toggle in the plan, SA-10 processes declaration entries by commenting them out with a `[TOGGLE-DECOMP]` marker.
5. SA-10 processes `if`-wrapper blocks by removing the wrapper and promoting the toggle-ON body inline.
6. SA-10 processes `else` blocks by commenting out each line with a `[TOGGLE-OFF]` marker.
7. SA-10 processes toggle-OFF test methods by commenting out the body with a `[TOGGLE-OFF-TEST]` marker.
8. After every file edit, SA-10 calls `get_errors` to verify no compile errors are introduced.
9. If a compile error is detected, SA-10 automatically reverts the file and flags it as `NEEDS_MANUAL_REVIEW`.
10. SA-10 writes a changes log to `logs/toggle-decomp-changes-<repo>-(date).txt`.
11. SA-10 appends a changelog entry.

**Step-by-step (Actual Run):**
- All steps are the same as Dry Run, except that after confirmation all `[TOGGLE-DECOMP]`, `[TOGGLE-OFF]`, and `[TOGGLE-OFF-TEST]` commented-out artefacts are permanently removed from the source files.

```mermaid
sequenceDiagram
    actor User
    participant Orch as toggle-orchestrator
    participant SA10 as SA-10 Decomposition Implementer

    User->>Orch: "decompose toggles in CPE dry run"
    Orch->>SA10: Delegate dry-run decomposition for CPE
    SA10->>SA10: Pre-flight -- verify plan file exists + confirm DRY RUN mode
    SA10->>SA10: Read logs/toggle-decomp-plan-CPE-(date).txt
    loop For each toggle in plan
        SA10->>SA10: Process declaration entries -- comment out with [TOGGLE-DECOMP]
        SA10->>SA10: Process if-wrapper -- remove, promote toggle-ON body inline
        SA10->>SA10: Process else block -- comment out each line with [TOGGLE-OFF]
        SA10->>SA10: Process toggle-OFF tests -- comment out body with [TOGGLE-OFF-TEST]
        SA10->>SA10: get_errors -- verify no compile errors
        alt Compile error detected
            SA10->>SA10: Revert file + flag NEEDS_MANUAL_REVIEW
        end
    end
    SA10->>SA10: Write logs/toggle-decomp-changes-CPE-(date).txt
    SA10->>SA10: Append changelog entry
    SA10-->>Orch: Dry run complete -- N files modified, M need manual review
    Orch-->>User: Dry run complete -- review logs before confirming actual run

    Note over SA10: Actual run only after "confirm actual run for CPE"
    User->>Orch: "confirm actual run for CPE"
    Orch->>SA10: Delegate actual run for CPE
    SA10->>SA10: Pre-flight -- verify dry run log exists + confirm ACTUAL RUN mode
    SA10->>SA10: Read toggle-decomp-changes-CPE-(date).txt
    loop For each modified file
        SA10->>SA10: Remove all [TOGGLE-DECOMP] commented-out artefacts permanently
        SA10->>SA10: get_errors -- verify no compile errors
        alt Compile error detected
            SA10->>SA10: Revert file + flag NEEDS_MANUAL_REVIEW
        end
    end
    SA10->>SA10: Append changelog entry
    SA10-->>Orch: Actual run complete -- N files permanently cleaned
    Orch-->>User: Toggle decomposition complete
```

**Expected Output:**
- Modified Java source files in the target repository (dry run = commented; actual run = removed)
- `logs/toggle-decomp-changes-CPE-(date).txt`
- `logs/changelog.md` appended

**Sample Prompts:**
> `decompose toggles in CPE dry run`
> `decompose toggles in Orchestrator dry run`
> `review the dry run output for CPE -- then I will confirm the actual run`
> `confirm actual run for CPE`
> `decompose toggle "Random Terminal Allocation" in CPE dry run`

---


---

## Workflow L — Session Analyst *(On-Request or Reactive)*

**Trigger:** `debug session issues`, `what went wrong with batch <N>?`, `review batch quality`, `analyse session`, `suggest improvements`

> ℹ️ **SA-13 is never auto-invoked during normal batch processing.** The Orchestrator calls it reactively when a batch reports anomalies (FAILED rows, unexpected NOT_FOUND count, SA-12 errors), or you can call it proactively at any time.

**Agents:** Orchestrator -> SA-13

**Step-by-step:**
1. Orchestrator delegates to SA-13, passing the scope (session, specific batch, or specific toggle).
2. SA-13 reads `logs/changelog.md` to build a timeline of all file writes in the session.
3. SA-13 reads the relevant `logs/toggle-batch-N-checkpoint.txt` files for the scope.
4. SA-13 reads the relevant rows from `data/toggle-codebase-usage-analysis.csv` for the scope.
5. SA-13 checks for **structural issues**: wrong agent doing leaf work, SA-2b bypassing SA-12 for S2A rows, SA-5 not creating a checkpoint.
6. SA-13 checks for **output quality issues**: vague Business text (no field names), S2A toggle with no TSPI notation, ISO DE notation in an S2A row, Field Impact saying "Internal only" for a known S2A class.
7. SA-13 checks for **data integrity issues**: duplicate rows, NOT_FOUND rows that now have registry entries, stale line numbers.
8. SA-13 produces a structured issue report with severity (ERROR / WARN / INFO) and an action point for each issue.
9. SA-13 returns the report to the Orchestrator, which either displays it to the user or acts on the action points directly.

```mermaid
sequenceDiagram
    actor User
    participant Orch as toggle-orchestrator
    participant SA13 as SA-13 Session Analyst

    alt User explicitly requests analysis
        User->>Orch: debug session issues or what went wrong with batch 3?
    else Orchestrator detects anomaly
        Orch->>Orch: Detects FAILED rows, high NOT_FOUND count, or SA-12 errors
        Orch->>Orch: Decide to call SA-13 reactively
    end

    Orch->>SA13: Delegate session analysis (scope: session or batch N)
    SA13->>SA13: Read logs/changelog.md -- build session timeline
    SA13->>SA13: Read batch checkpoint files for scope
    SA13->>SA13: Read analysis CSV rows for scope
    SA13->>SA13: Check structural issues (wrong agent, bypass patterns, missing checkpoints)
    SA13->>SA13: Check output quality (vague impacts, wrong S2A/S2I notation, missing Field Impact)
    SA13->>SA13: Check data integrity (duplicates, stale rows, NOT_FOUND with new registry hits)
    SA13-->>Orch: Structured issue report with ERROR/WARN/INFO severities + action points

    alt Issues found
        Orch-->>User: Session issues report -- N errors, M warnings, P info
        Orch->>Orch: Apply action points that are safe to auto-resolve
        Note over Orch: Manual action points displayed to user for confirmation
    else No issues
        Orch-->>User: Session health check passed -- no issues found
    end
```

**Issue categories SA-13 checks:**

| Category | Examples |
|---|---|
| Structural | Orchestrator doing SA-2b's job directly, SA-2b bypassing SA-12 for S2A rows |
| Output quality | Field Impact = "Internal only" for S2A class, ISO DE notation in S2A row, Business sentence missing noun phrase |
| Data integrity | Duplicate rows in analysis CSV, NOT_FOUND row where registry now has a hit, line number drifted |
| Session state | Missing checkpoint for completed batch, execution guide not updated, changelog entries missing |

**Expected Output:**
- Structured issue report displayed in session
- Action points for each issue (some auto-applied, manual ones confirmed by user)
- Optional: `logs/session-analysis-(date).txt` written if user requests a persistent copy

**Sample Prompts:**
> `debug session issues`
> `what went wrong with batch 3?`
> `review batch quality for batches 4 and 5`
> `analyse session`
> `suggest improvements for completed batches`
> `check if SA-12 was called for all S2A rows in batch 6`

---

## System-Level Flow Diagrams

### Diagram 1 — Full System Data Flow

```mermaid
flowchart LR
    subgraph INPUT["📥 Inputs"]
        TOGGLECSV["data/feature-toggle-\nconfluence-page-enquiry.csv\n(input toggle list)"]
        JAVASRC["Java Source Repositories\nCPE, Orchestrator, BusinessService\nConsole, MSOUI, DirectAPI\nBatchSettlementService"]
        CONF["Confluence\n(MPGSIOG / MPGSIOGWIP spaces)"]
    end

    subgraph AGENTS["🤖 Agent Processing Layer"]
        SA1["SA-1\nRegistry Manager"]
        SA2a["SA-2a\nSearch Locator"]
        SA2b["SA-2b\nImpact Analyzer"]
        SA2c["SA-2c\nS2A Specialist"]
        SA12["SA-12\nCSV Updater"]
        SA3["SA-3\nConfluence Enquiry"]
        SA4["SA-4\nReport Generator"]
        SA11["SA-11\nPolished Report Writer"]
    end

    subgraph DATASTORE["📄 Data Store"]
        REG["data/toggle-registry-lookup.csv\n+ 7 per-repo split files"]
        ANA["data/toggle-codebase-usage-analysis.csv\n+ 7 per-repo split files"]
        CFRES["data/feature-toggle-confluence-\npage-enquiry-results.csv"]
    end

    subgraph OUTPUT["📤 Reports"]
        TXT["reports/*.txt\n(S2A, per-repo, missing, dashboard)"]
        MD["reports/toggle-polished-usage-report-(date).md"]
        LOG["logs/changelog.md\nlogs/toggle-batch-(N)-checkpoint.txt"]
    end

    TOGGLECSV --> SA3
    JAVASRC --> SA1
    JAVASRC --> SA2a
    CONF --> SA3

    SA1 --> REG
    SA2a --> SA2b
    SA2b --> ANA
    SA2b --> SA2c
    SA2c --> SA12
    SA12 --> ANA
    SA3 --> CFRES

    REG --> SA2a
    ANA --> SA4
    CFRES --> SA4
    ANA --> SA11
    CFRES --> SA11

    SA4 --> TXT
    SA11 --> MD
    ANA --> LOG
    REG --> LOG
```

---

### Diagram 2 — Toggle Analysis Lifecycle

> **How to read this diagram:** The inner loop (nodes B through N) repeats for **each of the 5 toggles** in a batch. Once all 5 toggles are fully processed, the batch is handed to SA-5 (node Q onwards). SA-5 does **not** run per toggle or per row — it runs **once at the end of the batch**.

```mermaid
flowchart TD
    subgraph BATCH["Batch of 5 Toggles -- repeat nodes B to N for each toggle"]

        A([Start: 5 toggle names\nfrom execution guide]) --> B

        B[SA-1: Registry Lookup\nget constant_name + declaring class\n+ repository for this toggle]
        B --> C{Found in\nregistry?}
        C -->|Yes| D[SA-2a: Search Java source\ndisplay string + constant name\nin src/main/java only]
        C -->|No| D2[SA-2a: Search Java source\ndisplay string only\nacross all repos]
        D --> E{Any\nhits?}
        D2 --> E

        E -->|No hits| F[Run 20-step NOT_FOUND\nvalidation checklist]
        F --> G{All checks\npassed?}
        G -->|Hit found on retry| D
        G -->|Confirmed not found| H[SA-2b: Write NOT_FOUND row\nto per-repo CSV + combined CSV]

        E -->|Hits found| I[SA-2b: Read complete\nif/else block via read_file]
        I --> J{Is this hit\na declaration\nor implementation?}
        J -->|Pure declaration\nno isToggleOn call| K[Skip -- DECLARATION_ONLY\nno row written for this file]
        J -->|Implementation hit\nisToggleOn present| L[SA-2b: Write 2-part impact\nBusiness + Field Impact\nfor both ON and OFF states]

        L --> M{Is toggle\nS2A-flagged OR\nS2A class matched?}
        M -->|No -- standard toggle| N[SA-2b: Append final row\nto per-repo CSV\n+ combined analysis CSV]
        M -->|Yes -- S2A toggle| O[SA-2c: Enrich row\nwith TSPI JSON field notation\nor ISO DE notation]
        O --> P[SA-12: In-place row update\nreplaces the row SA-2b wrote\nwith the S2A-enriched version\nin per-repo CSV + combined CSV]
        P --> N

        H --> NEXT([Toggle done -- move to\nnext toggle in batch])
        K --> NEXT
        N --> NEXT
    end

    NEXT --> DONE{All 5 toggles\nin batch done?}
    DONE -->|No -- more toggles remain| B
    DONE -->|Yes -- batch complete| Q

    Q[SA-5: Create batch checkpoint file\nlogs/toggle-batch-N-checkpoint.txt\nRecords: toggle names processed,\nrow counts written, status=COMPLETE]
    Q --> R[SA-5: Update execution guide\nknowledge/new-session-execution-guide.md\nMarks batch N as COMPLETE\nand advances the queue pointer\nto batch N+1]
    R --> S[SA-5: Append to changelog\nlogs/changelog.md\nRecords all file writes\nthat happened during this batch]
    S --> END([Batch N complete\nSession can safely end\nor continue to batch N+1])
```

> **What does SA-5 updating the execution guide mean?**
> The `knowledge/new-session-execution-guide.md` file is the system's memory between sessions. It holds the batch queue (which batches are PENDING, IN_PROGRESS, or COMPLETE). When SA-5 marks batch N as COMPLETE it means: the next time a new AI session starts and someone types `analyze toggles batch N+1`, the orchestrator already knows exactly which 5 toggles are next and which ones were already done. Without this update, the system would lose track of progress between sessions.

---

### Diagram 3 — Session Management Flow

```mermaid
flowchart TD
    A([New AI Session Starts]) --> B[Orchestrator reads\nknowledge/config.yml]
    B --> C[Orchestrator reads\nnew-session-execution-guide.md]
    C --> D[Orchestrator reads\n07-lessons-learned.md]
    D --> E[Orchestrator reads\nagent-registry.yml + workflow-commands]

    E --> F{User command?}
    F -->|"analyze toggles..."| G[Input Resolver\nDetermine toggle list from source\nbatch number, range, names, file, or all remaining]
    G --> H[Split into sub-batches of 5\nProcess each sub-batch\nSA-1 to SA-2a to SA-2b]
    H --> I[SA-5: Write checkpoint\nlogs/toggle-batch-N-checkpoint.txt]
    I --> J{Anomalies\ndetected?}
    J -->|Yes -- FAILED rows or errors| JFIX[SA-13: Reactive session analysis\nIdentify root cause + action points]
    JFIX --> K
    J -->|No -- clean batch| K{5th batch\ncompleted?}
    K -->|Yes| L[Auto-trigger\nWorkflow H -- SA-8 cleanup]
    K -->|No| M([Session ends or\nnext batch begins])
    L --> M

    F -->|"resume"| N[Read checkpoint file\nfor last completed batch]
    N --> O[Identify remaining toggles\nin current batch]
    O --> H

    F -->|"debug session issues"\nor "analyse session"| JFIX2[SA-13: Proactive session analysis\nFull scope review]
    JFIX2 --> M

    F -->|Other command| P[Route to appropriate\nworkflow A-L]
    P --> M
```

---

### Diagram 4 — Repository Onboarding Flow

```mermaid
flowchart TD
    A(["User: onboard repo TokenService"]) --> B[SA-6: Resolve repo path\nfrom user command]
    B --> C[Count Java files in\nsrc/main/java]
    C --> D{File count?}
    D -->|"< 2000 files"| E[Strategy: FULL SCAN\nAll .java files]
    D -->|">= 2000 files"| F[Strategy: TARGETED SCAN\nPre-identify toggle-bearing files\nvia initial full scan]
    E --> G[Run toggle discovery\ngrep for isToggleOn + constant patterns]
    F --> G
    G --> H[Build per-repo registry CSV\ndata/toggle-registry-token-service.csv]
    H --> I[Add new repo entry to\nknowledge/config.yml]
    I --> J[Update .github/agents/docs/\n01-repositories.md]
    J --> K[Run sample search\nto validate 3+ toggles found]
    K --> L{Validation\npassed?}
    L -->|No| M[Investigate -- re-scan\nwith debug output]
    M --> K
    L -->|Yes| N[Write onboarding log\nlogs/onboarding-TokenService-YYYY-MM-DD.txt]
    N --> O[SA-5: Archive log\nUpdate knowledge/index.md]
    O --> P([Repo onboarded -- ready\nfor Workflow A analysis])
```

---

### Diagram 5 — Agent Decision Matrix

```mermaid
flowchart TD
    U([User Request]) --> Q1{What type\nof request?}

    Q1 -->|Analyse toggles| Q2{Input source?}
    Q2 -->|Batch number or range| WFA["Workflow A\nInput Resolver then SA-1 to SA-2a to SA-2b to SA-2c to SA-12 to SA-5"]
    Q2 -->|Names in chat or file| WFA
    Q2 -->|All remaining| WFA
    Q2 -->|Missing toggles check| WFE["Workflow E\nSA-1"]

    Q1 -->|Registry work| WFB["Workflow B\nSA-1"]

    Q1 -->|Confluence data| WFC["Workflow C\nSA-3"]

    Q1 -->|Generate report| Q4{Report type?}
    Q4 -->|Structured report| WFD["Workflow D\nSA-4"]
    Q4 -->|Polished Markdown| WFDp["Workflow D -- polished mode (on-request)\nSA-11 and optionally SA-2c"]

    Q1 -->|New repository| WFF["Workflow F\nSA-6 to SA-5"]

    Q1 -->|Post-release changes| WFG["Workflow G\nSA-7 to SA-1, SA-2a, SA-3"]

    Q1 -->|File cleanup| WFH["Workflow H\nSA-8 to SA-5"]

    Q1 -->|Toggle decomposition| Q5{Mode?}
    Q5 -->|Plan only| WFJ["Workflow J (on-request)\nSA-9"]
    Q5 -->|Implement| Q6{Confirmation?}
    Q6 -->|Dry run| WFK["Workflow K dry run (on-request)\nSA-10"]
    Q6 -->|Actual run confirmed| WFK2["Workflow K actual run (on-request)\nSA-10"]

    Q1 -->|Debug or quality review| WFL["Workflow L (on-request or reactive)\nSA-13"]
```

---

*End of Toggle Management System — User Flows Guide*
*Version 2.0 · April 11, 2026 · Classification: Internal Use Only*
*© 2026 Mastercard. All rights reserved.*

