<!--
  Copyright (c) 2026 Mastercard. All rights reserved.
-->

# Toggle Management System — User Guide

| Field | Value |
|---|---|
| **Author** | Ravi Teja Thota (raviteja.thota@mastercard.com) |
| **Version** | 2.0 |
| **Date** | April 11, 2026 |
| **Classification** | Internal Use Only |
| **System** | Toggle Management Multi-Agent AI System |
| **Organisation** | Mastercard Payment Gateway Services (MPGS) |

> 📋 For detailed sequence diagrams and step-by-step agent interaction flows, see `knowledge/user-flows-guide.md`

---

## Quick Start in 5 Steps

1. **Start a session** — Open the AI agent in your IDE and type your command. The orchestrator loads all context automatically.
2. **Analyse a batch** — Type `analyze toggles batch 1` to process the first 5 toggles in the queue.
3. **Fetch Confluence data** — Type `fetch confluence data for batch 1` to pull documentation metadata.
4. **Generate a report** — Type `generate report` or `generate S2A report for CPE` to get a structured output.
5. **Resume any time** — Type `resume batch 3` after an interruption and the system picks up exactly where it left off.

---

## What Is This System?

The Toggle Management System automates the full lifecycle of feature toggles across the MPGS Java codebase. It finds where each toggle is used, works out what happens when it is switched on or off, enriches S2A-impacting toggles with TSPI field notation, and produces structured reports for engineers, product owners, and compliance audits.

A feature toggle in a payment gateway is high-risk. A single toggle can control ISO DE field population, TSPI MegaMessage content, or acquirer routing across millions of transactions. This system gives teams a single, automated source of truth for every toggle's codebase footprint and documentation status — eliminating the manual effort and risk of tracking this by hand.

The system is built around a **central orchestrator** that delegates all work to specialised sub-agents. You only ever need to type a plain-English command. The agents read configuration from `knowledge/config.yml`, record their work in `logs/changelog.md`, and maintain session state in `knowledge/new-session-execution-guide.md`.

### Agent Map

```mermaid
flowchart TD
    User([👤 User / Developer]) --> Orch["🎯 toggle-orchestrator\n(Main Entry Point)"]

    Orch --> SA1["SA-1\ntoggle-registry-manager\nRegistry & Lookup"]
    Orch --> SA2a["SA-2a\ntoggle-search-locator\nFind Toggle Usage in Java Source"]
    Orch --> SA3["SA-3\ntoggle-confluence-enquiry\nConfluence Metadata Fetch"]
    Orch --> SA4["SA-4\ntoggle-report-generator\nReport Generation"]
    Orch --> SA5["SA-5\ntoggle-knowledge-keeper\nSession State & Docs"]
    Orch --> SA6["SA-6\ntoggle-codebase-onboarding\nNew Repo Onboarding"]
    Orch --> SA7["SA-7\ntoggle-change-notifier\nPost-Release Change Detection"]
    Orch --> SA8["SA-8\ntoggle-file-organizer\nWorkspace Hygiene"]

    SA2a --> SA2b["SA-2b\ntoggle-impact-analyzer\nON/OFF Business Impact Analysis"]
    SA2b --> SA2c["SA-2c\ntoggle-s2a-specialist\nS2A TSPI Field Enrichment"]
    SA2c --> SA12["SA-12\ntoggle-s2a-csv-updater\nS2A CSV In-Place Row Update"]

    Orch -.->|"⚡ ON-REQUEST ONLY"| SA9["SA-9\ntoggle-decomposition-planner\nDecomposition Plan (read-only)"]
    Orch -.->|"⚡ ON-REQUEST ONLY"| SA10["SA-10\ntoggle-decomposition-implementer\nSource Code Refactoring"]
    Orch -.->|"⚡ ON-REQUEST ONLY"| SA11["SA-11\ntoggle-polished-report-writer\nPolished Markdown Report"]
    Orch -.->|"⚡ ON-REQUEST OR REACTIVE"| SA13["SA-13\ntoggle-session-analyst\nDebug, Review Output Quality"]

    SA9 -.->|"plan required first"| SA10

    SA1 --> REGCSV[("📄 toggle-registry-lookup.csv\n+ per-repo split files")]
    SA2b --> ANACSV[("📄 toggle-codebase-usage-analysis.csv\n+ per-repo split files")]
    SA3 --> CONFCSV[("📄 feature-toggle-confluence-page-enquiry-results.csv")]
    SA5 --> GUIDE[("📄 knowledge/new-session-execution-guide.md\n+ logs/changelog.md\n+ batch checkpoints")]
    SA4 --> REPORTS[("📁 reports/\nS2A, per-repo, missing toggle, dashboard")]
    SA11 --> POLISHED[("📄 reports/toggle-polished-usage-report-YYYY-MM-DD.md")]
    SA9 --> PLAN[("📄 logs/toggle-decomp-plan-repo-YYYY-MM-DD.txt")]

    style SA9 fill:#f9f,stroke:#c66,stroke-dasharray:5
    style SA10 fill:#f9f,stroke:#c66,stroke-dasharray:5
    style SA11 fill:#f9f,stroke:#c66,stroke-dasharray:5
    style SA13 fill:#f9f,stroke:#c66,stroke-dasharray:5
```

---

## The 11 Workflows — Quick Reference

| # | Workflow | What you type | What you get |
|---|---|---|---|
| A | Analyse Toggles | `analyze toggles batch 3` | CSV rows with ON/OFF business + field impact per toggle usage |
| B | Rebuild Registry | `rebuild registry` | Updated 7-column registry CSV mapping all toggles to their Java constants |
| C | Fetch Confluence Data | `fetch confluence data for batch 5` | Confluence page links, team ownership, S2A flags per toggle |
| D | Generate Report | `generate S2A report for CPE` | Structured `.txt` report (SA-4) or Polished Markdown `.md` (SA-11 ⚡ on-request) |
| E | Check Missing Toggles | `check for missing toggles` | Three-set gap report: unanalysed, NOT_FOUND, and Confluence-only |
| F | Onboard New Repository | `onboard repo BatchSettlementService` | New repo added to config, registry built, onboarding log written |
| G | Detect Toggle Changes | `check for toggle changes` | Change report: new, removed, renamed, and stale toggles |
| H | Clean Up Files | `clean up files` | Deduped CSVs, archived old files, UTF-8 BOM validated |
| I | Plan Decomposition | `plan toggle decomposition for CPE` | Read-only decomposition plan with compile risk levels |
| J | Decompose Toggles | `decompose toggles in CPE dry run` | Modified source files (dry run = reversible, actual run = permanent) |
| L | Session Analyst | `debug session issues` | Debug report + improvement action list |

---

## Workflow Examples

### Workflow A — Analyse Toggles

**You type:** `analyze toggles batch 3` *(or a range, list, file, or "all remaining")*

**What happens:** The orchestrator first resolves the input -- this can be a batch number from the queue, a list of toggle names pasted directly in chat, or a CSV file path. Regardless of input source, processing always happens in sub-batches of 5 toggles. For each toggle it looks up the Java constant name in the registry, searches all registered repositories for usages, reads the surrounding `if/else` block, then writes a plain-English description of what happens when the toggle is ON vs OFF. If the toggle affects S2A (TSPI) flows, it additionally enriches the output with TSPI JSON field names.

**Input sources supported:**
- `analyze toggles batch 3` -- uses queue position from execution guide (5 toggles)
- `analyze toggles 1 to 20` -- resolves range from the queue, processes in batches of 5
- `analyze toggles batch 3 to 7` -- multiple consecutive batches in one run
- `analyze all remaining toggles` -- processes the full PENDING queue in batches of 5
- `analyze toggle "Enable VISA AFT"` -- single named toggle from chat
- `analyze toggles from file data/my-toggle-list.csv` -- reads toggle names from a CSV

**Example result:**

```
Toggle Name: Enable VISA Account Funding Transactions
Class: VisaAFTPaymentProcessor
Line: 142
ON Impact:  Business: VISA Account Funding Transactions are enabled and processed.
            Field Impact: TSPI: Transaction.AccountFunding.fundingTransactionType populated.
OFF Impact: Business: VISA Account Funding Transactions are blocked at processor entry.
            Field Impact: Internal only -- no TSPI/ISO/acquirer fields affected.
```

**Sample prompts:**
> `analyze toggles batch 1`
> `analyze toggles batch 3 to 7`
> `analyze toggles 1 to 20`
> `analyze all remaining toggles`
> `analyze toggle "Enable VISA Account Funding Transactions"`
> `analyze toggles from file data/my-toggle-list.csv`
> `resume batch 2 from checkpoint`

---

### Workflow B — Rebuild Registry

**You type:** `rebuild registry`

**What happens:** SA-1 runs the PowerShell registry script across all 7+ registered repositories, scans for toggle constant declarations, validates the schema, and writes fresh CSV files.

**Example result:**

```
Registry rebuilt -- 87 unique toggles, 412 total rows, 7 repos
Files written:
  data/toggle-registry-lookup.csv
  data/toggle-registry-cpe.csv  (and 6 more per-repo files)
```

**Sample prompts:**
> `rebuild registry`
> `rebuild registry and refresh the DirectAPI file list`

---

### Workflow C — Fetch Confluence Data for Batch N

**You type:** `fetch confluence data for batch 5`

**What happens:** SA-3 searches Confluence using a 4-tier strategy (exact title in priority spaces first, then progressively broader searches) for each toggle in the batch. It extracts the page link, a summary, team ownership, affected applications, lifecycle status, and whether the toggle is S2A-impacting.

**Example result:**

```
Toggle: Enable Account Funding enhanced functionality for Mastercard and Visa
  page_link: https://confluence.mastercard.com/display/MPGSIOG/...
  is_s2a: TRUE
  team_responsible: CPE Core Team
  applications_affected: CardPaymentEngine, Orchestrator
  status: Active
```

**Sample prompts:**
> `fetch confluence data for batch 5`
> `fetch confluence data for batch 9`

---

### Workflow D — Generate Report

**You type:** `generate report`, `generate S2A report for CPE`, `generate polished report`

**What happens:** SA-4 generates structured `.txt` reports (5 types). For a human-readable Markdown report joining Confluence + analysis data, the orchestrator delegates to SA-11 instead. Both are triggered from the same Workflow D command -- the orchestrator decides which agent to call based on whether you asked for a "polished" report.

> ⚠️ SA-11 (polished report) is on-request only and never auto-invoked.

| Report type | Trigger example | Agent |
|---|---|---|
| Per-toggle detail | `show toggle profile for "Enable VISA AFT"` | SA-4 |
| Per-repo summary | `generate per-repo summary for BusinessService` | SA-4 |
| S2A report | `generate S2A report for CPE` | SA-4 |
| Missing toggles | `generate missing toggle report` | SA-4 |
| Status dashboard | `generate toggle status dashboard` | SA-4 |
| Polished Markdown | `generate polished report` | SA-11 ⚡ |
| Polished with S2A context | `generate polished report with S2A context` | SA-11 + SA-2c ⚡ |

**Example result:**

```
Report written: reports/s2a-report-cpe-2026-04-11.txt
  23 S2A-impacting toggles in CPE

-- OR --

Report written: reports/toggle-polished-usage-report-2026-04-11.md
  87 toggles rendered, 23 S2A-impacting
```

**Sample prompts:**
> `generate report`
> `generate S2A report for CPE`
> `show toggle profile for "Enable Account Funding enhanced functionality for Mastercard and Visa"`
> `generate missing toggle report`
> `generate polished report`
> `generate polished report with S2A context`
> `generate polished report for CPE`

---

### Workflow E — Check for Missing Toggles

**You type:** `check for missing toggles`

**What happens:** SA-1 compares the registry, analysis CSV, and Confluence results CSV to find gaps — toggles that have not been analysed yet, ones that came back NOT_FOUND, and ones that exist in Confluence but have no codebase trace.

**Example result:**

```
Set 1 -- In registry, NOT in analysis CSV: 14 toggles (queued for Workflow A)
Set 2 -- In analysis CSV as NOT_FOUND: 3 toggles (candidates for re-search)
Set 3 -- In Confluence, NOT in registry: 2 toggles (no codebase trace found)
```

---

### Workflow F — Onboard New Repository

**You type:** `onboard repo BatchSettlementService`

**What happens:** SA-6 counts the Java files in the new repo, picks a scan strategy (full scan if under 2,000 files, targeted scan if over), runs toggle discovery, builds a per-repo registry CSV, adds the repo entry to `knowledge/config.yml`, and writes an onboarding log. SA-5 then updates the index.

**Example result:**

```
Repo onboarded: BatchSettlementService
  Java files found: 347 -- strategy: FULL SCAN
  Toggles discovered: 12
  Files written:
    data/toggle-registry-batch-settlement-service.csv
    logs/onboarding-BatchSettlementService-2026-04-11.txt
  knowledge/config.yml updated
```

---

### Workflow G — Detect Toggle Changes

**You type:** `check for toggle changes`

**What happens:** SA-7 triggers a registry rebuild and diffs the result against the current registry to find new, removed, and renamed toggles. It also checks whether any previously NOT_FOUND toggles are now implemented, and whether any class file line numbers have drifted since the last analysis.

**Example result:**

```
Toggle change report: logs/toggle-change-report-2026-04-11.txt
  NEW_TOGGLE: 2 found
  REMOVED_TOGGLE: 1 found
  STALE_ANALYSIS_ROW: 4 rows (class still exists but line number changed)
  NOT_FOUND_NOW_IMPLEMENTED: 1 toggle
```

---

### Workflow H — Clean Up Files

**You type:** `clean up files`  *(also runs automatically every 5th batch)*

**What happens:** SA-8 deduplicates the analysis CSV, removes stale NOT_FOUND stub rows, validates UTF-8 BOM encoding on all CSVs, archives checkpoint and report files older than 30 days, cleans temp files, and reports any kebab-case naming violations.

**Example result:**

```
Cleanup complete:
  Duplicates removed: 7 rows
  Stale NOT_FOUND rows removed: 2
  CSVs re-encoded with UTF-8 BOM: 3 files
  Files archived to logs/archive/: 11
  Naming violations (no auto-rename): 0
```

---

### Workflow I — Backfill Missing Analysis Rows *(Auto-Internal + On-Request)*

**Auto-triggered internally** by the Orchestrator whenever it detects toggles in the master input CSV with no rows in `toggle-codebase-usage-analysis.csv`. Can also be triggered explicitly.

**You type (explicit):** `backfill missing analysis`

**What happens:** The Orchestrator reads the master toggle list and analysis CSV, computes the gap (MASTER_LIST minus ANALYSED_SET), then runs the full SA-1 → SA-2a → SA-2b → [SA-2c → SA-12] → SA-5 delegation chain in batches of 5 for each missing toggle.

**Auto-trigger conditions (no user command needed):**
1. During Workflow D-P (polished report) coverage check — fills gaps before reporting
2. After Workflow E (missing toggle check) — immediately queues unfilled toggles
3. When a chat enquiry references a toggle with no analysis row — fills it inline

---

### Workflow J — Plan Toggle Decomposition *(On-Request Only)*

**You type:** `plan toggle decomposition for CPE`

> ⚠️ SA-9 is never auto-invoked. This produces a **plan only** — no source files are modified.

**What happens:** SA-9 reads every toggle in the CPE registry and analysis CSV, reads the surrounding code blocks for each hit, classifies each change site (declaration, implementation-if-on, implementation-if-off, test), and assigns a compile risk level.

**Example result:**

```
Decomposition plan: logs/toggle-decomp-plan-CPE-2026-04-11.txt
  18 toggles analysed
  Risk summary: 9 LOW, 6 MEDIUM, 3 HIGH
  HIGH risk toggles listed with reason and recommended manual steps
```

---

### Workflow K — Decompose Toggles *(On-Request Only)*

**You type:** `decompose toggles in CPE dry run`  then  `confirm actual run for CPE`

> ⚠️ SA-10 is never auto-invoked. A plan from SA-9 (Workflow J) must exist first. Actual run requires explicit confirmation.

**What happens (Dry Run):** SA-10 comments out toggle artefacts using `[TOGGLE-DECOMP]`, `[TOGGLE-OFF]`, and `[TOGGLE-OFF-TEST]` markers. No code is permanently deleted. After every file edit the compiler is checked — any error causes an automatic revert.

**What happens (Actual Run):** All commented-out toggle artefacts are permanently removed.

**Example result:**

```
Dry run complete: logs/toggle-decomp-changes-CPE-2026-04-11.txt
  Files modified: 31
  Toggles fully processed: 15
  NEEDS_MANUAL_REVIEW: 3 (compile errors -- reverted automatically)
```

---


**You type:** `debug session issues`, `what went wrong with batch 3?`, `review batch quality`, `analyse session`

> ℹ️ SA-13 is never auto-invoked for normal batches. The Orchestrator calls it reactively when an error occurs, or you can call it proactively at any time.

**What happens:** SA-13 reads the changelog, checkpoint files, analysis CSV rows, and any error outputs from the current session. It identifies root causes of problems (wrong agent doing leaf work, bad CSV rows, S2A/S2I mis-classification, missing Field Impact text, duplicate rows, NOT_FOUND rows that should be re-checked), and returns a structured action list.

**Example result:**

```
Session analysis: 2026-04-11
  Issues found: 3
  [WARN] Batch 4, toggle 3: Field Impact text is "Internal only" but class is JsonMegaMessageRequestBuilder -- likely S2A miss
  [ERROR] Batch 5: SA-2b wrote directly to CSV instead of delegating to SA-12 for S2A row
  [INFO] 2 NOT_FOUND rows in batch 3 have new registry entries since last run -- re-run Workflow A for them
  Action points:
    1. Re-analyse toggle 3 from batch 4 with SA-2c
    2. Correct the SA-2b direct write in batch 5 using SA-12
    3. Run "analyze toggles from file <list of 2 toggle names>"
```

**Sample prompts:**
> `debug session issues`
> `what went wrong with batch 3?`
> `review batch quality for batches 4 and 5`
> `analyse session`
> `suggest improvements for completed batches`

---

## Agent Quick Reference

| Agent | Job in one sentence | Called by |
|---|---|---|
| toggle-orchestrator | Reads your command and delegates all work to the right sub-agent | You (user) |
| SA-1 registry-manager | Owns the toggle registry CSV -- maps toggle names to Java constants and classes | Orchestrator (Workflows A, B, E) |
| SA-2a search-locator | Finds every place a toggle is used in Java source code | Orchestrator (Workflow A) |
| SA-2b impact-analyzer | Reads the if/else block and writes ON/OFF business + field impact descriptions | SA-2a chain (Workflow A) |
| SA-2c s2a-specialist | Enriches S2A toggle rows with TSPI JSON field notation | SA-2b (when S2A class matched) |
| SA-12 s2a-csv-updater | Writes SA-2c's enriched S2A data back into the CSV using safe in-place update | SA-2c |
| SA-3 confluence-enquiry | Searches Confluence for toggle documentation using a 4-tier strategy | Orchestrator (Workflow C) |
| SA-4 report-generator | Generates 6 report types from the analysis and Confluence data | Orchestrator (Workflow D) |
| SA-5 knowledge-keeper | Keeps the session guide, index, changelog, and batch checkpoints current | Orchestrator (end of every batch) |
| SA-6 codebase-onboarding | Adds a new repository to the system | Orchestrator (Workflow F) |
| SA-7 change-notifier | Detects new, removed, and renamed toggles after a code release | Orchestrator (Workflow G) |
| SA-8 file-organizer | Deduplicates CSVs, fixes encoding, archives old files | Orchestrator (Workflow H, auto every 5th batch) |
 SA-9 decomposition-planner  Analyses toggles and produces a read-only decomposition change-plan  Orchestrator (Workflow J -- on-request only) 
 SA-10 decomposition-implementer  Applies decomposition changes to Java source files  Orchestrator (Workflow K -- on-request only) 
| SA-11 polished-report-writer | Generates the final human-readable Markdown usage report | Orchestrator (Workflow D -- on-request only) |
| SA-13 toggle-session-analyst | Debugs session issues, reviews output quality, provides improvement action points | Orchestrator (on-request or reactive on error) |

---

## Data Files

| File | What it contains | Who writes it |
|---|---|---|
| `data/feature-toggle-confluence-page-enquiry.csv` | Input list of all toggle names -- read-only | Nobody (input only) |
| `data/toggle-registry-lookup.csv` | Combined 7-column registry: toggle to constant to class to repo | SA-1 |
| `data/toggle-registry-<repo>.csv` | Per-repo registry split (one per registered repo) | SA-1 |
| `data/toggle-codebase-usage-analysis.csv` | Combined analysis: class, line, ON/OFF impacts for every usage hit | SA-2b (append), SA-12 (update) |
| `data/toggle-codebase-usage-analysis-<repo>.csv` | Per-repo analysis split | SA-2b, SA-12 |
| `data/feature-toggle-confluence-page-enquiry-results.csv` | Confluence page link, team, status, S2A flag per toggle | SA-3 |
| `data/s2a-keywords-lookup.csv` | S2A class keyword index used by SA-2c | SA-2c (reads only) |
| `logs/changelog.md` | Mandatory log -- every agent appends after every file write | All agents |
| `logs/toggle-batch-{N}-checkpoint.txt` | Per-batch progress record enabling session resumption | SA-5 |
| `reports/*.txt` | Standard reports (S2A, per-repo, missing, dashboard) | SA-4 |
| `reports/toggle-polished-usage-report-{date}.md` | Human-readable Markdown report | SA-11 |
| `knowledge/config.yml` | Single source of truth for all paths and repo settings | SA-6 (new repos), manual |
| `knowledge/new-session-execution-guide.md` | Session state: batch queue, progress, toggle assignments | SA-5 |

---

## Troubleshooting

| Problem | Fix |
|---|---|
| Toggle not found by SA-2a | Run `rebuild registry` to refresh the registry, then retry the batch |
| ON/OFF impact uses wrong notation (ISO DE in an S2A row) | Read the source block manually, delete the incorrect CSV row, re-trigger SA-2b for that toggle |
| CSV opens with garbled characters (mojibake) | Run `clean up files` -- SA-8 re-encodes all CSVs with UTF-8 BOM |
| New session re-processes already-analysed toggles | Read `knowledge/new-session-execution-guide.md` and the latest checkpoint file in `logs/` |
| Orchestrator is doing leaf work instead of delegating | Start session with: `Read knowledge/config.yml and new-session-execution-guide.md, then proceed` |
| Registry out of date after a code release | Run `rebuild registry`; for DirectAPI also add `and refresh the DirectAPI file list` |
| S2A toggle only has S2IAcquirerV1/V2 hits | Search for the constant name in `**/messagemapimpl/**/*.java` and `**JsonMegaMessage*.java` -- the S2A hit is in a different class |
| Batch checkpoint file missing | Check `logs/` for the highest-numbered checkpoint; read the last rows of the analysis CSV to determine actual progress |

---

## Glossary

| Term | Plain English meaning |
|---|---|
| Toggle | A named boolean feature flag in Java (`public static final String`) evaluated via `isToggleOn()` to turn a code path on or off at runtime |
| Registry | The 7-column CSV (`toggle-registry-lookup.csv`) mapping every toggle name to its constant identifier, declaring class, file path, and repository |
| S2A | Streamlined to Acquirer -- TSPI JSON transaction flow. Field impacts use `TSPI: Transaction.<field>` notation |
| S2I | Streamlined to Issuer -- ISO 8583 transaction flow. Field impacts use `ISO DE<n> [SE<n>] [SF<n>]` notation |
| TSPI | Transaction Switching Protocol Interface -- the JSON message format used in S2A acquirer flows |
| ISO DE | ISO 8583 Data Element -- a numbered field in the ISO 8583 financial messaging standard |
| Batch | A group of 5 toggles processed together in Workflow A |
| Cardinal Error | A class of severe mistakes documented in `07-lessons-learned.md` that have caused incorrect output historically |
| NOT_FOUND | A toggle classification applied only after completing the 20-step validation checklist -- toggle has no implementation usage in any registered repo |
| Hybrid Class | A Java class that both declares a toggle constant AND calls `isToggleOn()` -- must be treated as IMPLEMENTATION, not DECLARATION_ONLY |
| Two-Part Impact Format | Mandatory output format: `Business: <outcome>. Field Impact: <field names OR "Internal only">` |
| Decomposition | Removing a toggle from the codebase by promoting the ON path inline and deleting the OFF path |
| Dry Run | SA-10 mode 1 -- comments out toggle artefacts with markers; fully reversible |
| Actual Run | SA-10 mode 2 -- permanently removes toggle artefacts; requires explicit confirmation |
| Mojibake | Garbled text caused by opening a UTF-8 CSV without BOM in an editor expecting Windows-1252 |
| Targeted Scan | Registry scan strategy for repos with more than 2,000 Java files -- uses a pre-identified list of toggle-bearing files instead of a full scan |
| Changelog Rule | Every agent must append to `logs/changelog.md` immediately after writing any file |
| BOM | Byte Order Mark (`0xEF 0xBB 0xBF`) -- required at the start of every CSV so IntelliJ and Excel read the encoding correctly |
| Polished Report | The SA-11 human-readable Markdown report joining Confluence metadata with codebase analysis data |

---

> 📋 For detailed sequence diagrams and step-by-step agent interaction flows for all 12 workflows, see `knowledge/user-flows-guide.md`

---

*End of Toggle Management System — User Guide*
*Version 2.0 · April 11, 2026 · Classification: Internal Use Only*
*© 2026 Mastercard. All rights reserved.*
