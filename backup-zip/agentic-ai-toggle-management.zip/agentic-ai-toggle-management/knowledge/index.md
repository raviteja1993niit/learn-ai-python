# Toggle Management System — File Index

> **Updated**: 2026-04-11 — Full reorganization complete.  
> **Maintained by**: toggle-knowledge-keeper (SA-5)  
> **Entry point**: `toggle-orchestrator.agent.md` (reads `knowledge/` first)

---

## ⚡ Critical Session-State Files (read by orchestrator at every session start)
| File | Purpose | Read Order |
|---|---|---|
| `knowledge/config.yml` | All paths, repo roots, tool locations | 1st |
| `knowledge/new-session-execution-guide.md` | Batch queue, current state, per-toggle workflow | 2nd |
| `.github/agents/docs/07-lessons-learned.md` | Cardinal Errors 1–22, 20-step NOT_FOUND checklist | 3rd |
| `knowledge/tool-command-registry.yml` | **Fast-lookup registry** — all scripts, commands, traps, decision matrix | on-demand |

---

## Data Files (`data/`)
| File | Owner Agent | Purpose | Rows |
|---|---|---|---|
| `data/feature-toggle-confluence-page-enquiry.csv` | input (never modified) | List of toggle names to process | - |
| `data/feature-toggle-confluence-page-enquiry-results.csv` | SA-3 (writes) | Confluence page data per toggle | - |
| `data/toggle-registry-lookup.csv` | SA-1 (writes) | Combined toggle registry — all 6 repos | **1069** |
| `data/toggle-registry-cpe.csv` | SA-1 (writes) | CPE-only registry | **663** |
| `data/toggle-registry-orchestrator.csv` | SA-1 (writes) | Orchestrator-only registry | **194** |
| `data/toggle-registry-business-service.csv` | SA-1 (writes) | BusinessService-only registry | **47** |
| `data/toggle-registry-console.csv` | SA-1 (writes) | Console-only registry | **13** |
| `data/toggle-registry-msoui.csv` | SA-1 (writes) | MSOUI-only registry | **107** |
| `data/toggle-registry-direct-api.csv` | SA-1 (writes) | DirectAPI-only registry | **45** |
| `data/toggle-codebase-usage-analysis.csv` | SA-2b (writes) | Main analysis output — ON/OFF impacts | - |
| `data/s2a-keywords-lookup.csv` | SA-2c (reads) | S2A class keyword index (cached per session) | - |
| `data/toggle-dependency-on-card-payment-engine.csv` | reference | CPE toggle dependency map | - |
| `data/toggle-registry-msoui.csv` | SA-1 (writes) | MSOUI-only registry |
| `data/toggle-registry-direct-api.csv` | SA-1 (writes) | DirectAPI-only registry |
| `data/toggle-codebase-usage-analysis.csv` | SA-2b (writes) | Main analysis output — ON/OFF impacts |
| `data/s2a-keywords-lookup.csv` | SA-2c (reads) | S2A class keyword index (cached per session) |
| `data/toggle-dependency-on-card-payment-engine.csv` | reference | CPE toggle dependency map |

---

## Active Tools (`tools/active/`)
| File | Used By | Purpose |
|---|---|---|
| `build-toggle-registry-lookup.ps1` | SA-1 | Build registry from all 6 repos |
| `toggle-search-utility.ps1` | SA-2a | Search toggle patterns across repos |
| `toggle-publish-utility.ps1` | SA-2b | Publish validated analysis to CSV |
| `toggle-analysis-batch-processor.ps1` | orchestrator | Master batch driver (5 toggles/batch) |
| `fix-csv-encoding.py` | SA-8 | Re-encode CSVs with UTF-8 BOM |
| `generate-java-tree.ps1` | SA-6 | Build Java file tree for repo onboarding |
| `repo-memory-mapper.ps1` | SA-6 | Map repo class responsibilities |

> 📖 **Full tool reference** (parameters, examples, caveats, decision matrix): `knowledge/tool-command-registry.yml`

---

## Log Files (`logs/`)
| File | Owner Agent | Purpose |
|---|---|---|
| `logs/changelog.md` | SA-5 | Session history |
| `logs/toggle-batch-{N}-checkpoint.txt` | SA-5 | Batch completion checkpoints |
| `logs/toggle-batch-final-checkpoint.txt` | SA-5 | Last known complete checkpoint |
| `logs/toggle-change-report-{date}.txt` | SA-7 | Change detection reports |
| `logs/onboarding-{repo}-{date}.txt` | SA-6 | Repo onboarding reports |

---

## Report Files (`reports/`)
| Pattern | Owner Agent | Purpose |
|---|---|---|
| `reports/per-toggle-detail-{date}.txt` | SA-4 | Full toggle profile |
| `reports/per-repo-summary-{date}.txt` | SA-4 | All toggles per repository |
| `reports/s2a-report-{repo}-{date}.txt` | SA-4 | S2A toggles with ISO DE / TSPI field detail |
| `reports/missing-toggle-report-{date}.txt` | SA-4 | Toggles not yet analyzed |
| `reports/toggle-status-dashboard-{date}.txt` | SA-4 | Status by team/application |

---

## Agent Definitions (`.github/agents/`)
| File | ID | Status |
|---|---|---|
| `toggle-orchestrator.agent.md` | main | active |
| `toggle-registry-manager.agent.md` | SA-1 | active |
| `toggle-search-locator.agent.md` | SA-2a | active |
| `toggle-impact-analyzer.agent.md` | SA-2b | active |
| `toggle-s2a-specialist.agent.md` | SA-2c | active |
| `toggle-confluence-enquiry.agent.md` | SA-3 | active |
| `toggle-report-generator.agent.md` | SA-4 | active |
| `toggle-knowledge-keeper.agent.md` | SA-5 | active |
| `toggle-codebase-onboarding.agent.md` | SA-6 | active |
| `toggle-change-notifier.agent.md` | SA-7 | active |
| `toggle-file-organizer.agent.md` | SA-8 | active |
| `toggle-codebase-usage-analyzer.agent.md` | legacy-1 | **deprecated** |
| `toggle-page-enquiry-assist.agent.md` | legacy-2 | **deprecated** |

---

## Shared Knowledge Docs (`.github/agents/docs/`)
| File | Load When | Contents |
|---|---|---|
| `07-lessons-learned.md` | **initial** (by orchestrator) | Cardinal Errors 1–22, 20-step NOT_FOUND checklist |
| `01-repositories.md` | on-demand (SA-1, SA-6) | Repo paths, scan strategies, Java file counts |
| `02-search-patterns-and-csv.md` | on-demand (SA-2a) | Toggle name variants, CSV format |
| `03-optimization-rules.md` | on-demand (SA-2a) | Rules 1–10 |
| `04-workflow.md` | on-demand (SA-2b) | Phase 0–6 workflow |
| `05-s2a-field-notation.md` | on-demand (SA-2c) | Full ISO DE + TSPI JSON field reference |
| `06-analysis-guidelines.md` | on-demand (SA-2b) | Code path capture requirements |
| `08-mcp-toolkit.md` | on-demand (SA-1) | PS1 tools reference |

---

## Instruction/Skill Files (`.github/instructions/`)
| File | Category | Load When |
|---|---|---|
| `file-naming-standards.instructions.md` | standards | initial |
| `workflow-commands.instructions.md` | workflows | initial |
| `toggle-search-rules.instructions.md` | search-rules | on-demand |
| `toggle-impact-format.instructions.md` | impact-analysis | on-demand |
| `s2a-field-notation.instructions.md` | s2a-analysis | on-demand |
| `registry-build-rules.instructions.md` | registry | on-demand |
| `confluence-search-rules.instructions.md` | confluence | on-demand |

---

## Historical / Session Archive (`sessions/`)
Batch completion reports, session notes, strategy docs — not needed by agents.
