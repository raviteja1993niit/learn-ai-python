﻿# Toggle Codebase Usage Analyzer — New Session Execution Guide

**Date**: April 10, 2026  
**Purpose**: Complete context handoff for continuing batch processing in a new session  
**Status**: Batch 1 (5 toggles, 6 rows) ✅ Complete — Batches 2–15 (68 toggles) 🔄 Pending

---

## 1. What This Project Is

Analyze **73 feature toggles** from the MPGS gateway codebase (CardPaymentEngine + Orchestrator repositories) to produce a CSV report of where each toggle is used in production code, and what the business and field-level impact is when the toggle is ON vs OFF.

### Goal Output
File: `C:\Users\e135408\Downloads\mcp-servers\jobs\TogglePageEnquiry\data\ToggleCodebaseUsageAnalysis.csv`  
Header: `Toggle Name,Implementation Class Name,Line Number Code,Toggle ON Impact,Toggle OFF Impact,Repository`

---

## 2. Current State (as of end of last session)

### ✅ Completed
| Item | Status | Details |
|------|--------|---------|
| `ToggleCodebaseUsageAnalysis.csv` | **96 data rows** | All 73 toggles analyzed; 18 N/A rows reprocessed in Session 3 |
| `ToggleRegistryLookup.csv` | **279 entries** | Expanded to 6 repos — CPE(199) + Orch(45) + BusinessService(3) + Console(2) + MSOUI(16) + DirectAPI(14) |
| `Toggle-SearchUtility.ps1` | Fixed | Dual search, brace-balance blockStart/blockEnd, test file exclusion |
| `Toggle-AnalysisBatchProcessor.ps1` | Fixed | Phase 3A locate-only, Row 61 auto-clean |
| `Toggle-PublishUtility.ps1` | Ready | CSV append mode with validation |
| `build-toggle-registry.ps1` | Fixed | `Get-UsageType` heuristic from live source |
| `BuildToggleRegistryLookup.ps1` | **Updated** | Now scans 6 repos; DirectAPI uses targeted 22-file scan (99.8% faster) |
| Agent file | 1,673 lines | Updated with Session 3 learnings — N/A row reprocessing, bulk CSV update technique |

### ✅ Session 3 Completed (April 10, 2026)
- **18 N/A rows reprocessed** — toggles previously marked FOUND_DECLARATION_ONLY / NOT_FOUND now have real implementation class names, line numbers, and proper ON/OFF business + field impact analysis
- **Encoding fixed** — CSV file saved as UTF-8 with BOM (EF BB BF) — IntelliJ IDEA opens without encoding warnings
- **Root cause documented** — Failure 5: constant-name search was never run across full codebase for S2IAcquirerToggleConstants declarations
- **96 total data rows** in output CSV (up from 79 before Session 3)### 🔄 Pending
- **28 genuine NOT_FOUND toggles** — no implementation found after exhaustive search in both repos; likely in planning stage or future releases

### ⚠️ Known Tool Issue
The PS1 tools (`Toggle-SearchUtility.ps1`, `Toggle-AnalysisBatchProcessor.ps1`) are **syntactically correct** and pass validation, but produce **no terminal output** in the current JetBrains/PowerShell environment. Root cause: PowerShell child-process output capture issue in this terminal session. **Workaround**: The agent must perform searches directly using `grep_search` and `read_file` tools, then use PowerShell `WriteAllText` directly for CSV updates (which works via file I/O, not stdout capture).

---

## 3. File Locations

### Input Files
| File | Path |
|------|------|
| Input toggles CSV | `C:\Users\e135408\Downloads\mcp-servers\jobs\TogglePageEnquiry\data\FeatureToggleConfluencePageEnquiryResults.csv` |
| Toggle registry cache | `C:\Users\e135408\Downloads\mcp-servers\jobs\TogglePageEnquiry\data\ToggleRegistryLookup.csv` |

### Output Files
| File | Path |
|------|------|
| **Analysis output CSV** | `C:\Users\e135408\Downloads\mcp-servers\jobs\TogglePageEnquiry\data\ToggleCodebaseUsageAnalysis.csv` |
| Batch checkpoints | `C:\Users\e135408\Downloads\mcp-servers\jobs\TogglePageEnquiry\logs\` |

### Repository Source Roots (Java)
| Repo | Path | Files | Scan Strategy |
|------|------|-------|---------------|
| CPE (CardPaymentEngine) | `C:\Users\e135408\IdeaProjects\MPGS\SourceCode\cardpaymentengine\src\main\java` | ~2,420 | Full scan |
| Orchestrator | `C:\Users\e135408\IdeaProjects\MPGS\SourceCode\orchestrator\src\main/java` | ~751 | Full scan |
| BusinessService | `C:\Users\e135408\IdeaProjects\MPGS\SourceCode\businessservice\src\main\java` | ~581 | Full scan |
| Console | `C:\Users\e135408\IdeaProjects\MPGS\SourceCode\console\console\src\main\java` | ~749 | Full scan |
| MSOUI | `C:\Users\e135408\IdeaProjects\MPGS\SourceCode\msoui\src\main\java` | ~1,065 | Full scan |
| DirectAPI | `C:\Users\e135408\IdeaProjects\MPGS\SourceCode\directapi\src\main\java` | ~10,367 | **Targeted: 22 known toggle-bearing files** (see §16) |
| **BatchSettlementService 🆕** | `C:\Users\e135408\IdeaProjects\MPGS\SourceCode\batchsettlementservice\src\main\java` | **285** | **Full scan** |

### Tools
| Tool | Path |
|------|------|
| Search utility | `C:\Users\e135408\Downloads\mcp-servers\tools\Toggle-SearchUtility.ps1` |
| Publish utility | `C:\Users\e135408\Downloads\mcp-servers\tools\Toggle-PublishUtility.ps1` |
| Batch processor | `C:\Users\e135408\Downloads\mcp-servers\tools\Toggle-AnalysisBatchProcessor.ps1` |
| Registry builder (legacy) | `C:\Users\e135408\Downloads\mcp-servers\build-toggle-registry.ps1` |
| **Registry builder (current)** | `C:\Users\e135408\Downloads\mcp-servers\tools\BuildToggleRegistryLookup.ps1` — scans 6 repos, DirectAPI optimized |

---

## 4. Toggle Processing Queue — Remaining 68 Toggles

### Batch 2 (Toggles 6–10)
| # | Toggle Name | is_s2a | CSV Row |
|---|-------------|--------|---------|
| 6 | Enable TAF fields support for Passthrough | FALSE | 6 |
| 7 | MEA PVL and Co-branded Card Transaction Processing | FALSE | 7 |
| 8 | Enable issuer country code in transaction response | FALSE | 8 |
| 9 | System Toggle: Use 8_4 Masked PAN for Scheme Token Transaction Response | FALSE | 9 |
| 10 | Support New Merchant Advice Codes with optimal retry advice for Mastercard | FALSE | 10 |

### Batch 3 (Toggles 11–15)
| # | Toggle Name | is_s2a | CSV Row |
|---|-------------|--------|---------|
| 11 | System Toggle:Enable DPG New Mapping | FALSE | 11 |
| 12 | Enable Unusual Transaction Protection | FALSE | 12 |
| 13 | Enable Lookup up to 11 digit bin for Card Identification | FALSE | 13 |
| 14 | Log Acquirer Details for Sanctioned Transactions | FALSE | 14 |
| 15 | Enable New COF Token Value for Target | FALSE | 15 |

### Batch 4 (Toggles 16–20)
| # | Toggle Name | is_s2a | CSV Row |
|---|-------------|--------|---------|
| 16 | System Toggle: Enable Data Instrumentation Logging for WSAPI requests | FALSE | 16 |
| 17 | Unify Order Creation Time In Retrieval | FALSE | 17 |
| 18 | Get Most Recent Transaction as Initial Transaction If Auto-Capture Failed in Settlement Transaction | FALSE | 18 |
| 19 | Enable historical transaction data aggregation for prioritised merchant flow control | FALSE | 19 |
| 20 | System Toggle: Enable Data Instrumentation Logging for WSAPI Transactions | FALSE | 20 |

### Batch 5 (Toggles 21–25)
| # | Toggle Name | is_s2a | CSV Row |
|---|-------------|--------|---------|
| 21 | System Toggle: Enable 8-4 PAN Masking in API Response | FALSE | 21 |
| 22 | System Toggle: Honour DoNotProcessAfterTime for transaction processing | FALSE | 22 |
| 23 | System Toggle: Enable Rate Limit For Test Merchants | FALSE | 23 |
| 24 | Apply per-merchant limits for invalid operation rates in WSAPI | FALSE | 24 |
| 25 | Apply per-merchant maximum request rate limits in WSAPI | FALSE | 25 |

### Batch 6 (Toggles 26–30)
| # | Toggle Name | is_s2a | CSV Row |
|---|-------------|--------|---------|
| 26 | System Toggle: Enable Version Deprecation for Transactions | FALSE | 26 |
| 27 | Route Risk Operations via the R-SPI Service and enable Merchant Risk | FALSE | 27 |
| 28 | RSPI Mapping: Send Fields to Risk Provider - SubMerchant | FALSE | 28 |
| 29 | Populate payer authentication details on pre-risk RSPI | FALSE | 29 |
| 30 | Bypass CSC checks for Scheme Token Transactions | FALSE | 30 |

### Batch 7 (Toggles 31–35)
| # | Toggle Name | is_s2a | CSV Row |
|---|-------------|--------|---------|
| 31 | Retrieve Card Bin Set Id for Subsequent Transactions | FALSE | 31 |
| 32 | Filter out transactions unrelated to current order | FALSE | 32 |
| 33 | Use partitioned tables for CPE transaction storage | FALSE | 33 |
| 34 | System Toggle: CPE - Recovery actions bypass Shared Memory CPE PersistenceTable to go straight to DB | FALSE | 34 |
| 35 | Shared Memory CPE PersistenceTable | FALSE | 35 |

### Batch 8 (Toggles 36–40)
| # | Toggle Name | is_s2a | CSV Row |
|---|-------------|--------|---------|
| 36 | System Toggle: Reversal Daemon delays remote takeovers | FALSE | 36 |
| 37 | System Toggle: Use Enhanced Optimistic Lock With Terminal Batch Counters | FALSE | 37 |
| 38 | Allow Network Data Tag in DE123 for domestic card brand transactions | FALSE | 38 |
| 39 | Random Terminal Allocation | FALSE | 39 |
| 40 | Use Status Code when calculating if PSD2 Exemption has been granted by Visa | FALSE | 40 |

### Batch 9 (Toggles 41–45)
| # | Toggle Name | is_s2a | CSV Row |
|---|-------------|--------|---------|
| 41 | Use Authentication Status when performing Transaction Filtering | FALSE | 41 |
| 42 | Bypass 3DS Transaction Filtering for TAS Passkey transactions | FALSE | 42 |
| 43 | Send Authentication fields in RiskSPI and AuthenticationStatusCode field in TSPI | **TRUE** | 43 |
| 44 | Store PARes and VERes in Postgres only | FALSE | 44 |
| 45 | Scheme Transaction Throttle for WS API - Passive Mode | FALSE | 45 |

### Batch 10 (Toggles 46–50)
| # | Toggle Name | is_s2a | CSV Row |
|---|-------------|--------|---------|
| 46 | Support STRIPE failover using Operations console | FALSE | 46 |
| 47 | Enable replication lag tracking by MCS | FALSE | 47 |
| 48 | System Toggle: Enable DC Replication Locks | FALSE | 48 |
| 49 | Allow payment transaction with authentication return surcharge | FALSE | 49 |
| 50 | Use Enhanced Certificate Sets | FALSE | 50 |

### Batch 11 (Toggles 51–55)
| # | Toggle Name | is_s2a | CSV Row |
|---|-------------|--------|---------|
| 51 | Derive Amount Variability For CIT And MIT Recurring Transactions | FALSE | 51 |
| 52 | Enable CIT MIT indicators for Mastercard | FALSE | 52 |
| 53 | Enable Activity Calls to Protection Service | FALSE | 53 |
| 54 | Enable VISA Account Funding Transactions | FALSE | 54 |
| 55 | Return refund authorization data to merchants | FALSE | 55 |

### Batch 12 (Toggles 56–60)
| # | Toggle Name | is_s2a | CSV Row |
|---|-------------|--------|---------|
| 56 | Enable Single Tap Transactions | FALSE | 56 |
| 57 | Enable known fare transit with transportationMode | FALSE | 57 |
| 58 | Auto reversals on final capture | FALSE | 58 |
| 59 | Set approvedAmount only when the transaction is approved | FALSE | 59 |
| 60 | Mastercard QR Transaction Identifiers | FALSE | 60 |

### Batch 13 (Toggles 61–65)
| # | Toggle Name | is_s2a | CSV Row |
|---|-------------|--------|---------|
| 61 | Enable New COF Token Value for T-SPI | **TRUE** | 61 |
| 62 | Revised Standards to Introduce BPSP Category to Support B2B | FALSE | 62 |
| 63 | Enable Exclusion Rule in Merchant Acquirer Link Resolution | FALSE | 63 |
| 64 | Enable Card Identification Service | FALSE | 64 |
| 65 | Optimize loading of terminal batch counters | FALSE | 65 |

### Batch 14 (Toggles 66–70)
| # | Toggle Name | is_s2a | CSV Row |
|---|-------------|--------|---------|
| 66 | Submit EDQP Phase 3 fields in standalone transactions to WSAPI | FALSE | 66 |
| 67 | Enable MC Account Funding Transactions | FALSE | 67 |
| 68 | Submit EDQP Phase 3 fields to RSC for Standalone Refunds | FALSE | 68 |
| 69 | Enable Account Funding enhanced functionality for Mastercard and Visa | **TRUE** | 69 |
| 70 | Enable Protection Blocking Of Unusual Transactions | FALSE | 70 |

### Batch 15 (Toggles 71–72)
| # | Toggle Name | is_s2a | CSV Row |
|---|-------------|--------|---------|
| 71 | System Toggle: Enable Activity Analyzer in Protection Service | FALSE | 71 |
| 72 | Enable Transaction Filtering BIN Range White listing | FALSE | 72 |

---

## 5. Exact Per-Toggle Workflow (Agent Must Follow)

For **each toggle** in a batch of 5, the agent performs these 4 steps in order:

### Step 1 — Registry Lookup
Look up the toggle name in `ToggleRegistryLookup.csv`.

Extract for the toggle:
- `constant_name` — Java constant identifier (e.g. `TOGGLE_ENABLE_TAF_FIELDS_SUPPORT_FOR_PASSTHROUGH`)
- `registry_class_name` — declaring class (exclude matches from this class)
- `usage_type` — `DECLARATION` (skip as target) or `IMPLEMENTATION` (priority read target)
- `repository` — `CPE` or `Orchestrator`

**If not found**: search by display string only.

### Step 2 — Phase 3A: Locate Usage (grep_search)
Search for the toggle in **both** CPE and Orchestrator source:

```
Search pattern 1: the display string (toggle name as-is)
Search pattern 2: the constant_name (e.g. TOGGLE_XYZ)
includePattern: "src/main/java/**/*.java"   ← ALWAYS use this, never **/*.java
Exclude: /test/, *Test.java, *Tests.java, *Spec.java, *IT.java
Exclude: any file matching registry_class_name if usage_type = DECLARATION
```

Record per hit:
- `filePath`, `className`, `lineNumber`, `matchLine`, `repository`

### Step 3 — Phase 3B: Read Block
For each non-declaration hit, call `read_file` with:
```
filePath = absolute full path
offset   = blockStart (line of enclosing method opening brace, or match line − 10)
limit    = blockEnd − blockStart + 10  (full method body)
```

Read the **complete** if/else block. Do not summarise — read the actual code.

### Step 4 — Phase 4: Write Impact (Two-Part Format — MANDATORY)
For each usage location write **both** ON and OFF impact in this exact format:

```
Toggle ON Impact:
  Business: <what the merchant / cardholder / acquirer CAN do or what is enabled>
  Field Impact: <exact TSPI API field names / ISO DE elements / acquirer fields OR
                 "Internal only — no TSPI/ISO/acquirer fields affected">

Toggle OFF Impact:
  Business: <what the merchant / cardholder / acquirer CANNOT do or what fallback applies>
  Field Impact: <fields not populated / not validated / not sent OR "Internal only — ...">
```

**PROHIBITED** (never use):
- ❌ "Enables S2A feature"
- ❌ "When enabled: executes method at line X..."
- ❌ "Complementary behavior when toggle disabled"
- ❌ Generic descriptions without field names

**CORRECT examples** (from Batch 1):
```
Toggle ON: "Business: The gateway actively monitors the health of each load-balanced merchant
  server by pinging it on a fixed schedule — only healthy servers receive transaction traffic.
  Field Impact: Internal only — no TSPI/ISO/acquirer fields affected."

Toggle ON: "Business: For Visa AFT at API v1.0.0+, gateway auto-populates purposeOfPayment
  (defaults to ISOTHR) if merchant omits it.
  Field Impact: accountFunding.purposeOfPayment (TSPI API field) auto-set to ISOTHR;
  validated against 6-char uppercase alpha format."
```

---

## 6. S2A Field Notation Rules

### When to use ISO DE notation
**Class is**: `S2IAcquirerV1`, `S2IAcquirerV2`, `IsoDataField*Populator`, `S2IAcquirerHelper`

**Format**: `ISO DE<n> [SE<n>] [SF<n>]`

Examples:
- `ISO DE48 SE36 SF05` — purposeOfPayment code
- `ISO DE54` — Foreign Exchange Fee (Visa AFT)
- `ISO DE108 SF01` — Transaction Reference
- `ISO DE123` — Address/tag data

### When to use TSPI JSON notation
**Class is**: `JsonMegaMessageRequestBuilder`, `TspiRequestMessageBuilder`, `JsonMegaMessageMap`

**Format**: `TSPI: <ContextObject>.<FieldName>`

Context objects: `Transaction`, `Acquirer`, `Merchant`, `RoutingHeader`

Examples:
- `TSPI: Transaction.AccountFunding (AccountFundingPaymentPurpose, AccountFundingForeignExchangeFee)`
- `TSPI: Transaction.AccountFunding.Recipient.Address (PaymentRecipientStreet, PaymentRecipientCity)`
- `TSPI: Transaction.CustomerIdentification (CustomerIdentificationType, CustomerIdentificationValue)`
- `TSPI: Acquirer.NetworkTransactionId`

### When to use API field notation
**Class is**: `AccountFundingValidator` (Orchestrator), `TransactionRequestValidator` (CPE)

**Format**: `accountFunding.<field>`, `order.<field>`, `sourceOfFunds.provided.card.<field>`

---

## 7. Output CSV Append Rules

**File**: `C:\Users\e135408\Downloads\mcp-servers\jobs\TogglePageEnquiry\data\ToggleCodebaseUsageAnalysis.csv`

**Header** (already exists — DO NOT add again):
```
Toggle Name,Implementation Class Name,Line Number Code,Toggle ON Impact,Toggle OFF Impact,Repository
```

**One row per usage location per repository.**

If a toggle is used in both CPE and Orchestrator → create **separate rows**, one per repo.

If a toggle is used in multiple classes in same repo → create **separate rows**, one per class.

**CSV escaping**: Wrap all fields in double quotes. Inner double-quotes escaped as `""`.

**Append method**: Use `insert_edit_into_file` to append new rows to the CSV at the end of the file.  
Alternatively use the publish utility (when it works):
```powershell
cd C:\Users\e135408\Downloads\mcp-servers\tools
.\Toggle-PublishUtility.ps1 -AnalysisData $data -AppendOnly
```

---

## 8. Registry Quick-Reference for Key Toggles

| Toggle Name | Constant Name | Class | Repo | Type |
|-------------|---------------|-------|------|------|
| Bypass CSC checks for Scheme Token Transactions | TOGGLE_BYPASS_CSC_CHECKS_FOR_SCHEME_TOKEN_TRANSACTIONS | CscHelper | CPE | IMPLEMENTATION |
| Random Terminal Allocation | TOGGLE_RANDOM_TERMINAL_ALLOCATION | CoreTerminalPool | CPE | IMPLEMENTATION |
| Enable Account Funding enhanced functionality for Mastercard and Visa | TOGGLE_ENABLE_ACCOUNT_FUNDING_ENHANCED_FUNCTIONALITY_FOR_MASTERCARD_AND_VISA | AccountFundingValidator | CPE/Orch | IMPLEMENTATION |
| Enable MC Account Funding Transactions | TOGGLE_FOR_MC_FUNDING_TRANSACTIONS | S2IAcquirerToggleConstants | CPE | DECLARATION |
| Enable New COF Token Value for T-SPI | TOGGLE_ENABLE_NEW_COF_TOKEN_VALUE_FOR_T_SPI | (search by constant) | CPE | DECLARATION |
| Allow Network Data Tag in DE123 | TOGGLE_ALLOW_NETWORK_DATA_TAG_IN_DE123_FOR_DOMESTIC_CARD_BRAND_TRANSACTIONS | S2IAcquirerToggleConstants | CPE | DECLARATION |
| Allow Clearing Tag in DE123 | TOGGLE_ALLOW_CLR_TAG_IN_DE123_FOR_DOMESTIC_CARD_BRANDS | IsoDataField123Populator | CPE | IMPLEMENTATION |
| Send Authentication fields in RiskSPI... | (search by display string + constant) | (S2A toggle — use TSPI JSON notation) | CPE | — |

---

## 9. Critical Rules Checklist

Before writing any row to the output CSV, verify:

- [ ] Toggle name is **cleaned** (no `"61 | "` prefix corruption)
- [ ] Match file is **NOT** the registry declaration class (`usage_type = DECLARATION`)
- [ ] Match file is **NOT** in `/test/` directory and does NOT end with `Test.java`, `Tests.java`, `Spec.java`
- [ ] Phase 3B `read_file` was called with correct offset/limit to get the **complete if/else block**
- [ ] Toggle ON Impact uses **two-part format**: `Business: ... Field Impact: ...`
- [ ] Toggle OFF Impact uses **two-part format**: `Business: ... Field Impact: ...`
- [ ] For S2A toggles: field notation matches the class type (ISO DE vs TSPI JSON vs API field)
- [ ] Dual-repo hits produce **separate rows** per repository
- [ ] Multi-class hits produce **separate rows** per implementation class
- [ ] **NEW CHECK — ToggleHelper Indirection**: If toggle is declared in a constants class AND a `ToggleHelper` wrapper exists (e.g. `ToggleHelper.isToggleOn84PanMasking()`), search for ALL callers of that helper method — the actual implementation class is the caller, NOT the helper itself.
  - Pattern: `ToggleConstants` → `ToggleHelper.isToggleOnXxx()` → `CallerClass.method()` (← THIS is the IMPLEMENTATION row)
  - Search: `grep_search("ToggleHelper.isToggleOnXxx", includePattern="src/main/java/**/*.java")` in both repos
  - Known affected toggle: `"System Toggle: Use 8_4 Masked PAN for Scheme Token Transaction Response"` → `TokenDetailsContainer` (Orchestrator) + `CardPaymentDecoratorPostRetrieveAction` (CPE)

---

## 10. Current Output CSV State

File has **6 data rows** (1 header + 6 data):

| Row | Toggle | Class | Line | Repo |
|-----|--------|-------|------|------|
| 1 | System Toggle: CPE Load Balancer Uses Ping | MerchantLoadBalancer | 82 | CPE |
| 2 | System Toggle: CPE Load Balancer Uses Ping | MerchantLoadBalancer | 195 | CPE |
| 3 | System Toggle: Enable Lookup up to 8 digit bin for Card Identification | BinBaseCardBrandService | 63 | CPE |
| 4 | Apply New Order ID Reuse Rule | OrderIdReuseHelper | 36 | CPE |
| 5 | Apply New Order ID Reuse Rule | OrderIdReuseHelper | 45 | Orchestrator |
| 6 | System Toggle: Disables loading from orderCache in CPE for Transaction Retrieval | TransactionRetrievalDataAccess | 40 | CPE |

**Note**: Toggle 5 ("Enable TAF fields support for Passthrough" — Batch 1, row 5) had 0 implementation hits found, consistent with it being a passthrough validation feature with no toggle evaluation logic found in main source (TAF fields may be validated declaratively or outside the Java toggle pattern).

---

## 11. Batch Processing Command

To begin processing **Batch 2** (toggles 6–10), the agent must:

1. Read this guide  
2. For each of the 5 toggles in Batch 2:
   - Look up in `ToggleRegistryLookup.csv`
   - `grep_search` in `src/main/java/**/*.java` for **both** display string AND constant_name
   - For each non-declaration hit: `read_file` the surrounding method block
   - Write two-part ON/OFF impact descriptions
   - Append row to `ToggleCodebaseUsageAnalysis.csv`
3. After all 5: verify CSV row count increased by expected amount
4. Create batch checkpoint file in `jobs/TogglePageEnquiry/logs/`

### Quick start for new session:
```
"Read NEW_SESSION_EXECUTION_GUIDE.md and continue batch processing of feature toggles 
starting at Batch 2 (toggle 6: Enable TAF fields support for Passthrough). 
Process 5 toggles per batch, append results to ToggleCodebaseUsageAnalysis.csv.
Follow the workflow in Section 5 exactly."
```

---

## 12. Impact Format Templates

### Template A — Internal-only toggle (no external fields)
```
Toggle ON: "Business: <what happens operationally — which service, which path, which behavior>.
  Field Impact: Internal only — no TSPI/ISO/acquirer fields affected."

Toggle OFF: "Business: <fallback behavior — what is skipped or reverted to>.
  Field Impact: Internal only — no TSPI/ISO/acquirer fields affected."
```

### Template B — API field validation toggle
```
Toggle ON: "Business: <field> is validated/accepted/auto-populated for <transaction type>.
  Merchants <can submit / are required to submit / benefit from auto-default> of <field>.
  Field Impact: <fieldName> (TSPI API field) <validated/defaulted/required> when toggle on."

Toggle OFF: "Business: <field> validation skipped / field not returned / fallback value used.
  Field Impact: <fieldName> not validated / not populated / uses legacy default."
```

### Template C — S2I ISO 8583 acquirer field toggle
```
Toggle ON: "Business: Enhanced acquirer message sent to S2I network with <data>.
  Field Impact: ISO DE<n> SE<n> SF<n> — <description>; ISO DE<n> — <description>."

Toggle OFF: "Business: Legacy acquirer message format used; <enhanced fields> not included.
  Field Impact: ISO DE<n> not populated / uses legacy value; ISO DE<n> omitted."
```

### Template D — S2A TSPI JSON field toggle
```
Toggle ON: "Business: MEGA/TSPI JSON message includes <context fields> enabling <capability>.
  Field Impact: TSPI: Transaction.<SubObject> (<Field1>, <Field2>) included in MEGA JSON;
  TSPI: Transaction.<SubObject2> (<Field3>) included."

Toggle OFF: "Business: <Context fields> not sent to MEGA/TSPI acquirer; <capability> not available.
  Field Impact: TSPI: Transaction.<SubObject> (<Fields>) omitted from MEGA JSON message."
```

---

## 13. File Structure Quick Reference

```
C:\Users\e135408\Downloads\mcp-servers\
├── jobs\TogglePageEnquiry\
│   ├── data\
│   │   ├── FeatureToggleConfluencePageEnquiryResults.csv   ← 73 input toggles
│   │   ├── ToggleRegistryLookup.csv                        ← 279 registry entries (6 repos, 6 columns)
│   │   └── ToggleCodebaseUsageAnalysis.csv                 ← OUTPUT (6 rows currently)
│   └── logs\
│       └── CHANGELOG.md
├── tools\
│   ├── Toggle-SearchUtility.ps1             ← Phase 3A search (dual search + blockStart/blockEnd)
│   ├── Toggle-PublishUtility.ps1            ← CSV append writer
│   ├── Toggle-AnalysisBatchProcessor.ps1    ← Phase 3A orchestrator
│   └── BuildToggleRegistryLookup.ps1        ← Registry rebuild (6 repos, DirectAPI optimized)
├── build-toggle-registry.ps1               ← Legacy registry builder (CPE+Orch only)
└── .github\agents\
    ├── toggle-codebase-usage-analyzer.agent.md  ← Agent definition
    └── CHANGELOG_toggle-codebase-usage-analyzer.md

C:\Users\e135408\IdeaProjects\MPGS\SourceCode\
├── cardpaymentengine\src\main\java\   ← CPE Java source (~2,420 files, full scan)
│   ├── com\mastercard\gateway\
│   ├── com\dialect\
│   ├── QSI\PaymentServer\             ← S2I acquirer classes here
│   └── com\qsipayments\
├── orchestrator\src\main\java\        ← Orchestrator Java source (~751 files, full scan)
│   └── com\dialect\orchestrator\
├── businessservice\src\main\java\     ← BusinessService Java source (~581 files, full scan)
├── console\console\src\main\java\     ← Console Java source (~749 files, full scan)
├── msoui\src\main\java\               ← MSOUI Java source (~1,065 files, full scan)
└── directapi\src\main\java\           ← DirectAPI Java source (~10,367 files, TARGETED scan)
    └── [22 toggle-bearing files scanned — see §16]
```
│       └── CHANGELOG.md
├── tools\
│   ├── Toggle-SearchUtility.ps1     ← Phase 3A search (dual search + blockStart/blockEnd)
│   ├── Toggle-PublishUtility.ps1    ← CSV append writer
│   └── Toggle-AnalysisBatchProcessor.ps1  ← Phase 3A orchestrator
├── build-toggle-registry.ps1        ← Registry rebuild tool
└── .github\agents\
    ├── toggle-codebase-usage-analyzer.agent.md  ← 1,425 line agent definition
    └── CHANGELOG_toggle-codebase-usage-analyzer.md

C:\Users\e135408\IdeaProjects\MPGS\SourceCode\
├── cardpaymentengine\src\main\java\   ← CPE Java source (~3,142 files)
│   ├── com\mastercard\gateway\
│   ├── com\dialect\
│   ├── QSI\PaymentServer\             ← S2I acquirer classes here
│   └── com\qsipayments\
└── orchestrator\src\main\java\        ← Orchestrator Java source (~847 files)
    └── com\dialect\orchestrator\
```

---

## 14. Batch Completion Verification

After each batch of 5 toggles, verify:
1. `read_file` the output CSV — confirm row count increased
2. All new rows have non-empty `Toggle ON Impact` and `Toggle OFF Impact`
3. No rows have `Implementation Class Name` matching a **pure** constants class (e.g., `S2IAcquirerToggleConstants`, `ToggleConstants`).
   - ⚠️ **Exception**: A class like `SanctionHelper`, `TransactionDataCommonService`, or `CardTypeDetailsDecorator` may appear — these are **hybrid classes** that contain both the declaration and `isToggleOn()` calls. These ARE valid implementation classes.
   - **Rule**: If `Implementation Class Name` contains only `static final String` constants and NO `isToggleOn` calls → flag as wrong. Otherwise accept.
4. S2A toggles (`is_s2a=TRUE`) have field-level ISO DE or TSPI JSON notation in Field Impact
5. **NEW CHECK**: For any row marked `FOUND_DECLARATION_ONLY`, confirm that `grep_search('isToggleOn|isEnabled', includePattern='src/main/java/**/ClassName.java')` returned zero results — otherwise that row is incorrectly classified and must be reclassified as IMPLEMENTATION

---

## 15. Exact Agent Tool Commands Per Toggle

This section gives the **exact sequence of tool calls** the agent must execute for every single toggle. No guessing — follow these commands in order.

---

### COMMAND 1 — Registry Lookup
```
Tool: read_file
File: C:\Users\e135408\Downloads\mcp-servers\jobs\TogglePageEnquiry\data\ToggleRegistryLookup.csv
```
Filter rows where `toggle_name` = current toggle name.  
Extract: `constant_name`, `registry_class_name`, `registry_file_path`, `usage_type`, `repository`.

---

### COMMAND 2 — Search CPE (display string)
```
Tool: grep_search
query: "<toggle display name as-is, e.g.: Enable TAF fields support for Passthrough>"
includePattern: "src/main/java/**/*.java"
workspace: cardpaymentengine
```

---

### COMMAND 3 — Search CPE (constant name)
```
Tool: grep_search
query: "<CONSTANT_NAME from registry, e.g.: TOGGLE_ENABLE_TAF_FIELDS_SUPPORT_FOR_PASSTHROUGH>"
includePattern: "src/main/java/**/*.java"
workspace: cardpaymentengine
```
**Skip this command if registry has no constant_name for this toggle.**

---

### COMMAND 4 — Search Orchestrator (display string)
```
Tool: grep_search
query: "<toggle display name as-is>"
includePattern: "src/main/java/**/*.java"
workspace: orchestrator
```

---

### COMMAND 5 — Search Orchestrator (constant name)
```
Tool: grep_search
query: "<CONSTANT_NAME from registry>"
includePattern: "src/main/java/**/*.java"
workspace: orchestrator
```
**Skip this command if registry has no constant_name for this toggle.**

---

### COMMAND 6 — Filter results and check same-file implementations

From all grep_search hits:

**STEP A — Remove genuine test / non-source hits:**
- Remove any hit in a file path containing `/test/`
- Remove any hit in a file whose name ends with `Test.java`, `Tests.java`, `Spec.java`, `IT.java`, `ITest.java`

**STEP B — Handle declaration-line hits with same-file check (⚠️ BUG FIX):**

> ⚠️ **KNOWN BUG IN PREVIOUS SESSIONS**: Hits on declaration lines (`public/private static final String = "..."`) were being blindly discarded. This caused false FOUND_DECLARATION_ONLY misclassifications for **hybrid classes** that contain both the constant declaration AND actual `isToggleOn()` calls.
>
> **Affected examples**: `CardTypeDetailsDecorator` (decl line 70, usage line 124), `SanctionHelper` (decl line 327, usage lines 1568/1708/1729/1755), `TransactionDataCommonService` (decl line 157, usage lines 550/1540).

For every hit on a declaration line, do the following **before** discarding it:

```
Tool: grep_search
query: "isToggleOn|isEnabled"
includePattern: "<exact relative path of the file containing the declaration>"
```

- **If `isToggleOn` / `isEnabled` hits exist in the same file** → the file is a **hybrid class**
  - Keep the file as an analysis target
  - Use the isToggleOn line numbers (not the declaration line) as the actual usage locations
  - Go to COMMAND 7 to read those blocks
  - Output row with `Implementation Class Name` = this class name
- **If zero `isToggleOn` / `isEnabled` hits in the same file** → confirmed **pure constants class**
  - Now safely discard this hit (declaration-only, no implementation here)
  - Mark as `FOUND_DECLARATION_ONLY` with the class and line number

**STEP C — Remove matches from pure constants registry classes:**
- Only discard a registry class file AFTER the same-file check above confirms zero `isToggleOn` calls
- A file in `registry_class_name` with zero `isToggleOn` calls = pure declaration → skip
- A file in `registry_class_name` with >0 `isToggleOn` calls = hybrid class → keep and analyze

---

### COMMAND 6B — Same-file implementation check (MANDATORY for every declaration hit)

For **each** file that had a declaration-line hit (to resolve hybrid vs pure-constants class):
```
Tool: grep_search
query: "isToggleOn|isEnabled"
includePattern: "src/main/java/**/ClassName.java"
workspace: <CPE or Orchestrator>
```
- If results found → hybrid class → note all isToggleOn line numbers → proceed to COMMAND 7 for those lines
- If no results → pure constants class → mark `FOUND_DECLARATION_ONLY` → skip COMMAND 7

**Quick decision table:**
| Class type | Has `isToggleOn` in same file? | Classification | Action |
|---|---|---|---|
| Pure constants (e.g. `S2IAcquirerToggleConstants`) | ❌ No | `FOUND_DECLARATION_ONLY` | Skip analysis |
| Hybrid (e.g. `SanctionHelper`, `CardTypeDetailsDecorator`) | ✅ Yes | `IMPLEMENTATION` | Read blocks → write impacts |

---

### COMMAND 7 — Read full method block for each remaining hit
For EACH non-declaration hit from Commands 2–5:
```
Tool: read_file
filePath: <absolute full path to the Java file>
           CPE base:  C:\Users\e135408\IdeaProjects\MPGS\SourceCode\cardpaymentengine\src\main\java\
           Orch base: C:\Users\e135408\IdeaProjects\MPGS\SourceCode\orchestrator\src\main\java\
offset: <match line number> - 20    (read 20 lines before the match)
limit:  60                           (read 60 lines total — captures full if/else method block)
```
**Example**: If match is at line 145, use `offset=125, limit=60` to read lines 125–185.

**Adjust** offset/limit if the method block is larger — read until you have the complete `if (...) { ... } else { ... }` block.

---

### COMMAND 8 — Write ON/OFF impacts
Using the code read in Command 7, write for each hit:

**Toggle ON Impact** (what happens when toggle is TRUE):
```
Business: <specific operational outcome for merchant/cardholder/acquirer>
Field Impact: <exact field names: TSPI API / ISO DE elements / acquirer fields>
              OR: Internal only — no TSPI/ISO/acquirer fields affected
```

**Toggle OFF Impact** (what happens when toggle is FALSE / else branch):
```
Business: <specific fallback/legacy outcome for merchant/cardholder/acquirer>
Field Impact: <fields not populated / not sent / not validated>
              OR: Internal only — no TSPI/ISO/acquirer fields affected
```

---

### COMMAND 9 — Append row to output CSV
```
Tool: insert_edit_into_file
filePath: C:\Users\e135408\Downloads\mcp-servers\jobs\TogglePageEnquiry\data\ToggleCodebaseUsageAnalysis.csv
```

Append one row per hit at the END of the file in this exact CSV format:
```csv
"<Toggle Name>","<ImplementationClassName>","<LineNumber>","<Toggle ON Impact text>","<Toggle OFF Impact text>","<CPE or Orchestrator>"
```

**Escaping rule**: Replace any `"` inside field text with `""` (double-double-quote).

**Example row**:
```csv
"Enable TAF fields support for Passthrough","TransactionRequestValidator","234","Business: TAF authentication fields (authenticationTimestamp, transactionId) are accepted and validated in gateway for passthrough transactions — merchants can submit TAF-compliant transactions without rejection. Field Impact: transaction.authentication.taf.timestamp and transaction.authentication.taf.transactionId (TSPI API fields) accepted and passed through to acquirer.","Business: TAF authentication fields are rejected or ignored — merchants cannot submit TAF-compliant transactions via passthrough flow. Field Impact: transaction.authentication.taf.* fields not accepted; TAF passthrough flow unavailable.","CPE"
```

---

### COMMAND 10 — Verify row was written
```
Tool: read_file
filePath: C:\Users\e135408\Downloads\mcp-servers\jobs\TogglePageEnquiry\data\ToggleCodebaseUsageAnalysis.csv
offset: <last few lines>
limit: 5
```
Confirm the new row appears at the end of the file.

---

### COMMAND 11 (S2A toggles only) — Extra grep for S2A classes
If `is_s2a = TRUE` OR if any hit is in an S2A-related class, additionally search:
```
Tool: grep_search
query: "<CONSTANT_NAME>"
includePattern: "src/main/java/**/*.java"
workspace: cardpaymentengine
```
Look specifically in paths containing:
- `acquirer/messagemapimpl/`
- `S2IAcquirer`
- `JsonMegaMessage`
- `TspiRequest`

If found in S2I class (`S2IAcquirerV1`, `S2IAcquirerV2`) → use `ISO DE<n> SE<n> SF<n>` field notation.  
If found in MEGA/TSPI class (`JsonMegaMessageRequestBuilder`) → use `TSPI: Transaction.<Field>` notation.

---

## 16. CRITICAL LEARNED LESSON: Toggle #8 False Negative RCA and Prevention

### ⚠️ ISSUE: Toggle "Enable issuer country code in transaction response" Was Marked NOT_FOUND But EXISTS in Code

**Status**: Issue identified and corrected in Session 1  
**Original Result**: Reported NOT_FOUND (Row 8)  
**Actual Result**: Found in `CardTypeDetailsDecorator.java` at line 124 in CPE  
**Root Cause**: Three-part search failure pattern

#### Three-Part Failure Analysis (Session 1)

**Failure 1: Fragmented Search Terms**
- Used decomposed keywords: `issuer`, `country`, `code` searched separately
- Missed constant `ENABLE_ISSUER_COUNTRY_CODE_IN_TRANSACTION_RESPONSE` because fragments don't match
- **Fix**: Always search the COMPLETE display name as a literal string FIRST
- **Command**: `grep_search('"Enable issuer country code in transaction response"', includePattern='src/main/java/**/*.java')`

**Failure 2: Package Hierarchy Assumption**
- Expected toggle in `QSI/PaymentServer/acquirer/messagemapimpl/` (following MEA PVL pattern)
- Toggle actually exists in `com/mastercard/gateway/retrieval/decorator/CardTypeDetailsDecorator.java`
- **Fix**: Don't assume package hierarchy — toggles scatter across decorator, helper, service, core classes
- **Lesson**: Decorator pattern classes (`*Decorator.java`, `*Helper.java`) are HIGH-RISK for false negatives

**Failure 3: No Literal String Search with Quotes**
- Didn't search using the EXACT string as stored in the Java constant
- The code stores: `"Enable issuer country code in transaction response"`
- **Fix**: Always run a quoted-string search: `grep_search('"Enable issuer country code..."')`

---

---
### ⚠️ NEW BUG FIXED IN SESSION 3: Bulk N/A Row Reprocessing — Declaration-Only Rows Had Hidden Implementations
**Status**: Corrected in Session 3 (April 10, 2026)
**Scope**: 18 toggles previously N/A (FOUND_DECLARATION_ONLY, NOT_FOUND, FOUND_UTILITY_ONLY) — all had real implementations
**Root Cause**: **Failure 5 — Constant-name search was never run across the full codebase for S2IAcquirerToggleConstants declarations**
**What Was Wrong**: Toggles declared in `S2IAcquirerToggleConstants.java`, `CassandraThreeDsTogglesUtils.java`, and `DoNotProcessAfterTimeHandler.java` were being marked DECLARATION_ONLY because the search found only the declaration and stopped. The constant name was **never searched across the rest of the codebase** to find where it was imported and evaluated in `isToggleOn()` calls.
**Key Insight (Thumb Rule)**:
> Declared toggle constants are almost never unused. If declared in a pure constants class (e.g. `S2IAcquirerToggleConstants`), there WILL be at least one implementation class importing it and calling `isToggleOn()`. Always search the constant identifier across the **full codebase** to find the consuming classes.
**Fix — The Correct Commands**:
```
Step 1: Get constant_name from ToggleRegistryLookup.csv for the toggle
Step 2: grep_search(CONSTANT_NAME, includePattern='src/main/java/**/*.java') in BOTH CPE and Orchestrator
        This finds ALL import static references + ALL isToggleOn(CONSTANT_NAME) calls in one search.
Step 3: For toggles NOT in registry (e.g. Derive Amount Variability), search the display string:
        grep_search("Derive Amount Variability For CIT...", includePattern='src/main/java/**/*.java')
```
**Mass CSV Update Technique (PowerShell in-memory)**:
See Section 17 of this guide for the full command sequence. Key points:
- Use `[System.IO.File]::ReadAllText` / `WriteAllText` — not `Get-Content` / `Set-Content`
- Split on `` `n `` and modify by array index (line number - 1)
- Use `[System.Collections.ArrayList]` for Insert() operations
- Insert bottom-up (highest index first) to keep lower indexes stable
- Always write with `New-Object System.Text.UTF8Encoding $true` (BOM) — required for IntelliJ IDEA### ⚠️ NEW BUG FOUND IN SESSION 2: Declaration-in-Same-Class Misclassification

**Status**: Corrected in Session 2 (April 10, 2026)  
**Affected toggles**: "Log Acquirer Details for Sanctioned Transactions", "Unify Order Creation Time In Retrieval", "Return refund authorization data to merchants"  
**Root Cause**: **Failure 4 — Stopping at Declaration Without Checking Same File for isToggleOn**

**Failure 4: Stopping at Declaration When Implementation Is in the Same File**

When a toggle declaration was found (e.g. `private static final String TOGGLE_X = "..."`), the analysis was discarding that file entirely and marking the toggle as `FOUND_DECLARATION_ONLY`. This was **wrong** because many Java classes contain **both** the constant declaration and the actual `isToggleOn()` conditional logic in the same file.

**Concrete examples where this bug caused misclassification:**

| Toggle | File | Declaration Line | isToggleOn Lines | Wrong Status | Correct Status |
|---|---|---|---|---|---|
| Log Acquirer Details for Sanctioned Transactions | `SanctionHelper.java` | 327 | 1568, 1708, 1729, 1755 | FOUND_DECLARATION_ONLY | IMPLEMENTATION |
| Unify Order Creation Time In Retrieval | `TransactionDataCommonService.java` | 157 | 550, 1540 | FOUND_DECLARATION_ONLY | IMPLEMENTATION |
| Return refund authorization data to merchants | `TransactionDataCommonService.java` | 158 | 632 | NOT_FOUND | IMPLEMENTATION |

**Root cause**: The filter rule "skip any hit where the matching line is a declaration" was over-broad. It discarded the **entire file** from analysis when it should have only discarded the declaration **line** and then searched the same file for `isToggleOn` usage.

**Fix — Two-class taxonomy:**
- **Pure constants class** (e.g. `S2IAcquirerToggleConstants.java`): Contains ONLY `public static final String` constants, zero `isToggleOn` calls in the file → `FOUND_DECLARATION_ONLY` is correct
- **Hybrid class** (e.g. `SanctionHelper.java`, `CardTypeDetailsDecorator.java`, `TransactionDataCommonService.java`): Contains the constant declaration AND `isToggleOn()` conditional calls → must be classified as `IMPLEMENTATION` and analyzed

**Detection command:**
```
After finding a declaration in File X, ALWAYS run:
  grep_search('isToggleOn|isEnabled', includePattern='src/main/java/**/FileName.java')

If hits > 0 → hybrid class → extract isToggleOn line numbers → read and analyze
If hits = 0 → pure constants class → FOUND_DECLARATION_ONLY is correct
```

#### Updated Prevention Checklist: Before Marking Any Toggle as NOT_FOUND or FOUND_DECLARATION_ONLY

**DO NOT mark a toggle NOT_FOUND or DECLARATION_ONLY unless you have executed ALL these checks:**

```
SEARCH VALIDATION (Must complete all 3 methods):
  ☐ Method 1: Literal display string search with EXACT wording
    Command: grep_search('"<toggle name exact>"', includePattern='src/main/java/**/*.java')
    Workspace: Both CPE and Orchestrator

  ☐ Method 2: Registry constant name search
    Command: grep_search('CONSTANT_NAME_FROM_REGISTRY', includePattern='src/main/java/**/*.java')
    Workspace: Both CPE and Orchestrator

  ☐ Method 3: Keyword fallback (only if Methods 1-2 find nothing)
    High false-positive risk — validate results manually

SAME-FILE IMPLEMENTATION CHECK (NEW — MANDATORY for every declaration hit):
  ☐ Method 4: For every file where a declaration was found, check same file for isToggleOn
    Command: grep_search('isToggleOn|isEnabled', includePattern='src/main/java/**/ClassName.java')
    IF hits found → hybrid class → DO NOT mark as DECLARATION_ONLY → read and analyze isToggleOn blocks
    IF no hits   → pure constants class → DECLARATION_ONLY is correct

PACKAGE INSPECTION:
  ☐ Did I search ONLY in expected packages? → EXPAND to entire src/main/java if not found
  ☐ Did I check decorator pattern classes? (*Decorator.java, *Helper.java, *Manager.java)
  ☐ Did I check validator and helper classes? (*Validator.java, *Helper.java, *Utility.java)

CROSS-REPOSITORY CHECK:
  ☐ Searched CPE src/main/java/**/*.java?
  ☐ Searched Orchestrator src/main/java/**/*.java?
  ☐ If found in CPE: also checked Orchestrator?

ONLY IF ALL CHECKS PASS WITH ZERO MATCHES:
  ✓ NOT_FOUND status is valid
  ✓ DECLARATION_ONLY status is valid (pure constants class confirmed via Method 4)
```

**DO NOT mark a toggle NOT_FOUND unless you have executed ALL these checks:**

```
SEARCH VALIDATION (Must complete all 3 methods):
  ☐ Method 1: Literal display string search with EXACT wording
    Command: grep_search('"Enable issuer country code in transaction response"', includePattern='src/main/java/**/*.java')
    Workspace: Both CPE and Orchestrator
    
  ☐ Method 2: Registry constant name search
    Command: grep_search('CONSTANT_NAME_FROM_REGISTRY', includePattern='src/main/java/**/*.java')
    Workspace: Both CPE and Orchestrator
    
  ☐ Method 3: Fallback keyword search (if Methods 1-2 fail)
    Command: grep_search('keyword1.*keyword2', includePattern='src/main/java/**/*.java')
    Note: High false-positive risk — use only for validation, not primary finding

PACKAGE INSPECTION (Must validate all):
  ☐ Did I search ONLY in expected packages?
    (e.g., only in acquirer/ when toggle affects card types?)
    Action: EXPAND search to entire src/main/java if not found
    
  ☐ Did I check decorator pattern classes?
    Classes to check: *Decorator.java, *Helper.java, *Manager.java, *Processor.java
    (Toggle #8 was in CardTypeDetailsDecorator — a decorator class)
    Action: If toggle relates to cards/cardholder data, search /decorator/ packages
    
  ☐ Did I check validator and helper classes?
    Classes to check: *Validator.java, *Helper.java, *Utility.java
    Action: These classes often contain cross-cutting toggles

CROSS-REPOSITORY CHECK (Must verify both):
  ☐ Searched in CPE src/main/java/**/*.java?
  ☐ Searched in Orchestrator src/main/java/**/*.java?
  ☐ If found in CPE: Did I also check Orchestrator for dual-repo usage?

ONLY IF ALL CHECKS PASS WITH ZERO MATCHES:
  Status: Assign NOT_FOUND with explanation
```

#### High-Risk Toggle Categories (Most Likely to Be Missed)

Based on Toggle #8 RCA, these patterns have high false-negative rates:

| Category | Risk Pattern | Where to Look (Search Scope) |
|---|---|---|
| **Card/Cardholder Data** | Not in expected acquirer packages; scattered across card service and decorator classes | `/cardservice/`, `/decorator/`, `/retrieval/`, `/processor/` |
| **Multi-word Toggle Names** (>3 words) | Fragmentation errors when splitting into keywords | Search LITERAL STRING FIRST, then keywords as fallback |
| **Transaction Response Data** | May be in retrieval, decorator, or response builder classes | `/retrieval/`, `/decorator/`, `*Response*.java`, `*Decorator.java` |
| **Acquirer Message Fields** | Usually in `/acquirer/messagemapimpl/` but some in helper/validator classes | Search `/acquirer/` PLUS `*Helper.java`, `*Validator.java` |
| **Protection/Validation Features** | Scattered across protection service, validators, and filter classes | `/protectionService/`, `*Validator.java`, `*Filter.java` |

#### NOT_FOUND Toggles to Re-Check (Session 1 Analysis Artifacts)

The following toggles from ToggleCodebaseUsageAnalysis.csv are currently marked NOT_FOUND. Based on RCA, they MAY be false negatives:

**High Suspicion (search thoroughly):**
- Row 11: "Enable TAF fields support for Passthrough" — TAF is a Visa feature, check response/validation classes
- Row 15: "Log Acquirer Details for Sanctioned Transactions" — sanctioned = security feature, check protection/security classes
- Row 18: "Unify Order Creation Time In Retrieval" — order/retrieval feature, check `/retrieval/` and `*Retrieval.java` classes
- Row 22: "System Toggle: Enable 8-4 PAN Masking in API Response" — response masking, check response/decorator classes
- Row 32: "Retrieve Card Bin Set Id for Subsequent Transactions" — card/BIN feature, check `/cardservice/` and `*BinSet*.java`

**Medium Suspicion (standard search may suffice):**
- Row 20: "Enable historical transaction data aggregation..." — infrastructure feature
- Row 24: "System Toggle: Enable Rate Limit For Test Merchants" — system/test feature
- Row 30: "Populate payer authentication details on pre-risk RSPI" — authentication/RSPI feature

**Low Suspicion (likely genuinely NOT_FOUND):**
- Row 23: "System Toggle: Honour DoNotProcessAfterTime..." — system feature, probably in constants class only
- Row 26: "Apply per-merchant maximum request rate limits in WSAPI" — WSAPI system feature
- Row 46+: Infrastructure/storage/replication features (usually internal only, may not be toggle-gated)

#### Command Sequence FOR RE-CHECKING NOT_FOUND TOGGLES

When re-analyzing a NOT_FOUND toggle, use this sequence:

**Step 1: Literal String Search (ALWAYS FIRST)**
```
grep_search(
  query = '"Enable TAF fields support for Passthrough"',
  includePattern = 'src/main/java/**/*.java'
)
# Run in both CPE and Orchestrator
```

**Step 2: If Step 1 fails → Constant Name Search**
```
read_file('ToggleRegistryLookup.csv') → find constant_name for this toggle
grep_search(
  query = 'CONSTANT_NAME_VALUE',
  includePattern = 'src/main/java/**/*.java'
)
# Run in both CPE and Orchestrator
```

**Step 3: If Steps 1-2 fail → Targeted Package Search**
```
# Based on toggle domain, search specific packages:
grep_search(
  query = '"Enable TAF fields support for Passthrough"',
  includePattern = 'src/main/java/**/validation/**/*.java'  # For validation features
)
grep_search(
  query = '"Enable TAF fields support for Passthrough"',
  includePattern = 'src/main/java/**/response/**/*.java'    # For response features
)
grep_search(
  query = '"Enable TAF fields support for Passthrough"',
  includePattern = 'src/main/java/**/*Decorator*.java'       # For decorator pattern
)
```

**Step 4: If Steps 1-3 fail → Keyword Search (High False-Positive Risk)**
```
grep_search(
  query = 'TAF.*field|field.*support.*Passthrough|Passthrough.*[Aa]uthentication',
  includePattern = 'src/main/java/**/*.java'
)
# Manually validate matches — many will be unrelated
```

**Step 5: If All Steps Fail → Confirm NOT_FOUND**
```
Result: Status = NOT_FOUND with explanation:
  "Literal string search executed in both CPE and Orchestrator, 
   constant name search performed, decorator/validation packages scanned, 
   keyword searches completed — no matches found. Toggle may be in planning stage 
   or awaiting implementation."
```

---

## 17. N/A Row Reprocessing — Exact Command Sequence (Session 3 Technique)

Use this sequence when any row in `ToggleCodebaseUsageAnalysis.csv` has `Line Number Code = N/A` but already has an implementation class name (or when a NOT_FOUND toggle needs to be re-verified).

### Step 1 — Identify all N/A rows
```powershell
$csv = [System.IO.File]::ReadAllText("C:\...\ToggleCodebaseUsageAnalysis.csv", [System.Text.Encoding]::UTF8)
$lines = $csv.Split("`n")
for ($i=1; $i -lt $lines.Count; $i++) {
    if ($lines[$i] -match ',"N/A",') { Write-Host "Row $($i+1): $($lines[$i].Substring(0,100))" }
}
```

### Step 2 — Get constant names from registry for each N/A toggle
```
Tool: read_file
File: C:\Users\e135408\Downloads\mcp-servers\jobs\TogglePageEnquiry\data\ToggleRegistryLookup.csv
```
Find `constant_name` column for each toggle. If toggle is NOT in registry, search display string directly.

### Step 3 — Search constant name across BOTH repos (key fix)
```
Tool: grep_search
query: "CONSTANT_NAME_FROM_REGISTRY"
includePattern: "src/main/java/**/*.java"
workspace: cardpaymentengine      ← CPE first

Tool: grep_search
query: "CONSTANT_NAME_FROM_REGISTRY"
includePattern: "src/main/java/**/*.java"
workspace: orchestrator            ← ALWAYS also check Orchestrator
```
**This is the step that was missing in previous sessions.** The constant name finds all `import static` references AND all `isToggleOn(CONSTANT_NAME)` calls in one search.

### Step 4 — For toggles NOT in registry, search the display string
```
Tool: grep_search
query: "Derive Amount Variability For CIT And MIT Recurring Transactions"
includePattern: "src/main/java/**/*.java"
workspace: orchestrator
```
Catches toggles defined in `ToggleConstants.java` or `Constants.java` utility files.

### Step 5 — Read each isToggleOn block
For each non-declaration hit found in Steps 3/4:
```
Tool: read_file
filePath: <absolute path>
offset: <hit line> - 20
limit: 60
```

### Step 6 — Update CSV rows in bulk (PowerShell in-memory technique)
```powershell
$csvPath = "C:\Users\e135408\Downloads\mcp-servers\jobs\TogglePageEnquiry\data\ToggleCodebaseUsageAnalysis.csv"
$content = [System.IO.File]::ReadAllText($csvPath, [System.Text.Encoding]::UTF8)
$lines = $content.Split("`n")

# Replace N/A rows by line index (lineNum - 1)
$lines[10] = '"Toggle Name","ImplementationClass","LineNo","Business: ON impact. Field Impact: ...","Business: OFF impact. Field Impact: ...","CPE"'

# Insert additional rows for multi-class toggles
$finalLines = [System.Collections.ArrayList]$lines
$finalLines.Insert(11, '"Toggle Name","SecondClass","LineNo","ON","OFF","CPE"')

# Write with UTF-8 BOM
$utf8Bom = New-Object System.Text.UTF8Encoding $true
[System.IO.File]::WriteAllText($csvPath, ($finalLines -join "`n"), $utf8Bom)
```

### Step 7 — Verify encoding after write
```powershell
$bytes = [System.IO.File]::ReadAllBytes($csvPath)
Write-Host "BOM: $($bytes[0].ToString('X2')) $($bytes[1].ToString('X2')) $($bytes[2].ToString('X2'))"
# Must show: EF BB BF
$bad = ($bytes | Where-Object { $_ -eq 0x97 -or $_ -eq 0x96 }).Count
Write-Host "Bad Windows-1252 bytes: $bad"   # Must be 0
```

### Common N/A Reprocessing Pitfalls (Failure 5 Prevention)

| Mistake | Consequence | Correct Approach |
|---------|-------------|-----------------|
| Only checking the declaration file | Misses all implementation classes that import the constant | **Always search the constant name across the WHOLE codebase** |
| Stopping after finding CPE | Misses dual-repo toggles (e.g. Visa/MC AFT used in both) | **Always search Orchestrator too** |
| Not searching display string when toggle absent from registry | Misses toggles defined in `ToggleConstants.java`, `Constants.java` | **Search display string as fallback for non-registry toggles** |
| Using `Set-Content` without `-Encoding UTF8` | Saves without BOM → IntelliJ encoding warning | **Use `[System.IO.File]::WriteAllText` with `UTF8Encoding($true)`** |
| Inserting extra rows at wrong index | Row numbers shift; wrong content at wrong toggle | **Insert bottom-up (higher indexes first) to keep lower indexes stable** |

---

## 16. Batch-by-Batch Agent Prompt Templates

Copy-paste these into the new session chat to direct the agent for each batch.

### Start Batch 2 (Toggles 6–10)
```
Read the file at:
C:\Users\e135408\Downloads\mcp-servers\jobs\TogglePageEnquiry\NEW_SESSION_EXECUTION_GUIDE.md

Then process BATCH 2 — the following 5 toggles in order:
1. Enable TAF fields support for Passthrough
2. MEA PVL and Co-branded Card Transaction Processing
3. Enable issuer country code in transaction response
4. System Toggle: Use 8_4 Masked PAN for Scheme Token Transaction Response
5. Support New Merchant Advice Codes with optimal retry advice for Mastercard

For each toggle:
- Follow the exact tool command sequence in Section 15 of the guide
- grep_search in BOTH CPE and Orchestrator src/main/java/**/*.java
- read_file the complete if/else block (offset = matchLine-20, limit=60)
- Write two-part Business+Field Impact for ON and OFF
- Append one CSV row per usage location to ToggleCodebaseUsageAnalysis.csv

After all 5 toggles: verify CSV row count and create checkpoint file:
C:\Users\e135408\Downloads\mcp-servers\jobs\TogglePageEnquiry\logs\Batch2_Checkpoint.txt
```

### Start Batch 3 (Toggles 11–15)
```
Continue toggle codebase analysis. Current output CSV:
C:\Users\e135408\Downloads\mcp-servers\jobs\TogglePageEnquiry\data\ToggleCodebaseUsageAnalysis.csv

Process BATCH 3 — the following 5 toggles:
1. System Toggle:Enable DPG New Mapping
2. Enable Unusual Transaction Protection
3. Enable Lookup up to 11 digit bin for Card Identification
4. Log Acquirer Details for Sanctioned Transactions
5. Enable New COF Token Value for Target

Follow Section 15 of NEW_SESSION_EXECUTION_GUIDE.md for exact tool command sequence.
Append results to ToggleCodebaseUsageAnalysis.csv. Create Batch3_Checkpoint.txt after.
```

### Start Batch 4 (Toggles 16–20)
```
Continue toggle codebase analysis — BATCH 4:
1. System Toggle: Enable Data Instrumentation Logging for WSAPI requests
2. Unify Order Creation Time In Retrieval
3. Get Most Recent Transaction as Initial Transaction If Auto-Capture Failed in Settlement Transaction
4. Enable historical transaction data aggregation for prioritised merchant flow control
5. System Toggle: Enable Data Instrumentation Logging for WSAPI Transactions

Follow NEW_SESSION_EXECUTION_GUIDE.md Section 15. Append to ToggleCodebaseUsageAnalysis.csv.
```

### Start Batch 5 (Toggles 21–25)
```
Continue toggle codebase analysis — BATCH 5:
1. System Toggle: Enable 8-4 PAN Masking in API Response
2. System Toggle: Honour DoNotProcessAfterTime for transaction processing
3. System Toggle: Enable Rate Limit For Test Merchants
4. Apply per-merchant limits for invalid operation rates in WSAPI
5. Apply per-merchant maximum request rate limits in WSAPI

Follow NEW_SESSION_EXECUTION_GUIDE.md Section 15. Append to ToggleCodebaseUsageAnalysis.csv.
```

### Start Batch 6 (Toggles 26–30)
```
Continue toggle codebase analysis — BATCH 6:
1. System Toggle: Enable Version Deprecation for Transactions
2. Route Risk Operations via the R-SPI Service and enable Merchant Risk
3. RSPI Mapping: Send Fields to Risk Provider - SubMerchant
4. Populate payer authentication details on pre-risk RSPI
5. Bypass CSC checks for Scheme Token Transactions

NOTE: Toggle 30 (Bypass CSC) constant = TOGGLE_BYPASS_CSC_CHECKS_FOR_SCHEME_TOKEN_TRANSACTIONS in CscHelper.java (CPE, IMPLEMENTATION).
Follow NEW_SESSION_EXECUTION_GUIDE.md Section 15. Append to ToggleCodebaseUsageAnalysis.csv.
```

### Start Batch 7 (Toggles 31–35)
```
Continue toggle codebase analysis — BATCH 7:
1. Retrieve Card Bin Set Id for Subsequent Transactions
2. Filter out transactions unrelated to current order
3. Use partitioned tables for CPE transaction storage
4. System Toggle: CPE - Recovery actions bypass Shared Memory CPE PersistenceTable to go straight to DB
5. Shared Memory CPE PersistenceTable

Follow NEW_SESSION_EXECUTION_GUIDE.md Section 15. Append to ToggleCodebaseUsageAnalysis.csv.
```

### Start Batch 8 (Toggles 36–40)
```
Continue toggle codebase analysis — BATCH 8:
1. System Toggle: Reversal Daemon delays remote takeovers
2. System Toggle: Use Enhanced Optimistic Lock With Terminal Batch Counters
3. Allow Network Data Tag in DE123 for domestic card brand transactions
4. Random Terminal Allocation
5. Use Status Code when calculating if PSD2 Exemption has been granted by Visa

NOTE: Toggle 39 (Random Terminal Allocation) constant = TOGGLE_RANDOM_TERMINAL_ALLOCATION in CoreTerminalPool.java (CPE, IMPLEMENTATION).
NOTE: Toggle 38 constant = TOGGLE_ALLOW_NETWORK_DATA_TAG_IN_DE123_FOR_DOMESTIC_CARD_BRAND_TRANSACTIONS — search S2I classes for ISO DE123 usage.
Follow NEW_SESSION_EXECUTION_GUIDE.md Section 15. Append to ToggleCodebaseUsageAnalysis.csv.
```

### Start Batch 9 (Toggles 41–45)
```
Continue toggle codebase analysis — BATCH 9:
1. Use Authentication Status when performing Transaction Filtering
2. Bypass 3DS Transaction Filtering for TAS Passkey transactions
3. Send Authentication fields in RiskSPI and AuthenticationStatusCode field in TSPI  [is_s2a=TRUE]
4. Store PARes and VERes in Postgres only
5. Scheme Transaction Throttle for WS API - Passive Mode

NOTE: Toggle 43 is is_s2a=TRUE. Search for TSPI JSON fields: Transaction.AuthenticationStatus, TSPI AuthenticationStatusCode.
Follow NEW_SESSION_EXECUTION_GUIDE.md Section 15. Append to ToggleCodebaseUsageAnalysis.csv.
```

### Start Batch 10 (Toggles 46–50)
```
Continue toggle codebase analysis — BATCH 10:
1. Support STRIPE failover using Operations console
2. Enable replication lag tracking by MCS
3. System Toggle: Enable DC Replication Locks
4. Allow payment transaction with authentication return surcharge
5. Use Enhanced Certificate Sets

Follow NEW_SESSION_EXECUTION_GUIDE.md Section 15. Append to ToggleCodebaseUsageAnalysis.csv.
```

### Start Batch 11 (Toggles 51–55)
```
Continue toggle codebase analysis — BATCH 11:
1. Derive Amount Variability For CIT And MIT Recurring Transactions
2. Enable CIT MIT indicators for Mastercard
3. Enable Activity Calls to Protection Service
4. Enable VISA Account Funding Transactions
5. Return refund authorization data to merchants

NOTE: Toggle 52 (CIT MIT Mastercard) — search S2I classes for ISO DE61 SF4 and DE48 SE22 SF05.
Follow NEW_SESSION_EXECUTION_GUIDE.md Section 15. Append to ToggleCodebaseUsageAnalysis.csv.
```

### Start Batch 12 (Toggles 56–60)
```
Continue toggle codebase analysis — BATCH 12:
1. Enable Single Tap Transactions
2. Enable known fare transit with transportationMode
3. Auto reversals on final capture
4. Set approvedAmount only when the transaction is approved
5. Mastercard QR Transaction Identifiers

Follow NEW_SESSION_EXECUTION_GUIDE.md Section 15. Append to ToggleCodebaseUsageAnalysis.csv.
```

### Start Batch 13 (Toggles 61–65)
```
Continue toggle codebase analysis — BATCH 13:
1. Enable New COF Token Value for T-SPI  [is_s2a=TRUE — search TSPI Transaction.CredentialOnFile]
2. Revised Standards to Introduce BPSP Category to Support B2B
3. Enable Exclusion Rule in Merchant Acquirer Link Resolution
4. Enable Card Identification Service
5. Optimize loading of terminal batch counters

NOTE: Toggle 61 toggle name was corrupted as "61 | Enable New COF Token Value for T-SPI" in old CSV — correct name is "Enable New COF Token Value for T-SPI".
NOTE: Toggle 61 is_s2a=TRUE. Search for TSPI: Transaction.CredentialOnFile field.
Follow NEW_SESSION_EXECUTION_GUIDE.md Section 15. Append to ToggleCodebaseUsageAnalysis.csv.
```

### Start Batch 14 (Toggles 66–70)
```
Continue toggle codebase analysis — BATCH 14:
1. Submit EDQP Phase 3 fields in standalone transactions to WSAPI
2. Enable MC Account Funding Transactions
3. Submit EDQP Phase 3 fields to RSC for Standalone Refunds
4. Enable Account Funding enhanced functionality for Mastercard and Visa  [is_s2a=TRUE]
5. Enable Protection Blocking Of Unusual Transactions

NOTE: Toggle 69 is_s2a=TRUE and DUAL-REPO — must produce SEPARATE rows for CPE and Orchestrator.
  CPE rows: search S2IAcquirerV1/V2 for ISO DE fields; search JsonMegaMessageRequestBuilder for TSPI JSON fields.
  Orchestrator row: AccountFundingValidator — TSPI API field purposeOfPayment auto-default.
  Constant name: TOGGLE_ENABLE_ACCOUNT_FUNDING_ENHANCED_FUNCTIONALITY_FOR_MASTERCARD_AND_VISA
Follow NEW_SESSION_EXECUTION_GUIDE.md Section 15. Append to ToggleCodebaseUsageAnalysis.csv.
```

### Start Batch 15 (Toggles 71–72)
```
Continue toggle codebase analysis — BATCH 15 (final batch):
1. System Toggle: Enable Activity Analyzer in Protection Service
2. Enable Transaction Filtering BIN Range White listing

Follow NEW_SESSION_EXECUTION_GUIDE.md Section 15. Append to ToggleCodebaseUsageAnalysis.csv.
After completing: verify total row count in output CSV and write final summary checkpoint.
```

---

## 17. If No Usage Found for a Toggle

If `grep_search` returns zero results for both display string AND constant name in both repos:

1. Write a **NOT_FOUND row** to document it:
```csv
"<Toggle Name>","NOT_FOUND","N/A","Business: No implementation usage found in CPE or Orchestrator src/main/java. Toggle may be evaluated in a non-Java component (Target, DirectApi, ThreeDSService) or may have been removed. Field Impact: Unknown — not found in searched scope.","Business: Not applicable — no usage found. Field Impact: Unknown.","NOT_FOUND"
```

2. Continue to the next toggle — do not stop the batch.

---

## 18. When to Use PS1 Tools vs Agent Tools vs Python

This section defines exactly which tool to use for each task in the workflow, based on what works reliably in the JetBrains + PowerShell v5.1 environment.

---

### Tool Capability Matrix

| Task | PS1 Tool | Agent Tool | Python | Recommended |
|------|----------|------------|--------|-------------|
| Search Java files for toggle name/constant | `Toggle-SearchUtility.ps1` | `grep_search` | `toggle_search_optimized.py` | ✅ **Agent `grep_search`** (most reliable) |
| Read complete method block from file | — | `read_file` | — | ✅ **Agent `read_file`** (only option) |
| Write/append rows to output CSV | `Toggle-PublishUtility.ps1` | `insert_edit_into_file` | — | ✅ **Agent `insert_edit_into_file`** (reliable) |
| Load toggle registry lookup | — | `read_file` | — | ✅ **Agent `read_file`** |
| Rebuild toggle registry from source | `build-toggle-registry.ps1` | — | — | ✅ **PS1** (run_in_terminal once only) |
| Batch orchestration / batch loop | `Toggle-AnalysisBatchProcessor.ps1` | Agent batch loop | — | ✅ **Agent batch loop** (PS1 has output issue) |
| Fast parallel search across all 73 toggles | — | — | `toggle_search_optimized.py` | ✅ **Python** (if created, 8x faster) |
| Validate CSV output | `Toggle-PublishUtility.ps1 -ValidateOnly` | `read_file` | — | ✅ **Agent `read_file`** |

---

### Decision Rules

#### USE `grep_search` (Agent Tool) — PRIMARY SEARCH METHOD
**When**: Every toggle Phase 3A search  
**Why**: Works directly in the agent, no subprocess/output-capture issue, always returns results  
**How**:
```
grep_search(query="<toggle name or constant>", includePattern="src/main/java/**/*.java")
```
- Run twice per toggle: once for display string, once for constant_name
- Run in both CPE and Orchestrator workspaces separately
- **Always use `includePattern: "src/main/java/**/*.java"`** — never omit this

#### USE `read_file` (Agent Tool) — PRIMARY FILE READ METHOD
**When**: Every Phase 3B code block read  
**Why**: Agent-native, reads exact line ranges, no subprocess issues  
**How**:
```
read_file(filePath="<absolute path>", offset=<matchLine-20>, limit=60)
```
- Use for every implementation hit to get the complete if/else block
- Adjust offset/limit if method body is larger than 60 lines

#### USE `insert_edit_into_file` (Agent Tool) — PRIMARY CSV WRITE METHOD
**When**: Every Phase 6 output row append  
**Why**: Agent-native file write, no subprocess, confirmed working  
**How**: Append at end of `ToggleCodebaseUsageAnalysis.csv` using `// ...existing code...` comment to preserve existing rows

#### USE `Toggle-PublishUtility.ps1` (PS1) — ALTERNATIVE CSV WRITE
**When**: Only use as **fallback** if `insert_edit_into_file` has issues, OR for bulk writes of 5+ rows at once  
**Why**: Has output capture issue in JetBrains terminal but file I/O (Set-Content/Add-Content) still works  
**How** (run via `run_in_terminal`):
```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass -Force
cd C:\Users\e135408\Downloads\mcp-servers\tools
$data = @(
    @{ ToggleName="..."; ImplementationClassName="..."; LineNumber="...";
       ONImpact="..."; OFFImpact="..."; Repository="CPE" }
)
.\Toggle-PublishUtility.ps1 -AnalysisData $data -AppendOnly
```
> ⚠️ **Known issue**: No stdout output visible in terminal — but the CSV file IS written. Always verify with `read_file` after.

#### USE `Toggle-SearchUtility.ps1` (PS1) — FALLBACK SEARCH ONLY
**When**: Use ONLY as fallback if `grep_search` misses results (e.g. complex constant alias not found)  
**Why**: Has output capture issue — produces no visible output in current terminal session  
**How** (run via `run_in_terminal`):
```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass -Force
cd C:\Users\e135408\Downloads\mcp-servers\tools
# Redirect JSON output to a file, then read it
.\Toggle-SearchUtility.ps1 -ToggleName "Toggle Name" -Repository "Both" -ExcludeDeclarations `
    | Out-File -FilePath "C:\Temp\toggle_search_result.json" -Encoding UTF8
```
Then read the file:
```
read_file(filePath="C:\Temp\toggle_search_result.json")
```

#### USE `Toggle-AnalysisBatchProcessor.ps1` (PS1) — DO NOT USE IN PRIMARY FLOW
**When**: **Not recommended** for primary batch processing in current environment  
**Why**: Produces no output (output capture issue), Phase 3A output not visible to agent  
**Alternative**: Agent performs Phase 3A directly using `grep_search` per toggle  
**Future use**: Can be used in an automated run if the PS1 output issue is fixed

#### USE `build-toggle-registry.ps1` (PS1) — ONE-TIME REGISTRY REBUILD ONLY
**When**: Only if `ToggleRegistryLookup.csv` needs to be rebuilt (new toggles added to codebase)  
**Why**: Only tool that scans all Java files to rebuild the 244-entry registry  
**Current status**: Registry already rebuilt on April 10, 2026 — do NOT re-run unless needed  
**How** (one-time only):
```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass -Force
cd C:\Users\e135408\Downloads\mcp-servers
.\build-toggle-registry.ps1
```

#### USE Python `toggle_search_optimized.py` — FAST BULK SEARCH (IF CREATED)
**When**: If you want to pre-index all 73 toggle locations in one pass before starting analysis  
**Why**: 8 parallel workers, 50-80% faster than sequential grep, caches Java file index  
**Current status**: ⚠️ Script does NOT yet exist — would need to be created  
**Location if created**: `C:\Users\e135408\Downloads\mcp-servers\tools\toggle_search_optimized.py`  
**How** (if created):
```bash
cd C:\Users\e135408\Downloads\mcp-servers\tools
python toggle_search_optimized.py
```
**Output**: JSON file with all search hits pre-indexed — agent then reads file instead of grep_searching

---

### Recommended Tool Strategy per Batch

```
┌─────────────────────────────────────────────────────────────┐
│  RECOMMENDED WORKFLOW PER BATCH (5 toggles)                 │
├──────────────────┬──────────────────────────────────────────┤
│ Phase            │ Tool to Use                              │
├──────────────────┼──────────────────────────────────────────┤
│ Phase 0 (Setup)  │ read_file → ToggleRegistryLookup.csv     │
│                  │ (already loaded — no re-read needed)     │
├──────────────────┼──────────────────────────────────────────┤
│ Phase 3A (Find)  │ grep_search × 4 per toggle               │
│                  │ (CPE display, CPE constant,              │
│                  │  Orch display, Orch constant)            │
├──────────────────┼──────────────────────────────────────────┤
│ Phase 3B (Read)  │ read_file × N hits                       │
│                  │ offset=matchLine-20, limit=60            │
├──────────────────┼──────────────────────────────────────────┤
│ Phase 4 (Impact) │ Agent analysis (no tool — write impacts) │
├──────────────────┼──────────────────────────────────────────┤
│ Phase 6 (Output) │ insert_edit_into_file → CSV              │
│                  │ (or Toggle-PublishUtility.ps1 fallback)  │
├──────────────────┼──────────────────────────────────────────┤
│ Verify           │ read_file → last 5 lines of CSV          │
└──────────────────┴──────────────────────────────────────────┘
```

---

### PS1 Tool Status Summary

| Script | Location | Status | Use In Batches? |
|--------|----------|--------|-----------------|
| `Toggle-SearchUtility.ps1` | `tools/` | ⚠️ Output issue (no stdout) | Fallback only — use with file redirect |
| `Toggle-PublishUtility.ps1` | `tools/` | ⚠️ Output issue but writes file OK | Fallback CSV write — verify with read_file |
| `Toggle-AnalysisBatchProcessor.ps1` | `tools/` | ⚠️ Output issue | Not recommended — use agent batch loop |
| `build-toggle-registry.ps1` | root | ✅ Works (file output) | One-time only (already done) |
| `BuildToggleRegistryLookup.ps1` | `tools/` | ✅ Same as above | One-time only |
| `generate-java-tree.ps1` | `tools/` | ✅ Works (file output) | One-time only if needed |

> **Root Cause of PS1 Output Issue**: PowerShell child-process stdout is not captured by the JetBrains terminal in the current environment. Scripts execute correctly and write files, but `Write-Host` / `Write-Output` / `ConvertTo-Json` piped to stdout produce no visible output. **Workaround**: Always redirect output to a temp file and read it back with `read_file`.

---

### PS1 Workaround Pattern (When PS1 Output Needed)

If you must use a PS1 tool and read its output, always use this pattern:

```powershell
# Step 1 — Run PS1 redirecting output to file
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass -Force
cd C:\Users\e135408\Downloads\mcp-servers\tools
.\Toggle-SearchUtility.ps1 `
    -ToggleName "Enable TAF fields support for Passthrough" `
    -Repository "Both" `
    -ExcludeDeclarations `
    | Out-File -FilePath "C:\Temp\ts_result.json" -Force -Encoding UTF8
```

```
# Step 2 — Agent reads the file
Tool: read_file
filePath: C:\Temp\ts_result.json
```

This pattern works because file I/O bypasses the stdout capture issue.

---

**Ready to start Batch 2.**  
Begin with toggle 6: `"Enable TAF fields support for Passthrough"`  
Use Section 15 commands: Registry lookup → grep_search CPE + Orchestrator → read_file block → write impact → append to CSV.

---

## 16. Toggle Registry — Multi-Repo Optimization (April 10, 2026)

### Overview

The `ToggleRegistryLookup.csv` was expanded from 2 repositories (CPE + Orchestrator) to **6 repositories** covering the full MPGS gateway platform. The registry builder script `tools/BuildToggleRegistryLookup.ps1` was also updated to support all 6 repos.

### Registry Summary (303 entries total)

| Repository | Entries | IMPLEMENTATION | DECLARATION | Scan Strategy |
|---|---|---|---|---|
| CPE | 199 | 57 | 142 | Full scan (~2,420 files) |
| Orchestrator | 45 | 27 | 18 | Full scan (~751 files) |
| MSOUI | 16 | 6 | 10 | Full scan (~1,065 files) |
| DirectAPI | **14** | **12** | **2** | **Targeted scan (22 files)** |
| BusinessService | 3 | 2 | 1 | Full scan (~581 files) |
| Console | 2 | 2 | 0 | Full scan (~749 files) |
| **BatchSettlementService** | **24** | **8** | **16** | **Full scan (285 files)** |

### DirectAPI Targeted-File Optimization

**Problem**: DirectAPI has ~10,367 Java files — a full scan takes ~5 minutes and finds toggles in only 22 files (~0.2% hit rate).

**Solution**: Pre-identify the 22 toggle-bearing files once, hard-code them in the script as `$directAPITargetRelPaths`. Subsequent registry rebuilds process only those 22 files, completing in **under 1 second** (~99.8% reduction in files scanned).

**The 22 known DirectAPI toggle-bearing files** (as of 2026-04-10):
```
src/main/java/com/dialect/gateway/merchant/utility/api/converter/common/JsonWithJweEncryptedContentToPlainStringConverter.java
src/main/java/com/dialect/gateway/merchant/utility/api/documentation/api/ProtocolPathTemplate.java
src/main/java/com/dialect/gateway/merchant/utility/api/protocol/rest/RestOperation.java
src/main/java/com/dialect/gateway/merchant/utility/internal/common/execute/concurrent/permerchant/historical/HistoricalTransactionDataConfiguration.java
src/main/java/com/dialect/gateway/merchant/utility/internal/common/execute/concurrent/permerchant/MerchantInvalidRequestRateLimiter.java
src/main/java/com/dialect/gateway/merchant/utility/internal/common/execute/concurrent/permerchant/MerchantPrioritisedRequestRateLimiter.java
src/main/java/com/dialect/gateway/merchant/utility/internal/common/execute/concurrent/permerchant/TestingMerchantsRateLimiter.java
src/main/java/com/dialect/gateway/merchant/utility/internal/common/execute/concurrent/permerchant/UnauthenticatedPaymentRateLimiter.java
src/main/java/com/dialect/gateway/merchant/utility/internal/common/execute/AkamaiDecorator.java
src/main/java/com/dialect/gateway/merchant/utility/internal/common/execute/PANMaskingHelper.java
src/main/java/com/dialect/gateway/merchant/utility/internal/common/execute/RequestExecutor.java
src/main/java/com/dialect/gateway/merchant/utility/internal/common/execute/ResponseFieldLogHandler.java
src/main/java/com/dialect/gateway/merchant/v64/utility/AuthorizationPayGatewayRecommendationConverter.java
src/main/java/com/dialect/gateway/merchant/v67/utility/AuthorizationPayGatewayRecommendationConverter.java
src/main/java/com/dialect/gateway/merchant/v69/utility/AuthorizationPayGatewayRecommendationConverter.java
src/main/java/com/dialect/gateway/merchant/v70/utility/AuthorizationPayGatewayRecommendationConverter.java
src/main/java/com/dialect/gateway/merchant/v71/canon/CreateOrUpdateMerchantRequestCanon.java
src/main/java/com/dialect/gateway/merchant/v72/canon/CreateOrUpdateMerchantRequestCanon.java
src/main/java/com/dialect/gateway/merchant/v73/canon/CreateOrUpdateMerchantRequestCanon.java
src/main/java/com/dialect/gateway/merchant/v73/utility/AuthorizationPayGatewayRecommendationConverter.java
src/main/java/com/dialect/gateway/merchant/v74/utility/AuthorizationPayGatewayRecommendationConverter.java
src/main/java/com/dialect/gateway/merchant/v77/utility/AuthorizationPayGatewayRecommendationConverter.java
```

**To refresh the DirectAPI file list** (e.g. after a new release adds toggle-bearing files):
```powershell
& "C:\Users\e135408\Downloads\mcp-servers\tools\BuildToggleRegistryLookup.ps1" -RefreshDirectAPIFileList
```
This triggers a full DirectAPI scan, prints any newly discovered toggle-bearing files, and reminds you to update `$directAPITargetRelPaths` in the script.

### Key DirectAPI Toggles (14 unique, all IMPLEMENTATION except 2)

| Toggle Name | Class | Constant | usage_type |
|---|---|---|---|
| System Toggle: Enable Akamai Transactions processing | AkamaiDecorator | `TOGGLE_ENABLE_AKAMAI_TRANSACTIONS_PROCESSING` | IMPLEMENTATION |
| System Toggle: Enable 8-4 PAN Masking in API Response | PANMaskingHelper | `ENABLE_8_4_PAN_MASKING_IN_API_RESPONSE` | IMPLEMENTATION |
| System Toggle: Enable Version Deprecation for Transactions | RequestExecutor | `ENABLE_VERSION_DEPRECATION_TOGGLE` | IMPLEMENTATION |
| System Toggle: Enable Version Deprecation for Documentation | ProtocolPathTemplate | `ENABLE_DOCUMENTATION_VERSION_DEPRECATION_TOGGLE` | IMPLEMENTATION |
| System Toggle: Enable Data Instrumentation Logging for WSAPI Transactions | ResponseFieldLogHandler | `ENABLE_LOGGING_FOR_WSAPI_TRANSACTIONS` | IMPLEMENTATION |
| System Toggle: Enable Rate Limit For Test Merchants | TestingMerchantsRateLimiter | `ENABLE_RATE_LIMIT_TEST_MERCHANT_REQUESTS_TOGGLE` | IMPLEMENTATION |
| Enable Rate Limit For Unauthenticated Requests | UnauthenticatedPaymentRateLimiter | `ENABLE_RATE_LIMIT_UNAUTHENTICATED_REQUESTS_TOGGLE` | IMPLEMENTATION |
| Enable tokenization extended logging | RestOperation | `TOGGLE_ENABLE_EXTENDED_TOKENIZATION_LOGGING` | IMPLEMENTATION |
| Enable HSM key cryptography for Token search UI | JsonWithJweEncryptedContentToPlainStringConverter | `ENABLE_HSM_KEY_CRYPTOGRAPHY` | IMPLEMENTATION |
| Enable new GatewayRecommendation for Auth Pay and Authentication Operation | AuthorizationPayGatewayRecommendationConverter | `TOGGLE_FOR_NEW_GATEWAY_RECOMMENDATION` | IMPLEMENTATION |
| Enable new GatewayRecommendation for UNKNOWN and UNSPECIFIED_FAILURE Response Codes | AuthorizationPayGatewayRecommendationConverter | `TOGGLE_FOR_NEW_GATEWAY_RECOMMENDATION_FOR_AVOIDING_DUPLICATE_TRANSACTIONS` | IMPLEMENTATION |
| Support New Merchant Advice Codes with optimal retry advice for Mastercard | AuthorizationPayGatewayRecommendationConverter | `TOGGLE_FOR_NEW_MERCHANT_ADVICE_CODES_FOR_RETRY_ADVICE` | IMPLEMENTATION |
| Enable historical transaction data aggregation for prioritised merchant flow control | HistoricalTransactionDataConfiguration | `ENABLE_HISTORICAL_TRANSACTION_DATA_AGGREGATION` | DECLARATION |
| Enable Dynamic 3-D Secure Authentication for this merchant. | CreateOrUpdateMerchantRequestCanon | `ENABLE_DYNAMIC_3DSECURE_DESCRIPTION` | DECLARATION |

### Registry Rebuild Command
```powershell
# Normal rebuild (fast — uses targeted 22-file list for DirectAPI)
& "C:\Users\e135408\Downloads\mcp-servers\tools\BuildToggleRegistryLookup.ps1"

# Full refresh of DirectAPI file list (slow — scans all 10k files, ~5 min)
& "C:\Users\e135408\Downloads\mcp-servers\tools\BuildToggleRegistryLookup.ps1" -RefreshDirectAPIFileList
```

### When to Rebuild the Registry
- After any code release that may add new toggle constants
- If a toggle lookup returns `NOT_FOUND` unexpectedly
- If `DirectAPI` toggles are suspected to have moved to new files (run with `-RefreshDirectAPIFileList`)

---

## 17. Terminal & Tool Tricks, Traps and Known Issues

This section documents every terminal and tooling issue encountered across all sessions so future agents don't repeat the same mistakes.

---

### 🔴 TRAP 1: PowerShell Terminal Buffers Output from Long-Running Commands

**What happens**: When a large `Get-ChildItem | Select-String` scan runs across thousands of files, the terminal **buffers all output** and flushes it slowly — sometimes across **10–20+ subsequent commands**. Every new command you run appears to "succeed" but shows the previous command's buffered output instead of its own.

**Symptoms**:
```
PS> Write-Host "FRESH_OUTPUT"
[SchemeThrottle] Console :: ApplicationType.java:323 -> ...   ← OLD BUFFERED OUTPUT
```
You see the old output, not `FRESH_OUTPUT`. The terminal appears stuck.

**Why it happens**: PowerShell 5.1 on Windows streams output through a shared pipe buffer. A scan of 3,000+ Java files produces hundreds of KB of output that takes time to flush through the terminal capture mechanism.

**How to detect**: Run `Write-Host "TEST_$(Get-Date -Format HHmmss)"` — if you see anything other than your exact timestamp, the buffer is still flushing.

**Fix — Use background terminal + `get_terminal_output`**:
```powershell
# Launch as background process — returns immediately with an ID
# Use get_terminal_output(id) to poll results later
```
Background terminals have **independent buffers** — they never show stale output from other commands.

**Fix — Run one repo at a time**: Instead of `Get-ChildItem $CPE,$ORC -Recurse`, scan CPE and ORC separately in separate commands. Smaller output = faster flush.

**Fix — Verify with a clean marker** before reading results:
```powershell
Start-Sleep -Seconds 5; Write-Host "BUFFER_FLUSHED_$(Get-Date -Format HHmmss)"
# Only proceed when you see YOUR timestamp in the output
```

---

### 🔴 TRAP 2: PowerShell Pipe Characters (`|`) Inside `-Pattern` String Corrupt the Command

**What happens**: When you embed a regex alternation (`|`) inside a PowerShell string that's also part of a pipeline, the shell parser misinterprets it as a pipe operator, breaking the command silently or producing `ParserError`.

**Symptom**:
```powershell
# This FAILS — the | inside the string breaks the pipeline
Get-ChildItem ... | Select-String "Optimistic Lock|Scheme Throttle|Session Merge"
```
PowerShell sees `"Optimistic Lock` as the pattern and then tries to pipe `Scheme Throttle|Session Merge"` to the next command — resulting in a parser error or wrong results.

**Fix — Use separate variables or separate loops**:
```powershell
# SAFE: one pattern per call
$p1 = Get-ChildItem $CPE -Recurse -Include "*.java" | Select-String "Optimistic Lock" -SimpleMatch
$p2 = Get-ChildItem $CPE -Recurse -Include "*.java" | Select-String "Scheme Throttle" -SimpleMatch

# OR: use a foreach loop with individual patterns
foreach ($q in @("Optimistic Lock", "Scheme Throttle", "Session Merge")) {
  Get-ChildItem $CPE -Recurse -Include "*.java" | Select-String $q -SimpleMatch
}
```

**Fix — Use `-SimpleMatch` flag**: When `-SimpleMatch` is specified, `Select-String` treats the pattern as a plain string, not a regex — `|` is treated as a literal pipe character, not an alternation operator. This is the safest approach for toggle display string searches.

---

### 🔴 TRAP 3: PowerShell Foreach Loop Goes Into Multi-Line Input Mode (`>>` Prompt)

**What happens**: If you paste a multi-line `foreach` block into the terminal and the closing `}` is not recognized as complete, PowerShell enters `>>` continuation mode and waits for more input indefinitely — the entire terminal freezes for all subsequent commands.

**Symptom**: Terminal prompt changes from `PS C:\...>` to `>>` and nothing you type executes.

**Fix**: Type `}` and press Enter repeatedly until the prompt returns to `PS C:\...>`.

**Prevention**:
- Always run multi-line scripts via `run_in_terminal` as a single submitted block — never paste incrementally
- Test loop syntax locally before submitting
- Prefer single-line chained commands over multi-line blocks when possible:
  ```powershell
  # Single line — safer
  $results = @("Toggle1","Toggle2") | ForEach-Object { Get-ChildItem $CPE -Recurse -Include "*.java" | Select-String $_ -SimpleMatch | Select-Object -First 1 }
  ```

---

### 🔴 TRAP 4: `replace_string_in_file` on CSV Rows — Silent No-Op or Duplicate Insertion

**What happens**: Using `replace_string_in_file` to update a single cell or row in a large CSV file fails in two ways:

**Mode A — Silent no-op**: The tool finds no exact match (because the long CSV row content differs by a single character, trailing space, or line ending) and returns "success" without changing anything. The original NOT_FOUND row remains. You don't know it failed unless you re-read the file.

**Mode B — Duplicate row**: The tool matches in an unexpected location and inserts a new row rather than replacing the target. You end up with two identical rows for the same toggle.

**Both modes were hit in Session 4**:
- Lines 42 and 52 (OptimisticLock, SchemeThrottle) stayed as NOT_FOUND after replace was called ← **Mode A**
- Line 124 (Remove Orchestrator Session Merge) got duplicated to lines 124+125 ← **Mode B**

**Fix — NEVER use `replace_string_in_file` for CSV row updates. Use PowerShell direct array index write**:
```powershell
$path = "C:\path\to\file.csv"
$lines = [System.IO.File]::ReadAllLines($path, [System.Text.Encoding]::UTF8)

# Find the exact line index first
for ($i = 0; $i -lt $lines.Length; $i++) {
  if ($lines[$i] -match "Toggle Name To Replace") { Write-Host "Index: $i" }
}

# Replace by index (0-based)
$lines[41] = '"New","CSV","Row","Content"'

# Remove a duplicate (keep all lines EXCEPT the duplicate index)
$cleaned = [System.Collections.Generic.List[string]]::new()
for ($i = 0; $i -lt $lines.Length; $i++) {
  if ($i -eq 124) { continue }  # skip the duplicate
  $cleaned.Add($lines[$i])
}

# Write back
[System.IO.File]::WriteAllLines($path, $cleaned, [System.Text.Encoding]::UTF8)
```

**Always verify after any CSV write**:
```powershell
$rows = Import-Csv "C:\path\to\file.csv"
$rows | Where-Object { $_."Toggle Name" -eq "Target Toggle" } | Format-Table -AutoSize
Write-Host "Total rows: $($rows.Count)"
```

---

### 🔴 TRAP 5: `get_terminal_output(id)` Returns Stale/Partial Output — Must Poll

**What happens**: When a background terminal command is still running, `get_terminal_output` returns only the output captured so far — not the final result. If you read too early, you get incomplete results and may incorrectly conclude a search found nothing.

**Symptom**: Background search command shows only the first few `$q1`, `$q2` assignments in the output, then stops — the `=ALLSEARCHES_DONE=` marker never appears.

**Fix — Poll until completion marker appears**:
```powershell
# Add a final marker to your background command
... ; Write-Host "=SEARCH_COMPLETE_$(Get-Date -Format HHmmss)="
```
Keep calling `get_terminal_output(id)` until you see your completion marker in the output. Only then read the results.

**Fix — Don't run 17 searches in one background command**: Break into batches of 3–5 searches per background terminal. Each batch completes faster and the output is easier to read.

---

### 🟡 CAUTION 1: `Get-ChildItem $CPE,$ORC` Runs Both Searches in One Pipeline — Cannot Distinguish Repo

**What happens**: Passing two paths to `Get-ChildItem` combines results from both repos in one stream. You cannot tell from the output filename alone which repo a match came from (same filename may exist in both).

**Fix**: Always search repos separately and label results:
```powershell
$cpeHits = Get-ChildItem $CPE -Recurse -Include "*.java" | Select-String $pattern -SimpleMatch
$orcHits = Get-ChildItem $ORC -Recurse -Include "*.java" | Select-String $pattern -SimpleMatch
$cpeHits | ForEach-Object { "CPE:$($_.Filename):$($_.LineNumber)" }
$orcHits | ForEach-Object { "ORC:$($_.Filename):$($_.LineNumber)" }
```

---

### 🟡 CAUTION 2: Variable Interpolation in PowerShell Strings — `:` Triggers `DriveNotFound`

**What happens**: Inside a `Write-Host "..."` or `"$(...)"` expression, PowerShell interprets `:` after `$` as a drive specifier. `"LINE $i: $preview"` causes `ParserError: Variable reference is not valid. ':' was not followed by a valid variable name character`.

**Fix — Use `${}` syntax or string concatenation**:
```powershell
# FAILS:
Write-Host "LINE $i: $preview"

# WORKS:
Write-Host "LINE ${i}: $preview"
# OR:
Write-Host ("LINE " + $i + ": " + $preview)
```

---

### 🟡 CAUTION 3: `Select-String` Result Object Has `.Line` Not `.Content`

**What happens**: When you try to access the matched text via `.Content`, it returns nothing. The correct property is `.Line` (full line text) and `.LineNumber` (1-based).

**Correct usage**:
```powershell
$hits = Get-ChildItem $CPE -Recurse -Include "*.java" | Select-String "pattern" -SimpleMatch
$hits | ForEach-Object {
  Write-Host "$($_.Filename):$($_.LineNumber) -> $($_.Line.Trim())"
}
```

---

### 🟡 CAUTION 4: Long CSV Cell Content Truncated in `Format-Table`

**What happens**: Toggle ON/OFF impact descriptions are 200–500 chars. `Format-Table` truncates them with `...`. You cannot verify the full content.

**Fix — Use `Format-List` or select specific columns**:
```powershell
# See full content
$rows | Where-Object { $_."Toggle Name" -eq "target" } | Format-List *

# Or select only verification columns
$rows | Where-Object { $_."Toggle Name" -eq "target" } |
  Select-Object "Toggle Name","Implementation Class Name","Line Number Code","Repository" |
  Format-Table -AutoSize
```

---

### ✅ PROVEN PATTERNS — Copy-Paste Ready

#### Pattern A: Safe single-repo literal-string search
```powershell
$CPE = "C:\Users\e135408\IdeaProjects\MPGS\SourceCode\cardpaymentengine\src\main\java"
$hits = Get-ChildItem $CPE -Recurse -Include "*.java" |
        Select-String '"Toggle Display Name Here"' -SimpleMatch |
        Select-Object Filename, LineNumber, Line |
        Select-Object -First 5
$hits | ForEach-Object { Write-Host "CPE:$($_.Filename):$($_.LineNumber)" }
Write-Host "DONE"
```

#### Pattern B: Safe CSV row replacement by index
```powershell
$path = "C:\Users\e135408\Downloads\mcp-servers\jobs\TogglePageEnquiry\data\ToggleCodebaseUsageAnalysis.csv"
$lines = [System.IO.File]::ReadAllLines($path, [System.Text.Encoding]::UTF8)
# Find target index
$idx = -1
for ($i = 0; $i -lt $lines.Length; $i++) {
  if ($lines[$i] -match [regex]::Escape("Toggle Name To Update")) { $idx = $i; break }
}
Write-Host "Target index: $idx"
# Replace (only after confirming idx)
$lines[$idx] = '"New toggle row content here"'
[System.IO.File]::WriteAllLines($path, $lines, [System.Text.Encoding]::UTF8)
# Verify
$rows = Import-Csv $path
$rows | Where-Object { $_."Toggle Name" -eq "Toggle Name To Update" } |
  Select-Object "Toggle Name","Implementation Class Name","Repository" | Format-Table
```

#### Pattern C: Remove duplicate CSV row
```powershell
$path = "C:\Users\e135408\Downloads\mcp-servers\jobs\TogglePageEnquiry\data\ToggleCodebaseUsageAnalysis.csv"
$lines = [System.IO.File]::ReadAllLines($path, [System.Text.Encoding]::UTF8)
$seen = @{}; $clean = [System.Collections.Generic.List[string]]::new()
foreach ($line in $lines) {
  $key = $line.Substring(0, [Math]::Min(80, $line.Length))
  if (!$seen[$key]) { $seen[$key] = $true; $clean.Add($line) }
}
[System.IO.File]::WriteAllLines($path, $clean, [System.Text.Encoding]::UTF8)
Write-Host "After dedup: $($clean.Count) lines"
```

#### Pattern D: Check if terminal buffer is flushed
```powershell
Start-Sleep -Seconds 3
Write-Host "BUFFER_CHECK_$(Get-Date -Format HHmmss)"
# Only proceed if output shows YOUR timestamp
```


