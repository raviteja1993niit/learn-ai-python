Toggle Codebase Usage Analysis - Executive Summary & Strategy

COMPLETED PHASE 0: OPTIMIZATION SETUP
======================================

✓ Toggle Registry Lookup Cache Built
  - Location: C:\Users\e135408\Downloads\mcp-servers\jobs\TogglePageEnquiry\data\ToggleRegistryLookup.csv
  - Total Unique Toggle Declarations: 220
  - CPE Toggles: 207
  - Orchestrator Toggles: 45
  - Combined (deduplicated): 220
  - Contains: toggle_name, registry_class_name, registry_file_path, constant_name, repository
  
✓ Toggle Registry Classes Identified
  - CPE:
    * S2IAcquirerToggleConstants (195 toggles) - QSI\PaymentServer\acquirer\messagemapimpl\mastercard\
    * MerchantLoadBalancer (1 toggle) - System Toggle: CPE Load Balancer Uses Ping
    * CassandraThreeDsTogglesUtils (2 toggles) - PARes/VERes persistence toggles
    * Other scattered toggle declarations (9 toggles) in various classes
  - Orchestrator:
    * ToggleConstants (8 toggles) - com\dialect\orchestrator\constants\
    * AccountFundingValidator (3 toggles) - Account Funding related
    * AuthenticationAPIValidator (3 toggles) - Authentication monitoring
    * Various other classes (31 toggles)

INPUT CSV ANALYSIS
==================

Input File: FeatureToggleConfluencePageEnquiryResults.csv
Total Toggles to Analyze: 73 (rows 2-74)

Sample Toggles:
1. System Toggle: CPE Load Balancer Uses Ping (is_s2a=FALSE)
2. System Toggle: Enable Lookup up to 8 digit bin for Card Identification (is_s2a=FALSE)
3. Apply New Order ID Reuse Rule (is_s2a=FALSE)
4. System Toggle: Disables loading from orderCache in CPE for Transaction Retrieval (is_s2a=FALSE)
5. Enable TAF fields support for Passthrough (is_s2a=FALSE)
...
43. Send Authentication fields in RiskSPI and AuthenticationStatusCode field in TSPI (is_s2a=TRUE) [ONLY ONE S2A TOGGLE]

ANALYSIS BATCHES
================

Batch 1: Toggles 1-5 (Dry Run)
- System Toggle: CPE Load Balancer Uses Ping
- System Toggle: Enable Lookup up to 8 digit bin for Card Identification
- Apply New Order ID Reuse Rule
- System Toggle: Disables loading from orderCache in CPE for Transaction Retrieval
- Enable TAF fields support for Passthrough

Batch 2-3: Toggles 6-15
Batch 4-5: Toggles 16-25
... and so on until all 73 toggles are processed

OUTPUT CSV FORMAT
=================

File: ToggleCodebaseUsageAnalysis.csv
Columns: Toggle Name, Implementation Class Name, Line Number Code, Toggle ON Impact, Toggle OFF Impact, Repository
- One row per toggle USAGE location (not declaration)
- Same toggle can appear in multiple rows if used in multiple classes/files
- If toggle found in BOTH repos, create SEPARATE rows for each (dual-row separation rule)

KEY CONSTRAINTS & RULES
======================

Rule 1: Search ONLY in src/main/java/**/*.java (main production code)
Rule 2: EXCLUDE all test classes (*Test.java, *Tests.java, *Spec.java, /src/test/java/)
Rule 3: Use ToggleRegistryLookup.csv to filter out declaration-only matches
Rule 4: For S2A toggles (is_s2a=TRUE), check for MegaMessageMap, JsonMegaMessageMap, TSPI usage
Rule 5: Complete code path analysis - read ENTIRE if/else blocks
Rule 6: Dual-repository handling - if toggle found in CPE AND Orchestrator, create TWO SEPARATE ROWS

NEXT STEPS
==========

1. Run Batch 1 (Toggles 1-5) as DRY RUN
   - Extract toggle names from CSV
   - Search for usage in both repositories
   - Analyze complete code paths
   - Generate ToggleCodebaseUsageAnalysis.csv with 5 toggles
   - Validate output format
   
2. Review Batch 1 results
3. Process Batches 2-15 (remaining 68 toggles)
4. Generate final report

IMPORTANT NOTES
===============

- Toggle "System Toggle: CPE Load Balancer Uses Ping" is declared in MerchantLoadBalancer.java (line 56)
  but USED in same file at lines 82 and 195 - should have multiple rows if analyzed
  
- Toggle "Enable Account Funding enhanced functionality for Mastercard and Visa" is declared in:
  * S2IAcquirerToggleConstants.java (CPE) line 188
  * AccountFundingValidator.java (Orchestrator) line 143
  This is S2A-related and should generate 2+ rows (one per repository)

- Search must be robust to find all variations:
  * Quoted string matches: "toggleName"
  * Variable references: TOGGLE_CONSTANT_NAME
  * Method calls: Toggles.isToggleOn(toggleName), toggles.isEnabled(toggleName)

