# Repository Analysis Tools

This directory contains PowerShell scripts and batch wrappers for comprehensive repository analysis and documentation generation.

## Tools Overview

### 1. **Repository Tree Generator** (`generate-tree.ps1` / `run-generate-tree.bat`)
Generates a hierarchical tree view of the entire repository structure (files and folders).

**Features:**
- Full directory tree visualization
- Excludes large/unnecessary folders (target, .git, node_modules by default)
- Configurable recursion depth
- UTF-8 output support

**Usage:**
```batch
:: Generate tree with depth limit of 3 levels
run-generate-tree.bat 3

:: Generate tree with no depth limit
run-generate-tree.bat -1

:: Generate with custom output filename
run-generate-tree.bat 3 my-tree.txt
```

**Output:** `<repo_name>-tree.txt` (default location: repository root)

---

### 2. **Java Class Tree Generator** (`generate-java-tree.ps1` / `run-generate-java-tree.bat`)
Generates a comprehensive listing of all Java classes organized by package with fully qualified names.

**Features:**
- Complete Java class enumeration
- Organized by package structure
- Fully qualified class names
- Supports main, test, or all source files
- Package-based grouping

**Usage:**
```batch
:: Generate list of main source classes
run-generate-java-tree.bat main

:: Generate list including test classes
run-generate-java-tree.bat all

:: Generate with custom output filename
run-generate-java-tree.bat main my-java-classes.txt
```

**SourceType Options:**
- `main` (default) - Only source classes from `src/main/java`
- `test` - Only test classes from `src/test/java`
- `all` - Both source and test classes

**Output:** `<repo_name>-java-tree.txt` (default location: repository root)

**Sample Output:**
```
Java Class Structure - orchestrator
============================================================

Total Java Classes: 751
Total Packages: 74

============================================================

Package: com.dialect.orchestrator.axon.config
  |-- AxonCommonConfig  (com.dialect.orchestrator.axon.config.AxonCommonConfig)
  +-- AxonTopicConfig  (com.dialect.orchestrator.axon.config.AxonTopicConfig)
```

---

### 3. **Repository Memory Mapper** (`repo-memory-mapper.ps1` / `run-repo-memory-mapper.bat`)
Analyzes Java classes and generates a CSV memory map with class responsibilities and S2A transaction flow tracking.

**Features:**
- Automatic class type classification (Controller, Service, Repository, Model, etc.)
- S2A transaction flow detection
- Dependency analysis
- CSV export for easy analysis
- Priority-based organization

**Usage:**
```batch
:: Generate memory map for main source classes
run-repo-memory-mapper.bat 5

:: Generate map including test classes
run-repo-memory-mapper.bat 5 memory-map.csv true

:: Custom output file
run-repo-memory-mapper.bat -1 custom-map.csv
```

**Parameters:**
- `MaxDepth` (optional) - Recursion depth (default: 5, -1 for unlimited)
- `OutputFile` (optional) - Custom output filename
- `IncludeTests` (optional) - Include test classes (true/false)

**Output:** `<repo_name>-memory-map.csv` (default location: repository root)

**CSV Columns:**
| Column | Description |
|--------|-------------|
| CLASS_NAME | Simple class name |
| PACKAGE | Java package name |
| CLASS_TYPE | Classification (Controller, Service, Repository, Model, Utility, Config, Exception, Listener, Interceptor, Other) |
| RESPONSIBILITY | Brief description of class purpose |
| IS_S2A_FLOW | Yes/No - Indicates if class is involved in S2A transactions |
| S2A_DETAILS | Details about S2A implementation if applicable |
| DEPENDENCIES | Related classes or services |
| FILE_PATH | Relative path to source file |
| PRIORITY | High/Medium/Low based on classification |
| NOTES | Additional observations |

**Sample Output:**
```csv
CLASS_NAME,PACKAGE,CLASS_TYPE,RESPONSIBILITY,IS_S2A_FLOW,S2A_DETAILS,DEPENDENCIES,FILE_PATH,PRIORITY,NOTES
SessionManager,com.dialect.utility,Service,Business logic service for SessionManager,Yes,Pattern: Mobile/App Transaction,,src\main\java\com\dialect\utility\SessionManager.java,High,
PaymentServer,com.example,Other,Class: PaymentServer,Yes,Keyword: S2A,,src\main\java\com\example\PaymentServer.java,High,
```

---

## Dynamic Repository Detection

All scripts automatically detect the repository root by searching for common markers:
1. `.git` folder (Git repositories)
2. `pom.xml` (Maven projects)
3. `package.json` (Node.js projects)
4. `.sln` file (Visual Studio solutions)

The search starts from the current directory and walks up the directory tree until a marker is found.

**Example:**
```
C:\projects\repo\src\main\java> run-generate-java-tree.bat main
# Automatically detects repo root as: C:\projects\repo
```

---

## Agent Integration

### Repository Memory Mapper Agent

The `repo-memory-mapper` agent can be invoked to automate memory map generation:

```
run_subagent(
  agentName: "repo-memory-mapper",
  task: "Analyze the orchestrator repository and generate a comprehensive memory map CSV with S2A flow tracking"
)
```

---

## Output Specifications

### File Naming Convention
All generated files follow the pattern: `<repo_name>-<type>.txt`

Examples:
- `orchestrator-tree.txt` - Full directory tree
- `orchestrator-java-tree.txt` - Java classes organized by package
- `orchestrator-memory-map.csv` - Class analysis and S2A tracking

### Default Output Location
All files are generated in the repository root directory for easy access.

---

## Exclusion Rules

### Repository Tree Generator
Default excluded folders (configurable):
- `target` - Maven build output
- `.git` - Git metadata
- `node_modules` - Node.js dependencies

### Java Tree Generator
Includes all `.java` files from `src/main/java` and `src/test/java`

### Memory Mapper
Analyzes all Java classes and applies pattern-based classification

---

## Classification Types (Memory Mapper)

The Memory Mapper automatically classifies Java classes:

| Type | Pattern Keywords | Examples |
|------|------------------|----------|
| Controller | Controller, Servlet, Rest, Http | PaymentController, TransactionServlet |
| Service | Service, Manager, Processor, Handler | PaymentService, OrderManager |
| Repository | Repository, Dao, Mapper, Query | UserRepository, OrderDao |
| Model | Entity, Model, VO, DTO, Request, Response | PaymentEntity, OrderRequest |
| Config | Config, Configuration, Settings, Properties | AppConfig, DatabaseProperties |
| Utility | Util, Helper, Tools, Convert, Parser, Builder | DateUtil, CryptHelper |
| Exception | Exception, Error, ErrorHandler | PaymentException, ErrorHandler |
| Listener | Listener, Observer, Callback | OrderListener, EventObserver |
| Interceptor | Interceptor, Filter, Middleware | AuthInterceptor, LoggingFilter |
| Other | (Default) | CustomClass, Helper, etc. |

---

## S2A Flow Detection

The Memory Mapper detects S2A (Server-to-App) transaction patterns by searching for:

**Keywords:**
- S2A, s2a, serverToApp, ServerToApp
- S2A_FLOW, s2a_flow
- S2ATransaction, MobileTransaction, AppTransaction

**Patterns:**
- Mobile/App transaction methods
- S2A-specific handlers
- Server-app flow implementations

---

## Quick Start

### Generate All Analysis Files
```batch
:: From project root, run all three tools
run-generate-tree.bat -1
run-generate-java-tree.bat all
run-repo-memory-mapper.bat -1 memory-map.csv true
```

### From Any Subdirectory
```batch
:: Scripts automatically find repo root
cd C:\projects\repo\src\main\java
run-generate-java-tree.bat main
# Output: C:\projects\repo\repo-java-tree.txt
```

---

## Performance Characteristics

**Repository Size: 750 Java files**
- Tree Generation: ~2 seconds
- Java Tree Generation: ~30 seconds
- Memory Map Generation: ~35 seconds

**Repository Size: 2400 Java files**
- Tree Generation: ~3 seconds
- Java Tree Generation: ~70 seconds
- Memory Map Generation: ~70 seconds

---

## Troubleshooting

### Issue: "No Java files found"
**Solution:** Ensure repository has `src/main/java` or `src/test/java` directory structure

### Issue: Too large output files
**Solution:** Use MaxDepth parameter to limit recursion depth:
```batch
run-generate-tree.bat 2
run-repo-memory-mapper.bat 3
```

### Issue: Script execution policy error
**Solution:** Scripts use `-ExecutionPolicy Bypass` flag. If still blocked, run from PowerShell administrator

---

## Integration Examples

### Confluence Documentation Generation
Use the Java tree to create API documentation:
```
1. Generate Java tree: run-generate-java-tree.bat all
2. Parse output and create Confluence pages
3. Include memory map for architecture overview
```

### Code Review and Auditing
Use memory map for:
```
1. Identify S2A transaction dependencies
2. Track class responsibilities
3. Understand component relationships
4. Plan refactoring efforts
```

### Architecture Analysis
```
1. Generate memory map
2. Filter for high-priority classes
3. Analyze dependency patterns
4. Identify potential improvements
```

---

## Version Information

- **PowerShell Requirement:** PowerShell 5.1+
- **OS Support:** Windows (PowerShell)
- **Last Updated:** April 10, 2026

---

## License & Usage

These tools are provided as-is for repository analysis and documentation purposes. No sensitive data is included in generated files (filenames and structure only).

