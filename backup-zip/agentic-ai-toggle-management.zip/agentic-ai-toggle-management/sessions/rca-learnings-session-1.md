# Root Cause Analysis: Toggle #8 False Negative

**Date**: April 10, 2026  
**Issue**: Toggle "Enable issuer country code in transaction response" reported as NOT_FOUND  
**Status**: RESOLVED — Found in CardTypeDetailsDecorator.java:124  
**Impact**: 1 row corrected in ToggleCodebaseUsageAnalysis.csv

---

## Executive Summary

During Batch 1 analysis, Toggle #8 was incorrectly reported as NOT_FOUND. Manual inspection by user revealed the toggle exists in `CardTypeDetailsDecorator.java` at line 124 in CPE repository. Root cause analysis identified a three-part search failure pattern that is reproducible and must be prevented in remaining 68 toggles (Batches 2-15).

---

## Incident Details

### Toggle Information
| Property | Value |
|---|---|
| **Toggle Name** | Enable issuer country code in transaction response |
| **CSV Row** | 12 |
| **Confluence is_s2a** | FALSE |
| **Actual Implementation** | CardTypeDetailsDecorator.java (CPE), line 124 |
| **Constant Name** | ENABLE_ISSUER_COUNTRY_CODE_IN_TRANSACTION_RESPONSE |
| **Repository** | CPE |

### Initial (Incorrect) Result
```csv
"Enable issuer country code in transaction response","NOT_FOUND","N/A","Status: NOT_FOUND...","Status: NOT_FOUND...","UNKNOWN"
```

### Corrected Result
```csv
"Enable issuer country code in transaction response","CardTypeDetailsDecorator","124","Business: When enabled, issuer country code (A3 country code in ISO 3166-1 alpha-3 format) is populated in the transaction response for cardTypeDetails. The gateway retrieves the issuer country from order.getGatewayCardCountryOfIssue() and validates it against ISO 3166-1 alpha-3 standard before setting cardTypeDetails.setIssuerCountry(). Merchants receive issuerCountryCode in Retrieve Transaction/Order responses. Field Impact: sourceOfFunds.provided.card.issuerCountryCode (TSPI/merchant API response field) populated with validated A3 country code when available and toggle enabled.","Business: When disabled, issuer country code is not populated in transaction responses — cardTypeDetails.getIssuerCountry() remains null and issuerCountryCode field absent from API responses. Merchants do not receive country of card issuance information in retrieve operations. Field Impact: sourceOfFunds.provided.card.issuerCountryCode not populated; retrieval responses do not include issuer country data.","CPE"
```

### Code Context (Actual Implementation)
```java
// CardTypeDetailsDecorator.java, line 70
private static final String ENABLE_ISSUER_COUNTRY_CODE_IN_TRANSACTION_RESPONSE = 
    "Enable issuer country code in transaction response";

// Lines 124-137: Implementation in run() method
if (Toggles.isToggleOn(ENABLE_ISSUER_COUNTRY_CODE_IN_TRANSACTION_RESPONSE) 
    && cardTypeDetails.getIssuerCountry() == null) {
    String issuerCountryA3Code = order.getGatewayCardCountryOfIssue();
    if (StringUtils.isNotBlank(issuerCountryA3Code)) {
        if (Iso3166A3CountryCodeValidator.isValidCountryCode(issuerCountryA3Code)) {
            cardTypeDetails.setIssuerCountry(issuerCountryA3Code);
        } else {
            LOGGER.warn("Invalid issuer country A3 code: {0}...", issuerCountryA3Code, ISO_3166_A3_CODE_LENGTH);
        }
    }
}
```

---

## Root Cause Analysis: Three-Part Failure

### Failure Mode 1: Fragmented Search Terms (Search Strategy Failure)

**What Happened**:
Search strategy used fragmented keywords: `issuer country code | issuerCountryCode | ISSUER_COUNTRY`

**Why It Failed**:
- The actual constant identifier is `ENABLE_ISSUER_COUNTRY_CODE_IN_TRANSACTION_RESPONSE`
- None of the fragments match the full constant name
- Fragment `ISSUER_COUNTRY` is missing the `CODE` part
- Fragment `country code` doesn't match `country of issue` semantics

**Pattern Root Cause**:
Toggle name decomposition into fragments is LOSSY. Multi-word toggle names like "Enable issuer country code in transaction response" (7 words) cannot be reliably reconstructed from 2-3 word chunks.

**Lesson Learned**:
❌ **DO NOT** fragment toggle names into search terms  
✅ **DO** search the COMPLETE toggle display name as a single literal string FIRST

**Prevention**:
```
Phase 3A Search Sequence (REVISED):
  1. LITERAL STRING SEARCH (quotes included): grep_search('"Enable issuer country code..."')
     → Catches constant declarations via exact match
     → MUST be primary method
  
  2. CONSTANT NAME SEARCH: grep_search('CONSTANT_NAME_FROM_REGISTRY')
     → Catches usage points
  
  3. KEYWORD SEARCH (fallback only): grep_search('issuer.*country')
     → Use only if 1-2 fail
     → High false-positive risk — manually validate results
```

---

### Failure Mode 2: Package Hierarchy Assumption (Architecture Failure)

**What Happened**:
Search was implicitly scoped to packages expected for similar toggles (MEA PVL found in acquirer packages), so search may have focused on:
- `QSI/PaymentServer/acquirer/messagemapimpl/` (expected for S2I/acquirer toggles)
- `com/mastercard/gateway/processor/` (expected for processing toggles)

Toggle was actually in:
- `com/mastercard/gateway/retrieval/decorator/CardTypeDetailsDecorator.java`

**Why It Failed**:
This is a DECORATOR pattern class that wraps retrieval results, not an acquirer/processor class. Toggles affecting response data population are often in decorator/wrapper classes, not core processing classes.

**Pattern Root Cause**:
MPGS codebase uses multiple architectural patterns:
- **Acquirer pattern**: Toggles controlling S2I/MEGA message building → `/acquirer/messagemapimpl/`
- **Processor pattern**: Toggles controlling transaction processing → `/processor/`
- **Decorator pattern**: Toggles controlling response data enrichment → `/decorator/`
- **Service pattern**: Toggles controlling service behavior → `/service/`, `/protectionService/`
- **Core pattern**: Toggles controlling fundamental behavior → `/core/`

Each pattern scatters toggles across different packages.

**Lesson Learned**:
❌ **DO NOT** assume all toggles follow one package hierarchy  
❌ **DO NOT** limit search to "expected" packages based on similar toggles  
✅ **DO** search the entire codebase: `src/main/java/**/*.java`

**Prevention**:
```
MANDATORY SEARCH SCOPE:
  includePattern: 'src/main/java/**/*.java'
  (Always ALL Java files — never restrict to assumed packages)

HIGH-RISK LOCATIONS FOR FALSE NEGATIVES:
  - Decorator pattern: /decorator/, *Decorator.java
  - Helper/utility: /helper/, *Helper.java, *Utility.java
  - Validator: /validator/, *Validator.java
  - Manager: /manager/, *Manager.java
  - Service wrappers: /service/, *Service.java
  
SEARCH VALIDATION:
  After finding toggle in ONE package, EXPAND search to verify you haven't missed duplicates in OTHER packages
```

---

### Failure Mode 3: No Literal String Search with Quotes (Search Execution Failure)

**What Happened**:
Search did not include the constant declaration lookup using the LITERAL STRING with quotes.

**Why It Failed**:
Java code declares the toggle as:
```java
private static final String ENABLE_ISSUER_COUNTRY_CODE_IN_TRANSACTION_RESPONSE = 
    "Enable issuer country code in transaction response";
```

A grep search for the quoted string `"Enable issuer country code in transaction response"` would immediately locate this declaration:
```
grep -r '"Enable issuer country code in transaction response"' src/main/java
```

This pattern was not used, missing a quick way to find the declaration.

**Pattern Root Cause**:
Assumption that grep_search with the display name would find usage points. In reality, finding the CONSTANT DECLARATION (with quotes) first is the fastest way to:
1. Locate the file
2. Extract the constant identifier
3. Verify the constant exists
4. Then search for usage points

**Lesson Learned**:
❌ **DO NOT** skip the declaration search  
✅ **DO** search for the literal quoted string FIRST as a declaration finder

**Prevention**:
```
MANDATORY SEARCH #1 - Literal String Declaration Search:
  grep_search(query = '"Enable issuer country code in transaction response"', 
              includePattern = 'src/main/java/**/*.java')
  
  → This ALWAYS finds the constant declaration line
  → Result identifies file and confirms constant exists
  → Then extract constant_name and search for usage

EXAMPLE RESULT:
  Found in CardTypeDetailsDecorator.java line 70:
    private static final String ENABLE_ISSUER_COUNTRY_CODE_IN_TRANSACTION_RESPONSE = 
        "Enable issuer country code in transaction response";
  
  This tells us:
    - File: CardTypeDetailsDecorator.java ✓
    - Constant name: ENABLE_ISSUER_COUNTRY_CODE_IN_TRANSACTION_RESPONSE ✓
    - Exists: YES ✓
    → Now search for `ENABLE_ISSUER_COUNTRY_CODE_IN_TRANSACTION_RESPONSE` in same file for usage
```

---

## Prevention Strategy: Enhanced Search Methodology

### Revised Phase 3A Search Sequence (MANDATORY FOR ALL 73 TOGGLES)

This sequence replaces the original Phase 3A methodology:

#### Search Step 1: Literal String Declaration Search (PRIMARY - ALWAYS FIRST)
```
Pattern: "Toggle display name exactly as written"
Example: grep_search('"Enable issuer country code in transaction response"', includePattern='src/main/java/**/*.java')
Repositories: Both CPE and Orchestrator

Purpose:
  - Locate the constant declaration line
  - Verify toggle constant exists in codebase
  - Find the file and get the constant identifier

Success Criteria:
  - Found declaration line with `private static final String CONSTANT_NAME = "..."`
  - Extract the constant identifier from the line

Failure Handling:
  - 0 results → Proceed to Step 2 (search by constant name)
  - Multiple files → Check all for DECLARATIONS vs IMPLEMENTATIONS
```

#### Search Step 2: Constant Name Registry Search (SECONDARY)
```
Pattern: Constant name from ToggleRegistryLookup.csv
Example: grep_search('ENABLE_ISSUER_COUNTRY_CODE_IN_TRANSACTION_RESPONSE', includePattern='src/main/java/**/*.java')
Repositories: Both CPE and Orchestrator

Purpose:
  - Find all usage locations of the toggle by constant name
  - Catch variations if constant is aliased differently in different files

Success Criteria:
  - Found usage points where toggle is evaluated: `if (Toggles.isToggleOn(CONSTANT_NAME))`

Failure Handling:
  - 0 results in Step 1 AND 0 results here → Proceed to Step 3 (keyword fallback)
```

#### Search Step 3: Keyword Fallback Search (TERTIARY - HIGH FALSE-POSITIVE)
```
Pattern: 2-3 word keywords from toggle name
Example: grep_search('issuer.*country|country.*code|issuer.*code', includePattern='src/main/java/**/*.java')
Repositories: Both CPE and Orchestrator

Purpose:
  - Last resort validation when Steps 1-2 fail
  - Identify toggle variants or codenames
  - Catch if toggle name differs from constant value

Success Criteria:
  - Identified possible matches
  - Manually validate which are related to the toggle

Failure Handling:
  - Manually validate all matches (high false-positive risk)
  - If no valid matches after validation → Proceed to NOT_FOUND status
```

### Validation Checklist (BEFORE MARKING NOT_FOUND)

**For every toggle reported as NOT_FOUND, verify ALL of these:**

```
SEARCH EXECUTION:
  ☐ Step 1: Literal string search executed in BOTH CPE and Orchestrator
  ☐ Step 2: Constant name search executed in BOTH CPE and Orchestrator
  ☐ Step 3: Keyword fallback executed in BOTH CPE and Orchestrator
  
REGISTRY VERIFICATION:
  ☐ Toggle name exists in ToggleRegistryLookup.csv?
  ☐ Constant name extracted and searched?
  
PACKAGE EXPANSION:
  ☐ Search NOT limited to assumed packages?
  ☐ Entire src/main/java scanned, not subset?
  
ARCHITECTURE PATTERN CHECK:
  ☐ If card-related toggle: checked /decorator/, /retrieval/ packages?
  ☐ If response-related toggle: checked /response/, /decorator/ packages?
  ☐ If acquirer toggle: checked /acquirer/ AND other packages?
  
CROSS-REPOSITORY:
  ☐ Searched CPE src/main/java/**/*.java?
  ☐ Searched Orchestrator src/main/java/**/*.java?
  ☐ If found in CPE: also checked Orchestrator for dual-repo patterns?
  
FILE INSPECTION:
  ☐ Related classes manually inspected?
    (e.g., CardTypeDetailsDecorator searched for card-related toggles)
  ☐ Decorator and Helper classes checked if related?
  
NOT_FOUND ONLY AFTER:
  ☐ All 3 search steps completed with 0 matches
  ☐ All checks above passed
  ☐ Manual inspection confirmed
  
Status Assignment:
  ✓ Can assign NOT_FOUND
  ✗ Cannot assign — must re-search
```

---

## High-Risk Toggle Categories for False Negatives

Based on Toggle #8 analysis, the following categories have elevated false-negative risk:

### Category 1: Response/Retrieval Data Toggles
**Pattern**: Toggles controlling what data is populated in API responses

**Examples**:
- "Enable issuer country code in transaction response" (Toggle #8) — FOUND in CardTypeDetailsDecorator
- "System Toggle: Use 8_4 Masked PAN for Scheme Token Transaction Response" (Toggle #22) — currently NOT_FOUND

**Where to Search**:
- `/retrieval/` packages
- `*Decorator.java` classes
- `*Response*.java` classes
- `*Mapper.java` classes (data mapping)

**Search Strategy**:
```
grep_search('"Enable issuer country code..."', includePattern='src/main/java/**/*Decorator*.java')
grep_search('"Enable issuer country code..."', includePattern='src/main/java/**/retrieval/**/*.java')
grep_search('"Enable issuer country code..."', includePattern='src/main/java/**/*Response*.java')
```

### Category 2: Card/Cardholder Data Toggles
**Pattern**: Toggles controlling card identification, BIN lookup, masking

**Examples**:
- "Enable Lookup up to 8 digit bin for Card Identification" (Toggle #4) — FOUND
- "Retrieve Card Bin Set Id for Subsequent Transactions" (Toggle #32) — currently NOT_FOUND

**Where to Search**:
- `/cardservice/` packages
- `*Card*.java` classes
- `*BinBase*.java` classes
- `*BinSet*.java` classes
- `/decorator/` if data enrichment

**Search Strategy**:
```
grep_search('"Retrieve Card Bin Set Id..."', includePattern='src/main/java/**/cardservice/**/*.java')
grep_search('BinSetId', includePattern='src/main/java/**/*.java')
grep_search('"Retrieve Card Bin Set Id..."', includePattern='src/main/java/**/*BinSet*.java')
```

### Category 3: Multi-Word Toggle Names (>3 words)
**Pattern**: Long toggle names prone to fragmentation

**Examples**:
- "Enable issuer country code in transaction response" (7 words) — FOUND
- "Get Most Recent Transaction as Initial Transaction If Auto-Capture Failed in Settlement Transaction" (14 words) — NOT_FOUND

**Risk**: More fragmentation opportunities = higher false-negative risk

**Search Strategy**:
```
1. ALWAYS use literal string first (not fragments)
2. Use entire phrase in grep_search
3. Don't decompose into keywords until Step 3 fallback
```

### Category 4: Feature Authentication/Validation Toggles
**Pattern**: Toggles controlling authentication features, validation

**Examples**:
- "Enable TAF fields support for Passthrough" (Toggle #11) — currently NOT_FOUND
- Visa/Mastercard specific features

**Where to Search**:
- `/validation/`, `/validator/` packages
- `*Validator.java` classes
- `*Authentication*.java` classes
- `*Helper.java` utility classes

**Search Strategy**:
```
grep_search('"Enable TAF fields..."', includePattern='src/main/java/**/validation/**/*.java')
grep_search('"Enable TAF fields..."', includePattern='src/main/java/**/*Validator*.java')
grep_search('TAF.*passthrough|passthrough.*TAF', includePattern='src/main/java/**/*.java')
```

### Category 5: Protection/Security Service Toggles
**Pattern**: Toggles controlling protection, security, risk assessment

**Examples**:
- "Log Acquirer Details for Sanctioned Transactions" (Toggle #15) — currently NOT_FOUND
- Protection service, risk assessment, fraud detection

**Where to Search**:
- `/protectionService/` packages
- `/security/` packages
- `*Protection*.java` classes
- `*Risk*.java` classes
- `*Fraud*.java` classes

**Search Strategy**:
```
grep_search('"Log Acquirer Details..."', includePattern='src/main/java/**/protectionService/**/*.java')
grep_search('"Log Acquirer Details..."', includePattern='src/main/java/**/*Protection*.java')
grep_search('Sanctioned.*[Tt]ransaction|[Ss]anctioned.*[Ll]og', includePattern='src/main/java/**/*.java')
```

---

## NOT_FOUND Toggles That Should Be Re-Checked (Session 1 Candidate List)

Based on RCA, the following NOT_FOUND toggles have a MEDIUM-TO-HIGH probability of being false negatives:

| Row | Toggle Name | Category | Risk Level | Recommended Re-Check Packages |
|---|---|---|---|---|
| 11 | Enable TAF fields support for Passthrough | Authentication | MEDIUM | /validation/, *Validator, *Helper |
| 15 | Log Acquirer Details for Sanctioned Transactions | Protection/Security | MEDIUM | /protectionService/, *Protection, *Risk |
| 18 | Unify Order Creation Time In Retrieval | Response/Retrieval | MEDIUM | /retrieval/, *Decorator, *Response |
| 22 | System Toggle: Enable 8-4 PAN Masking in API Response | Response/Masking | MEDIUM | /response/, *Decorator, *Mapper |
| 32 | Retrieve Card Bin Set Id for Subsequent Transactions | Card/BIN | MEDIUM | /cardservice/, *BinSet, *Card |

**Low-Risk NOT_FOUND Toggles** (likely genuine):
- Row 23: "System Toggle: Honour DoNotProcessAfterTime..." — system feature, probably constants only
- Row 24+: System/infrastructure toggles — less likely to be scattered

---

## Action Items for Future Sessions

### For Batches 2-15 (Remaining 68 Toggles):

1. **Implement Enhanced Search Sequence**:
   - Use Phase 3A search sequence with all 3 steps (literal → constant → keyword)
   - Document which step found the toggle

2. **Apply Validation Checklist**:
   - Before marking any toggle NOT_FOUND, run through all 8 points
   - Document which checks passed/failed

3. **Monitor High-Risk Categories**:
   - When processing toggles matching patterns in "High-Risk Categories" section above
   - Apply expanded search to decorator/helper/response classes

4. **Cross-Repository Validation**:
   - After finding toggle in one repo, ALWAYS verify the other
   - Document if dual-repo usage exists

5. **Before Final Submission**:
   - Re-check the 5 medium-risk NOT_FOUND toggles using improved methodology
   - Generate updated report with corrected counts

---

## Corrected Analysis Metadata

| Metric | Value |
|---|---|
| **Session 1 Initial Analysis** | 72 rows (1 error) |
| **Corrections Made** | Row 12 corrected from NOT_FOUND to FOUND |
| **Final Analysis** | 72 rows (0 errors — assuming no other issues) |
| **Quality Assurance Status** | MEDIUM (1 false negative found; applies learning forward) |
| **Critical Risk Identified** | Fragmented search, architecture assumption, missing literal search |

---

## References

- **Main RCA location**: toggle-codebase-usage-analyzer.agent.md (§ "Lessons Learned: Critical Failure Mode RCA")
- **Execution guide update**: NEW_SESSION_EXECUTION_GUIDE.md (§ "16. CRITICAL LEARNED LESSON")
- **Corrected output**: ToggleCodebaseUsageAnalysis.csv (Row 12)
- **Discovered file**: CardTypeDetailsDecorator.java, lines 70 & 124-137
- **Discovery date**: Session 1, April 10, 2026

---

**Document Version**: 1.0  
**Last Updated**: April 10, 2026  
**Status**: COMPLETE — Learnings integrated into agent and execution guide documentation

---

## Session 2 Findings: NOT_FOUND Toggle Re-Check Results

Using the improved search methodology from RCA, re-checked 5 high-risk NOT_FOUND toggles. Found that **4 of them actually exist as declarations** (constants defined but not used in conditional logic).

### False Negatives Corrected (4 toggles)

| Row | Toggle Name | Original Status | Corrected Status | Location | Line |
|---|---|---|---|---|---|
| 11 | Enable TAF fields support for Passthrough | NOT_FOUND | FOUND_DECLARATION_ONLY | S2IAcquirerToggleConstants (CPE) | 139 |
| 15 | Log Acquirer Details for Sanctioned Transactions | NOT_FOUND | FOUND_DECLARATION_ONLY | SanctionHelper (Orchestrator) | 327 |
| 18 | Unify Order Creation Time In Retrieval | NOT_FOUND | FOUND_DECLARATION_ONLY | TransactionDataCommonService (Orchestrator) | 157 |
| 32 | Retrieve Card Bin Set Id for Subsequent Transactions | NOT_FOUND | FOUND_DECLARATION_ONLY | MerchantBase (CPE) | 212 |

### Why These Were Missed in Initial Analysis

All 4 toggles follow the pattern of **DECLARATION-ONLY: toggle constants defined in Java classes but NOT evaluated in conditional logic anywhere in the codebase**.

This represents a different category than the Toggle #8 issue:
- **Toggle #8 problem**: Toggle EXISTS and IS USED but was missed due to poor search methodology
- **Toggles 11,15,18,32 problem**: Toggles EXIST as constants but have NO USAGE, making them genuinely partial implementations

The initial analysis marked them NOT_FOUND because searches were looking for USAGE patterns (where toggle is evaluated), not DECLARATIONS (where constant is defined).

### Search Methodology That Caught These

Applied **Step 1: Literal Display String Search** from Enhanced Search Methodology:
```
grep_search('"Enable TAF fields support for Passthrough"', includePattern='src/main/java/**/*.java')
grep_search('"Log Acquirer Details for Sanctioned Transactions"', includePattern='src/main/java/**/*.java')
grep_search('"Unify Order Creation Time In Retrieval"', includePattern='src/main/java/**/*.java')
grep_search('"Retrieve Card Bin Set Id for Subsequent Transactions"', includePattern='src/main/java/**/*.java')
```

Result: Found all 4 declarations, then verified no usage points exist by searching for constant identifiers.

### Genuine NOT_FOUND (1 toggle)

| Row | Toggle Name | Status | Notes |
|---|---|---|---|
| 22 | System Toggle: Enable 8-4 PAN Masking in API Response | NOT_FOUND | No declaration or usage found in either CPE or Orchestrator |

---

## Key Lesson: Declaration-Only vs NOT_FOUND

The RCA identified two different failure modes:

1. **True False Negatives** (like Toggle #8): Toggle EXISTS and IS USED but search methodology missed it
   - Solution: Literal string search, expanded package scope, non-assumption-based approach

2. **Declaration-Only Classifications** (like Toggles 11,15,18,32): Toggle EXISTS as constant but has NO USAGE
   - These are NOT false negatives—they're correctly classified as FOUND but not implemented
   - Initial analysis marked them NOT_FOUND because it looked for usage patterns only
   - New analysis correctly identifies them as FOUND_DECLARATION_ONLY

3. **Genuine NOT_FOUND** (like Toggle #22): No trace of toggle anywhere
   - These are genuinely not in codebase

---

## CSV Update Summary

**Total toggles corrected**: 4  
**Status changes**: NOT_FOUND → FOUND_DECLARATION_ONLY  
**File**: ToggleCodebaseUsageAnalysis.csv (Rows 11, 15, 18, 32)  
**Date updated**: April 10, 2026 (Session 2)

**Before corrections**:
- 20 NOT_FOUND toggles in output CSV

**After corrections**:
- 16 NOT_FOUND toggles (reduced by 4)
- 4 FOUND_DECLARATION_ONLY toggles (added)

---

## Work Completion Summary

### Session 2 Deliverables

**Date**: April 10, 2026  
**Scope**: NOT_FOUND toggle re-check using improved search methodology  
**Results**: 4 false negatives identified and corrected  

### Changes Made

1. **Documentation Updates**:
   - ✅ Added comprehensive RCA section to `toggle-codebase-usage-analyzer.agent.md` (§ "Lessons Learned")
   - ✅ Added detailed prevention strategy to `NEW_SESSION_EXECUTION_GUIDE.md` (§ "16. CRITICAL LEARNED LESSON")
   - ✅ Both documents now include enhanced search methodology, validation checklist, and high-risk toggle categories

2. **CSV Corrections**:
   - ✅ Row 11: "Enable TAF fields support for Passthrough" → S2IAcquirerToggleConstants:139
   - ✅ Row 15: "Log Acquirer Details for Sanctioned Transactions" → SanctionHelper:327
   - ✅ Row 18: "Unify Order Creation Time In Retrieval" → TransactionDataCommonService:157
   - ✅ Row 32: "Retrieve Card Bin Set Id for Subsequent Transactions" → MerchantBase:212

3. **Search Validation**:
   - ✅ Applied Step 1 (Literal Display String Search) from enhanced methodology
   - ✅ Applied Step 2 (Constant Name Search) for verification
   - ✅ Confirmed 4 declarations with NO USAGE points
   - ✅ Verified 1 toggle remains genuinely NOT_FOUND (Toggle #22 - 8-4 PAN Masking)

### Key Findings

**NOT_FOUND → FOUND_DECLARATION_ONLY (4 toggles)**:
These toggles exist as Java constants but are NOT evaluated in conditional logic anywhere in the codebase. This is a valid state (declaration without implementation).

**Pattern Identified**:
- All 4 are in toggle constant registry classes (S2IAcquirerToggleConstants, SanctionHelper, TransactionDataCommonService, MerchantBase)
- None have corresponding usage patterns (if statements, conditional evaluations)
- Represent incomplete feature implementations or planned features

**Lessons Applied**:
- Literal string searches (with quotes) successfully locate declarations
- Declaration-only toggles are different from true false negatives
- Improved methodology catches BOTH declaration-only and missing-entirely cases

### Quality Metrics

| Metric | Value |
|---|---|
| **Toggles re-checked (high-risk)** | 5 |
| **False negatives corrected** | 4 |
| **Genuinely NOT_FOUND** | 1 (Toggle #22) |
| **Remaining NOT_FOUND in CSV** | ~16 (reduced from original 20 by corrections) |
| **CSV update accuracy** | 4 rows verified correct |
| **Documentation quality** | Both files updated with RCA and prevention strategy |

### Validation Status

**✅ Complete**:
- RCA documentation updated in both files
- 4 toggles corrected in CSV output file
- Enhanced search methodology documented
- High-risk toggle categories identified
- Prevention checklist created for future sessions

**For Future Sessions**:
- Apply improved search methodology to remaining NOT_FOUND toggles
- Re-validate medium-risk categories (Response/Retrieval, Card/BIN, Authentication)
- Consider whether toggles marked NOT_FOUND should be DECLARATION_ONLY instead
