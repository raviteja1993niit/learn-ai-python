# Quick Reference Guide - Repository Analysis Tools

## 🎯 Three Tools, Three Purposes

```
┌─────────────────────────┬──────────────────────┬─────────────────┐
│  Repository Tree        │  Java Tree Generator │ Memory Mapper    │
│  Generator              │  ⭐ MAIN SOLUTION    │                 │
├─────────────────────────┼──────────────────────┼─────────────────┤
│ Shows directory         │ Lists ALL Java       │ Analyzes class  │
│ structure               │ classes by package   │ responsibility  │
│                         │                      │ & S2A flow      │
│ 37 lines for 751 files  │ 830 lines for 751    │ CSV with details│
│                         │ files                │                 │
└─────────────────────────┴──────────────────────┴─────────────────┘
```

---

## 📋 Basic Commands

### Generate Java Class List (MAIN SOLUTION)
```bash
run-generate-java-tree.bat main
# Output: <repo>-java-tree.txt (All Java classes organized by package)
```

### Generate Memory Map with S2A Tracking
```bash
run-repo-memory-mapper.bat
# Output: <repo>-memory-map.csv (Class analysis with S2A flag)
```

### Generate Directory Tree
```bash
run-generate-tree.bat 3
# Output: <repo>-tree.txt (Directory structure, depth=3)
```

---

## 🚀 From Any Subdirectory

**No need to cd to repo root!** Scripts automatically detect it.

```bash
cd C:\projects\repo\src\main\java
run-generate-java-tree.bat all
# Works! Creates: C:\projects\repo\repo-java-tree.txt
```

---

## 📊 CSV Memory Map Columns

| Column | Purpose | Example |
|--------|---------|---------|
| CLASS_NAME | Simple name | `SessionManager` |
| PACKAGE | Java package | `com.dialect.utility` |
| CLASS_TYPE | Auto-classified | `Service`, `Controller`, `Repository` |
| RESPONSIBILITY | What it does | `Business logic service for SessionManager` |
| **IS_S2A_FLOW** | S2A involvement | `Yes` or `No` |
| S2A_DETAILS | How it's S2A | `Pattern: Mobile/App Transaction` |
| DEPENDENCIES | Related classes | `OrderService, PaymentUtil` |
| FILE_PATH | Source location | `src\main\java\com\dialect\utility\...` |
| PRIORITY | Importance | `High`, `Medium`, `Low` |
| NOTES | Additional info | (optional) |

**Filter for S2A classes:** `IS_S2A_FLOW = "Yes"`

---

## 📈 What Gets Generated

### For 751 Java Files (orchestrator)
```
orchestrator-tree.txt         (0.87 KB)   - Directory structure
orchestrator-java-tree.txt    (73.54 KB)  - All 751 classes listed ✅
orchestrator-memory-map.csv   (175.18 KB) - Class analysis + S2A
```

### For 2420 Java Files (cardpaymentengine)
```
cardpaymentengine-tree.txt         (1.35 KB)   - Directory structure
cardpaymentengine-java-tree.txt    (251.96 KB) - All 2420 classes listed ✅
cardpaymentengine-memory-map.csv   (106.76 KB) - Class analysis + S2A
```

---

## 🔍 Finding What You Need

### "I need to see all Java classes"
```bash
run-generate-java-tree.bat main
# 830 lines showing all 751 classes by package
```

### "I need to find S2A transaction classes"
```bash
run-repo-memory-mapper.bat
# Open CSV → Filter IS_S2A_FLOW = "Yes"
# Found 56 classes in orchestrator
```

### "I need to understand class responsibilities"
```bash
run-repo-memory-mapper.bat -1
# Check RESPONSIBILITY and CLASS_TYPE columns
# Classes automatically classified as Service, Controller, etc.
```

### "I need class dependencies"
```bash
run-repo-memory-mapper.bat
# Check DEPENDENCIES column in CSV
# See what each class depends on
```

---

## ⚡ Common Workflows

### Complete Repository Analysis
```bash
run-generate-tree.bat -1
run-generate-java-tree.bat all
run-repo-memory-mapper.bat -1 analysis.csv true
# Creates 3 files with different levels of detail
```

### Quick S2A Review
```bash
run-repo-memory-mapper.bat
# Open CSV → Sort by IS_S2A_FLOW
# 56 S2A classes found in orchestrator
```

### Architecture Documentation
```bash
run-generate-java-tree.bat main
run-repo-memory-mapper.bat -1
# Use outputs for Confluence documentation
```

### Focused Class Review
```bash
run-repo-memory-mapper.bat
# Filter by CLASS_TYPE = "Service"
# Review service responsibilities
```

---

## 📍 File Locations

### Tools
```
C:\Users\e135408\Downloads\mcp-servers\tools\
- run-generate-java-tree.bat
- run-repo-memory-mapper.bat
- run-generate-tree.bat
- README.md (detailed docs)
```

### Output Files
```
<Repository Root>/
- <repo>-java-tree.txt
- <repo>-memory-map.csv
- <repo>-tree.txt
```

---

## ⏱️ Execution Times

| Operation | Files | Time |
|-----------|-------|------|
| Java Tree | 751 | ~30 sec |
| Memory Map | 751 | ~35 sec |
| Java Tree | 2400 | ~70 sec |
| Memory Map | 2400 | ~70 sec |

---

## 🛠️ Troubleshooting

**Q: Script says "No Java files found"**  
A: Repo doesn't have `src/main/java` or `src/test/java` structure

**Q: Output files too large**  
A: Use `run-generate-tree.bat 2` to limit depth for directory tree

**Q: Want to see test classes too**  
A: Use `run-generate-java-tree.bat all` instead of `main`

**Q: How to run from my IDE terminal**  
A: Works from any directory - scripts auto-detect repo root!

---

## 🎓 Advanced: Custom Analysis

### Open CSV in Excel/Power Query
1. Run: `run-repo-memory-mapper.bat`
2. Open CSV in Excel
3. Sort/filter by columns:
   - IS_S2A_FLOW = "Yes" (find S2A classes)
   - CLASS_TYPE = "Service" (find services)
   - PRIORITY = "High" (find critical classes)

### Analyze Dependencies
1. Open memory map CSV
2. Use DEPENDENCIES column
3. Create dependency graph
4. Identify tight coupling

### S2A Flow Tracking
1. Filter IS_S2A_FLOW = "Yes"
2. Review S2A_DETAILS
3. Check DEPENDENCIES
4. Map transaction flow

---

## 💾 Batch Mode (For Automation)

```batch
@echo off
REM Generate all analysis files for repo
pushd C:\projects\myrepo
call C:\path\to\run-generate-tree.bat -1
call C:\path\to\run-generate-java-tree.bat all
call C:\path\to\run-repo-memory-mapper.bat -1 complete-map.csv true
popd
REM All files created in C:\projects\myrepo
```

---

## 📞 Need More Help?

See `README.md` in tools directory for:
- ✅ Complete tool documentation
- ✅ Parameter explanations
- ✅ Classification types
- ✅ S2A detection methods
- ✅ Integration examples
- ✅ Advanced usage

---

## 🎯 Remember

- ✅ Works from ANY subdirectory (auto-detects repo root)
- ✅ Three tools with different purposes
- ✅ Java tree shows ALL classes (solves the main issue)
- ✅ Memory map CSV easy to filter/sort
- ✅ S2A detection built-in
- ✅ No setup needed - just run!

---

**Last Updated:** April 10, 2026

