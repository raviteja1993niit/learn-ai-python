# Toggle Codebase Usage Analyzer - Complete Reference

## Quick Start

**Main Specification**: `toggle-codebase-usage-analyzer.agent.md` (Complete workflow + all rules)

**Three Things to Remember**:
1. Read COMPLETE if/else blocks in Phase 4 (all methods, all classes)
2. Write SPECIFIC impacts (not generic like "enables feature")
3. Use Rule 5: Search ONLY .java files with `includePattern="**/*.java"`

---

## Workflow Summary

### Phase 0: Setup (One-Time)
```
Rule 1: Build ToggleRegistryLookup.csv (196 toggles)
Rule 2: Build Java file indices (CPE: 3142, Orchestrator: 847)
Rule 3: Build S2AKeywordsLookup.csv (234 classes)
```

### Batch Processing (15 batches × 5 toggles)
```
Phase 1: Read 5 toggles + generate search variants (Rule 4)
Phase 2: Lookup in registry cache (Rule 1 - no re-searching)
Phase 3: Search with .java filter (Rule 5), cache results (Rule 6)
Phase 4: Read COMPLETE if/else blocks, document all methods/classes
Phase 5: Use S2A keywords lookup (Rule 3 - no re-searching)
Phase 6: Consolidate, validate, output (Rule 9)
```

---

## Critical Code Analysis Rules (Phase 4)

### MUST DO:
```
1. Read ENTIRE if block: if (toggle) { ALL statements }
2. Read ENTIRE else block: else { ALL statements }
3. Document every method: ClassName.methodName(params)
4. Document every object: new ClassName(args)
5. Document every variable: Type name = value
```

### MUST NOT DO:
```
1. Skip any code in if/else blocks
2. Paraphrase - use actual code details
3. Write generic descriptions: "enables X", "disables Y"
4. Ignore nested conditionals
5. Miss absent else blocks - document what doesn't execute
```

### Output Format (REQUIRED):
```
Toggle ON: "When enabled: (1) Instantiates JsonMegaMessageMap; 
(2) Calls builder.buildStreamlinedMessage(); 
(3) Routes via TspiRouter to S2A acquirer; 
(4) Uses Streamlined message format"

Toggle OFF: "When disabled: Skips JsonMegaMessageMap; 
uses standard MegaMessageMap; routes to default handler; 
uses standard message format"
```

---

## S2A Impact Classification (Phase 5)

After reading code in Phase 4, classify which type:

1. **S2A Flow Toggle**
   - ON: Instantiates S2A processor (JsonMegaMessageMap, TSPI routing)
   - OFF: Uses standard processor (standard MegaMessageMap)

2. **S2A Feature Toggle**
   - ON: Enables specific S2A feature within S2A flow
   - OFF: Disables feature but still in S2A context

3. **S2A Routing Toggle**
   - ON: Uses TSPI router for S2A-eligible transactions
   - OFF: Uses merchant default routing

4. **S2A Message Format Toggle**
   - ON: Generates JsonMegaMessageMap format
   - OFF: Generates standard MegaMessageMap format

---

## Essential Search Rule (Rule 5)

**EVERY search must specify Java files ONLY:**

```powershell
✓ CORRECT:
grep_search(pattern="toggleName", includePattern="**/*.java")
file_search(query="**/*ToggleClass*.java")

✗ WRONG (DO NOT USE):
grep_search(pattern="toggleName")  # Missing includePattern!
file_search(query="src/**/*")  # Matches XML, properties, etc.!
```

---

## Output CSV Validation Checklist

For each row before appending to final CSV:

- [ ] Toggle Name: Exact match from input CSV
- [ ] Implementation Class: Where toggle is USED (not declared)
- [ ] Line Number: Exact line from code
- [ ] Toggle ON Impact: Specific methods + classes (NOT generic)
- [ ] Toggle OFF Impact: Specific fallback or "Skips..." (NOT generic)
- [ ] All method names come from actual code read
- [ ] All class names come from actual code read
- [ ] If S2A-related: Type classified (flow/feature/routing/format)
- [ ] If S2A-related: Specific classes named (JsonMegaMap, TSPI, etc.)

---

## Common Mistakes

| ❌ WRONG | ✓ RIGHT |
|---------|---------|
| "Enables feature" | "Instantiates JsonMegaMessageMap; calls builder.buildMessage()" |
| "Disables toggle" | "Skips JsonMegaMessageMap; uses standard MegaMessageMap" |
| Miss else block | Document what doesn't execute: "Skips [block], proceeds to..." |
| Summarize code | Use actual method/class names: `ClassName.methodName()` |
| Generic "S2A impact" | Specific: "Uses JsonMegaMessageMap with TSPI routing" |
| Search all files | Filter to .java: `includePattern="**/*.java"` |

---

## Files Needed

**Input**:
- `FeatureToggleConfluencePageEnquiryResults.csv` (73 toggles)
- `cardpaymentengine.tree.txt` (for Rule 2 indexing)
- `orchestrator.tree.txt` (for Rule 2 indexing)

**Source Registries**:
- CPE: `S2IAcquirerToggleConstants.java` (188 toggles)
- Orchestrator: `ToggleConstants.java` (8 toggles)

**Search Scope**:
- CPE: `src/main/java/**/*.java` (3142 files)
- Orchestrator: `src/main/java/**/*.java` (847 files)

**Output**:
- `ToggleCodebaseUsageAnalysis.csv` (73+ rows, one per usage location)

---

## Success Metrics

- [x] All 73 toggles analyzed
- [x] Complete if/else blocks read for every toggle usage
- [x] No generic descriptions in output
- [x] Every method name and class name from actual code
- [x] ON and OFF behaviors differ and describe actual code paths
- [x] S2A-related toggles classified and documented
- [x] No false positives (Rule 5 Java-only filter applied)
- [x] No registry class entries (Rule 8 filtering applied)
- [x] All checkpoints validated for 15 batches

---

## Reference

**Main Specification**: `.github/agents/toggle-codebase-usage-analyzer.agent.md`
- Contains: Complete Phase 0-6 workflows, all 9 optimization rules, search patterns, error handling, detailed examples
- Size: 816 lines (consolidated for efficiency)
- Scope: All required information in single file

**This Document**: Quick reference with essential requirements
- Use this for quick lookups while implementing
- Refer to main specification for detailed procedures

## File Summary

**Essential Files**:
- `toggle-codebase-usage-analyzer.agent.md` - Complete agent specification (ONLY specification needed)
- `FeatureToggleConfluencePageEnquiryResults.csv` - Input (73 toggles)
- `cardpaymentengine.tree.txt` - For Rule 2 indexing (Rule 2 setup)
- `orchestrator.tree.txt` - For Rule 2 indexing (Rule 2 setup)

**Output Files** (Generated during execution):
- `ToggleCodebaseUsageAnalysis.csv` - Final analysis (one row per usage location)
- Phase 0 Lookup CSVs: ToggleRegistryLookup.csv, CPEJavaFileLookup.csv, OrchestratorJavaFileLookup.csv, S2AKeywordsLookup.csv
- Batch Checkpoints: ToggleBatch_{N}_Checkpoint.txt (for validation & resume)

**This Reference**: REFERENCE.md - Quick lookup guide
- Condensed requirements
- Common mistakes
- Validation checklist

