# Toggle Codebase Usage Analyzer — Session Checkpoint
**Date**: April 10, 2026  
**Status**: IN PROGRESS — NOT_FOUND recheck pending

---

## Current Task
User reported NOT_FOUND entries are incorrectly classified. Agent fixed `Enable Update Authorization for Card Payments` (found in `UpdateAuthorisationThenCaptureExecutor.java` line 159, CPE). User then asked to **recheck ALL NOT_FOUND entries searching only across the 6 source repos**.

---

## Output File
`C:\Users\e135408\Downloads\mcp-servers\jobs\TogglePageEnquiry\data\ToggleCodebaseUsageAnalysis.csv`  
**Current state**: 133 lines (header + 132 data rows)

---

## CRITICAL TOOL NOTE
**`replace_string_in_file` is broken** — reports success but makes NO disk changes on this machine.  
**Always use `insert_edit_into_file` instead** when editing the CSV.

---

## 6 Source Repositories
| Repo | Base Path |
|------|-----------|
| CPE | `C:\Users\e135408\IdeaProjects\MPGS\SourceCode\cardpaymentengine\src\main\java` |
| Orchestrator | `C:\Users\e135408\IdeaProjects\MPGS\SourceCode\orchestrator\src\main\java` |
| BusinessService | `C:\Users\e135408\IdeaProjects\MPGS\SourceCode\businessservice\src\main\java` |
| Console | `C:\Users\e135408\IdeaProjects\MPGS\SourceCode\console\src\main\java` |
| MSOUI | `C:\Users\e135408\IdeaProjects\MPGS\SourceCode\msoui\src\main\java` |
| DirectAPI | `C:\Users\e135408\IdeaProjects\MPGS\SourceCode\directapi\src\main\java` |

---

## Remaining NOT_FOUND / DECLARATION_ONLY Entries (CSV Lines)

| CSV Line | Toggle Name | Status |
|----------|-------------|--------|
| 22 | Get Most Recent Transaction as Initial Transaction If Auto-Capture Failed in Settlement Transaction | NOT_FOUND |
| 26 | System Toggle: Honour DoNotProcessAfterTime for transaction processing | NOT_FOUND |
| 28 | Apply per-merchant limits for invalid operation rates in WSAPI | NOT_FOUND |
| 29 | Apply per-merchant maximum request rate limits in WSAPI | NOT_FOUND |
| 36 | Populate payer authentication details on pre-risk RSPI | NOT_FOUND |
| 42 | Shared Memory CPE PersistenceTable | NOT_FOUND |
| 44 | System Toggle: Use Enhanced Optimistic Lock With Terminal Batch Counters | NOT_FOUND |
| 48 | Use Status Code when calculating if PSD2 Exemption has been granted by Visa | NOT_FOUND |
| 54 | Scheme Transaction Throttle for WS API - Passive Mode | NOT_FOUND |
| 57 | Enable replication lag tracking by MCS | NOT_FOUND |
| 58 | System Toggle: Enable DC Replication Locks | NOT_FOUND |
| 59 | Allow payment transaction with authentication return surcharge | NOT_FOUND |
| 60 | Use Enhanced Certificate Sets | NOT_FOUND |
| 66 | Enable Activity Calls to Protection Service | NOT_FOUND |
| 78 | Set approvedAmount only when the transaction is approved | NOT_FOUND |
| 86 | Optimize loading of terminal batch counters | NOT_FOUND |
| 95 | Enable Protection Blocking Of Unusual Transactions | NOT_FOUND |
| 96 | System Toggle: Enable Activity Analyzer in Protection Service | NOT_FOUND |
| 97 | Enable Transaction Filtering BIN Range White listing | NOT_FOUND |
| 100 | Batch Settlement Service use Base32 ID Generator | NOT_FOUND |
| 107 | Enable Update Authorization for Card Payments | NOT_FOUND (WAS FIXED — see below) |
| 112 | Enable transit transaction without sourceOfFunds | DECLARATION_ONLY |
| 117 | Remove Orchestrator Session Merge | NOT_FOUND |
| 122 | System Toggle: Enable SCOF as a Network Token Provider | NOT_FOUND |
| 124 | System Toggle: Extend SCT token DB locking behaviour | NOT_FOUND |
| 125 | System Toggle: Streamline SQL update for token use | NOT_FOUND |
| 127 | System Toggle:Enable HSM Encryption For BatchSettlementService and PTS | NOT_FOUND |

---

## Fix Already Applied This Session

### Enable Update Authorization for Card Payments (CSV line 107)
**Fixed**: Row updated from NOT_FOUND stub to:
- **Class**: `UpdateAuthorisationThenCaptureExecutor`
- **Line**: `159`
- **Repo**: `CPE`
- **Method**: `isIncrementalAuthorizationSupportTogglesEnabled()` — returns `Toggles.isToggleOn(ENABLE_UPDATE_AUTHORIZATION_FOR_CARD_PAYMENTS) && Toggles.isToggleOn(ENABLE_INCREMENTAL_AUTHORIZATION) && Toggles.isToggleOn(SYSTEM_TOGGLE_SUPPORT_AUTO_INCREMENTAL_AUTHORIZATION_FOR_EXCESSIVE_CAPTURE)`
- **Called from**: `shouldPopulateInitialAuthorizationForUpdateAuthorizationTransaction()` at line 149

---

## Search Strategy for Tomorrow

### Step 1: Run comprehensive PowerShell search across all 6 repos
Search by constant name fragments AND display string keywords. Key patterns to try:

```powershell
$repos = @(
    "C:\Users\e135408\IdeaProjects\MPGS\SourceCode\cardpaymentengine\src\main\java",
    "C:\Users\e135408\IdeaProjects\MPGS\SourceCode\orchestrator\src\main\java",
    "C:\Users\e135408\IdeaProjects\MPGS\SourceCode\businessservice\src\main\java",
    "C:\Users\e135408\IdeaProjects\MPGS\SourceCode\console\src\main\java",
    "C:\Users\e135408\IdeaProjects\MPGS\SourceCode\msoui\src\main\java",
    "C:\Users\e135408\IdeaProjects\MPGS\SourceCode\directapi\src\main\java"
)
```

Search for `isToggleOn` near these keyword fragments (search ONE repo at a time to avoid timeout):

| Toggle | Search Keywords |
|--------|----------------|
| Get Most Recent Transaction as Initial | `MOST_RECENT`, `INITIAL_TRANSACTION`, `AUTO_CAPTURE_FAILED` |
| Honour DoNotProcessAfterTime | `HONOUR_DO_NOT_PROCESS`, `doNotProcessAfterTime` in toggle context |
| Apply per-merchant limits invalid operation | `INVALID_OPERATION_RATE`, `PER_MERCHANT_LIMIT` |
| Apply per-merchant max request rate | `MAX_REQUEST_RATE`, `PER_MERCHANT_MAX` |
| Shared Memory CPE PersistenceTable | `SHARED_MEMORY`, `PERSISTENCE_TABLE` |
| Enhanced Optimistic Lock Terminal Batch | `ENHANCED_OPTIMISTIC_LOCK`, `OPTIMISTIC_LOCK_TERMINAL` |
| PSD2 Exemption Status Code | `PSD2_EXEMPTION`, `STATUS_CODE.*EXEMPTION` |
| Scheme Transaction Throttle Passive | `SCHEME_THROTTLE`, `THROTTLE.*PASSIVE` |
| Enable replication lag tracking | `REPLICATION_LAG`, `LAG_TRACKING` |
| Enable DC Replication Locks | `DC_REPLICATION`, `REPLICATION_LOCK` |
| Auth return surcharge | `SURCHARGE`, `AUTH.*SURCHARGE`, `AUTHENTICATION_RETURN_SURCHARGE` |
| Enhanced Certificate Sets | `ENHANCED_CERTIFICATE`, `CERTIFICATE_SET` |
| Activity Calls to Protection Service | `ACTIVITY_CALLS`, `PROTECTION_SERVICE.*ACTIVITY` |
| Set approvedAmount only when approved | `APPROVED_AMOUNT`, `SET_APPROVED_AMOUNT` |
| Optimize terminal batch counters | `OPTIMIZE.*TERMINAL_BATCH`, `TERMINAL_BATCH_COUNTER` |
| Protection Blocking Unusual Transactions | `PROTECTION_BLOCKING`, `BLOCKING.*UNUSUAL` |
| Activity Analyzer Protection Service | `ACTIVITY_ANALYZER`, `ANALYZER.*PROTECTION` |
| BIN Range White listing | `BIN_RANGE.*WHITE`, `WHITELIST.*BIN` |
| Payer auth pre-risk RSPI | `PAYER_AUTH.*PRE_RISK`, `PRE_RISK.*PAYER` |
| Enable transit without sourceOfFunds | `TRANSIT_WITHOUT_SOURCE`, `isToggleOn.*TRANSIT_WITHOUT` |
| Remove Orchestrator Session Merge | `SESSION_MERGE`, `ORCHESTRATOR.*SESSION` |
| SCOF as Network Token Provider | `SCOF.*NETWORK_TOKEN`, `NETWORK_TOKEN_PROVIDER` |
| Extend SCT token DB locking | `SCT.*LOCK`, `TOKEN_DB_LOCK` |
| Streamline SQL update token use | `STREAMLINE_SQL`, `SQL.*TOKEN_USE` |
| HSM Encryption BatchSettlement PTS | `HSM_ENCRYPTION.*BATCH`, `BATCH_SETTLEMENT.*HSM` |

### Step 2: For each hit found — read file, verify `isToggleOn()` call, extract context
### Step 3: Update CSV using `insert_edit_into_file` (NOT replace_string_in_file)

---

## Key Files Referenced
- **Registry**: `C:\Users\e135408\Downloads\mcp-servers\jobs\TogglePageEnquiry\data\ToggleRegistryLookup.csv` (283 lines, 279 entries)
- **Input CSV**: `C:\Users\e135408\Downloads\mcp-servers\jobs\TogglePageEnquiry\data\FeatureToggleConfluencePageEnquiryResults.csv`
- **Output CSV**: `C:\Users\e135408\Downloads\mcp-servers\jobs\TogglePageEnquiry\data\ToggleCodebaseUsageAnalysis.csv`

---

## Important Lesson Learned
Registry-based lookups alone are NOT sufficient. Toggle constants are often used via:
1. **Helper method wrappers** (e.g. `isIncrementalAuthorizationSupportTogglesEnabled()` wraps `isToggleOn(...)`)
2. **Multiple toggles ANDed together** in one method
3. **Classes not indexed** in the registry
→ Always search by CONSTANT NAME directly (not just display string) across ALL 6 repos

