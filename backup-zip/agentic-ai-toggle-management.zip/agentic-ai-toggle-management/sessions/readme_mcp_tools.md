# Toggle Codebase Usage Analysis - MCP Tool Suite Documentation

## Overview

Three PowerShell-based MCP utility tools for comprehensive toggle analysis:

1. **Toggle-SearchUtility.ps1** - Search for toggle usage in codebases
2. **Toggle-PublishUtility.ps1** - Publish analysis results to CSV
3. **Toggle-AnalysisBatchProcessor.ps1** - Master orchestration for batch processing

---

## Tool 1: Toggle-SearchUtility.ps1

### Purpose
Searches for all usage instances of a toggle name across CPE and Orchestrator Java source files.

### Location
`C:\Users\e135408\Downloads\mcp-servers\tools\Toggle-SearchUtility.ps1`

### Usage

#### Basic Search (Both Repositories)
```powershell
.\Toggle-SearchUtility.ps1 -ToggleName "System Toggle: CPE Load Balancer Uses Ping"
```

#### Search Specific Repository
```powershell
.\Toggle-SearchUtility.ps1 -ToggleName "Apply New Order ID Reuse Rule" -Repository "CPE"
```

#### Exclude Declaration Locations
```powershell
.\Toggle-SearchUtility.ps1 -ToggleName "Enable TAF fields support for Passthrough" -ExcludeDeclarations
```

### Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| ToggleName | string | Yes | - | Toggle name to search for (exact match from CSV) |
| Repository | string | No | "Both" | "CPE", "Orchestrator", or "Both" |
| ExcludeDeclarations | switch | No | - | Skip matches in toggle registry classes |
| RegistryPath | string | No | `ToggleRegistryLookup.csv` | Path to registry lookup CSV |
| CPEPath | string | No | `...cardpaymentengine/src/main/java` | CPE source path |
| OrchestratorPath | string | No | `...orchestrator/src/main/java` | Orchestrator source path |

### Output

#### Console Output
```
Searching CPE repository...
Found 3 matches in CPE
Searching Orchestrator repository...
Found 1 matches in Orchestrator

=== SEARCH SUMMARY ===
Toggle: Apply New Order ID Reuse Rule
Total Usage Locations Found: 4
  [CPE] OrderIdReuseHelper.java:36
  [CPE] OrderValidationService.java:112
  [Orchestrator] OrderIdReuseHelper.java:45
  [Orchestrator] OrderSyncService.java:89
```

#### JSON Output (for programmatic use)
```json
{
  "toggleName": "Apply New Order ID Reuse Rule",
  "totalMatches": 4,
  "searchParameters": {
    "repository": "Both",
    "excludeDeclarations": false
  },
  "results": [
    {
      "repository": "CPE",
      "className": "OrderIdReuseHelper",
      "filePath": "src/main/java/com/dialect/orchestrator/helper/OrderIdReuseHelper.java",
      "lineNumber": 36,
      "context": "...",
      "matchLine": "if (toggles.isEnabled(\"Apply New Order ID Reuse Rule\")) {"
    },
    ...
  ]
}
```

### Features

- ✓ Searches both CPE and Orchestrator repositories
- ✓ Finds exact toggle name matches (string literal searches)
- ✓ Extracts code context (3 lines before/after)
- ✓ Filters out test classes (`*Test.java`, `/src/test/java/`)
- ✓ Optional declaration filtering using registry lookup
- ✓ Deduplicates same-location matches
- ✓ Returns structured JSON for integration
- ✓ Provides human-readable console summary

---

## Tool 2: Toggle-PublishUtility.ps1

### Purpose
Validates and publishes toggle analysis data to ToggleCodebaseUsageAnalysis.csv report file.

### Location
`C:\Users\e135408\Downloads\mcp-servers\tools\Toggle-PublishUtility.ps1`

### Usage

#### Basic Publish
```powershell
$analysisData = @(
    @{
        ToggleName = "Test Toggle"
        ImplementationClassName = "TestClass"
        LineNumber = "42"
        ONImpact = "When enabled: does X, calls Y.method(), instantiates Z"
        OFFImpact = "When disabled: skips X, uses default behavior"
        Repository = "CPE"
    },
    @{
        ToggleName = "Test Toggle"
        ImplementationClassName = "OtherClass"
        LineNumber = "89"
        ONImpact = "When enabled: alternate code path"
        OFFImpact = "When disabled: main code path"
        Repository = "Orchestrator"
    }
)

.\Toggle-PublishUtility.ps1 -AnalysisData $analysisData -BatchName "Batch1"
```

#### Validate Only (No Write)
```powershell
.\Toggle-PublishUtility.ps1 -AnalysisData $analysisData -ValidateOnly
```

#### Append to Existing File
```powershell
.\Toggle-PublishUtility.ps1 -AnalysisData $analysisData -AppendOnly -BatchName "Batch2"
```

### Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| AnalysisData | object[] | Yes | - | Array of analysis row objects |
| OutputPath | string | No | `ToggleCodebaseUsageAnalysis.csv` | Output CSV file path |
| BatchName | string | No | "Manual" | Batch identifier for logging |
| AppendOnly | switch | No | - | Append instead of replace |
| ValidateOnly | switch | No | - | Validate data without writing |
| Verbose | switch | No | - | Show detailed processing info |

### Input Data Structure

Each object in AnalysisData must contain:

```powershell
@{
    ToggleName = [string]           # Toggle name from input CSV
    ImplementationClassName = [string]  # Class where toggle is used (not declared)
    LineNumber = [string|int]       # Line number in implementation class
    ONImpact = [string]             # Detailed impact when toggle=ON
    OFFImpact = [string]            # Detailed impact when toggle=OFF
    Repository = [string]           # "CPE" or "Orchestrator"
}
```

### Output

#### Console Output
```
=== DATA VALIDATION ===
Validating 7 rows of analysis data...

✓ All validation checks passed

=== CSV PUBLISHING ===
Output Path: ToggleCodebaseUsageAnalysis.csv
Batch Name: Batch1

Created CSV file with 8 lines (including header)

=== PUBLISH SUMMARY ===
Status: SUCCESS
Rows Written: 7
Total Lines in File: 8
Output File: ToggleCodebaseUsageAnalysis.csv

Sample rows published:
  • System Toggle: CPE Load Balancer Uses Ping -> MerchantLoadBalancer:82 [CPE]
  • Apply New Order ID Reuse Rule -> OrderIdReuseHelper:36 [CPE]
  • Apply New Order ID Reuse Rule -> OrderIdReuseHelper:45 [Orchestrator]
```

#### JSON Output (for integration)
```json
{
  "status": "SUCCESS",
  "timestamp": "2026-04-10 15:45:23",
  "batch": "Batch1",
  "rowsWritten": 7,
  "outputFile": "ToggleCodebaseUsageAnalysis.csv",
  "totalLinesInFile": 8,
  "validationErrors": 0,
  "validationWarnings": 2
}
```

### Validation Rules

1. **Required Fields**: All fields must be present and non-empty
2. **Repository Value**: Must be exactly "CPE" or "Orchestrator"
3. **LineNumber**: Must be numeric
4. **Impact Descriptions**: ONImpact and OFFImpact must be at least 50 characters
5. **CSV Escaping**: Automatically escapes quotes and special characters
6. **Duplicates**: No deduplication (each row unique per usage location)

---

## Tool 3: Toggle-AnalysisBatchProcessor.ps1

### Purpose
Master orchestration script that combines Search and Publish tools for batch processing.

### Location
`C:\Users\e135408\Downloads\mcp-servers\tools\Toggle-AnalysisBatchProcessor.ps1`

### Usage

#### Process Specific Batch
```powershell
.\Toggle-AnalysisBatchProcessor.ps1 -BatchNumber 1
```

#### Process Custom Range
```powershell
.\Toggle-AnalysisBatchProcessor.ps1 -StartToggleIndex 5 -ToggleCount 3
```

#### Process All Batches (1-15)
```powershell
for ($i = 1; $i -le 15; $i++) {
    .\Toggle-AnalysisBatchProcessor.ps1 -BatchNumber $i
}
```

### Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| BatchNumber | int | No | - | Batch number (1-15) to process |
| StartToggleIndex | int | No | 0 | Starting toggle index (0-based) |
| ToggleCount | int | No | 5 | Number of toggles to process per batch |
| ToolsPath | string | No | tools folder | Path to MCP tools directory |

### Workflow

```
1. Load input CSV (FeatureToggleConfluencePageEnquiryResults.csv)
   ↓
2. Extract batch of toggles (5 per batch by default)
   ↓
3. For each toggle in batch:
   a. Call Toggle-SearchUtility.ps1
   b. Parse JSON results
   c. Extract code context
   d. Create analysis objects
   ↓
4. Call Toggle-PublishUtility.ps1
   a. Validate all analysis data
   b. Write to ToggleCodebaseUsageAnalysis.csv
   ↓
5. Report batch completion metrics
```

### Output Example

```
================================================
Batch 1: Toggles 1-5 (5 toggles)
================================================

[1/5] Processing: System Toggle: CPE Load Balancer Uses Ping
  is_s2a: FALSE
  Searching repositories...
  Found 2 usage location(s)
    • CPE: MerchantLoadBalancer.java:82
    • CPE: MerchantLoadBalancer.java:195

[2/5] Processing: System Toggle: Enable Lookup up to 8 digit bin for Card Identification
  is_s2a: FALSE
  Searching repositories...
  Found 1 usage location(s)
    • CPE: BinBaseCardBrandService.java:63

...

Publishing 7 analysis rows...

Publish Result:
Status        : SUCCESS
Timestamp     : 2026-04-10 15:47:30
Batch         : Batch 1
RowsWritten   : 7
OutputFile    : ToggleCodebaseUsageAnalysis.csv
TotalLinesInFile : 8
ValidationErrors : 0
ValidationWarnings : 0

================================================
BATCH PROCESSING SUMMARY
================================================
Batch: Batch 1
Toggles Processed: 5
Analysis Rows Created: 7
Status: COMPLETE
```

---

## Usage Examples

### Example 1: Analyze Single Toggle

```powershell
# Search for toggle
$results = & "Toggle-SearchUtility.ps1" -ToggleName "Apply New Order ID Reuse Rule"

# Then manually create analysis and publish
$analysis = @{
    ToggleName = "Apply New Order ID Reuse Rule"
    ImplementationClassName = "OrderIdReuseHelper"
    LineNumber = "36"
    ONImpact = "When enabled: Applies new reuse rule allowing orders processed then blocked then reversed to be reused"
    OFFImpact = "When disabled: Uses legacy rule preventing such reuse scenarios"
    Repository = "CPE"
}

& "Toggle-PublishUtility.ps1" -AnalysisData @($analysis)
```

### Example 2: Batch Process Toggles 6-10

```powershell
.\Toggle-AnalysisBatchProcessor.ps1 -BatchNumber 2
```

### Example 3: Validate Data Before Publishing

```powershell
$analysisData = @(...)
.\Toggle-PublishUtility.ps1 -AnalysisData $analysisData -ValidateOnly
```

### Example 4: Process Multiple Batches

```powershell
1..5 | ForEach-Object {
    Write-Host "Processing Batch $_..."
    .\Toggle-AnalysisBatchProcessor.ps1 -BatchNumber $_
    Start-Sleep -Seconds 5
}
```

---

## Output Files

### ToggleCodebaseUsageAnalysis.csv

**Location**: `C:\Users\e135408\Downloads\mcp-servers\jobs\TogglePageEnquiry\data\ToggleCodebaseUsageAnalysis.csv`

**Format**: CSV with UTF8 encoding

**Columns**:
1. `Toggle Name` - Original toggle name from input CSV
2. `Implementation Class Name` - Class where toggle is USED (not declared)
3. `Line Number Code` - Line number in implementation class
4. `Toggle ON Impact` - Detailed description of code execution when toggle=TRUE
5. `Toggle OFF Impact` - Detailed description of code execution when toggle=FALSE
6. `Repository` - "CPE" or "Orchestrator"

**Sample Row**:
```csv
"System Toggle: CPE Load Balancer Uses Ping","MerchantLoadBalancer","82","When enabled: Checks toggle condition, calls pingServers() method in @Scheduled bean; iterates usableServers entries; updates server status map; logs changes","When disabled: Early return at line 82-84; skips all ping operations; usableServers unchanged","CPE"
```

---

## Integration Points

### MCP Tool Invocation Format

```powershell
# Search
$output = & $searchTool -ToggleName "Toggle Name" -Repository "Both"
$jsonData = $output | Where-Object {$_ -match "^{"} | ConvertFrom-Json

# Publish
$output = & $publishTool -AnalysisData $data -BatchName "Batch1"
$result = $output | Where-Object {$_ -match "^{"} | ConvertFrom-Json
```

### JSON Response Format

Both Search and Publish tools return JSON in their output streams:

**Search Tool**:
```json
{
  "toggleName": "...",
  "totalMatches": N,
  "searchParameters": {...},
  "results": [...]
}
```

**Publish Tool**:
```json
{
  "status": "SUCCESS|FAILED",
  "timestamp": "...",
  "batch": "...",
  "rowsWritten": N,
  ...
}
```

---

## Performance Notes

- **Search Tool**: ~2-5 seconds per toggle (searches ~4000 Java files)
- **Publish Tool**: <1 second regardless of batch size
- **Batch Processor**: ~15-30 seconds per batch of 5 toggles
- **Full Analysis (73 toggles)**: ~2-3 hours total

---

## Troubleshooting

### Search Tool Returns No Results
1. Verify toggle name exact match with CSV
2. Check if toggle is declared but not used in production code
3. Try with `-ExcludeDeclarations $false` to include declarations

### Publish Tool Reports Validation Errors
1. Ensure all required fields are present
2. Check Repository value is "CPE" or "Orchestrator"
3. Verify ONImpact and OFFImpact are > 50 characters
4. Run with `-ValidateOnly` to preview errors

### Batch Processor Shows 0 Results
1. Check input CSV exists at specified path
2. Verify Toggle-SearchUtility.ps1 returns valid JSON
3. Check search results with `-Verbose` flag

---

## Version History

- **v1.0** (2026-04-10): Initial release with Batch 1 completion
  - Toggle-SearchUtility.ps1
  - Toggle-PublishUtility.ps1
  - Toggle-AnalysisBatchProcessor.ps1

---

## Support

For issues or questions:
1. Review the Usage Examples section
2. Check Troubleshooting section
3. Run with `-Verbose` flag for detailed output
4. Review Batch1_CompletionReport.md for reference analysis

