"""
Find lines inside Mermaid blocks containing semicolons or other
characters that can break sequenceDiagram / flowchart parsing.
Semicolons terminate Mermaid statements, so they must not appear
unquoted inside message labels.
"""
import re

fpath = r'C:\Users\e135408\Downloads\agentic-ai-toggle-management\knowledge\user-guide.md'

with open(fpath, 'r', encoding='utf-8') as f:
    lines = f.readlines()

in_mermaid = False
issues = []

for i, raw in enumerate(lines):
    line = raw.rstrip()
    clean = line.strip()

    if clean == '```mermaid':
        in_mermaid = True
        continue
    if in_mermaid and clean == '```':
        in_mermaid = False
        continue

    if in_mermaid:
        # Semicolons outside of quoted strings are statement terminators in Mermaid
        if ';' in line:
            issues.append(('SEMICOLON', i + 1, line))
        # Curly braces in labels can confuse flowchart parser
        if '{' in line and not re.search(r'^[\s]*(flowchart|sequenceDiagram|subgraph|\w+\s*\{)', line):
            issues.append(('CURLY-BRACE', i + 1, line))
        # Square brackets inside node labels that are already in square brackets
        if re.search(r'\[[^\]]*\[[^\]]*\]', line):
            issues.append(('NESTED-BRACKETS', i + 1, line))

if issues:
    print('Found %d issues:\n' % len(issues))
    for kind, lineno, content in issues:
        print('[%s] Line %d: %s' % (kind, lineno, repr(content[:120])))
else:
    print('No issues found.')

