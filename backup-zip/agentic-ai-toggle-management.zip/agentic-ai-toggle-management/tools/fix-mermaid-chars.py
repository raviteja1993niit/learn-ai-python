"""
Find and fix all lines inside Mermaid code blocks that contain
em dashes (U+2014), en dashes (U+2013), or Unicode arrows (U+2192)
which break Mermaid's parser.

Replacement rules inside Mermaid blocks:
  — (U+2014)  ->  -  (hyphen, safe in Mermaid labels)
  – (U+2013)  ->  -  (hyphen)
  → (U+2192)  ->  ->  (Mermaid arrow syntax, only outside quoted strings)
"""

fpath = r'C:\Users\e135408\Downloads\agentic-ai-toggle-management\knowledge\user-guide.md'

with open(fpath, 'r', encoding='utf-8') as f:
    content = f.read()

lines = content.split('\n')
in_mermaid = False
fixed_lines = []
issues_found = 0
issues_fixed = 0

for i, line in enumerate(lines):
    stripped = line.strip()

    # Detect mermaid block boundaries
    if stripped == '```mermaid':
        in_mermaid = True
        fixed_lines.append(line)
        continue
    if in_mermaid and stripped == '```':
        in_mermaid = False
        fixed_lines.append(line)
        continue

    if in_mermaid:
        original_line = line
        # Replace em dash with hyphen-hyphen inside mermaid
        line = line.replace('\u2014', '--')
        # Replace en dash with hyphen inside mermaid
        line = line.replace('\u2013', '-')
        # Replace Unicode right arrow with ASCII ->  (but not inside ->> which is already mermaid syntax)
        # Only replace standalone → that is NOT already part of ->
        line = line.replace('\u2192', '->')
        # Clean up any ---> that became >---> from double replacement
        line = line.replace('->->', '->')
        line = line.replace('-->>', '-->>')  # keep valid mermaid dotted arrows

        if line != original_line:
            issues_fixed += 1
            print('Line %d FIXED: %s' % (i + 1, repr(original_line.strip()[:80])))
            print('          TO: %s' % repr(line.strip()[:80]))

    fixed_lines.append(line)

fixed_content = '\n'.join(fixed_lines)

if fixed_content != content:
    with open(fpath, 'w', encoding='utf-8') as f:
        f.write(fixed_content)
    print('\nTotal lines fixed: %d' % issues_fixed)
    print('File saved.')
else:
    print('No changes needed.')

