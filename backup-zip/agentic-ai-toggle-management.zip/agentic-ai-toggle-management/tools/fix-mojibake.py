"""
Fix Windows-1252 double-encoding mojibake in all .md files under .github/

Root cause: Characters were encoded in Windows-1252 and then mis-read as UTF-8,
producing garbled sequences. Diagnosed patterns:
  - euro (U+20AC) + right-double-quote (U+201D) "€"" => em dash — (U+2014)
  - dagger (U+2020) + right-single-quote (U+2019) "†'" => right arrow → (U+2192)
  - lone â (U+00E2) => encoding artifact, context-cleaned
"""
import os
import glob

BASE = r'C:\Users\e135408\Downloads\agentic-ai-toggle-management\.github'

# Ordered list of (bad, good) replacements - ORDER MATTERS (longer patterns first)
FIXES = [
    # Windows-1252 double-encoding: diagnosed from actual file bytes
    ('\u2020\u2019', '\u2192'),    # †' -> →  (right arrow)
    ('\u2020\u0092', '\u2192'),    # †\x92 -> →
    ('\u20ac\u201d', '\u2014'),    # €" -> —  (em dash)
    ('\u20ac\u2019', '\u2019'),    # €' -> '  (keep right single quote)
    ('\u20ac\u00a2', '\u2022'),    # €¢ -> •  (bullet)
    ('\u20ac\u00a6', '\u2026'),    # €¦ -> …  (ellipsis)
    ('\u20ac\u2013', '\u2013'),    # already en dash
    # Standard 3-byte mojibake sequences (utf-8 bytes misread as latin-1)
    ('\u00e2\u0080\u0094', '\u2014'),   # â€" -> —
    ('\u00e2\u0080\u0093', '\u2013'),   # â€" -> –
    ('\u00e2\u0086\u0092', '\u2192'),   # â†' -> →
    ('\u00e2\u0087\u0092', '\u21d2'),   # â‡' -> ⇒
    ('\u00e2\u0080\u0099', '\u2019'),   # â€™ -> '
    ('\u00e2\u0080\u009c', '\u201c'),   # â€œ -> "
    ('\u00e2\u0080\u009d', '\u201d'),   # â€  -> "
    ('\u00e2\u0080\u00a2', '\u2022'),   # â€¢ -> •
    ('\u00e2\u0080\u00a6', '\u2026'),   # â€¦ -> …
    ('\u00e2\u009c\u0085', '\u2705'),   # -> ✅
    ('\u00e2\u009a\u00a1', '\u26a1'),   # -> ⚡
    ('\u00e2\u009a\u00a0', '\u26a0'),   # -> ⚠
    ('\u00e2\u009c\u0093', '\u2713'),   # -> ✓
    ('\u00e2\u009c\u0097', '\u2717'),   # -> ✗
    ('\u00e2\u0094\u0080', '\u2500'),   # -> ─
    ('\u00e2\u0094\u0082', '\u2502'),   # -> │
    ('\u00e2\u0094\u0094', '\u2514'),   # -> └
    ('\u00e2\u0094\u009c', '\u251c'),   # -> ├
    ('\u00c2\u00a0', '\u00a0'),         # Â -> non-breaking space
]

files = glob.glob(BASE + r'\**\*.md', recursive=True)
fixed_count = 0
ok_count = 0

for fpath in sorted(files):
    fname = os.path.basename(fpath)
    with open(fpath, 'r', encoding='utf-8') as fh:
        text = fh.read()
    
    original = text
    
    for bad, good in FIXES:
        text = text.replace(bad, good)
    
    if text != original:
        with open(fpath, 'w', encoding='utf-8') as fh:
            fh.write(text)
        fixed_count += 1
        print('FIXED:  ' + fname)
    else:
        ok_count += 1
        print('OK:     ' + fname)

print('')
print('Summary: ' + str(fixed_count) + ' fixed, ' + str(ok_count) + ' already clean, ' + str(len(files)) + ' total')

