"""
Check whether remaining U+00E2 chars are standalone (bad) or part of valid
multi-byte-derived sequences (e.g. →, —, →).
"""
import os
import glob

BASE = r'C:\Users\e135408\Downloads\agentic-ai-toggle-management\.github'

# These are chars that legitimately contain U+00E2 as their first UTF-8 byte
# U+2192 → = E2 86 92 -> decoded chars â (E2) + † (86) + ' (92) NO - that's WRONG
# Wait: U+2192 as a Python unicode char IS a single char: →
# The â appearing means the char U+00E2 is itself in the string, NOT part of →

# Let's just print every U+00E2 occurrence with its neighboring chars
files = glob.glob(BASE + r'\**\*.md', recursive=True)

print('=== All standalone U+00E2 (â) occurrences with context ===')
print()

VALID_AFTER_E2 = set()  # chars that come after â in valid sequences

for fpath in sorted(files):
    fname = os.path.basename(fpath)
    with open(fpath, 'r', encoding='utf-8') as fh:
        text = fh.read()
    
    count = 0
    i = 0
    issues = []
    while i < len(text):
        if ord(text[i]) == 0x00E2:
            # Get surrounding context (as codepoints)
            prev_ch = text[i-1] if i > 0 else '?'
            next_ch = text[i+1] if i+1 < len(text) else '?'
            next2_ch = text[i+2] if i+2 < len(text) else '?'
            
            prev_code = ord(prev_ch)
            next_code = ord(next_ch)
            next2_code = ord(next2_ch)
            
            # Context snippet
            start = max(0, i-15)
            end = min(len(text), i+15)
            snippet = ''
            for c in text[start:end]:
                code = ord(c)
                if code < 32:
                    snippet += '\\n' if c == '\n' else '\\x%02x' % code
                elif code > 126:
                    snippet += '[U+%04X]' % code
                else:
                    snippet += c
            
            issues.append('  pos %d: ...%s...' % (i, snippet))
            issues.append('    next chars: U+%04X U+%04X' % (next_code, next2_code))
            count += 1
            if count >= 3:
                issues.append('  ... (%d more)' % (text.count('\u00e2') - count))
                break
        i += 1
    
    if issues:
        print('FILE: ' + fname + ' (%d occurrences total)' % text.count('\u00e2'))
        for line in issues[:9]:
            print(line)
        print()

