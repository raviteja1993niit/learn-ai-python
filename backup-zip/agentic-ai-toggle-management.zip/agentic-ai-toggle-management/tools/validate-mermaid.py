"""
Validate Mermaid blocks in user-guide.md for common parse errors.
Checks for:
1. Em dash (U+2014) or en dash (U+2013) inside mermaid blocks
2. Unicode arrow (U+2192) inside mermaid blocks  
3. Lines ending with just a participant name after ->> (the exact error reported)
4. Unquoted special chars that may break Mermaid
"""

fpath = r'C:\Users\e135408\Downloads\agentic-ai-toggle-management\knowledge\user-guide.md'

with open(fpath, 'r', encoding='utf-8') as f:
    lines = f.readlines()

in_mermaid = False
mermaid_block = 0
errors = []
warnings = []

MERMAID_BAD_CHARS = {
    '\u2014': 'em dash (--)',
    '\u2013': 'en dash (-)',
    '\u2192': 'unicode arrow (->)',
    '\u2190': 'unicode left arrow',
    '\u21d2': 'unicode double arrow',
}

for i, line in enumerate(lines):
    stripped = line.rstrip()
    clean = stripped.strip()

    if clean == '```mermaid':
        in_mermaid = True
        mermaid_block += 1
        continue
    if in_mermaid and clean == '```':
        in_mermaid = False
        continue

    if in_mermaid:
        # Check 1: bad unicode chars
        for char, name in MERMAID_BAD_CHARS.items():
            if char in stripped:
                errors.append('Line %d: Contains %s: %s' % (i+1, name, repr(stripped[:100])))

        # Check 2: ->> or --> line ending with just participant (parse error pattern)
        import re
        # Pattern: contains ->> or --> but has a newline right after participant with no colon
        if re.search(r'->>[A-Za-z0-9_]+\s*$', stripped) and ':' not in stripped.split('->>')[-1]:
            if not stripped.strip().startswith('%') and not stripped.strip().startswith('note'):
                warnings.append('Line %d: Possible missing colon after participant in ->>: %s' % (i+1, repr(stripped[:100])))

if errors:
    print('ERRORS (%d):' % len(errors))
    for e in errors:
        print('  ' + e)
else:
    print('No unicode char errors found in any Mermaid block.')

if warnings:
    print('\nWARNINGS (%d):' % len(warnings))
    for w in warnings:
        print('  ' + w)
else:
    print('No syntax warnings.')

print('\nTotal Mermaid blocks found: %d' % mermaid_block)
print('Total lines scanned: %d' % len(lines))

