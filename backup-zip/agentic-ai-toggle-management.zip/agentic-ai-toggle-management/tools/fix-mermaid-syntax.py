"""
Comprehensive Mermaid syntax fixer for user-guide.md.

Fixes:
1. Semicolons in message labels -> replace with comma
2. Curly braces {date} {N} etc. in sequenceDiagram message labels
   -> replace { with ( and } with )  only in sequenceDiagram context message lines
3. Unquoted flowchart edge labels  A -->Label B  -> A -->|Label| B
4. Nested square brackets inside quoted node labels -> replace inner [ with (
5. {constant_name, ...} object literals in sequenceDiagram -> wrap in quotes safely
"""
import re

fpath = r'C:\Users\e135408\Downloads\agentic-ai-toggle-management\knowledge\user-guide.md'

with open(fpath, 'r', encoding='utf-8') as f:
    lines = f.readlines()

in_mermaid = False
diagram_type = None  # 'sequence' or 'flow'
fixed_lines = []
changes = []

# Known flowchart decision nodes - {text} IS valid Mermaid flowchart syntax, do NOT replace these
# Only fix { in sequenceDiagram message text (after the colon on ->> or -->> lines)

for i, raw in enumerate(lines):
    line = raw.rstrip('\n')
    clean = line.strip()
    lineno = i + 1

    if clean == '```mermaid':
        in_mermaid = True
        diagram_type = None
        fixed_lines.append(raw)
        continue

    if in_mermaid and clean == '```':
        in_mermaid = False
        diagram_type = None
        fixed_lines.append(raw)
        continue

    if in_mermaid:
        original = line

        # Detect diagram type from first keyword line
        if clean in ('sequenceDiagram',):
            diagram_type = 'sequence'
        elif clean.startswith('flowchart'):
            diagram_type = 'flow'

        # ── FIX 1: Semicolons in message labels ──────────────────────────────
        # Only on lines that are message arrows (contain ->> or -->> or --> after participant)
        if diagram_type == 'sequence' and (
            re.search(r'->>', line) or re.search(r'-->>', line)
        ):
            # Replace semicolons in the message text (after the colon)
            colon_pos = line.find(':', line.find('->>') if '->>' in line else line.find('-->>'))
            if colon_pos >= 0:
                prefix = line[:colon_pos + 1]
                msg = line[colon_pos + 1:]
                msg_fixed = msg.replace(';', ',')
                line = prefix + msg_fixed
                if line != original:
                    changes.append('L%d [SEMICOLON->COMMA]: %s' % (lineno, repr(original.strip()[:90])))

        # ── FIX 2: {date} {N} {repo} etc. in sequenceDiagram message text ───
        # Replace { } with ( ) only in message text of sequence diagrams
        if diagram_type == 'sequence':
            # Lines with message arrows: participant->>participant: message text
            msg_match = re.match(r'^(\s*(?:\w[\w\-]*)?(?:-->>|->>|--x|-x|--\)|->)(?:\w[\w\-]*)?: )(.*)', line)
            if msg_match:
                prefix = msg_match.group(1)
                msg = msg_match.group(2)
                # Replace {word} patterns (template placeholders) with (word)
                msg_fixed = re.sub(r'\{([^}]+)\}', r'(\1)', msg)
                line = prefix + msg_fixed
                if line != original:
                    changes.append('L%d [CURLY->PAREN seq]: %s' % (lineno, repr(original.strip()[:90])))
            # Also fix Note over lines
            if re.match(r'\s*[Nn]ote\s+(over|left of|right of)', line):
                line = re.sub(r'\{([^}]+)\}', r'(\1)', line)
                if line != original:
                    changes.append('L%d [CURLY->PAREN note]: %s' % (lineno, repr(original.strip()[:90])))

        # ── FIX 3: {date} {N} in flowchart node LABELS (inside quoted strings) ─
        # In flowchart: node["label {date}"] -> node["label (date)"]
        # But NOT: node{decision text} which is valid diamond syntax
        if diagram_type == 'flow':
            # Fix { } inside quoted strings ["..."] or ('...')
            def fix_quoted_curly(m):
                return m.group(0).replace('{', '(').replace('}', ')')
            new_line = re.sub(r'\["[^"]*"\]', fix_quoted_curly, line)
            new_line = re.sub(r"\['[^']*'\]", fix_quoted_curly, new_line)
            new_line = re.sub(r'\(\["[^"]*"\]\)', fix_quoted_curly, new_line)
            if new_line != line:
                changes.append('L%d [CURLY->PAREN flow label]: %s' % (lineno, repr(line.strip()[:90])))
                line = new_line

        # ── FIX 4: Unquoted flowchart edge labels ────────────────────────────
        # Pattern: A -->Label B  (without | delimiters)
        # Should be: A -->|Label| B
        if diagram_type == 'flow':
            # Match: spaces NODE -->Word WORD[  or  NODE -->Word WORD(
            # but NOT: -->|text| (already correct) or --> (no label) or --(text)--> (already correct)
            unquoted = re.match(
                r'^(\s*\w[\w\-]*\s*-->)([A-Z][a-zA-Z ]+)(\s+\w[\w\-]*[\[\(\{])',
                line
            )
            if unquoted and '|' not in line:
                prefix = unquoted.group(1)
                label = unquoted.group(2).strip()
                suffix = unquoted.group(3)
                new_line = '%s|%s|%s' % (prefix, label, suffix)
                changes.append('L%d [UNQUOTED-LABEL->|label|]: %s' % (lineno, repr(line.strip()[:90])))
                line = new_line

        # ── FIX 5: Nested brackets inside flowchart quoted node labels ────────
        # ["text [inner] text"] -> ["text (inner) text"]
        if diagram_type == 'flow':
            def fix_nested_brackets(m):
                content = m.group(0)
                # Replace [ and ] inside the outer quoted brackets
                inner = content[2:-2]  # strip ["  and  "]
                inner_fixed = re.sub(r'\[([^\]]*)\]', r'(\1)', inner)
                return '["' + inner_fixed + '"]'
            new_line = re.sub(r'\["[^"]*\[[^\]]*\][^"]*"\]', fix_nested_brackets, line)
            if new_line != line:
                changes.append('L%d [NESTED-BRACKETS->PARENS]: %s' % (lineno, repr(line.strip()[:90])))
                line = new_line

        fixed_lines.append(line + '\n')
        continue

    fixed_lines.append(raw)

# Write fixed content
fixed_content = ''.join(fixed_lines)
with open(fpath, 'r', encoding='utf-8') as f:
    original_content = f.read()

if fixed_content != original_content:
    with open(fpath, 'w', encoding='utf-8') as f:
        f.write(fixed_content)
    print('Fixed %d issues and saved file.\n' % len(changes))
    for c in changes:
        print('  ' + c)
else:
    print('No changes needed.')

