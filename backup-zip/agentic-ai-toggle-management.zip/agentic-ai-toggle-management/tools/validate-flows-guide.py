"""Run Mermaid validators against user-flows-guide.md"""
import re, sys

fpath = r'C:\Users\e135408\Downloads\agentic-ai-toggle-management\knowledge\user-flows-guide.md'

with open(fpath, 'r', encoding='utf-8') as f:
    lines = f.readlines()

in_mermaid = False
diagram_type = None
mermaid_count = 0
errors = []

BAD_UNICODE = {'\u2014':'em dash (--)','\u2013':'en dash (-)','\u2192':'arrow (->)','\u2190':'left arrow','\u21d2':'double arrow'}

for i, raw in enumerate(lines):
    line = raw.rstrip()
    clean = line.strip()

    if clean == '```mermaid':
        in_mermaid = True
        mermaid_count += 1
        diagram_type = None
        continue
    if in_mermaid and clean == '```':
        in_mermaid = False
        continue

    if in_mermaid:
        if clean in ('sequenceDiagram',): diagram_type = 'sequence'
        elif clean.startswith('flowchart'): diagram_type = 'flow'

        for char, name in BAD_UNICODE.items():
            if char in line:
                errors.append('L%d [%s]: %s' % (i+1, name, repr(line.strip()[:100])))

        if ';' in line and diagram_type == 'sequence' and ('>>' in line or '-->' in line):
            colon = line.find(':', line.find('>>') if '>>' in line else 0)
            if colon >= 0 and ';' in line[colon:]:
                errors.append('L%d [SEMICOLON in msg]: %s' % (i+1, repr(line.strip()[:100])))

        if diagram_type == 'sequence':
            m = re.match(r'^(\s*\w[\w\-]*)(->>|-->>|--x|-x)([\w][\w\-]*): (.*)', line)
            if m:
                msg = m.group(4)
                if re.search(r'\{[^}]+\}', msg):
                    errors.append('L%d [CURLY in seq msg]: %s' % (i+1, repr(line.strip()[:100])))

if errors:
    print('ERRORS (%d):' % len(errors))
    for e in errors: print('  ' + e)
else:
    print('No Mermaid syntax errors found.')

print('Total Mermaid blocks: %d | Total lines: %d' % (mermaid_count, len(lines)))

