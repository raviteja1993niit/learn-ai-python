"""
Final targeted fix for remaining garbled chars after first two passes.
Only two patterns remain:
1. U+26A0 + U+008F (⚠\x8f) -> ⚠️  (warning sign + variation selector 16)
2. euro + en-dash in code block context
"""
import os
import glob

BASE = r'C:\Users\e135408\Downloads\agentic-ai-toggle-management\.github'

FIXES = [
    # Warning emoji: ⚠ + \x8f (garbled variation selector) -> ⚠️
    ('\u26a0\x8f', '\u26a0\ufe0f'),   # ⚠\x8f -> ⚠️
    # Also handle the raw byte version
    ('\u26a0\x00\x8f', '\u26a0\ufe0f'),
    # Euro + en dash in code context (triple-quote arrow diagram)
    # """€– SA-2b  -> """: SA-2b  (was a decorative arrow/dash)
    ('"""\u20ac\u2013', '"""\u2014'),   # """€– -> """— 
]

files = glob.glob(BASE + r'\**\*.md', recursive=True)
fixed_count = 0
ok_count = 0

for fpath in sorted(files):
    fname = os.path.basename(fpath)
    with open(fpath, 'r', encoding='utf-8') as fh:
        text = fh.read()
    
    original = text
    for bad, good in FIXES:
        if bad in text:
            text = text.replace(bad, good)
    
    if text != original:
        with open(fpath, 'w', encoding='utf-8') as fh:
            fh.write(text)
        fixed_count += 1
        print('FIXED:  ' + fname)
    else:
        ok_count += 1
        print('OK:     ' + fname)

print('')
print('Done: ' + str(fixed_count) + ' fixed, ' + str(ok_count) + ' clean')

# Final report: list any non-ASCII chars that are NOT in the expected set
print('')
print('=== Final non-ASCII audit (unexpected chars only) ===')
EXPECTED = {
    0x2014,  # — em dash
    0x2013,  # – en dash  
    0x2192,  # → right arrow
    0x21d2,  # ⇒ double right arrow
    0x2190,  # ← left arrow
    0x2018,  # ' left single quote
    0x2019,  # ' right single quote
    0x201c,  # " left double quote
    0x201d,  # " right double quote
    0x2022,  # • bullet
    0x2026,  # … ellipsis
    0x2705,  # ✅ check mark button
    0x2713,  # ✓ check mark
    0x2717,  # ✗ cross mark
    0x26a1,  # ⚡ lightning bolt
    0x26a0,  # ⚠ warning sign
    0xfe0f,  # variation selector 16 (emoji modifier)
    0x2264,  # ≤ less than or equal
    0x2265,  # ≥ greater than or equal
    0xfeff,  # BOM
    0x00a0,  # non-breaking space
    0x00a9,  # © copyright
    0x2500,  # ─ box drawing
    0x2502,  # │ box drawing
    0x2514,  # └ box drawing
    0x251c,  # ├ box drawing
    0x252c,  # ┬ box drawing
    0x2534,  # ┴ box drawing
    0x253c,  # ┼ box drawing
    0x25ba,  # ► triangle
    0x25bc,  # ▼ triangle
    0x2503,  # ┃ heavy vertical
    0x2501,  # ━ heavy horizontal
    0x250f,  # ┏ heavy top-left
    0x2513,  # ┓ heavy top-right
    0x2517,  # ┗ heavy bottom-left
    0x251b,  # ┛ heavy bottom-right
    0x1f4d6, # 📖 book
    0x1f4a1, # 💡 bulb
    0x1f4cb, # 📋 clipboard
    0x2728,  # ✨ sparkles
    0x1f527, # 🔧 wrench
    0x1f4c4, # 📄 page
    0x1f4dd, # 📝 memo
    0x1f4ca, # 📊 chart
    0x1f50d, # 🔍 magnifier
    0x1f9e0, # 🧠 brain
    0x1f916, # 🤖 robot
    0x2b50,  # ⭐ star
    0x23f3,  # ⏳ hourglass
}

any_unexpected = False
for fpath in sorted(files):
    fname = os.path.basename(fpath)
    with open(fpath, 'r', encoding='utf-8') as fh:
        text = fh.read()
    unexpected = {}
    for ch in text:
        code = ord(ch)
        if code > 127 and code not in EXPECTED:
            unexpected[code] = unexpected.get(code, 0) + 1
    if unexpected:
        any_unexpected = True
        print('UNEXPECTED in ' + fname + ':')
        for code in sorted(unexpected.keys()):
            print('  U+%04X (%s) x%d' % (code, chr(code), unexpected[code]))

if not any_unexpected:
    print('All files clean - only expected Unicode characters found.')

