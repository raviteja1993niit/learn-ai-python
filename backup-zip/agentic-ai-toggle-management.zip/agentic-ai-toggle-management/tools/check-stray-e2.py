import os
import glob

BASE = r'C:\Users\e135408\Downloads\agentic-ai-toggle-management\.github'

# Check all files for remaining stray U+00E2 (â) characters
files = glob.glob(BASE + r'\**\*.md', recursive=True)

for fpath in sorted(files):
    fname = os.path.basename(fpath)
    with open(fpath, 'r', encoding='utf-8') as fh:
        text = fh.read()
    
    if '\u00e2' in text:
        print('FILE: ' + fname)
        # Show context around each occurrence
        idx = 0
        count = 0
        while True:
            pos = text.find('\u00e2', idx)
            if pos < 0 or count > 5:
                break
            start = max(0, pos - 20)
            end = min(len(text), pos + 20)
            snippet = text[start:end].replace('\n', '\\n').replace('\r', '\\r')
            print('  pos %d: ...%s...' % (pos, repr(snippet)))
            idx = pos + 1
            count += 1
        print()

