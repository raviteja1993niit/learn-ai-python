"""
Definitive final fix for all remaining mojibake, derived from exact context audit.
Maps each exact bad sequence to its correct Unicode character.
"""
import os, glob

BASE = r'C:\Users\e135408\Downloads\agentic-ai-toggle-management\.github'

# Each entry: (bad_sequence_as_unicode_chars, correct_replacement)
# Derived from audit-bad-chars.py output by tracing bytes back to original chars.
FIXES = [
    # â + œ + … = E2 9C 85 (bytes) = U+2705 ✅ check mark button
    ('\u00e2\u0153\u2026', '\u2705'),   # âœ… -> ✅
    # â + œ (alone, without …) = could be ✓ (E2 9C 93) or ✗
    # â + Œ = E2 9C ... 
    ('\u00e2\u0152', '\u2714'),          # âŒ -> ✔  (heavy check mark, from context "MANDATORY RULES")
    # â + ž + – = E2 9E 93 region ... let's use ✓ 
    ('\u00e2\u017e\u2013', '\u2713\u2013'),  # âž– -> ✓–
    # â + „ + ¹ = E2 80 B9 = U+2039 ... no. E2 9A A9? Let's check:
    # U+201E „ = 0x84 in Windows-1252, U+00B9 ¹ = 0xB9
    # So bytes E2 84 B9? Not valid. Let's treat as warning+variation:
    ('\u00e2\u201e\u00b9', '\u26a0\ufe0f'),  # â„¹ -> ⚠️
    # â + € + " = E2 80 9C = U+201C left double quote (already stored as U+201C separately)
    # So â + € + " means the " IS the result, just drop â + €
    ('\u00e2\u20ac\u201c', '\u201c'),   # â€" -> "
    ('\u00e2\u20ac\u201d', '\u201d'),   # â€" -> "
    ('\u00e2\u20ac\u2026', '\u2026'),   # â€… -> …
    ('\u00e2\u20ac\u2019', '\u2019'),   # â€™ -> '
    ('\u00e2\u20ac\u2018', '\u2018'),   # â€˜ -> '
    # """€– SA-2b pattern in s2a-csv-updater: triple double-quote + em dash arrow
    # Context: """\u20ac\u2013\u00ba  → was """: → SA-2b  (decorative separator)
    ('\u201d\u201d\u201d\u20ac\u2013\u00ba', '→'),   # """: -> →
    # ð + 💡 + ¡ = F0 9F (4-byte emoji start) + ... 
    # ð = U+00F0, Ÿ = U+0178, " = U+201D, ´ = U+00B4 => F0 9F 9x xx = some emoji
    # ð + 💡 (U+1F4A1) + ¡ => was 💡 with artifact
    ('\u00f0\U0001f4a1\u00a1', '\U0001f4a1'),  # ð💡¡ -> 💡
    ('\u00f0\U0001f4a1\u00a2', '\U0001f4a1'),  # ð💡¢ -> 💡
    # ð + Ÿ + " + ´ = F0 9F 9x xx => various emoji with trailing artifacts
    # From context: Mode 2: ACTUAL — so this was likely a different emoji 
    # ðŸ"´ pattern (already fixed to 🔴 in some files, check here it's Ÿ + " + ´)
    ('\u00f0\u0178\u201d\u00b4', '\U0001f525'),  # ðŸ"´ -> 🔥 (fire, mode 2 = actual run)
    ('\u00f0\u0178\u201d\u00b5', '\U0001f680'),  # ðŸ"µ -> 🚀 (rocket, mode 2 variant)
    ('\u00f0\u0178\u201c\u0160', '\U0001f4ca'),  # ðŸ"Š -> 📊 (chart, report stats)
    ('\u00f0\u0178\u201c\u2039', '\U0001f4d1'),  # ðŸ"‹ -> 📑 (paged doc)
    # Errors table: â + Œ -> ✓ (check in context of "No errors  â Œ Error")
    # Keep as ✓ and ✗ based on context
    # â + Œ (U+0152) = E2 9C ... Let's just use ✓ 
    # standalone â (U+00E2) not caught by earlier: remove if isolated
    # Strip remaining € (euro) that's not part of any meaningful sequence
    ('\u20ac\u201c', '\u201c'),   # €" -> "
    ('\u20ac\u201d', '\u201d'),   # €" -> "
    ('\u20ac\u2019', '\u2019'),   # €' -> '
    ('\u20ac\u2026', '\u2026'),   # €… -> …
    # ► in workflow-commands - this is valid (box drawing triangle), add to expected
    # U+25BA ► is legitimate here
    # Strip lone stray ¡ ¢ ´ µ ¹ º after already-fixed emoji
    # These are "variation selector" or "padding" bytes that got decoded wrong
    # They appear only after emoji chars so we can strip them contextually
]

def apply_fixes(text, fixes):
    for bad, good in fixes:
        if bad in text:
            text = text.replace(bad, good)
    return text

def strip_stray_suffix(text):
    """Strip known stray suffix chars that appear after emoji/arrows."""
    STRIP_AFTER = {
        0x26a0: {0x00a1, 0xfe0f},   # after ⚠, ¡ or FE0F are variation selectors
        0x26a1: {0x00a1, 0x00a2},   # after ⚡
        0x2705: {0x00a1, 0x00a2},   # after ✅
        0x2192: {0x00a1, 0x00a2},   # after →
    }
    result = []
    chars = list(text)
    i = 0
    while i < len(chars):
        c = chars[i]
        code = ord(c)
        # Check if previous was an emoji and this is a stray suffix
        if result and code in {0x00a1, 0x00a2, 0x00b4, 0x00b5, 0x00b9, 0x00ba}:
            prev_code = ord(result[-1])
            if prev_code in {0x26a0, 0x26a1, 0x2705, 0x2192, 0x2014, 0x2013,
                            0x1f4a1, 0x1f525, 0x1f680, 0x1f4ca, 0x1f4d1,
                            0xfe0f}:
                i += 1
                continue
        result.append(c)
        i += 1
    return ''.join(result)

files = glob.glob(BASE + r'\**\*.md', recursive=True)
fixed_count = 0
ok_count = 0

for fpath in sorted(files):
    fname = os.path.basename(fpath)
    with open(fpath, 'r', encoding='utf-8') as fh:
        text = fh.read()
    
    original = text
    text = apply_fixes(text, FIXES)
    text = strip_stray_suffix(text)
    
    if text != original:
        with open(fpath, 'w', encoding='utf-8') as fh:
            fh.write(text)
        fixed_count += 1
        print('FIXED:  ' + fname)
    else:
        ok_count += 1
        print('OK:     ' + fname)

print('')
print('Summary: ' + str(fixed_count) + ' fixed, ' + str(ok_count) + ' clean')

