import os

fpath = r'C:\Users\e135408\Downloads\agentic-ai-toggle-management\.github\agents\toggle-file-organizer.agent.md'

with open(fpath, 'rb') as fh:
    raw = fh.read()

text = raw.decode('utf-8')

# Find known broken area
for keyword in ['Sole', 'Task 1', 'Task 2', 'CRITICAL']:
    idx = text.find(keyword)
    if idx >= 0:
        snippet = text[idx:idx+300]
        print('=== Found: ' + keyword + ' ===')
        print(repr(snippet[:200]))
        print()
        break

# Also dump all unique non-ASCII chars in the file
non_ascii = {}
for i, ch in enumerate(text):
    code = ord(ch)
    if code > 127:
        non_ascii[code] = non_ascii.get(code, 0) + 1

print('Non-ASCII character codes in file:')
for code in sorted(non_ascii.keys()):
    count = non_ascii[code]
    try:
        char = chr(code)
    except:
        char = '?'
    print('  U+%04X (%s) x%d' % (code, char, count))

