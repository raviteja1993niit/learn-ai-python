#!/usr/bin/env powershell
<#
.SYNOPSIS
Toggle Analysis Batch Processor
Master orchestration script — Phase 3A (Locate) only.
Phase 3B (Read) and Phase 4 (Impact Analysis) are performed by the agent after reviewing
blockStart/blockEnd boundaries returned by this script.

.DESCRIPTION
Batch location workflow:
1. Reads toggles from input CSV
2. Cleans toggle names (strips row-number prefix corruption e.g. "61 | ")
3. For each toggle, calls Toggle-SearchUtility (dual search: display string + constant name)
4. Outputs structured location data (filePath, lineNumber, blockStart, blockEnd) per usage
5. Does NOT generate ON/OFF impact text — agent reads source blocks and writes impacts

The agent (Phase 3B) must call read_file(fullPath, offset=blockStart, limit=blockEnd-blockStart+5)
on each result before writing any Toggle ON/OFF impact to ToggleCodebaseUsageAnalysis.csv.

.PARAMETER BatchNumber
Batch number to process (1-15). If not specified, processes all.

.PARAMETER StartToggleIndex
Starting toggle index (0-based). Default: 0

.PARAMETER ToggleCount
Number of toggles to process. Default: 5 (process 5 per batch)

.EXAMPLE
.\Toggle-AnalysisBatchProcessor.ps1 -BatchNumber 1
.\Toggle-AnalysisBatchProcessor.ps1 -StartToggleIndex 0 -ToggleCount 3
#>

param(
    [Parameter(Mandatory=$false)]
    [int]$BatchNumber = $null,

    [Parameter(Mandatory=$false)]
    [int]$StartToggleIndex = $null,

    [Parameter(Mandatory=$false)]
    [int]$ToggleCount = 5,

    [Parameter(Mandatory=$false)]
    [string]$ToolsPath = "C:\Users\e135408\Downloads\mcp-servers\tools"
)

# Set script paths
$searchToolPath = "$ToolsPath\Toggle-SearchUtility.ps1"
$publishToolPath = "$ToolsPath\Toggle-PublishUtility.ps1"
$csvPath = "C:\Users\e135408\Downloads\mcp-servers\jobs\TogglePageEnquiry\data\FeatureToggleConfluencePageEnquiryResults.csv"

# Validate tool paths
if (-not (Test-Path $searchToolPath)) {
    Write-Host "ERROR: Toggle-SearchUtility.ps1 not found at $searchToolPath" -ForegroundColor Red
    exit 1
}
if (-not (Test-Path $publishToolPath)) {
    Write-Host "ERROR: Toggle-PublishUtility.ps1 not found at $publishToolPath" -ForegroundColor Red
    exit 1
}
if (-not (Test-Path $csvPath)) {
    Write-Host "ERROR: Input CSV not found at $csvPath" -ForegroundColor Red
    exit 1
}

# Load input toggles
Write-Host "Loading toggle input CSV..." -ForegroundColor Cyan
$rawToggles = @(Import-Csv -Path $csvPath)

# Clean row-number prefix corruption (e.g. "61 | Enable New COF Token Value for T-SPI")
$allToggles = $rawToggles | ForEach-Object {
    $cleanName = $_.toggle_name -replace '^\d+\s*\|\s*', ''
    $_ | Add-Member -NotePropertyName toggle_name -NotePropertyValue $cleanName -Force -PassThru
}
Write-Host "Found $($allToggles.Count) toggles total" -ForegroundColor Green

# Calculate batch parameters
if ($BatchNumber) {
    $StartToggleIndex = ($BatchNumber - 1) * $ToggleCount
    $batchLabel = "Batch $BatchNumber"
} else {
    $batchLabel = "Custom Range"
    if ($StartToggleIndex -eq $null) {
        $StartToggleIndex = 0
    }
}

# Get toggles for this batch
$togglesInBatch = $allToggles | Select-Object -Skip $StartToggleIndex -First $ToggleCount
$batchStartNum = $StartToggleIndex + 1
$batchEndNum = $StartToggleIndex + $togglesInBatch.Count

Write-Host ""
Write-Host "================================================" -ForegroundColor Yellow
Write-Host "$batchLabel: Toggles $batchStartNum-$batchEndNum ($($togglesInBatch.Count) toggles)" -ForegroundColor Yellow
Write-Host "================================================" -ForegroundColor Yellow
Write-Host ""

# Process each toggle
$analysisResults = @()
$toggleProcessed = 0

foreach ($toggle in $togglesInBatch) {
    $toggleProcessed++
    $toggleName = $toggle.toggle_name
    $isSa2 = $toggle.is_s2a

    Write-Host "[$toggleProcessed/$($togglesInBatch.Count)] Processing: $toggleName" -ForegroundColor Cyan
    Write-Host "  is_s2a: $isSa2"

    # Call search utility (Phase 3A — Locate)
    try {
        Write-Host "  Phase 3A: Locating usages (dual search)..." -ForegroundColor Gray
        $rawOutput = & $searchToolPath -ToggleName $toggleName -Repository "Both" -ExcludeDeclarations 2>&1

        # Parse JSON from output (ConvertFrom-Json on the first complete JSON block)
        $jsonString = ($rawOutput | Where-Object { $_ -is [string] }) -join "`n"
        $jsonStart  = $jsonString.IndexOf('{')
        $jsonResults = $null
        if ($jsonStart -ge 0) {
            try {
                $jsonResults = $jsonString.Substring($jsonStart) | ConvertFrom-Json
            } catch {
                Write-Host "  WARNING: Could not parse JSON output" -ForegroundColor Yellow
            }
        }

        if ($jsonResults -and $jsonResults.results.Count -gt 0) {
            Write-Host "  Found $($jsonResults.results.Count) usage location(s)" -ForegroundColor Green

            foreach ($loc in $jsonResults.results) {
                Write-Host "    • [$($loc.repository)] $($loc.className).java:$($loc.lineNumber) block($($loc.blockStart)-$($loc.blockEnd))" -ForegroundColor Green

                # ── Phase 3A output: location metadata only ──────────────────
                # Agent must perform Phase 3B: read_file(fullPath, offset=blockStart,
                # limit=(blockEnd - blockStart + 5)) to get the full if/else block,
                # then write ON/OFF impacts in the two-part format:
                #   Business: <what the merchant/cardholder/acquirer can or cannot do>
                #   Field Impact: <TSPI API fields / ISO DE elements / acquirer message fields>
                # ─────────────────────────────────────────────────────────────

                $analysisResults += @{
                    ToggleName              = $toggleName
                    ImplementationClassName = $loc.className
                    LineNumber              = $loc.lineNumber
                    BlockStart              = $loc.blockStart
                    BlockEnd                = $loc.blockEnd
                    FullPath                = $loc.fullPath
                    FilePath                = $loc.filePath
                    MatchLine               = $loc.matchLine
                    IsDeclaration           = $loc.isDeclaration
                    Repository              = $loc.repository
                    # ON/OFF impacts intentionally empty — agent fills these after Phase 3B read
                    ONImpact                = ""
                    OFFImpact               = ""
                }
            }
        } else {
            Write-Host "  No implementation usage locations found (declarations excluded)" -ForegroundColor Yellow
        }
    }
    catch {
        Write-Host "  ERROR during search: $_" -ForegroundColor Red
    }

    Write-Host ""
}

# Output Phase 3A location data for agent to consume (Phase 3B + 4)
if ($analysisResults.Count -gt 0) {
    Write-Host ""
    Write-Host "================================================" -ForegroundColor Yellow
    Write-Host "PHASE 3A COMPLETE — $($analysisResults.Count) locations staged for agent review" -ForegroundColor Yellow
    Write-Host "================================================" -ForegroundColor Yellow
    Write-Host ""
    Write-Host "Agent next steps (Phase 3B + Phase 4):" -ForegroundColor Cyan
    Write-Host "  For each location below, call read_file(FullPath, offset=BlockStart, limit=BlockEnd-BlockStart+5)"
    Write-Host "  Then write Toggle ON/OFF impacts in two-part format:"
    Write-Host "    Business: <what merchant/cardholder/acquirer can or cannot do>"
    Write-Host "    Field Impact: <TSPI API fields / ISO DE elements / acquirer message fields>"
    Write-Host ""

    # Output structured JSON for agent consumption
    $locationOutput = @{
        batchLabel        = $batchLabel
        totalLocations    = $analysisResults.Count
        agentAction       = "Phase3B_Read_Then_Phase4_Impact"
        locations         = $analysisResults
    }
    $locationOutput | ConvertTo-Json -Depth 10 | Write-Output

    # Only publish rows that already have ON/OFF impacts filled (agent-written rows)
    $readyToPublish = $analysisResults | Where-Object { $_.ONImpact -ne "" -and $_.OFFImpact -ne "" }
    if ($readyToPublish.Count -gt 0) {
        Write-Host ""
        Write-Host "Publishing $($readyToPublish.Count) completed analysis rows..." -ForegroundColor Cyan
        try {
            $publishResults = & $publishToolPath -AnalysisData $readyToPublish -BatchName $batchLabel -Verbose -ErrorAction Stop 2>&1
            foreach ($line in $publishResults) {
                if ($line -match "^\{") {
                    Write-Host ""
                    Write-Host "Publish Result:"
                    $line | ConvertFrom-Json | Format-Table -AutoSize
                    break
                }
            }
            Write-Host "✓ Analysis publishing COMPLETE" -ForegroundColor Green
        }
        catch {
            Write-Host "ERROR during publish: $_" -ForegroundColor Red
        }
    } else {
        Write-Host "NOTE: No rows ready to publish yet — agent must complete Phase 3B reads and write impacts first." -ForegroundColor Yellow
    }
} else {
    Write-Host "No usage locations found for this batch (all matches were declarations or no matches found)" -ForegroundColor Yellow
}

# Final summary
Write-Host ""
Write-Host "================================================" -ForegroundColor Yellow
Write-Host "BATCH PROCESSING SUMMARY (Phase 3A — Locate)" -ForegroundColor Yellow
Write-Host "================================================" -ForegroundColor Yellow
Write-Host "Batch: $batchLabel"
Write-Host "Toggles Processed: $($togglesInBatch.Count)"
Write-Host "Phase 3A Locations Staged: $($analysisResults.Count)"
Write-Host "Status: AWAITING Phase 3B (agent read_file) + Phase 4 (impact analysis)" -ForegroundColor Yellow
Write-Host ""

