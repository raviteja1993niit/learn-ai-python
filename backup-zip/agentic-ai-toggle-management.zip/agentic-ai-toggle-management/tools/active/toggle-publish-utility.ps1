#!/usr/bin/env powershell
<#
.SYNOPSIS
MCP Tool: Toggle Analysis Publisher
Writes toggle analysis results to the ToggleCodebaseUsageAnalysis.csv report
#>

param(
    [Parameter(Mandatory=$true)]
    [object[]]$AnalysisData,

    [Parameter(Mandatory=$false)]
    [string]$OutputPath = "C:\Users\e135408\Downloads\mcp-servers\jobs\TogglePageEnquiry\data\ToggleCodebaseUsageAnalysis.csv",

    [Parameter(Mandatory=$false)]
    [string]$BatchName = "Manual",

    [Parameter(Mandatory=$false)]
    [switch]$AppendOnly,

    [Parameter(Mandatory=$false)]
    [switch]$ValidateOnly,

    [Parameter(Mandatory=$false)]
    [switch]$Verbose
)

$outputDir = Split-Path -Parent $OutputPath
if (-not (Test-Path $outputDir)) {
    New-Item -ItemType Directory -Path $outputDir -Force | Out-Null
}

# Validate data
$validationErrors = @()
$validationWarnings = @()
$rowNum = 0

foreach ($row in $AnalysisData) {
    $rowNum++
    $requiredFields = @("ToggleName", "ImplementationClassName", "LineNumber", "ONImpact", "OFFImpact", "Repository")

    foreach ($field in $requiredFields) {
        if ([string]::IsNullOrWhiteSpace($row.$field)) {
            $validationErrors += "Row $rowNum`: Missing field '$field'"
        }
    }

    if ($row.Repository -notmatch "^(CPE|Orchestrator)$") {
        $validationErrors += "Row $rowNum`: Invalid Repository '$($row.Repository)'"
    }
}

Write-Host "=== DATA VALIDATION ===" -ForegroundColor Cyan
Write-Host "Validating $($AnalysisData.Count) rows..."
Write-Host ""

if ($validationErrors.Count -gt 0) {
    Write-Host "VALIDATION ERRORS ($($validationErrors.Count)):" -ForegroundColor Red
    $validationErrors | ForEach-Object { Write-Host "  X $_" }
    if (-not $ValidateOnly) { exit 1 }
}

Write-Host "✓ Validation passed" -ForegroundColor Green
Write-Host ""

if ($ValidateOnly) {
    exit 0
}

Write-Host "=== CSV PUBLISHING ===" -ForegroundColor Cyan
$fileExists = Test-Path $OutputPath
$needsHeader = (-not $fileExists) -or (-not $AppendOnly)

$csvHeader = "Toggle Name,Implementation Class Name,Line Number Code,Toggle ON Impact,Toggle OFF Impact,Repository"
$csvLines = @()

if ($needsHeader) {
    $csvLines += $csvHeader
}

foreach ($row in $AnalysisData) {
    $toggleName = "`"$($row.ToggleName.Replace('"', '""'))`""
    $className = "`"$($row.ImplementationClassName.Replace('"', '""'))`""
    $lineNum = "`"$($row.LineNumber)`""
    $onImpact = "`"$($row.ONImpact.Replace('"', '""'))`""
    $offImpact = "`"$($row.OFFImpact.Replace('"', '""'))`""
    $repo = "`"$($row.Repository)`""

    $csvLine = "$toggleName,$className,$lineNum,$onImpact,$offImpact,$repo"
    $csvLines += $csvLine
}

if ($needsHeader -or -not $fileExists) {
    $csvLines | Set-Content -Path $OutputPath -Encoding UTF8 -Force
} else {
    $csvLines | Add-Content -Path $OutputPath -Encoding UTF8
}

$lineCount = @(Get-Content $OutputPath).Count
Write-Host "Status: SUCCESS" -ForegroundColor Green
Write-Host "Rows Written: $($AnalysisData.Count)"
Write-Host "Total Lines: $lineCount"
Write-Host ""

$result = @{
    status = "SUCCESS"
    batch = $BatchName
    rowsWritten = $AnalysisData.Count
    outputFile = $OutputPath
}

$result | ConvertTo-Json | Write-Output

