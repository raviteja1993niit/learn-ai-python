#!/usr/bin/env powershell
<#
.SYNOPSIS
MCP Tool: Toggle Search Utility
Searches for toggle usage patterns in Java source files across CPE and Orchestrator repositories

.DESCRIPTION
Comprehensive toggle search tool that:
- Searches both CPE and Orchestrator repositories using DUAL search (display string + constant name)
- Finds all toggle usage locations in src/main/java only (test files excluded)
- Detects method boundaries via brace-balance walking (blockStart/blockEnd)
- Filters out pure declaration-only matches (public static final String = "...")
- Returns structured JSON results with block boundaries for targeted read_file calls

.PARAMETER ToggleName
The toggle display name to search for (exact match from CSV)

.PARAMETER ConstantName
Optional: Java constant name (e.g. TOGGLE_RANDOM_TERMINAL_ALLOCATION). If omitted,
looked up automatically from the registry. Dual search runs when constant name is available.

.PARAMETER Repository
Repository to search: "CPE", "Orchestrator", or "Both" (default)

.PARAMETER ExcludeDeclarations
If specified, excludes pure declaration lines (public static final String assignments)

.EXAMPLE
.\Toggle-SearchUtility.ps1 -ToggleName "Random Terminal Allocation" -Repository "Both"
.\Toggle-SearchUtility.ps1 -ToggleName "Random Terminal Allocation" -ConstantName "TOGGLE_RANDOM_TERMINAL_ALLOCATION"
#>

param(
    [Parameter(Mandatory=$true)]
    [string]$ToggleName,

    [Parameter(Mandatory=$false)]
    [string]$ConstantName = "",

    [Parameter(Mandatory=$false)]
    [ValidateSet("CPE", "Orchestrator", "Both")]
    [string]$Repository = "Both",

    [Parameter(Mandatory=$false)]
    [switch]$ExcludeDeclarations,

    [Parameter(Mandatory=$false)]
    [string]$RegistryPath = "C:\Users\e135408\Downloads\mcp-servers\jobs\TogglePageEnquiry\data\ToggleRegistryLookup.csv",

    [Parameter(Mandatory=$false)]
    [string]$CPEPath = "C:\Users\e135408\IdeaProjects\MPGS\SourceCode\cardpaymentengine\src\main\java",

    [Parameter(Mandatory=$false)]
    [string]$OrchestratorPath = "C:\Users\e135408\IdeaProjects\MPGS\SourceCode\orchestrator\src\main\java"
)

# ── Registry lookup ──────────────────────────────────────────────────────────
# Build declaration exclusion map and resolve constant name(s) from registry
$registryDeclarations = @{}   # key = "relPath:className" -> $true  (DECLARATION rows)
$constantNames = @()          # all constant_name values for this toggle across both repos

if (Test-Path $RegistryPath) {
    $registry = @(Import-Csv -Path $RegistryPath)
    foreach ($reg in $registry) {
        if ($reg.toggle_name -eq $ToggleName) {
            # Build exclusion key using the registry_file_path exactly as stored
            $declKey = "$($reg.registry_file_path):$($reg.registry_class_name)"
            $registryDeclarations[$declKey] = $true

            if ($reg.constant_name -and $reg.constant_name.Trim() -ne "" -and
                $constantNames -notcontains $reg.constant_name.Trim()) {
                $constantNames += $reg.constant_name.Trim()
            }
        }
    }
}

# Also honour the -ConstantName parameter if supplied
if ($ConstantName -and $ConstantName.Trim() -ne "" -and $constantNames -notcontains $ConstantName.Trim()) {
    $constantNames += $ConstantName.Trim()
}

# ── Block boundary detection ──────────────────────────────────────────────────
# Walk outward from match line using brace balance to find enclosing method block
function Get-BlockBoundaries {
    param(
        [string[]]$Lines,
        [int]$MatchIndex   # 0-based
    )

    # Walk backward to find opening brace of the enclosing method
    $blockStart = $MatchIndex
    $depth = 0
    for ($i = $MatchIndex; $i -ge 0; $i--) {
        $line = $Lines[$i]
        $depth += ($line.ToCharArray() | Where-Object { $_ -eq '}' }).Count
        $depth -= ($line.ToCharArray() | Where-Object { $_ -eq '{' }).Count
        if ($depth -lt 0) {
            $blockStart = $i
            break
        }
        if ($i -eq 0) { $blockStart = 0 }
    }

    # Walk forward to find closing brace of the enclosing method
    $blockEnd = $MatchIndex
    $depth = 0
    for ($i = $blockStart; $i -lt $Lines.Count; $i++) {
        $line = $Lines[$i]
        $depth += ($line.ToCharArray() | Where-Object { $_ -eq '{' }).Count
        $depth -= ($line.ToCharArray() | Where-Object { $_ -eq '}' }).Count
        if ($depth -le 0 -and $i -gt $blockStart) {
            $blockEnd = $i
            break
        }
        if ($i -eq $Lines.Count - 1) { $blockEnd = $i }
    }

    return @{ blockStart = $blockStart + 1; blockEnd = $blockEnd + 1 }  # 1-based for read_file
}

# ── Is line a pure declaration? ───────────────────────────────────────────────
function Test-IsDeclarationLine {
    param([string]$Line)
    # Matches:  public static final String TOGGLE_XYZ = "..."
    return $Line -match '^\s*(public\s+)?static\s+final\s+String\s+\w+\s*='
}

# ── Core search function ───────────────────────────────────────────────────────
function Search-Directory {
    param(
        [string]$SearchPath,
        [string]$RepositoryName,
        [string[]]$Patterns      # one or more patterns to search (display string + constant names)
    )

    $hits = @()

    try {
        # Only src/main/java — test files excluded
        $javaFiles = Get-ChildItem -Path $SearchPath -Recurse -Include "*.java" -File | Where-Object {
            $_.FullName -notmatch "[\\/]test[\\/]" -and
            $_.BaseName -notmatch "Test$|Tests$|Spec$|IT$|ITest$"
        }

        foreach ($file in $javaFiles) {
            try {
                $content = [System.IO.File]::ReadAllText($file.FullName, [System.Text.Encoding]::UTF8)

                # Quick pre-filter: does any pattern appear in this file at all?
                $anyMatch = $false
                foreach ($pat in $Patterns) {
                    if ($content.Contains($pat)) { $anyMatch = $true; break }
                }
                if (-not $anyMatch) { continue }

                $lines = $content -split "`n"
                $className = $file.BaseName
                $relPath = $file.FullName.Replace($SearchPath, "").Replace("\", "/").TrimStart("/")

                for ($i = 0; $i -lt $lines.Count; $i++) {
                    $lineText = $lines[$i]

                    # Check if any pattern matches this line
                    $patternMatched = $false
                    foreach ($pat in $Patterns) {
                        if ($lineText.Contains($pat)) { $patternMatched = $true; break }
                    }
                    if (-not $patternMatched) { continue }

                    # Skip pure comment lines
                    if ($lineText -match "^\s*//" -and $lineText -notmatch "isToggle|isOn|Toggles\.") {
                        continue
                    }

                    $lineNum = $i + 1

                    # Skip declaration-only lines if -ExcludeDeclarations is set
                    if ($ExcludeDeclarations -and (Test-IsDeclarationLine -Line $lineText)) {
                        continue
                    }

                    # Also check registry exclusion key for DECLARATION rows
                    $declKey = "$relPath`:$className"
                    if ($ExcludeDeclarations -and $registryDeclarations.ContainsKey($declKey)) {
                        # Only skip if this specific line is a declaration
                        if (Test-IsDeclarationLine -Line $lineText) { continue }
                    }

                    # Detect block boundaries (method-level)
                    $bounds = Get-BlockBoundaries -Lines $lines -MatchIndex $i

                    $hits += @{
                        repository  = $RepositoryName
                        className   = $className
                        filePath    = $relPath
                        fullPath    = $file.FullName
                        lineNumber  = $lineNum
                        blockStart  = $bounds.blockStart
                        blockEnd    = $bounds.blockEnd
                        matchLine   = $lineText.Trim()
                        isDeclaration = (Test-IsDeclarationLine -Line $lineText)
                    }
                }
            }
            catch {
                # Silent skip on read errors
            }
        }
    }
    catch {
        Write-Error "Error searching $RepositoryName`: $_"
    }

    return $hits
}

# ── Build pattern list for dual search ───────────────────────────────────────
# Pattern 1: display string (as it appears in Java: "Toggle Name")
# Pattern 2+: constant name(s) from registry (e.g. TOGGLE_RANDOM_TERMINAL_ALLOCATION)
$searchPatterns = @($ToggleName)
foreach ($cn in $constantNames) {
    if ($searchPatterns -notcontains $cn) {
        $searchPatterns += $cn
    }
}

Write-Host "Search patterns: $($searchPatterns -join ', ')" -ForegroundColor DarkGray

$results = @()

# ── Execute searches ──────────────────────────────────────────────────────────
if ($Repository -eq "CPE" -or $Repository -eq "Both") {
    Write-Host "Searching CPE repository..." -ForegroundColor Cyan
    $cpeMatches = Search-Directory -SearchPath $CPEPath -RepositoryName "CPE" -Patterns $searchPatterns
    $results += $cpeMatches
    Write-Host "Found $($cpeMatches.Count) matches in CPE" -ForegroundColor Green
}

if ($Repository -eq "Orchestrator" -or $Repository -eq "Both") {
    Write-Host "Searching Orchestrator repository..." -ForegroundColor Cyan
    $orchMatches = Search-Directory -SearchPath $OrchestratorPath -RepositoryName "Orchestrator" -Patterns $searchPatterns
    $results += $orchMatches
    Write-Host "Found $($orchMatches.Count) matches in Orchestrator" -ForegroundColor Green
}

# ── Deduplicate (same repo + file + line) ────────────────────────────────────
$uniqueResults = @{}
foreach ($result in $results) {
    $key = "$($result.repository):$($result.filePath):$($result.lineNumber)"
    if (-not $uniqueResults.ContainsKey($key)) {
        $uniqueResults[$key] = $result
    }
}

# ── JSON output ───────────────────────────────────────────────────────────────
$output = @{
    toggleName      = $ToggleName
    totalMatches    = $uniqueResults.Count
    searchPatterns  = $searchPatterns
    searchParameters = @{
        repository          = $Repository
        excludeDeclarations = $ExcludeDeclarations.IsPresent
    }
    results = @($uniqueResults.Values | ForEach-Object {
        @{
            repository    = $_.repository
            className     = $_.className
            filePath      = $_.filePath
            fullPath      = $_.fullPath
            lineNumber    = $_.lineNumber
            blockStart    = $_.blockStart
            blockEnd      = $_.blockEnd
            matchLine     = $_.matchLine
            isDeclaration = $_.isDeclaration
        }
    })
}

$output | ConvertTo-Json -Depth 10 | Write-Output

# ── Summary ───────────────────────────────────────────────────────────────────
Write-Host ""
Write-Host "=== SEARCH SUMMARY ===" -ForegroundColor Yellow
Write-Host "Toggle: $ToggleName"
Write-Host "Total Usage Locations Found: $($uniqueResults.Count)"
foreach ($result in $uniqueResults.Values) {
    $declTag = if ($result.isDeclaration) { " [DECLARATION]" } else { "" }
    Write-Host "  [$($result.repository)] $($result.className).java:$($result.lineNumber) (block $($result.blockStart)-$($result.blockEnd))$declTag"
}

