<#
.SYNOPSIS
Repository Memory Mapper - Analyzes repository structure and generates memory map CSV

.DESCRIPTION
Scans a repository for Java classes, analyzes their responsibilities, identifies S2A transaction flows,
and generates a comprehensive memory map CSV file for architecture understanding and documentation.

.PARAMETER RepoPath
Path to the repository root to analyze. Defaults to current directory.

.PARAMETER TreeFile
Optional path to a tree file (from run-generate-tree.bat) to use for structure analysis.

.PARAMETER OutputFile
Output CSV filename. Defaults to <repo_name>-memory-map.csv in the repo root.

.PARAMETER MaxDepth
Maximum depth to scan for Java files. -1 for unlimited (default: 5).

.PARAMETER IncludeTests
Include test classes in the analysis. Default: $false

.EXAMPLE
# Analyze current repository
.\repo-memory-mapper.ps1 -RepoPath "."

.EXAMPLE
# Analyze specific repository and output to custom file
.\repo-memory-mapper.ps1 -RepoPath "C:\path\to\repo" -OutputFile "custom-map.csv"

.EXAMPLE
# Analyze with tree file
.\repo-memory-mapper.ps1 -RepoPath "." -TreeFile ".\repo-tree.txt"
#>

param(
    [Parameter(Position=0)]
    [string]
    $RepoPath = '.',

    [Parameter(Position=1)]
    [string]
    $TreeFile = '',

    [string]
    $OutputFile = '',

    [int]
    $MaxDepth = 5,

    [switch]
    $IncludeTests = $false
)

# ============================================================================
# Configuration and Constants
# ============================================================================

$ErrorActionPreference = 'Continue'

$S2A_Keywords = @(
    'S2A', 's2a', 'serverToApp', 'ServerToApp', 'SERVER_TO_APP',
    'S2A_FLOW', 's2a_flow', 'S2ATransaction', 's2atransaction',
    'ServerAppTransaction', 'server.*app.*transaction',
    'MobileTransaction', 'AppTransaction'
)

# Critical S2A Impact Classes
$CriticalS2AClasses = @(
    'MegaMessageMap',
    'JsonMegaMessageMap',
    'Tspi'
)

$ClassificationPatterns = @{
    'Controller'  = @('Controller', 'Servlet', 'Rest', 'Http')
    'Service'     = @('Service', 'Manager', 'Processor', 'Handler')
    'Repository'  = @('Repository', 'Dao', 'Mapper', 'Query')
    'Model'       = @('Entity', 'Model', 'VO', 'DTO', 'Request', 'Response', 'Payload')
    'Config'      = @('Config', 'Configuration', 'Settings', 'Properties')
    'Utility'     = @('Util', 'Helper', 'Tools', 'Convert', 'Parser', 'Builder')
    'Exception'   = @('Exception', 'Error', 'ErrorHandler')
    'Listener'    = @('Listener', 'Observer', 'Callback')
    'Interceptor' = @('Interceptor', 'Filter', 'Middleware')
}

# ============================================================================
# Helper Functions
# ============================================================================

function Write-Log {
    param([string]$Message, [string]$Level = 'INFO')
    $timestamp = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
    Write-Host "[$timestamp] [$Level] $Message"
}

function Resolve-RepoPath {
    param([string]$Path)
    try {
        $resolved = Resolve-Path -LiteralPath $Path -ErrorAction Stop
        return $resolved.Path
    } catch {
        Write-Log "Failed to resolve path: $Path" 'ERROR'
        exit 1
    }
}

function Get-RepoName {
    param([string]$Path)
    return (Split-Path -Leaf $Path)
}

function Classify-Class {
    param([string]$ClassName, [string]$Content)

    foreach ($classification in $ClassificationPatterns.GetEnumerator()) {
        foreach ($pattern in $classification.Value) {
            if ($ClassName -match $pattern) {
                return $classification.Key
            }
        }
    }
    return 'Other'
}

function Detect-S2A-Flow {
    param([string]$ClassName, [string]$Content)

    $isS2A = $false
    $details = @()

    if (-not $Content) { return @($isS2A, $details) }

    # Check if this is a critical S2A class
    foreach ($criticalClass in $CriticalS2AClasses) {
        if ($ClassName -eq $criticalClass -or $ClassName -match $criticalClass) {
            $isS2A = $true
            $details += "Critical S2A Class: $criticalClass"
        }
    }

    # Check if this class depends on critical S2A classes
    foreach ($criticalClass in $CriticalS2AClasses) {
        if ($Content -match "\b$criticalClass\b") {
            $isS2A = $true
            $details += "Depends on: $criticalClass"
        }
    }

    # Check for keyword matches
    foreach ($keyword in $S2A_Keywords) {
        if ($Content -match $keyword) {
            $isS2A = $true
            $details += "Keyword: $keyword"
        }
    }

    # Check for common S2A patterns
    if ($Content -match 'transaction.*mobile|mobile.*transaction|app.*payment|payment.*app') {
        $isS2A = $true
        $details += "Pattern: Mobile/App Transaction"
    }

    # Check for specific method patterns
    if ($Content -match 'processS2A|handleS2A|s2aTransaction|server.*app.*flow') {
        $isS2A = $true
        $details += "Pattern: S2A Method"
    }

    return @($isS2A, ($details -join '; '))
}

function Extract-Dependencies {
    param([string]$Content, [string]$ClassName)

    $dependencies = @()

    # Find import statements and class dependencies
    $imports = $Content | Select-String '@(Autowired|Inject|Resource)\s+\w+\s+(\w+)' -AllMatches | ForEach-Object { $_.Matches.Groups[1].Value }
    $imports = @($imports | Select-Object -Unique | Where-Object { $_ -ne $ClassName })

    # Find class declarations that indicate dependencies
    $extends = $Content | Select-String 'extends\s+(\w+)' -AllMatches | ForEach-Object { $_.Matches.Groups[1].Value }
    $implements = $Content | Select-String 'implements\s+([\w\s,]+)' -AllMatches | ForEach-Object { $_.Matches.Groups[1].Value }

    $dependencies += @($imports)
    if ($extends) { $dependencies += @($extends) }
    if ($implements) { $dependencies += @($implements -split ',') }

    return $dependencies | Select-Object -Unique | Where-Object { $_ -and $_.Trim().Length -gt 0 } | ForEach-Object { $_.Trim() }
}

function Extract-Package {
    param([string]$Content)

    $match = $Content | Select-String 'package\s+([\w.]+);' -AllMatches
    if ($match) {
        return $match.Matches[0].Groups[1].Value
    }
    return ''
}

function Get-ClassDescription {
    param([string]$ClassName, [string]$Content, [string]$ClassType)

    # Try to extract JavaDoc
    $javadocMatch = $Content | Select-String '/\*\*\s*\n\s*\*\s*(.+?)\n\s*\*/' -AllMatches
    if ($javadocMatch) {
        return $javadocMatch.Matches[0].Groups[1].Value.Trim()
    }

    # Generate description based on class type and name
    switch ($ClassType) {
        'Controller' { return "REST Controller for $ClassName operations" }
        'Service' { return "Business logic service for $ClassName" }
        'Repository' { return "Data access layer for $ClassName" }
        'Model' { return "Data model/Entity representing $ClassName" }
        'Config' { return "Configuration class for $ClassName" }
        'Utility' { return "Utility/Helper class for $ClassName operations" }
        default { return "Class: $ClassName" }
    }
}

function Set-Priority {
    param([string]$ClassType, [bool]$IsS2A)

    if ($IsS2A) { return 'High' }

    switch ($ClassType) {
        'Controller' { return 'High' }
        'Service' { return 'High' }
        'Repository' { return 'Medium' }
        'Model' { return 'Medium' }
        default { return 'Low' }
    }
}

# ============================================================================
# Main Analysis Functions
# ============================================================================

function Analyze-Repository {
    param([string]$Path, [int]$MaxDepth, [bool]$IncludeTests)

    Write-Log "Starting repository analysis: $Path"

    $javaFiles = @()

    # Search for Java files
    $srcPath = Join-Path $Path 'src'
    if (Test-Path $srcPath) {
        $mainPath = Join-Path $srcPath 'main\java'
        if (Test-Path $mainPath) {
            if ($MaxDepth -gt 0) {
                $javaFiles += @(Get-ChildItem -Path $mainPath -Filter '*.java' -Recurse -Depth $MaxDepth -ErrorAction SilentlyContinue)
            } else {
                $javaFiles += @(Get-ChildItem -Path $mainPath -Filter '*.java' -Recurse -ErrorAction SilentlyContinue)
            }
        }

        if ($IncludeTests) {
            $testPath = Join-Path $srcPath 'test\java'
            if (Test-Path $testPath) {
                if ($MaxDepth -gt 0) {
                    $javaFiles += @(Get-ChildItem -Path $testPath -Filter '*.java' -Recurse -Depth $MaxDepth -ErrorAction SilentlyContinue)
                } else {
                    $javaFiles += @(Get-ChildItem -Path $testPath -Filter '*.java' -Recurse -ErrorAction SilentlyContinue)
                }
            }
        }
    }

    Write-Log "Found $($javaFiles.Count) Java files"

    $analysisResults = @()
    $processedCount = 0

    foreach ($file in $javaFiles) {
        $processedCount++

        if ($processedCount % 50 -eq 0) {
            Write-Log "Processing: $processedCount / $($javaFiles.Count) files"
        }

        try {
            $content = Get-Content -Path $file.FullName -Raw -ErrorAction Stop
            $className = $file.BaseName
            $package = Extract-Package -Content $content
            $classType = Classify-Class -ClassName $className -Content $content
            $s2aResult = Detect-S2A-Flow -ClassName $className -Content $content
            $isS2A = $s2aResult[0]
            $s2aDetails = $s2aResult[1]
            $dependencies = Extract-Dependencies -Content $content -ClassName $className
            $description = Get-ClassDescription -ClassName $className -Content $content -ClassType $classType
            $priority = Set-Priority -ClassType $classType -IsS2A $isS2A
            $relativePath = $file.FullName.Replace($Path, '').TrimStart('\')

            $analysisResults += [PSCustomObject]@{
                CLASS_NAME    = $className
                PACKAGE       = $package
                CLASS_TYPE    = $classType
                RESPONSIBILITY = $description
                IS_S2A_FLOW   = if ($isS2A) { 'Yes' } else { 'No' }
                S2A_DETAILS   = if ($s2aDetails) { $s2aDetails } else { '' }
                DEPENDENCIES  = ($dependencies -join ', ')
                FILE_PATH     = $relativePath
                PRIORITY      = $priority
                NOTES         = ''
            }
        } catch {
            Write-Log "Error processing file $($file.FullName): $_" 'WARN'
        }
    }

    return $analysisResults
}

function Export-MemoryMapCSV {
    param([array]$Results, [string]$OutputPath)

    Write-Log "Exporting memory map to: $OutputPath"

    try {
        $Results | Export-Csv -Path $OutputPath -NoTypeInformation -Encoding UTF8 -Force
        Write-Log "Memory map exported successfully"
        Write-Log "Total classes analyzed: $($Results.Count)"

        # Print summary statistics
        $s2aCount = ($Results | Where-Object { $_.IS_S2A_FLOW -eq 'Yes' }).Count
        $byType = $Results | Group-Object -Property CLASS_TYPE | Select-Object @{Name='Type';Expression={$_.Name}}, @{Name='Count';Expression={$_.Count}}

        Write-Log "S2A Flow Classes: $s2aCount"
        Write-Log "Classes by Type:"
        foreach ($type in $byType) {
            Write-Log "  $($type.Type): $($type.Count)"
        }

        return $true
    } catch {
        Write-Log "Failed to export CSV: $_" 'ERROR'
        return $false
    }
}

# ============================================================================
# Main Execution
# ============================================================================

$resolvedPath = Resolve-RepoPath -Path $RepoPath
$repoName = Get-RepoName -Path $resolvedPath

if (-not $OutputFile -or $OutputFile.Trim() -eq '') {
    $OutputFile = Join-Path $resolvedPath "$repoName-memory-map.csv"
} else {
    # If just a filename, put it in the repo root
    if (-not (Split-Path -Path $OutputFile -Parent)) {
        $OutputFile = Join-Path $resolvedPath $OutputFile
    }
}

Write-Log "Repository Memory Mapper"
Write-Log "========================"
Write-Log "Repository Path: $resolvedPath"
Write-Log "Repository Name: $repoName"
Write-Log "Output File: $OutputFile"
Write-Log "Include Tests: $IncludeTests"
Write-Log ""

# Analyze repository
$results = Analyze-Repository -Path $resolvedPath -MaxDepth $MaxDepth -IncludeTests $IncludeTests

# Export results
if ($results -and $results.Count -gt 0) {
    $success = Export-MemoryMapCSV -Results $results -OutputPath $OutputFile
    if ($success) {
        Write-Log "Analysis complete! Memory map saved to: $OutputFile"
        exit 0
    } else {
        Write-Log "Analysis complete but export failed." 'ERROR'
        exit 3
    }
} else {
    Write-Log "No Java classes found to analyze." 'WARN'
    exit 2
}

