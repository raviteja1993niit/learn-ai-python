#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
fix_csv_encoding.py
Rewrites ToggleCodebaseUsageAnalysis.csv fixing the 8 NOT_FOUND stubs
with proper UTF-8 encoding (no BOM).
"""

import os

csv_path = r"/jobs/TogglePageEnquiry/data/ToggleCodebaseUsageAnalysis.csv"

# Read the current file - try UTF-8 first, fall back to latin-1
try:
    with open(csv_path, 'r', encoding='utf-8-sig') as f:
        lines = f.readlines()
    print(f"Read {len(lines)} lines (utf-8-sig)")
except Exception as e:
    with open(csv_path, 'r', encoding='latin-1') as f:
        lines = f.readlines()
    print(f"Read {len(lines)} lines (latin-1): {e}")

# Fix mojibake in the newly written lines (â€" -> —, â€™ -> ', etc.)
def fix_mojibake(text):
    """Fix UTF-8 bytes misread as latin-1"""
    try:
        return text.encode('latin-1').decode('utf-8')
    except Exception:
        return text

fixed_lines = []
mojibake_count = 0
for line in lines:
    if 'â€' in line or 'â€™' in line or 'â€œ' in line:
        fixed = fix_mojibake(line)
        fixed_lines.append(fixed)
        mojibake_count += 1
    else:
        fixed_lines.append(line)

print(f"Fixed mojibake in {mojibake_count} lines")

# Write back as clean UTF-8 without BOM
with open(csv_path, 'w', encoding='utf-8', newline='') as f:
    f.writelines(fixed_lines)

print(f"Written {len(fixed_lines)} lines as UTF-8 without BOM")

# Verify a few key lines
with open(csv_path, 'r', encoding='utf-8') as f:
    verify_lines = f.readlines()

print(f"\nVerification - total lines: {len(verify_lines)}")
for i, check_line in enumerate(verify_lines):
    if 'HistoricalTransactionDataCollector' in check_line:
        print(f"Line {i+1} [HistoricalTransactionDataCollector]: {check_line[:100]}...")
    if 'PANMaskingHelper' in check_line:
        print(f"Line {i+1} [PANMaskingHelper]: {check_line[:100]}...")
    if 'ReversalDaemon' in check_line:
        print(f"Line {i+1} [ReversalDaemon]: {check_line[:100]}...")
    if 'FailoverController' in check_line:
        print(f"Line {i+1} [FailoverController]: {check_line[:100]}...")
    if 'RemoteStripeService' in check_line:
        print(f"Line {i+1} [RemoteStripeService]: {check_line[:100]}...")
    if 'â€' in check_line:
        print(f"Line {i+1} STILL HAS MOJIBAKE: {check_line[:80]}")

print("\nDone.")

