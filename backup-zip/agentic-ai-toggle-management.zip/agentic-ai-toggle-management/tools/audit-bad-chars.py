"""
Check context of remaining truly unexpected chars to determine correct fix.
"""
import os, glob

BASE = r'C:\Users\e135408\Downloads\agentic-ai-toggle-management\.github'

# Chars that ARE legitimate (don't report these)
KNOWN_VALID = {
    # Math / technical
    0x00D7, 0x2260, 0x00B1, 0x00B7, 0x2264, 0x2265, 0x2248,
    0x2610, 0x2713, 0x2717, 0x274C, 0x2705, 0x2714,
    # Symbols
    0x00A7, 0x00A9, 0x00B0, 0x00AE,
    # Emoji
    0x1F195, 0x1F534, 0x1F7E1, 0x1F4C2, 0x1F4C4, 0x1F4A1,
    0x1F527, 0x1F4D6, 0x1F4CB, 0x1F4CA, 0x1F4DD, 0x1F4C8,
    0x1F50D, 0x1F9E0, 0x1F916, 0x2B50, 0x23F3, 0x2728,
    0x1F4E4, 0x1F4E5, 0x1F4CC, 0x1F4CE, 0x1F4CF,
    0x1F6A7, 0x1F525, 0x1F3AF, 0x1F4AB,
    # Standard expected
    0x2014, 0x2013, 0x2192, 0x2190, 0x21D2, 0x2022, 0x2026,
    0x2018, 0x2019, 0x201C, 0x201D,
    0x26A0, 0x26A1, 0xFE0F,
    0x2500, 0x2502, 0x2514, 0x251C, 0x252C, 0x2534, 0x253C,
    0x2503, 0x2501, 0x250F, 0x2513, 0x2517, 0x251B,
    0xFEFF, 0x00A0,
}

TRULY_BAD_CODES = set()

files = glob.glob(BASE + r'\**\*.md', recursive=True)
for fpath in sorted(files):
    fname = os.path.basename(fpath)
    with open(fpath, 'r', encoding='utf-8') as fh:
        text = fh.read()
    
    bad_chars = {}
    for ch in text:
        code = ord(ch)
        if code > 127 and code not in KNOWN_VALID:
            bad_chars[code] = bad_chars.get(code, 0) + 1
    
    if bad_chars:
        print('STILL BAD in ' + fname + ':')
        for code in sorted(bad_chars.keys()):
            TRULY_BAD_CODES.add(code)
            # Find context
            idx = text.find(chr(code))
            if idx >= 0:
                start = max(0, idx-10)
                end = min(len(text), idx+15)
                snippet = ''
                for c in text[start:end]:
                    c_code = ord(c)
                    if c_code < 32:
                        snippet += '\\n'
                    elif c_code > 126:
                        snippet += '[%s/U+%04X]' % (c if c_code < 0x2000 else '?', c_code)
                    else:
                        snippet += c
                print('  U+%04X (%s) x%d  context: ...%s...' % (
                    code, repr(chr(code)), bad_chars[code], snippet))
        print()

print('Unique truly-bad codepoints:', sorted(hex(c) for c in TRULY_BAD_CODES))

