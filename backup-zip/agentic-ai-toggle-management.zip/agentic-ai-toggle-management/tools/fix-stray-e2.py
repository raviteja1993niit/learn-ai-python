"""
Final cleanup: remove stray U+00E2 (â) prefix bytes that appear
immediately before known Unicode characters (→, —, ⚠, ⚡, ✅, etc.)
These are leftover first-bytes from incomplete mojibake conversion.
Also fix remaining isolated Windows-1252 artifacts.
"""
import os
import glob
import re

BASE = r'C:\Users\e135408\Downloads\agentic-ai-toggle-management\.github'

# Characters that U+00E2 incorrectly precedes (it should be stripped)
STRIP_E2_BEFORE = {
    0x2014,  # — em dash
    0x2013,  # – en dash
    0x2192,  # → right arrow
    0x2190,  # ← left arrow
    0x21d2,  # ⇒ double arrow
    0x2705,  # ✅ check mark
    0x2713,  # ✓ check
    0x2717,  # ✗ cross
    0x26a0,  # ⚠ warning
    0x26a1,  # ⚡ lightning
    0x2022,  # • bullet
    0x2026,  # … ellipsis
    0x2264,  # ≤ less-equal
    0x2265,  # ≥ greater-equal
    0x2018,  # ' left single quote
    0x2019,  # ' right single quote
    0x201c,  # " left double quote
    0x201d,  # " right double quote
    0x2500,  # ─ box drawing
    0x2502,  # │ box drawing
    0x2514,  # └ box drawing
    0x251c,  # ├ box drawing
    0xfe0f,  # variation selector
}

# Additional targeted replacements for remaining artifacts
EXTRA_FIXES = [
    # U+00E2 before ⚡ then U+00A1 (the ⚡ emoji modifier leftover)
    ('\u26a1\u00a1', '\u26a1'),     # ⚡¡ -> ⚡  (strip stray ¡)
    # U+00A5 (¥) before numbers = was ≤ sign damage
    ('\u2264\u00a5', '\u2264'),     # ≤¥ -> ≤
    # U+2020 (†) alone remaining = was right arrow second byte
    ('\u2020', '\u2192'),           # † -> → (dagger leftover)
    # U+0090 (control char) = leftover from emoji encoding
    ('\u0090', ''),                 # strip control char
    # U+009D (control char) = leftover
    ('\u009d', ''),
    # U+008F (control char) = leftover  
    ('\u008f', ''),
    # U+00A1 (¡) after emoji = leftover variation selector byte
    ('\u26a1\u00a1', '\u26a1'),
    # U+20AC (€) + U+2014 = was em dash (already fixed in first pass but check combos)
    ('\u20ac\u2014', '\u2014'),     # €— -> —
    # U+20AC remaining before other chars
    ('\u20ac\u2192', '\u2192'),     # €→ -> →
    ('\u20ac\u2013', '\u2013'),     # €– -> –
    ('\u20ac\u2026', '\u2026'),     # €… -> …
    ('\u20ac\u2022', '\u2022'),     # €• -> •
    # U+0178 (Ÿ) leftover from 4-byte emoji
    ('\u0178\u017e', ''),           # Ÿž -> strip (garbled 4-byte emoji artifacts)
    # U+0153 (œ) = second byte of some sequences, usually can be stripped
    # Only strip when adjacent to other garbled chars
    # U+00F0 (ð) before 0x9F = 4-byte emoji lead (U+F0 9F = 4-byte UTF-8 emoji start)
    # These were emoji like 📖 📋 etc that got double-mangled
    # Common 4-byte emoji artifacts: ð + Ÿ + specific char
    ('\u00f0\u0178\u0178', '\U0001f4a1'),   # ðŸŸ -> 💡 light bulb
    ('\u00f0\u0178\u0161', '\U0001f527'),   # ðŸš -> 🔧 wrench
    ('\u00f0\u0178\u0092', '\U0001f4d2'),   # ðŸ' -> 📒 notebook
    # U+00C2 (Â) before space = non-breaking space artifact
    ('\u00c2\u00a0', '\u00a0'),
    ('\u00c2\u00a9', '\u00a9'),     # Â© -> ©
]

def fix_stray_e2(text):
    """Remove U+00E2 when it immediately precedes a known special char."""
    result = []
    i = 0
    chars = list(text)
    n = len(chars)
    while i < n:
        ch = chars[i]
        if ord(ch) == 0x00E2 and i + 1 < n and ord(chars[i+1]) in STRIP_E2_BEFORE:
            # Skip this stray â
            i += 1
            continue
        result.append(ch)
        i += 1
    return ''.join(result)

files = glob.glob(BASE + r'\**\*.md', recursive=True)
fixed_count = 0
ok_count = 0

for fpath in sorted(files):
    fname = os.path.basename(fpath)
    with open(fpath, 'r', encoding='utf-8') as fh:
        text = fh.read()
    
    original = text
    
    # Apply extra targeted fixes first
    for bad, good in EXTRA_FIXES:
        if bad in text:
            text = text.replace(bad, good)
    
    # Then strip stray E2 prefixes
    text = fix_stray_e2(text)
    
    if text != original:
        with open(fpath, 'w', encoding='utf-8') as fh:
            fh.write(text)
        fixed_count += 1
        print('FIXED:  ' + fname)
    else:
        ok_count += 1
        print('OK:     ' + fname)

print('')
print('Summary: ' + str(fixed_count) + ' fixed, ' + str(ok_count) + ' clean')

