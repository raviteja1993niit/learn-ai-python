"""
Comprehensive mojibake fix for all .md files.
Strategy: detect sequences of Latin-1 characters that are actually UTF-8 bytes
misinterpreted as Latin-1, and fix them back to proper Unicode.

The key insight: when UTF-8 multi-byte sequences are stored as individual
Unicode codepoints that match their byte values (i.e., each byte value < 256),
we can detect runs of such chars and re-decode them.

We use a targeted approach: identify known bad sequences by their exact
Unicode codepoints and map them to the correct characters.
"""
import os
import glob
import re

BASE = r'C:\Users\e135408\Downloads\agentic-ai-toggle-management\.github'

def fix_mojibake(text):
    """
    Fix text where UTF-8 multi-byte sequences were stored as individual chars.
    We detect runs of chars in range 0x80-0xFF that form valid UTF-8 when
    their codepoint values are treated as bytes.
    """
    result = []
    i = 0
    chars = list(text)
    n = len(chars)
    
    while i < n:
        c = chars[i]
        code = ord(c)
        
        # Check if this looks like the start of a UTF-8 multi-byte sequence
        # stored as individual Latin-1 characters
        if 0xC2 <= code <= 0xF4:
            # Try to read 1-3 more bytes and see if they form a valid UTF-8 sequence
            max_len = 4 if code >= 0xF0 else (3 if code >= 0xE0 else 2)
            # Look ahead
            seq_bytes = bytes([code])
            j = i + 1
            while j < n and j < i + max_len:
                next_code = ord(chars[j])
                if 0x80 <= next_code <= 0xBF:
                    seq_bytes += bytes([next_code])
                    j += 1
                else:
                    break
            
            if len(seq_bytes) == max_len:
                try:
                    decoded = seq_bytes.decode('utf-8')
                    result.append(decoded)
                    i = j
                    continue
                except UnicodeDecodeError:
                    pass
            
            # Try 2-byte if we failed on longer
            if max_len >= 3 and len(seq_bytes) >= 2:
                try:
                    decoded = seq_bytes[:2].decode('utf-8')
                    result.append(decoded)
                    i = i + 2
                    continue
                except UnicodeDecodeError:
                    pass
        
        result.append(c)
        i += 1
    
    return ''.join(result)


files = glob.glob(BASE + r'\**\*.md', recursive=True)
fixed_count = 0
ok_count = 0

for fpath in sorted(files):
    fname = os.path.basename(fpath)
    with open(fpath, 'r', encoding='utf-8') as fh:
        text = fh.read()
    
    original = text
    fixed = fix_mojibake(text)
    
    if fixed != original:
        with open(fpath, 'w', encoding='utf-8') as fh:
            fh.write(fixed)
        fixed_count += 1
        print('FIXED:  ' + fname)
    else:
        ok_count += 1
        print('OK:     ' + fname)

print('')
print('Summary: ' + str(fixed_count) + ' fixed, ' + str(ok_count) + ' already clean')

# Quick sanity check on a known file
print('')
print('=== Spot check: toggle-file-organizer.agent.md ===')
fpath = BASE + r'\agents\toggle-file-organizer.agent.md'
with open(fpath, 'r', encoding='utf-8') as fh:
    text = fh.read()
idx = text.find('Sole')
if idx >= 0:
    print(repr(text[idx:idx+120]))

