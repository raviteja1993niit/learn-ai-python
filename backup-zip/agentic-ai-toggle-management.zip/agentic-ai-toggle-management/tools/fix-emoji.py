"""
Fix remaining garbled emoji/special characters in .md files.
These are Windows-1252 single/double byte sequences that survived the first pass.
"""
import os
import glob

BASE = r'C:\Users\e135408\Downloads\agentic-ai-toggle-management\.github'

# Additional fixes for remaining garbled chars found in check-stray-e2 output
# Pattern -> correct replacement
FIXES = [
    # Garbled checkmark emojis: Windows-1252 0x9D 0x90 => various checkmarks
    ('\u02dc\x90', '\u2705'),        # ˜\x90 -> ✅ (check mark button)
    ('\u02dc\x90', '\u2705'),        # same
    # Garbled warning/info emojis
    ('\u0161\xa0\x8f', '\u26a0\ufe0f'),   # š\xa0\x8f -> ⚠️
    ('\u0161\xa0', '\u26a0'),             # š\xa0 -> ⚠
    # Lightning bolt
    ('\u0161', '\u26a1'),                  # š alone in emoji context -> ⚡
    # Garbled book/bookmark emoji
    ('\u0178\x9f', '\U0001f4d6'),         # Ÿ\x9f -> 📖 (open book)
    # ‰ (per mille) used where ≤ should be
    ('\u2030', '\u2264'),                  # ‰ -> ≤
    # Garbled arrow in SA-2c: """€– 
    ('\u20ac\u2013', '\u2013'),           # €– -> – (en dash, keep)
    # Remaining stray sequences
    ('\u00e2\u02dc\x90', '\u2705'),       # â˜\x90 -> ✅
    ('\u00e2\x9c\x85', '\u2705'),         # -> ✅
    ('\u00e2\x9a\xa1', '\u26a1'),         # -> ⚡
    ('\u00e2\x9a\xa0', '\u26a0'),         # -> ⚠
    # Mode labels with garbled emoji
    ('\u0178\u0178', '\U0001f4a1'),       # ŸŸ -> 💡
]

files = glob.glob(BASE + r'\**\*.md', recursive=True)
fixed_count = 0
ok_count = 0

for fpath in sorted(files):
    fname = os.path.basename(fpath)
    with open(fpath, 'r', encoding='utf-8') as fh:
        text = fh.read()
    
    original = text
    
    for bad, good in FIXES:
        if bad in text:
            text = text.replace(bad, good)
    
    if text != original:
        with open(fpath, 'w', encoding='utf-8') as fh:
            fh.write(text)
        fixed_count += 1
        print('FIXED:  ' + fname)
    else:
        ok_count += 1
        print('OK:     ' + fname)

print('')
print('Summary: ' + str(fixed_count) + ' fixed, ' + str(ok_count) + ' clean')

