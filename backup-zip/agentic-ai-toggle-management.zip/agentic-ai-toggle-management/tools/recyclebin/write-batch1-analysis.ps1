########################################
# Batch 1 Final Analysis - Manual Data Entry
# Based on code review of toggle usages
########################################

$outputPath = "C:\Users\e135408\Downloads\mcp-servers\jobs\TogglePageEnquiry\data\ToggleCodebaseUsageAnalysis.csv"

# Create analysis data for Batch 1 (5 toggles)
$analysisData = @(
    @{
        'Toggle Name' = "System Toggle: CPE Load Balancer Uses Ping"
        'Implementation Class Name' = "MerchantLoadBalancer"
        'Line Number Code' = "82"
        'Toggle ON Impact' = "When enabled: Checks if toggle is ON, calls pingServers() method in Scheduled bean (@Scheduled(fixedDelayString...)); iterates over usableServers entrySet; for each entry calls pingServer() method; updates usableServers map with new status; logs server status changes via log.info()"
        'Toggle OFF Impact' = "When disabled: Early return from pingServers() method at line 82-84; skips all server ping operations; usableServers map remains unchanged; no server health checks performed"
        'Repository' = "CPE"
    },
    @{
        'Toggle Name' = "System Toggle: CPE Load Balancer Uses Ping"
        'Implementation Class Name' = "MerchantLoadBalancer"
        'Line Number Code' = "195"
        'Toggle ON Impact' = "When enabled: Filters usableServers entrySet to include only entries where value == true (servers that are up); maps entries to ServerKey objects; maps ServerKey to ServerAddress objects; collects into List; returns filtered candidate list of UP servers for load balancing"
        'Toggle OFF Impact' = "When disabled: Returns entire candidateServerList without filtering; all servers included regardless of health status; no usableServers filtering applied"
        'Repository' = "CPE"
    },
    @{
        'Toggle Name' = "System Toggle: Enable Lookup up to 8 digit bin for Card Identification"
        'Implementation Class Name' = "BinBaseCardBrandService"
        'Line Number Code' = "63"
        'Toggle ON Impact' = "When enabled: Performs BIN lookup supporting up to 8 digit BIN (6-digit, 7-digit, 8-digit BIN); BinBase service queries Global BIN files with extended BIN length; returns card brand/type identification for Card Identification Service"
        'Toggle OFF Impact' = "When disabled: BIN lookup limited to standard length; Card Identification Service uses fallback mechanism or standard BIN range; reduced BIN matching capability"
        'Repository' = "CPE"
    },
    @{
        'Toggle Name' = "Apply New Order ID Reuse Rule"
        'Implementation Class Name' = "OrderIdReuseHelper"
        'Line Number Code' = "36"
        'Toggle ON Impact' = "When enabled in CPE: Applies new Order ID reuse rule; allows reuse of orders where transaction was successfully processed by acquirer, subsequently blocked by risk (response.gatewayCode=BLOCKED), and successfully reversed; implements new reuse validation logic"
        'Toggle OFF Impact' = "When disabled in CPE: Follows legacy Order ID reuse rules; does not apply new reuse conditions; prevents certain order reuse scenarios"
        'Repository' = "CPE"
    },
    @{
        'Toggle Name' = "Apply New Order ID Reuse Rule"
        'Implementation Class Name' = "OrderIdReuseHelper"
        'Line Number Code' = "45"
        'Toggle ON Impact' = "When enabled in Orchestrator: Applies new Order ID reuse validation; checks if order can be reused based on transaction history and risk blocking status; allows reuse for blocked-then-reversed scenarios"
        'Toggle OFF Impact' = "When disabled in Orchestrator: Uses legacy validation logic; rejects order reuse for scenarios that would be allowed with new rules; preserves backward compatibility"
        'Repository' = "Orchestrator"
    },
    @{
        'Toggle Name' = "System Toggle: Disables loading from orderCache in CPE for Transaction Retrieval"
        'Implementation Class Name' = "TransactionRetrievalDataAccess"
        'Line Number Code' = "40"
        'Toggle ON Impact' = "When enabled: Bypasses orderCache for transaction retrieval operations; skips cache lookup; queries database directly; avoids race condition issues with immediate capture after auth when card wallet used"
        'Toggle OFF Impact' = "When disabled: Uses orderCache for transaction retrieval; loads from cache first before database query; default behavior for transaction retrieval performance optimization"
        'Repository' = "CPE"
    },
    @{
        'Toggle Name' = "Enable TAF fields support for Passthrough"
        'Implementation Class Name' = "S2IAcquirerToggleConstants"
        'Line Number Code' = "139"
        'Toggle ON Impact' = "When enabled: Enables TAF (Transaction Authentication Framework) field support for passthrough transactions; allows merchant to send TAF-required fields (ID&V completion markers); processes and validates TAF fields in transaction request; sends TAF fields to S2I acquirer"
        'Toggle OFF Impact' = "When disabled: TAF fields not processed in passthrough transactions; field validation skipped; TAF field mapping not applied to S2I messages"
        'Repository' = "CPE"
    }
)

# Clear CSV and write header
@"
Toggle Name,Implementation Class Name,Line Number Code,Toggle ON Impact,Toggle OFF Impact,Repository
"@ | Set-Content -Path $outputPath -Encoding UTF8 -Force

# Append data rows
foreach ($row in $analysisData) {
    $onImpact = $row['Toggle ON Impact'].Replace('"', '""')
    $offImpact = $row['Toggle OFF Impact'].Replace('"', '""')

    $csvLine = """$($row['Toggle Name'].Replace('"', '""'))""," +
        """$($row['Implementation Class Name'])""," +
        """$($row['Line Number Code'])""," +
        """$onImpact""," +
        """$offImpact""," +
        """$($row['Repository'])"""

    Add-Content -Path $outputPath -Value $csvLine -Encoding UTF8
}

Write-Host "Batch 1 analysis complete!" -ForegroundColor Green
Write-Host "Analysis file: $outputPath"
Write-Host "Total rows: $($analysisData.Count)"

