########################################
# Toggle Codebase Usage Analysis - Batch 1 (Detailed Analysis)
# Toggles 1-5: Complete Code Path Analysis
########################################

$csvPath = "C:\Users\e135408\Downloads\mcp-servers\jobs\TogglePageEnquiry\data\FeatureToggleConfluencePageEnquiryResults.csv"
$outputPath = "C:\Users\e135408\Downloads\mcp-servers\jobs\TogglePageEnquiry\data\ToggleCodebaseUsageAnalysis.csv"
$cpePath = "C:\Users\e135408\IdeaProjects\MPGS\SourceCode\cardpaymentengine"
$orchestratorPath = "C:\Users\e135408\IdeaProjects\MPGS\SourceCode\orchestrator"

$inputToggles = @(Import-Csv -Path $csvPath)
$togglesInBatch = $inputToggles | Select-Object -First 5
$analysisRows = @()

# Helper function to extract complete if/else block context
function Get-CodeBlockContext {
    param(
        [string]$filePath,
        [int]$lineNum,
        [string]$searchPattern
    )

    try {
        $content = [System.IO.File]::ReadAllText($filePath, [System.Text.Encoding]::UTF8)
        $lines = $content -split "`n"

        if ($lineNum -le 0 -or $lineNum > $lines.Count) {
            return @{ context = ""; onImpact = ""; offImpact = "" }
        }

        # Get extended context
        $contextStart = [Math]::Max(0, $lineNum - 5)
        $contextEnd = [Math]::Min($lines.Count - 1, $lineNum + 15)
        $contextLines = $lines[$contextStart..$contextEnd]
        $context = $contextLines -join "`n"

        # Try to identify if/else blocks
        $targetLine = $lines[$lineNum - 1]

        # Simple extraction - look for if (toggle pattern and corresponding else
        $hasIfBlock = $targetLine -match "if\s*\(" -or $targetLine -match "Toggles\." -or $targetLine -match "toggles\."

        if ($hasIfBlock) {
            # Find matching braces or statement
            $braceCount = 0
            $inBlock = $false
            $blockContent = ""
            $foundElse = $false
            $elseContent = ""

            for ($i = $lineNum; $i -lt [Math]::Min($lineNum + 50, $lines.Count); $i++) {
                $blockContent += $lines[$i] + "`n"

                if ($lines[$i] -match "}\s*else\s*\{") {
                    $foundElse = $true
                }
            }

            $onImpact = "IF Block: $blockContent"
            $offImpact = if ($foundElse) { "ELSE Block Found" } else { "No explicit ELSE block" }
        } else {
            $onImpact = "Toggle evaluation pattern not recognized"
            $offImpact = "Unable to determine OFF path"
        }

        return @{
            context = $context
            onImpact = $onImpact
            offImpact = $offImpact
        }
    }
    catch {
        return @{
            context = "Error reading file"
            onImpact = "ERROR: $_"
            offImpact = "ERROR: $_"
        }
    }
}

Write-Host "===== BATCH 1 - DETAILED CODE ANALYSIS =====" -ForegroundColor Yellow
Write-Host "Processing 5 toggles with complete code path analysis..."
Write-Host ""

foreach ($toggle in $togglesInBatch) {
    $toggleName = $toggle.toggle_name
    Write-Host "Processing: $toggleName" -ForegroundColor Cyan

    # Search in both repositories
    $allMatches = @()

    # Search CPE
    try {
        $cpeJavaPath = "$cpePath\src\main\java"
        $javaFiles = Get-ChildItem -Path $cpeJavaPath -Recurse -Include "*.java" -File | Where-Object {
            $_.FullName -notmatch "[\\/]test[\\/]|Test\.java|Tests\.java|Spec\.java"
        }

        foreach ($file in $javaFiles) {
            try {
                $content = [System.IO.File]::ReadAllText($file.FullName, [System.Text.Encoding]::UTF8)

                if ($content -match [regex]::Escape($toggleName)) {
                    $lines = $content -split "`n"
                    for ($i = 0; $i -lt $lines.Count; $i++) {
                        if ($lines[$i] -match [regex]::Escape($toggleName)) {
                            # Skip if this is in a test class or comment only
                            if ($lines[$i] -notmatch "^\\s*//" -or $lines[$i] -match "Toggles\.|isToggle|isOn|isEnabled") {
                                $className = $file.BaseName
                                $fullClassName = $file.BaseName.Replace(".java", "")

                                # Get code context
                                $codeBlock = Get-CodeBlockContext -filePath $file.FullName -lineNum ($i + 1) -searchPattern $toggleName

                                $allMatches += @{
                                    className = $fullClassName
                                    filePath = $file.FullName
                                    lineNum = $i + 1
                                    context = $codeBlock.context
                                    onImpact = $codeBlock.onImpact
                                    offImpact = $codeBlock.offImpact
                                    repository = "CPE"
                                }
                            }
                        }
                    }
                }
            }
            catch {
                # Silently skip errors
            }
        }
    }
    catch {
        Write-Host "  Error searching CPE: $_" -ForegroundColor Red
    }

    # Search Orchestrator
    try {
        $orchestratorJavaPath = "$orchestratorPath\src\main\java"
        $javaFiles = Get-ChildItem -Path $orchestratorJavaPath -Recurse -Include "*.java" -File | Where-Object {
            $_.FullName -notmatch "[\\/]test[\\/]|Test\.java|Tests\.java|Spec\.java"
        }

        foreach ($file in $javaFiles) {
            try {
                $content = [System.IO.File]::ReadAllText($file.FullName, [System.Text.Encoding]::UTF8)

                if ($content -match [regex]::Escape($toggleName)) {
                    $lines = $content -split "`n"
                    for ($i = 0; $i -lt $lines.Count; $i++) {
                        if ($lines[$i] -match [regex]::Escape($toggleName)) {
                            if ($lines[$i] -notmatch "^\\s*//" -or $lines[$i] -match "Toggles\.|isToggle|isOn|isEnabled") {
                                $className = $file.BaseName
                                $fullClassName = $file.BaseName.Replace(".java", "")

                                $codeBlock = Get-CodeBlockContext -filePath $file.FullName -lineNum ($i + 1) -searchPattern $toggleName

                                $allMatches += @{
                                    className = $fullClassName
                                    filePath = $file.FullName
                                    lineNum = $i + 1
                                    context = $codeBlock.context
                                    onImpact = $codeBlock.onImpact
                                    offImpact = $codeBlock.offImpact
                                    repository = "Orchestrator"
                                }
                            }
                        }
                    }
                }
            }
            catch {
                # Silently skip errors
            }
        }
    }
    catch {
        Write-Host "  Error searching Orchestrator: $_" -ForegroundColor Red
    }

    # Deduplicate matches (same class, same line number in same repo)
    $uniqueMatches = $allMatches | Group-Object -Property { "$($_.repository)_$($_.className)_$($_.lineNum)" } | ForEach-Object { $_.Group[0] }

    # Create CSV rows for each unique match
    foreach ($match in $uniqueMatches) {
        $row = [PSCustomObject]@{
            'Toggle Name' = $toggleName
            'Implementation Class Name' = $match.className
            'Line Number Code' = $match.lineNum
            'Toggle ON Impact' = $match.onImpact.Substring(0, [Math]::Min(500, $match.onImpact.Length))
            'Toggle OFF Impact' = $match.offImpact.Substring(0, [Math]::Min(500, $match.offImpact.Length))
            'Repository' = $match.repository
        }
        $analysisRows += $row
        Write-Host "  Found usage in $($match.repository): $($match.className).java:$($match.lineNum)"
    }

    if ($uniqueMatches.Count -eq 0) {
        Write-Host "  No usages found in code" -ForegroundColor Yellow
    }

    Write-Host ""
}

# Append rows to CSV
Write-Host "Writing $($analysisRows.Count) rows to ToggleCodebaseUsageAnalysis.csv..." -ForegroundColor Cyan
if ($analysisRows.Count -gt 0) {
    $analysisRows | Export-Csv -Path $outputPath -NoTypeInformation -Encoding UTF8 -Append -Force
    Write-Host "Success! Added $($analysisRows.Count) analysis rows." -ForegroundColor Green
}

Write-Host ""
Write-Host "===== BATCH 1 ANALYSIS COMPLETE =====" -ForegroundColor Yellow
Write-Host "Total toggles processed: 5"
Write-Host "Total usages found: $($analysisRows.Count)"
Write-Host "Output file: $outputPath"

