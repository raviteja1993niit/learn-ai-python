# Toggle Declaration Extractor Script
param(
    [string]$CPEPath = "C:\Users\e135408\IdeaProjects\MPGS\SourceCode\cardpaymentengine",
    [string]$OrchestratorPath = "C:\Users\e135408\IdeaProjects\MPGS\SourceCode\orchestrator",
    [string]$OutputCSV = "C:\Users\e135408\Downloads\mcp-servers\jobs\TogglePageEnquiry\data\ToggleRegistryLookup.csv"
)

Write-Host "========================================" -ForegroundColor Green
Write-Host "Toggle Declaration Extractor" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Green

function Search-Toggles {
    param([string]$RepoPath, [string]$Repository)

    Write-Host "`nSearching $Repository..." -ForegroundColor Cyan
    $sourceDir = Join-Path $RepoPath "src/main/java"
    $declarations = @()

    if (-not (Test-Path $sourceDir)) {
        Write-Host "Source directory not found" -ForegroundColor Red
        return $declarations
    }

    $javaFiles = Get-ChildItem -Path $sourceDir -Filter "*.java" -Recurse | Where-Object { $_.FullName -notmatch "test" }
    Write-Host "Found $($javaFiles.Count) Java files"

    foreach ($file in $javaFiles) {
        $content = Get-Content -Path $file.FullName -Raw
        $pattern = 'public\s+static\s+final\s+String\s+(\w+)\s*=\s*"([^"]+)"\s*;'
        $matches = [regex]::Matches($content, $pattern)

        if ($matches.Count -gt 0) {
            $relativePath = $file.FullName -replace [regex]::Escape($sourceDir), ""
            $relativePath = $relativePath -replace "\\", "/" -replace "^/", "src/main/java/"

            $classMatch = [regex]::Match($content, 'public\s+(?:final\s+)?class\s+(\w+)')
            $className = if ($classMatch.Success) { $classMatch.Groups[1].Value } else { $file.BaseName }

            foreach ($match in $matches) {
                $declarations += @{
                    Name = $match.Groups[2].Value
                    Class = $className
                    Path = $relativePath
                    Constant = $match.Groups[1].Value
                    Repo = $Repository
                }
                Write-Host "  + $($match.Groups[2].Value)" -ForegroundColor Green
            }
        }
    }

    Write-Host "Found $($declarations.Count) declarations"
    return $declarations
}

$cpeDecl = Search-Toggles -RepoPath $CPEPath -Repository "CPE"
$orchDecl = Search-Toggles -RepoPath $OrchestratorPath -Repository "Orchestrator"

$all = @()
$all += $cpeDecl
$all += $orchDecl

Write-Host "`n========================================" -ForegroundColor Green
Write-Host "Total: $($all.Count) declarations found" -ForegroundColor Green
Write-Host "CPE: $($cpeDecl.Count) | Orchestrator: $($orchDecl.Count)" -ForegroundColor Green

$sorted = $all | Sort-Object -Property Name
$csv = @("toggle_name,registry_class_name,registry_file_path,constant_name,repository,class_type")

foreach ($decl in $sorted) {
    $line = "`"$($decl.Name)`",`"$($decl.Class)`",`"$($decl.Path)`",`"$($decl.Constant)`",`"$($decl.Repo)`",`"Registry`""
    $csv += $line
}

$csv -join "`n" | Set-Content -Path $OutputCSV -Encoding UTF8

Write-Host "`nCSV created: $OutputCSV"
Write-Host "Rows written: $($sorted.Count)"
Write-Host "========================================" -ForegroundColor Green

