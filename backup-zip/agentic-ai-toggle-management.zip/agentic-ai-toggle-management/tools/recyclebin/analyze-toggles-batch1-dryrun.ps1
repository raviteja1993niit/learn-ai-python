########################################
# Toggle Codebase Usage Analysis Script
# Batch Processing - Dry Run (Batch 1: Toggles 1-5)
########################################

# Configuration
$csvPath = "C:\Users\e135408\Downloads\mcp-servers\jobs\TogglePageEnquiry\data\FeatureToggleConfluencePageEnquiryResults.csv"
$registryPath = "C:\Users\e135408\Downloads\mcp-servers\jobs\TogglePageEnquiry\data\ToggleRegistryLookup.csv"
$outputPath = "C:\Users\e135408\Downloads\mcp-servers\jobs\TogglePageEnquiry\data\ToggleCodebaseUsageAnalysis.csv"
$cpePath = "C:\Users\e135408\IdeaProjects\MPGS\SourceCode\cardpaymentengine\src\main\java"
$orchestratorPath = "C:\Users\e135408\IdeaProjects\MPGS\SourceCode\orchestrator\src\main\java"

# Read input CSV
Write-Host "Reading toggle input CSV..." -ForegroundColor Cyan
$inputToggles = @(Import-Csv -Path $csvPath)
Write-Host "Found $($inputToggles.Count) toggles to analyze"

# Read registry lookup
Write-Host "Reading toggle registry lookup..." -ForegroundColor Cyan
$registry = @(Import-Csv -Path $registryPath)
Write-Host "Loaded $($registry.Count) toggle declarations"

# Build registry lookup map for quick filtering
$registryMap = @{}
foreach ($reg in $registry) {
    if (-not $registryMap.ContainsKey($reg.toggle_name)) {
        $registryMap[$reg.toggle_name] = @()
    }
    $registryMap[$reg.toggle_name] += @{
        class = $reg.registry_class_name
        path = $reg.registry_file_path
        repo = $reg.repository
    }
}
Write-Host "Built registry lookup map for $($registryMap.Keys.Count) toggles"

# Process Batch 1: Toggles 1-5 (rows 1-5 from CSV, which are indices 0-4)
$batchStart = 0
$batchSize = 5
$togglesInBatch = $inputToggles | Select-Object -First $batchSize
$analysisResults = @()

Write-Host ""
Write-Host "===== BATCH 1 DRY RUN (Toggles 1-5) =====" -ForegroundColor Yellow

$toggleIndex = 1
foreach ($toggle in $togglesInBatch) {
    $toggleName = $toggle.toggle_name
    $isSa2 = $toggle.is_s2a

    Write-Host ""
    Write-Host "[$toggleIndex/5] Analyzing: '$toggleName'" -ForegroundColor Cyan
    Write-Host "  is_s2a: $isSa2"

    # Check if toggle exists in registry
    if ($registryMap.ContainsKey($toggleName)) {
        $declLocations = $registryMap[$toggleName]
        Write-Host "  Found in registry: $($declLocations.Count) declaration(s)"
        foreach ($decl in $declLocations) {
            Write-Host "    - Class: $($decl.class), Repo: $($decl.repo)"
        }
    } else {
        Write-Host "  NOT FOUND in registry (may be declared elsewhere or used inline)" -ForegroundColor Yellow
    }

    # Search for toggle usage in CPE
    Write-Host "  Searching CPE..."
    $cpeMatches = @()

    try {
        $javaFiles = Get-ChildItem -Path $cpePath -Recurse -Include "*.java" -File
        foreach ($file in $javaFiles) {
            # Skip test files
            if ($file.FullName -match "[\\/]test[\\/]|Test\.java|Tests\.java|Spec\.java") {
                continue
            }

            try {
                $content = [System.IO.File]::ReadAllText($file.FullName, [System.Text.Encoding]::UTF8)

                # Search for toggle usage patterns
                # Pattern 1: Quoted toggle name
                if ($content -match [regex]::Escape($toggleName)) {
                    # Find line number
                    $lines = $content -split "`n"
                    for ($i = 0; $i -lt $lines.Count; $i++) {
                        if ($lines[$i] -match [regex]::Escape($toggleName)) {
                            $className = $file.BaseName
                            $relPath = $file.FullName.Replace($cpePath, "").Replace("\", "/").TrimStart("/")
                            $lineNum = $i + 1

                            # Get context (surrounding lines)
                            $contextStart = [Math]::Max(0, $i - 2)
                            $contextEnd = [Math]::Min($lines.Count - 1, $i + 2)
                            $context = $lines[$contextStart..$contextEnd] -join "`n"

                            $cpeMatches += @{
                                class = $className
                                path = $relPath
                                line = $lineNum
                                context = $context
                            }
                        }
                    }
                }
            }
            catch {
                # Silent skip on read errors
            }
        }
    }
    catch {
        Write-Host "    Error searching CPE: $_" -ForegroundColor Red
    }

    if ($cpeMatches.Count -gt 0) {
        Write-Host "    Found $($cpeMatches.Count) usage(s) in CPE"
        foreach ($match in $cpeMatches | Select-Object -First 3) {
            Write-Host "      Line $($match.line): $($match.class).java"
        }
    } else {
        Write-Host "    No usage found in CPE"
    }

    # Search for toggle usage in Orchestrator
    Write-Host "  Searching Orchestrator..."
    $orchMatches = @()

    try {
        $javaFiles = Get-ChildItem -Path $orchestratorPath -Recurse -Include "*.java" -File
        foreach ($file in $javaFiles) {
            # Skip test files
            if ($file.FullName -match "[\\/]test[\\/]|Test\.java|Tests\.java|Spec\.java") {
                continue
            }

            try {
                $content = [System.IO.File]::ReadAllText($file.FullName, [System.Text.Encoding]::UTF8)

                if ($content -match [regex]::Escape($toggleName)) {
                    $lines = $content -split "`n"
                    for ($i = 0; $i -lt $lines.Count; $i++) {
                        if ($lines[$i] -match [regex]::Escape($toggleName)) {
                            $className = $file.BaseName
                            $relPath = $file.FullName.Replace($orchestratorPath, "").Replace("\", "/").TrimStart("/")
                            $lineNum = $i + 1

                            $contextStart = [Math]::Max(0, $i - 2)
                            $contextEnd = [Math]::Min($lines.Count - 1, $i + 2)
                            $context = $lines[$contextStart..$contextEnd] -join "`n"

                            $orchMatches += @{
                                class = $className
                                path = $relPath
                                line = $lineNum
                                context = $context
                            }
                        }
                    }
                }
            }
            catch {
                # Silent skip on read errors
            }
        }
    }
    catch {
        Write-Host "    Error searching Orchestrator: $_" -ForegroundColor Red
    }

    if ($orchMatches.Count -gt 0) {
        Write-Host "    Found $($orchMatches.Count) usage(s) in Orchestrator"
        foreach ($match in $orchMatches | Select-Object -First 3) {
            Write-Host "      Line $($match.line): $($match.class).java"
        }
    } else {
        Write-Host "    No usage found in Orchestrator"
    }

    $totalMatches = $cpeMatches.Count + $orchMatches.Count
    Write-Host "  Total usages found: $totalMatches" -ForegroundColor Green

    $toggleIndex++
}

Write-Host ""
Write-Host "===== BATCH 1 DRY RUN SUMMARY =====" -ForegroundColor Yellow
Write-Host "Toggles analyzed: $($togglesInBatch.Count)"
Write-Host "Status: DRY RUN COMPLETE"
Write-Host ""
Write-Host "Next: Create headers in ToggleCodebaseUsageAnalysis.csv and process first batch for detailed analysis"

