@echo off
:: Dynamic repository memory map generator.
:: Usage: run-repo-memory-mapper.bat [MaxDepth] [OutputFile] [IncludeTests]
::
:: This script dynamically detects the repository root and analyzes Java classes
:: to generate a memory map CSV file with class responsibilities and S2A flow tracking.

setlocal enabledelayedexpansion

set "SCRIPT_DIR=%~dp0"
set "PS_SCRIPT=%SCRIPT_DIR%repo-memory-mapper.ps1"

set "MAXDEPTH=%~1"
set "OUTFILE=%~2"
set "INCLUDE_TESTS=%~3"

:: ============================================================================
:: Step 1: Dynamically detect the repository root
:: ============================================================================
set "REPO_ROOT="
set "CURRENT_PATH=%CD%"

:find_repo_root
if "!CURRENT_PATH!"=="" goto repo_not_found

:: Check for common repo markers in priority order
if exist "!CURRENT_PATH!\.git" (
  set "REPO_ROOT=!CURRENT_PATH!"
  goto repo_found
)
if exist "!CURRENT_PATH!\pom.xml" (
  set "REPO_ROOT=!CURRENT_PATH!"
  goto repo_found
)
if exist "!CURRENT_PATH!\package.json" (
  set "REPO_ROOT=!CURRENT_PATH!"
  goto repo_found
)
if exist "!CURRENT_PATH!\.sln" (
  set "REPO_ROOT=!CURRENT_PATH!"
  goto repo_found
)

:: Move up one directory level
for /f "delims=" %%A in ("!CURRENT_PATH!\..") do set "CURRENT_PATH=%%~fA"

:: Prevent infinite loop by checking if we've reached the root directory (e.g., C:\)
if "!CURRENT_PATH:~-1!"=="\" (
  if "!CURRENT_PATH!"=="!CURRENT_PATH:~0,3!" (
    goto repo_not_found
  )
)

goto find_repo_root

:repo_not_found
echo.
echo ERROR: Could not detect repository root. Searched for markers: .git, pom.xml, package.json, .sln
echo Current search path: %CD%
echo Falling back to current directory: %CD%
echo.
set "REPO_ROOT=%CD%"

:repo_found
:: ============================================================================
:: Step 2: Extract repo name and set output file path
:: ============================================================================
:: Extract the last folder name (repo name) from the repo root path
for %%F in ("!REPO_ROOT!") do set "REPO_NAME=%%~nF"

if "%OUTFILE%"=="" (
  set "OUTFILE=!REPO_ROOT!\!REPO_NAME!-memory-map.csv"
) else (
  :: If OUTFILE is just a filename (no path), put it in the repo root
  if not exist "!OUTFILE:\=!" (
    if "!OUTFILE:~1,1!" neq ":" (
      set "OUTFILE=!REPO_ROOT!\!OUTFILE!"
    )
  )
)

:: ============================================================================
:: Step 3: Prepare MaxDepth argument
:: ============================================================================
if "%MAXDEPTH%"=="" (
  set "MAXDEPTH=5"
)

:: ============================================================================
:: Step 4: Prepare IncludeTests argument
:: ============================================================================
set "INCLUDE_TESTS_ARG="
if /i "%INCLUDE_TESTS%"=="true" (
  set "INCLUDE_TESTS_ARG=-IncludeTests"
) else if /i "%INCLUDE_TESTS%"=="yes" (
  set "INCLUDE_TESTS_ARG=-IncludeTests"
) else if /i "%INCLUDE_TESTS%"=="1" (
  set "INCLUDE_TESTS_ARG=-IncludeTests"
)

:: ============================================================================
:: Step 5: Run the PowerShell script
:: ============================================================================
echo.
echo Detected repository root: !REPO_ROOT!
echo Output file: !OUTFILE!
echo Max Depth: !MAXDEPTH!
echo Include Tests: %INCLUDE_TESTS%
echo.
echo Running: powershell -NoProfile -ExecutionPolicy Bypass -File "!PS_SCRIPT!" -RepoPath "!REPO_ROOT!" -MaxDepth !MAXDEPTH! -OutputFile "!OUTFILE!" !INCLUDE_TESTS_ARG!
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "!PS_SCRIPT!" -RepoPath "!REPO_ROOT!" -MaxDepth !MAXDEPTH! -OutputFile "!OUTFILE!" !INCLUDE_TESTS_ARG!

endlocal

:: Note: Do not pass OutputFile with escaped surrounding quotes (e.g. \"C:\path\file.csv\").
:: Pass a normal path (relative or absolute) as the second argument.

