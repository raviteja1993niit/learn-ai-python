@echo off
:: Java-specific tree generator for comprehensive class listing.
:: Usage: run-generate-java-tree.bat [SourceType] [OutputFile]
::
:: This script generates a comprehensive list of all Java classes organized by package,
:: making it easier to understand the complete class structure of a repository.
::
:: SourceType options: main, test, all (default: main)

setlocal enabledelayedexpansion

set "SCRIPT_DIR=%~dp0"
set "PS_SCRIPT=%SCRIPT_DIR%generate-java-tree.ps1"

set "SOURCE_TYPE=%~1"
set "OUTFILE=%~2"

:: ============================================================================
:: Step 1: Dynamically detect the repository root
:: ============================================================================
set "REPO_ROOT="
set "CURRENT_PATH=%CD%"

:find_repo_root
if "!CURRENT_PATH!"=="" goto repo_not_found

:: Check for common repo markers in priority order
if exist "!CURRENT_PATH!\.git" (
  set "REPO_ROOT=!CURRENT_PATH!"
  goto repo_found
)
if exist "!CURRENT_PATH!\pom.xml" (
  set "REPO_ROOT=!CURRENT_PATH!"
  goto repo_found
)
if exist "!CURRENT_PATH!\package.json" (
  set "REPO_ROOT=!CURRENT_PATH!"
  goto repo_found
)
if exist "!CURRENT_PATH!\.sln" (
  set "REPO_ROOT=!CURRENT_PATH!"
  goto repo_found
)

:: Move up one directory level
for /f "delims=" %%A in ("!CURRENT_PATH!\..") do set "CURRENT_PATH=%%~fA"

:: Prevent infinite loop by checking if we've reached the root directory (e.g., C:\)
if "!CURRENT_PATH:~-1!"=="\" (
  if "!CURRENT_PATH!"=="!CURRENT_PATH:~0,3!" (
    goto repo_not_found
  )
)

goto find_repo_root

:repo_not_found
echo.
echo ERROR: Could not detect repository root. Searched for markers: .git, pom.xml, package.json, .sln
echo Current search path: %CD%
echo Falling back to current directory: %CD%
echo.
set "REPO_ROOT=%CD%"

:repo_found
:: ============================================================================
:: Step 2: Extract repo name and set output file path
:: ============================================================================
:: Extract the last folder name (repo name) from the repo root path
for %%F in ("!REPO_ROOT!") do set "REPO_NAME=%%~nF"

if "%OUTFILE%"=="" (
  set "OUTFILE=!REPO_ROOT!\!REPO_NAME!-java-tree.txt"
) else (
  :: If OUTFILE is just a filename (no path), put it in the repo root
  if not exist "!OUTFILE:\=!" (
    if "!OUTFILE:~1,1!" neq ":" (
      set "OUTFILE=!REPO_ROOT!\!OUTFILE!"
    )
  )
)

:: ============================================================================
:: Step 3: Prepare SourceType argument
:: ============================================================================
if "%SOURCE_TYPE%"=="" (
  set "SOURCE_TYPE=main"
)

:: ============================================================================
:: Step 4: Run the PowerShell script
:: ============================================================================
echo.
echo Detected repository root: !REPO_ROOT!
echo Output file: !OUTFILE!
echo Source Type: !SOURCE_TYPE!
echo.
echo Running: powershell -NoProfile -ExecutionPolicy Bypass -File "!PS_SCRIPT!" -TargetPath "!REPO_ROOT!" -SourceType "!SOURCE_TYPE!" -OutFile "!OUTFILE!"
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "!PS_SCRIPT!" -TargetPath "!REPO_ROOT!" -SourceType "!SOURCE_TYPE!" -OutFile "!OUTFILE!"

endlocal

:: Note: SourceType options: main (default), test, all
:: Example: run-generate-java-tree.bat all    (for main + test classes)

