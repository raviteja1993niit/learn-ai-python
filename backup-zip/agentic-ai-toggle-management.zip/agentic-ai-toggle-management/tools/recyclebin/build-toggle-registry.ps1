$toggleData = @()

# Constants-class patterns — files whose sole purpose is declaring toggle constants.
# Entries found here are tagged DECLARATION. All other files are tagged IMPLEMENTATION.
$declarationClassPatterns = @(
    'ToggleConstants',       # e.g. S2IAcquirerToggleConstants, ToggleConstants
    'ToggleConstant',
    'Constants',             # e.g. Constants.java in acquirer/util
    'HeaderConstants'
)

function Get-UsageType {
    param(
        [string]$ClassName,
        [string]$FilePath,
        [string]$ConstantName,
        [string]$FileContent
    )

    # 1. Name-pattern heuristic: class is purely a constants holder
    foreach ($pat in $declarationClassPatterns) {
        if ($ClassName -match $pat) { return "DECLARATION" }
    }

    # 2. Content heuristic: does the file also CALL isToggleOn / Toggles.isToggleOn
    #    with this constant — if yes, it is IMPLEMENTATION (or BOTH → mark IMPLEMENTATION)
    if ($FileContent -match "isToggleOn\s*\(\s*$([regex]::Escape($ConstantName))") {
        return "IMPLEMENTATION"
    }
    if ($FileContent -match "isToggleOn\s*\(.*$([regex]::Escape($ConstantName))") {
        return "IMPLEMENTATION"
    }

    # 3. Default: the declaration was found here but no conditional usage — DECLARATION
    return "DECLARATION"
}

# Process CPE
Write-Host "Processing CPE repository..."
$cpeFiles = Get-ChildItem -Path "C:\Users\e135408\IdeaProjects\MPGS\SourceCode\cardpaymentengine\src\main\java" -Recurse -Include "*.java" -File
$processedCPE = 0

foreach ($file in $cpeFiles) {
    $processedCPE++
    if ($processedCPE % 500 -eq 0) { Write-Host "  CPE: Processed $processedCPE files..." }

    try {
        $content = [System.IO.File]::ReadAllText($file.FullName, [System.Text.Encoding]::UTF8)
        if ($content -match "public\s+static\s+final\s+String\s+(TOGGLE|ENABLE|FEATURE)") {
            $className = $file.BaseName
            $relPath = $file.FullName.Replace("C:\Users\e135408\IdeaProjects\MPGS\SourceCode\cardpaymentengine\", "").Replace("\", "/")

            $regex = [regex]'public\s+static\s+final\s+String\s+(\w+)\s*=\s*"([^"]*)"'
            $regexMatches = $regex.Matches($content)

            foreach ($m in $regexMatches) {
                if ($m.Groups[1].Value -match "^(TOGGLE|ENABLE|FEATURE)") {
                    $constName = $m.Groups[1].Value
                    $usageType = Get-UsageType -ClassName $className -FilePath $relPath -ConstantName $constName -FileContent $content
                    $toggleData += [PSCustomObject]@{
                        toggle_name         = $m.Groups[2].Value
                        registry_class_name = $className
                        registry_file_path  = $relPath
                        constant_name       = $constName
                        repository          = "CPE"
                        usage_type          = $usageType
                    }
                }
            }
        }
    }
    catch {
        Write-Warning "Error processing $($file.FullName): $_"
    }
}
Write-Host "CPE: Found $(@($toggleData).Count) toggles from $processedCPE files"

# Process Orchestrator
Write-Host "Processing Orchestrator repository..."
$orchestratorFiles = Get-ChildItem -Path "C:\Users\e135408\IdeaProjects\MPGS\SourceCode\orchestrator\src\main\java" -Recurse -Include "*.java" -File
$processedOrch = 0
$orchStartCount = @($toggleData).Count

foreach ($file in $orchestratorFiles) {
    $processedOrch++
    if ($processedOrch % 500 -eq 0) { Write-Host "  Orchestrator: Processed $processedOrch files..." }

    try {
        $content = [System.IO.File]::ReadAllText($file.FullName, [System.Text.Encoding]::UTF8)
        if ($content -match "public\s+static\s+final\s+String\s+(TOGGLE|ENABLE|FEATURE)") {
            $className = $file.BaseName
            $relPath = $file.FullName.Replace("C:\Users\e135408\IdeaProjects\MPGS\SourceCode\orchestrator\", "").Replace("\", "/")

            $regex = [regex]'public\s+static\s+final\s+String\s+(\w+)\s*=\s*"([^"]*)"'
            $regexMatches = $regex.Matches($content)

            foreach ($m in $regexMatches) {
                if ($m.Groups[1].Value -match "^(TOGGLE|ENABLE|FEATURE)") {
                    $constName = $m.Groups[1].Value
                    $usageType = Get-UsageType -ClassName $className -FilePath $relPath -ConstantName $constName -FileContent $content
                    $toggleData += [PSCustomObject]@{
                        toggle_name         = $m.Groups[2].Value
                        registry_class_name = $className
                        registry_file_path  = $relPath
                        constant_name       = $constName
                        repository          = "Orchestrator"
                        usage_type          = $usageType
                    }
                }
            }
        }
    }
    catch {
        Write-Warning "Error processing $($file.FullName): $_"
    }
}
Write-Host "Orchestrator: Found $(@($toggleData).Count - $orchStartCount) toggles from $processedOrch files"

# Sort and deduplicate by toggle_name + constant_name + repository
# NOTE: We do NOT deduplicate solely by toggle_name — same toggle may have both
# DECLARATION and IMPLEMENTATION entries that must be preserved separately.
$uniqueToggles = $toggleData | Sort-Object toggle_name, constant_name, repository -Unique

Write-Host "Total registry entries: $(@($uniqueToggles).Count)"
Write-Host "  DECLARATION rows: $(@($uniqueToggles | Where-Object { $_.usage_type -eq 'DECLARATION' }).Count)"
Write-Host "  IMPLEMENTATION rows: $(@($uniqueToggles | Where-Object { $_.usage_type -eq 'IMPLEMENTATION' }).Count)"

# Export to CSV
$outputPath = "C:\Users\e135408\Downloads\mcp-servers\jobs\TogglePageEnquiry\data\ToggleRegistryLookup.csv"
$uniqueToggles | Select-Object toggle_name, registry_file_path, registry_class_name, repository, constant_name, usage_type |
    Export-Csv -Path $outputPath -NoTypeInformation -Encoding UTF8 -Force

Write-Host "Created $outputPath with $(@($uniqueToggles).Count) registry entries"
Write-Host ""
Write-Host "Sample entries:"
$uniqueToggles | Select-Object -First 5 | Format-Table -AutoSize

