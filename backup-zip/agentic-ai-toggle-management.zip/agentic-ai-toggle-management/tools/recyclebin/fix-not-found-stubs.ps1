# fix-not-found-stubs.ps1
# Replaces 8 old NOT_FOUND stubs with correct implementation rows
# and preserves all other rows (including the 28 user-added entries at lines 97-131)

$csvPath = "C:\Users\e135408\Downloads\mcp-servers\jobs\TogglePageEnquiry\data\ToggleCodebaseUsageAnalysis.csv"

# Read all lines
$lines = [System.IO.File]::ReadAllLines($csvPath, [System.Text.Encoding]::UTF8)
Write-Host "Total lines read: $($lines.Count)"

# Build a set of toggle-name prefixes that are the OLD NOT_FOUND stubs to replace
# Each entry: @{Prefix = <start of old line>; NewLine = <replacement CSV row>}
$replacements = @(
    @{
        Prefix  = '"Enable historical transaction data aggregation for prioritised merchant flow control","NOT_FOUND"'
        NewLine = '"Enable historical transaction data aggregation for prioritised merchant flow control","HistoricalTransactionDataCollector","88","Business: When ON, the gateway collects per-merchant transaction result counts — shouldCollectTransactionResult() returns true (based on configured operations and toggle), and persistTransactionCounts() records the aggregated counts for prioritised merchant flow control, enabling historical data-driven routing decisions. Field Impact: Internal only — no TSPI/ISO/acquirer fields affected. Internal: Toggles.isToggleOn(ENABLE_HISTORICAL_TRANSACTION_DATA_AGGREGATION) gates both shouldCollectTransactionResult() at line 88 and the persistTransactionCounts() scheduled task at line 92.","Business: When OFF, historical transaction data collection is disabled — shouldCollectTransactionResult() returns false; persistTransactionCounts() logs a warning and returns immediately without recording any counts. Historical data for merchant flow prioritisation not updated. Field Impact: Internal only — no transaction counts persisted; prioritised merchant flow control operates without fresh historical data.","DirectAPI"'
    },
    @{
        Prefix  = '"System Toggle: Enable 8-4 PAN Masking in API Response","NOT_FOUND"'
        NewLine = '"System Toggle: Enable 8-4 PAN Masking in API Response","PANMaskingHelper","68","Business: When ON, API responses for non-reporting contexts mask card PANs in 8-4 format (first 8 digits visible, last 4 visible, middle masked) — shouldUse84PanMasking() returns true when toggle is ON AND PAN length is sufficient AND merchant has the privilege AND the operation supports 8-4 masking. Card numbers in API responses are masked with enhanced 8-4 format instead of standard 6-4. Field Impact: sourceOfFunds.provided.card.number (DirectAPI response field) — masked using 8-4 format when shouldUse84PanMasking() returns true; PANMaskingHelper.shouldUse84PanMasking() gates the masking format in the API response layer.","Business: When OFF, standard PAN masking applies — shouldUse84PanMasking() returns false; standard 6-4 or other configured masking format used for card numbers in API responses. Field Impact: sourceOfFunds.provided.card.number — masked with standard format; 8-4 masking not applied.","DirectAPI"'
    },
    @{
        Prefix  = '"System Toggle: Enable Rate Limit For Test Merchants","NOT_FOUND"'
        NewLine = '"System Toggle: Enable Rate Limit For Test Merchants","TestingMerchantsRateLimiter","100","Business: When ON, a per-test-merchant rate limiter is enforced via RateLimiter.tryAcquire() — test merchant requests are throttled to the configured rate limit. If the rate limit is exceeded for a given test merchant, the slot is not acquired and the request is rate-limited, protecting production infrastructure from excessive test merchant traffic. Field Impact: Internal only — no TSPI/ISO/acquirer fields affected. Internal: Toggles.isToggleOn(ENABLE_RATE_LIMIT_TEST_MERCHANT_REQUESTS_TOGGLE) at line 100; if toggle is OFF, acquireSlot() returns immediately without throttling; if ON, per-merchant RateLimiter.tryAcquire() is called.","Business: When OFF, test merchant requests bypass the rate limiter entirely — acquireSlot() returns immediately after the toggle check; no rate limiting applied to test merchants. Field Impact: Internal only — RateLimiter not consulted; all test merchant request slots granted unconditionally.","DirectAPI"'
    },
    @{
        Prefix  = '"System Toggle: Enable Version Deprecation for Transactions","NOT_FOUND"'
        NewLine = '"System Toggle: Enable Version Deprecation for Transactions","ApiModelLookup","59","Business: When ON, if a deprecated API version is used for a transaction request, validateVersion() throws a MalformedRequest exception (RESOURCE_DOES_NOT_EXIST) — deprecated versions are actively rejected, forcing merchants to upgrade. When OFF, deprecated version requests are accepted and processed normally. Field Impact: Internal validation only — no TSPI/ISO/acquirer fields affected. Internal: Toggles.isToggleOn(ENABLE_VERSION_DEPRECATION_TOGGLE) at line 59; MalformedRequest thrown for deprecated version strings when toggle ON.","Business: When OFF, deprecated API versions for transactions are not rejected — requests using old/deprecated version values proceed without error; merchants on old API versions can continue sending requests without upgrade. Field Impact: Internal only — version deprecation check bypassed; all versions accepted.","DirectAPI"'
    },
    @{
        Prefix  = '"Filter out transactions unrelated to current order","NOT_FOUND"'
        NewLine = '"Filter out transactions unrelated to current order","OrderPersistenceService","318","Business: When ON, when loading the most recent successful initial transaction for an order, the gateway filters out financial transactions belonging to older orders that share the same order ID — using uniqueOrderId (persistentPk or transactionNumber) to exclude transactions from older order instances. This prevents stale initial transactions from older same-ID orders from being used in payment flows. Field Impact: Internal persistence lookup only — no TSPI/ISO/acquirer fields affected. Internal: filterTransactionsOnOldOrders(uniqueOrderId, x.getShoppingTransaction()) applied via stream filter; only transactions matching current order instance returned.","Business: When OFF, the legacy loadSuccessfulInitialTransaction(OrderIdentifier) path is used — no filtering by uniqueOrderId; older same-ID order transactions may be returned as the initial transaction. Field Impact: Internal only — OrderIdentifier-based lookup without uniqueOrderId filtering; may return stale initial transaction from older order.","CPE"'
    },
    @{
        Prefix  = '"Use partitioned tables for CPE transaction storage","NOT_FOUND"'
        NewLine = '"Use partitioned tables for CPE transaction storage","OrderPersistenceDelegate","382","Business: When ON, new order transactions and terminal close-batch operations use the partitioned table implementation (partitionTableImplSupplier) for CPE transaction storage — enabling database partitioning for improved performance and data lifecycle management. Field Impact: Internal persistence only — no TSPI/ISO/acquirer fields affected. Internal: partitionTableImplSupplier.get() returned at line 382 (new orders) and line 484 (terminal batch); partitioned DB tables used for transaction writes.","Business: When OFF, the legacy (non-partitioned) implementation (legacyImplSupplier) is used for CPE transaction storage — standard unpartitioned table writes apply for both new orders and terminal batch operations. Field Impact: Internal only — legacyImplSupplier.get() returned; legacy DB table structure used.","CPE"'
    },
    @{
        Prefix  = '"System Toggle: Reversal Daemon delays remote takeovers","NOT_FOUND"'
        NewLine = '"System Toggle: Reversal Daemon delays remote takeovers","ReversalDaemon","448","Business: When ON (alone or combined with the replication lag toggle), the Reversal Daemon processes same-site abandoned entries first via findAndTakeoverRemoteAbandonedEntries(SAME_SITE), then determines a configurable remote entry time limit before processing remote abandoned entries — delaying remote takeovers to give same-site processing priority and reduce cross-DC conflicts. Field Impact: Internal daemon processing only — no TSPI/ISO/acquirer fields affected. Internal: isRemoteTakeoverToggleOn drives SAME_SITE takeover first then REMOTE_SITE with determineRemoteEntryTimeLimit(); when OFF, NON_LOCAL takeover with m_sameSiteTimeLimit used instead.","Business: When OFF (and replication lag toggle also OFF), the Reversal Daemon uses the NON_LOCAL takeover path with the standard sameSiteTimeLimit — no differentiation between same-site and remote abandoned entries; both processed together without the prioritised same-site delay. Field Impact: Internal only — findAndTakeoverRemoteAbandonedEntries(NON_LOCAL) called; remote takeover not delayed.","CPE"'
    },
    @{
        Prefix  = '"Support STRIPE failover using Operations console","NOT_FOUND"'
        NewLine = '"Support STRIPE failover using Operations console","FailoverController","134","Business: When ON, the Console failover controller allows operators to activate/deactivate STRIPE stripe units via the Operations Console UI — isFailoverToggleOn() returns true and stripe activation/deactivation requests are forwarded to multiSiteConsistencyServiceClient. When OFF, operator attempts to activate/deactivate stripes are blocked with a warning log. Field Impact: Internal Console admin operation — no TSPI/ISO/acquirer fields affected. Internal: Toggles.isToggleOn(TOGGLE_SUPPORT_STRIPE_FAILOVER_USING_OPERATIONS_CONSOLE) at line 134; activateStripe() and deactivateStripe() request forwarding gated by this toggle.","Business: When OFF, all stripe activation/deactivation requests via the Operations Console are rejected with a warning — failover operations cannot be performed from the console; manual DB intervention required for stripe management. Field Impact: Internal only — multiSiteConsistencyServiceClient not called; stripe state unchanged.","Console"'
    }
)

# Build new lines array, replacing matching stubs
$newLines = New-Object System.Collections.Generic.List[string]
$replacedCount = 0

foreach ($line in $lines) {
    $replaced = $false
    foreach ($rep in $replacements) {
        if ($line.StartsWith($rep.Prefix)) {
            $newLines.Add($rep.NewLine)
            $replaced = $true
            $replacedCount++
            Write-Host "REPLACED: $($rep.Prefix.Substring(0, 60))..."
            break
        }
    }
    if (-not $replaced) {
        $newLines.Add($line)
    }
}

Write-Host "Replaced $replacedCount stub(s). Total lines: $($newLines.Count)"

# Write back
[System.IO.File]::WriteAllLines($csvPath, $newLines.ToArray(), [System.Text.Encoding]::UTF8)
Write-Host "File written successfully."

# Also add the second Console row for STRIPE failover (RemoteStripeService line 46)
# Check if it already exists
$written = [System.IO.File]::ReadAllLines($csvPath, [System.Text.Encoding]::UTF8)
$stripeRemoteExists = $written | Where-Object { $_ -match 'RemoteStripeService' }
if ($stripeRemoteExists) {
    Write-Host "RemoteStripeService row already present."
} else {
    $stripeRemoteLine = '"Support STRIPE failover using Operations console","RemoteStripeService","46","Business: When ON, the Console remote stripe service routes isStripeActive queries to the MultiSiteConsistencyService (multi-site aware) — enabling proper cross-site stripe state determination for Operations Console failover. Field Impact: Internal Console service routing only — no TSPI/ISO/acquirer fields affected. Internal: Toggles.isToggleOn(TOGGLE_SUPPORT_STRIPE_FAILOVER_USING_OPERATIONS_CONSOLE) at line 46; if ON, rpcClient.sendAndReceive(''MultiSiteConsistencyService'', ''isStripeActive'') called; returns cross-site consistent stripe status.","Business: When OFF, isStripeActive queries are routed to the legacy stripeService (sendAndReceive(''stripeService'', ''isStripeActiveForAsyncTasks'')) — legacy non-multi-site stripe status check used; may not reflect cross-site failover state. Field Impact: Internal only — legacy stripe service consulted instead of MultiSiteConsistencyService.","Console"'
    # Insert after the FailoverController row
    $finalLines = New-Object System.Collections.Generic.List[string]
    foreach ($wl in $written) {
        $finalLines.Add($wl)
        if ($wl -match 'FailoverController.*134.*Console') {
            $finalLines.Add($stripeRemoteLine)
            Write-Host "Inserted RemoteStripeService row after FailoverController row."
        }
    }
    [System.IO.File]::WriteAllLines($csvPath, $finalLines.ToArray(), [System.Text.Encoding]::UTF8)
    Write-Host "RemoteStripeService row added. Total lines: $($finalLines.Count)"
}

