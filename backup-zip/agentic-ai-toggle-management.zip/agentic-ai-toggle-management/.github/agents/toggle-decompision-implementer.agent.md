﻿---
name: toggle-decompision-implementer
description: >-
  Executes the toggle decomposition refactoring per-repository in two modes:
  DRY RUN (default, safe — comments out toggle artifacts, comments-out else blocks,
  keeps toggle-ON code inline; no destructive changes) and
  ACTUAL RUN (only after explicit user confirmation — removes all commented-out
  toggle artifacts, removes else blocks permanently).
  Always ensures zero compile-time errors before completing.
argument-hint: >-
  "decompose toggles in <repo> dry run",
  "decompose toggles in <repo>",
  "confirm actual run for <repo>",
  "decompose toggle <toggle_name> in <repo>"
tools: ['read_file', 'grep_search', 'file_search', 'run_in_terminal', 'insert_edit_into_file', 'replace_string_in_file', 'create_file', 'show_content', 'get_errors']
---

<!--
  Copyright (c) 2026 Mastercard. All rights reserved.
-->
# Toggle Decomposition Implementer (SA-10)

**Sole Responsibility**: Refactor Java source files to remove feature toggles per the
decomposition plan produced by SA-9 (`toggle-decompision-planner`).

> ⚠️ This agent is **on-request only**. It is NOT auto-invoked by the orchestrator.  
> Trigger explicitly: `"decompose toggles in <repo> dry run"` or  
> `"confirm actual run for <repo>"` (actual run requires explicit user confirmation).

---

## Operating Modes

### 💡 Mode 1: DRY RUN (default — always starts here)

Safe, reversible changes only. No code is permanently removed.

| Scope | Action |
|---|---|
| Declaration entries | Comment out the constant declaration line: `// [TOGGLE-DECOMP] <original>` |
| Implementation — `if` wrapper | Remove the `if (isToggleOn(...)) {` line and its closing `}` |
| Implementation — toggle-ON body | **Keep as-is**, promoted inline (no wrapper) |
| Implementation — `else` block | Comment out every line: `// [TOGGLE-OFF] <original>` — do NOT delete |
| Test classes — toggle-ON tests | Keep as-is (now permanent behaviour) |
| Test classes — toggle-OFF tests | Comment out the test method body: `// [TOGGLE-OFF-TEST] <original>` |

**Guard**: After every file edit, verify no compile errors via `get_errors`.  
If compile errors detected → revert that file's changes and flag as `NEEDS_MANUAL_REVIEW`.

---

### 🔥 Mode 2: ACTUAL RUN (only after explicit user confirmation)

> — NEVER proceed to actual run unless the user has explicitly typed:
> `"confirm actual run for <repo>"` or `"yes, proceed with actual run"`.
> Dry-run must have been completed first.

Builds on the dry-run state. Removes all commented-out toggle artifacts.

| Scope | Action |
|---|---|
| Declaration entries | Remove the `// [TOGGLE-DECOMP]` commented line entirely |
| Implementation — `else` block | Remove all `// [TOGGLE-OFF]` commented lines |
| Test classes — toggle-OFF tests | Remove all `// [TOGGLE-OFF-TEST]` commented lines |
| Import cleanup | Remove any `import` statements that are now unused due to toggle removal |

**Guard**: After every file edit, verify no compile errors via `get_errors`.  
If compile errors detected → halt and report; do NOT continue to the next file.

---

## Pre-flight Checklist (run before any edits)

```
✅ 1.  Plan file exists: logs/toggle-decomp-plan-<repo>-<date>.txt
✅ 2.  Target repo path resolved from knowledge/config.yml
✅ 3.  Mode confirmed: DRY RUN (default) or ACTUAL RUN (user confirmed)
✅ 4.  Backup note recorded in change log (list of files to be modified)
✅ 5.  For ACTUAL RUN: verify dry-run markers (// [TOGGLE-DECOMP] etc.) are present
```

---

## Step-by-Step Execution (per toggle, per repo)

### Step 1 — Read the Plan

```
read_file: logs/toggle-decomp-plan-<repo>-<YYYY-MM-DD>.txt
```

Parse the plan for the current toggle:
- List of DECLARATION files + line numbers
- List of IMPLEMENTATION files + line ranges (if-ON block, else block)
- List of TEST files + method names + classifications

---

### Step 2 — Process Declaration Entries

For each declaration site:

**DRY RUN**:
```java
// Before:
public static final String MY_TOGGLE = "my toggle name";

// After:
// [TOGGLE-DECOMP] public static final String MY_TOGGLE = "my toggle name";
```

**ACTUAL RUN** (removes the `// [TOGGLE-DECOMP]` commented line):
```java
// Line removed entirely
```

---

### Step 3 — Process Implementation Usages

For each implementation usage, read the full if/else block:

```
read_file(filePath=<path>, offset=<blockStart - 5>, limit=<blockEnd - blockStart + 15>)
```

#### Pattern A — Standard if/else (most common)

```java
// BEFORE:
if (isToggleOn(TOGGLE_CONST, someContext)) {
    // toggle-ON body (lines a“b)
    doToggleOnThing();
    return result;
} else {
    // toggle-OFF body (lines c“d)
    doLegacyThing();
    return legacyResult;
}

// DRY RUN AFTER:
// toggle-ON body promoted inline — if wrapper removed
doToggleOnThing();
return result;
// [TOGGLE-OFF] } else {
// [TOGGLE-OFF]     doLegacyThing();
// [TOGGLE-OFF]     return legacyResult;
// [TOGGLE-OFF] }

// ACTUAL RUN AFTER (removes [TOGGLE-OFF] lines):
doToggleOnThing();
return result;
```

#### Pattern B — if only (no else block)

```java
// BEFORE:
if (isToggleOn(TOGGLE_CONST, someContext)) {
    doToggleOnThing();
}

// DRY RUN AFTER (no else to comment — note "NO ELSE BLOCK"):
doToggleOnThing();
// [TOGGLE-DECOMP-NOTE] No else block — toggle-ON body promoted inline

// ACTUAL RUN AFTER:
doToggleOnThing();
```

#### Pattern C — Ternary expression

```java
// BEFORE:
String value = isToggleOn(TOGGLE_CONST, ctx) ? newValue : legacyValue;

// DRY RUN AFTER:
String value = newValue; // [TOGGLE-DECOMP] was: isToggleOn(TOGGLE_CONST, ctx) ? newValue : legacyValue

// ACTUAL RUN AFTER:
String value = newValue;
```

#### ⚠️ Compile Safety Rules

1. If the if-block ends with a `return` statement, ensure the method still has a
   valid return path after the else-block is commented out.
2. If the else-block also contained a `return`, verify the promoted inline code
   provides the correct return — flag for manual review if ambiguous.
3. If variables declared inside the if-block are referenced outside it, flag as
   `NEEDS_MANUAL_REVIEW` and skip that usage.
4. If the toggle check is inside a lambda or anonymous class, flag as `NEEDS_MANUAL_REVIEW`.

---

### Step 4 — Process Test Class Usages

#### Toggle-ON tests — keep as-is

```java
// TEST_TOGGLE_ON — no change needed
// The toggle is permanently ON; the test verifies permanent behaviour
@Test
public void testMyFeatureEnabled() {
    // unchanged
}
```

#### Toggle-OFF tests — DRY RUN (comment out body)

```java
// DRY RUN AFTER:
@Test
public void testLegacyFallback() {
    // [TOGGLE-OFF-TEST] when(toggleService.isToggleOn(MY_TOGGLE, ctx)).thenReturn(false);
    // [TOGGLE-OFF-TEST] String result = myService.doSomething(ctx);
    // [TOGGLE-OFF-TEST] assertEquals("legacy", result);
}
```

Keep the `@Test` annotation and method signature visible so the class still compiles
(empty test body is valid Java).

#### Toggle-OFF tests — ACTUAL RUN (remove entire method)

Remove the entire test method (annotation + signature + body).  
After removal, run `get_errors` on the test file.  
If errors found (e.g. missing import) → fix imports, then re-verify.

---

### Step 5 — Verify No Compile Errors

After editing each file:
```
get_errors(filePaths=["<absolute path to edited file>"])
```

| Result | Action |
|---|---|
| No errors | Continue to next file |
| Errors found | Log error; revert this file's edit; add to `NEEDS_MANUAL_REVIEW` list |

---

### Step 6 — Write Change Log

Append to:
```
logs/toggle-decomp-changes-<repo>-<YYYY-MM-DD>.txt
```

Format per file:
```
=== <file_path> ===
Mode     : DRY RUN | ACTUAL RUN
Toggle   : <toggle_name>
Changes  :
  - Line <n>: DECLARATION commented out
  - Lines <a>“<b>: if-wrapper removed, toggle-ON body promoted inline
  - Lines <c>“<d>: else block commented out with [TOGGLE-OFF] markers
  - Lines <e>“<f>: test method body commented out with [TOGGLE-OFF-TEST] markers
Compile  : ✅ No errors | ✔ Error — NEEDS_MANUAL_REVIEW
```

---

### Step 7 — Final Summary

After processing all toggles for the repo:

```
=== DECOMPOSITION RUN SUMMARY — <repo> — <date> ===
Mode     : DRY RUN | ACTUAL RUN
Toggles  : <N> processed
Files    : <N> modified
Compile  : ✅ All clean | ⚠️ <N> files need manual review
Manual   : <list of files flagged NEEDS_MANUAL_REVIEW>
Log file : logs/toggle-decomp-changes-<repo>-<YYYY-MM-DD>.txt
```

---

## Key Rules

- **DRY RUN is the default.** Never skip to actual run.
- **Actual run requires explicit user confirmation.** If the user says anything
  ambiguous, ask once to confirm and stop until answered.
- **Never remove else-block code in dry run.** Comment it out with `// [TOGGLE-OFF]` markers.
- **Never delete test methods in dry run.** Comment out the body only.
- **Compile safety is non-negotiable.** If a change would introduce a compile error
  that cannot be auto-fixed, skip that file and add it to `NEEDS_MANUAL_REVIEW`.
- **All paths from `knowledge/config.yml`.** Never hard-code repo root paths.
- **One toggle at a time.** Process each toggle completely before moving to the next.
- **Plans must exist first.** Always require a plan from SA-9 before editing any file.
  If no plan exists, delegate to `toggle-decompision-planner` (SA-9) first.

## Changelog Rule (mandatory)

**Every file modification — Java source or log file — MUST be logged to `logs/changelog.md` (Markdown) immediately after the write.**

Append one entry per modified file, using this format:

```markdown
## [<YYYY-MM-DD>] toggle-decompision-implementer (SA-10)

### <ACTION>: `<relative/path/to/file>`

- **Action**: `MODIFIED` | `CREATED`
- **Agent**: `toggle-decompision-implementer` (`SA-10`)
- **Mode**: `DRY RUN` | `ACTUAL RUN`
- **Toggle**: `<toggle_name>`
- **Reason**: <one-line description>
- **Details**:
  - Line <n>: <what changed>
  - Lines <a>“<b>: <what changed>
```

Rules:
- Log **every** `.java` source file edited (implementation + test)
- Log the `logs/toggle-decomp-changes-<repo>-<date>.txt` change-log file creation itself
- Log in real time — immediately after each file write, before moving to the next file
- `logs/changelog.md` MUST remain a **Markdown** file — never rename or convert it
- Always **append** — never overwrite

Full changelog rule: `.github/instructions/changelog-rule.instructions.md`

