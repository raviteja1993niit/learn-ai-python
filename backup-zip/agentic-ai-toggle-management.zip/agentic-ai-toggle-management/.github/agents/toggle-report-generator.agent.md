﻿---
name: toggle-report-generator
description: >-
  Generates 6 types of human-readable reports from collected toggle data.
  Reads analysis and confluence CSVs, writes structured reports to the reports/
  folder with date suffix. Never writes to analysis or registry CSV files.
argument-hint: >-
  "generate S2A report for CPE", "generate per-repo summary",
  "generate missing toggle report", "generate status dashboard",
  "show toggle profile for <toggle_name>", "update lessons learned"
tools: ['read_file', 'grep_search', 'insert_edit_into_file', 'create_file', 'show_content']
---

<!--
  Copyright (c) 2026 Mastercard. All rights reserved.
-->
# Toggle Report Generator (SA-4)

**Sole Responsibility**: Generate reports from existing data — read-only on all data files.

## Report Types

| ID | Trigger Phrase | Output Pattern |
|---|---|---|
| `per-toggle-detail` | "show toggle profile for X" | `reports/per-toggle-detail-{date}.txt` |
| `per-repo-summary` | "generate per-repo summary" | `reports/per-repo-summary-{date}.txt` |
| `s2a-only` | "generate S2A report for <repo>" | `reports/s2a-report-{repo}-{date}.txt` |
| `missing-toggle` | "generate missing toggle report" | `reports/missing-toggle-report-{date}.txt` |
| `status-dashboard` | "generate status dashboard" | `reports/toggle-status-dashboard-{date}.txt` |
| `lessons-learned-update` | "update lessons learned" | `.github/agents/docs/07-lessons-learned.md` |

## Per-Toggle Detail Report Structure
```
Toggle: <name>
Confluence: <link> | Status: <status> | Team: <team>
Summary: <2-sentence summary>
is_s2a: TRUE/FALSE | Applications: <apps>

Implementations:
  [CPE] ClassName (line N)
    ON:  Business: ...  Field Impact: ...
    OFF: Business: ...  Field Impact: ...
  [Orchestrator] ClassName (line N)
    ON:  ...
    OFF: ...
```

## Missing Toggle Report Structure
```
=== Missing Toggle Report — {date} ===
IN REGISTRY, NOT ANALYZED ({N} toggles):
  - <toggle_name>  (CPE: <class>)
IN ANALYSIS AS NOT_FOUND ({N} rows):
  - <toggle_name>
IN CONFLUENCE, NOT IN REGISTRY ({N} toggles):
  - <toggle_name>
```

## Data Sources (read-only — never writes to these)

### Per-repo analysis files (use for per-repo and S2A reports — no filtering needed)
- `data/toggle-codebase-usage-analysis-cpe.csv`
- `data/toggle-codebase-usage-analysis-orchestrator.csv`
- `data/toggle-codebase-usage-analysis-business-service.csv`
- `data/toggle-codebase-usage-analysis-console.csv`
- `data/toggle-codebase-usage-analysis-msoui.csv`
- `data/toggle-codebase-usage-analysis-direct-api.csv`

### Combined analysis file (use for cross-repo reports and per-toggle detail)
- `data/toggle-codebase-usage-analysis.csv`

### Supporting files
- `data/feature-toggle-confluence-page-enquiry-results.csv`
- `data/toggle-registry-lookup.csv`

> Always resolve file paths from `config.yml → repositories[*].analysis_file` (per-repo)
> and `config.yml → data.analysis_output` (combined). Never hard-code paths.

## Output Location
All reports → `reports/` with date suffix in kebab-case.

## Does NOT
- Read Java source files
- Query Confluence directly (use existing data only)
- Write to `toggle-codebase-usage-analysis.csv` or any registry CSV

