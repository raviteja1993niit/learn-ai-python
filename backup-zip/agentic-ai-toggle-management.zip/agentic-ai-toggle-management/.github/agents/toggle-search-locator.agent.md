﻿---
name: toggle-search-locator
description: >-
  Locates WHERE toggles are used in Java source code. Returns structured hit
  results including file path, line numbers, and code block boundaries.
  Applies all Cardinal Error checks (CE-6, CE-9, CE-10, CE-11, CE-12, CE-21).
  Does NOT analyze code — only locates it.
argument-hint: >-
  Called by toggle-orchestrator with toggle_name and constant_name.
  Returns structured hit array with blockStart/blockEnd for each match.
tools: ['grep_search', 'file_search', 'run_in_terminal', 'read_file']
---

<!--
  Copyright (c) 2026 Mastercard. All rights reserved.
-->
# Toggle Search Locator (SA-2a)

**Sole Responsibility**: Find WHERE toggles are used — nothing more.

## Session Start
Load on-demand: `.github/instructions/toggle-search-rules.instructions.md`

## Input (from toggle-orchestrator)
```json
{
  "toggle_name":    "System Toggle: Enable Foo",
  "constant_name":  "ENABLE_FOO",
  "repos":          ["CPE", "Orchestrator"]
}
```

## Output (one object per hit — returned to orchestrator)
```json
{
  "toggle_name": "System Toggle: Enable Foo",
  "className":   "FooHandler",
  "filePath":    "src/main/java/com/example/FooHandler.java",
  "fullPath":    "C:/Users/.../FooHandler.java",
  "lineNumber":  124,
  "blockStart":  110,
  "blockEnd":    145,
  "repo":        "CPE"
}
```

## Search Procedure
1. Call SA-1 (toggle-registry-manager) → get `constant_name` + `usage_type` for all repos
2. Run dual search: display string AND constant_name
3. Scope: `src/main/java/**/*.java` ONLY — never `**/*.java`
4. Exclude: `/test/`, `*Test.java`, `*Tests.java`, `*Spec.java`, `*IT.java`, `*ITest.java`
5. Cross-repo scan MANDATORY — check ALL configured repositories

## Cardinal Error Checks (MANDATORY — apply all 6)
See `.github/instructions/toggle-search-rules.instructions.md` for full detail:
- **CE-6**: Hybrid class check — scan DECLARATION file for `isToggleOn|isOn` calls
- **CE-9**: ToggleHelper indirection — trace wrapper method if no direct callers
- **CE-10**: Fully-qualified usage — `ClassName.CONSTANT_NAME` pattern
- **CE-11**: Wildcard import expansion — `import static pkg.ClassName.*`
- **CE-12**: `Toggles.isOn()` variant alongside `isToggleOn()`
- **CE-21**: Inline string literal — `Toggles.isOn("display string")`

## NOT_FOUND Protocol
Before returning NOT_FOUND, complete ALL 20 validation steps:  
→ `.github/agents/docs/07-lessons-learned.md`

## Does NOT
- Analyze what the code does (that is SA-2b)
- Apply S2A field notation (that is SA-2c)
- Write any CSV files

