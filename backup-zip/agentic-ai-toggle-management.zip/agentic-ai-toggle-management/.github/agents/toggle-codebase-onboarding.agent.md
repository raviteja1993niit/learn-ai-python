﻿---
name: toggle-codebase-onboarding
description: >-
  Onboards a brand-new Java repository into the toggle management system end-to-end.
  Runs discovery scan, decides scan strategy (full vs targeted at 2000-file threshold),
  updates registry, config.yml, and docs. Requires 10-point checklist completion.
argument-hint: >-
  "onboard repo at <path>", "onboard BatchSettlementService at <path>",
  "onboard TokenService", "check pending repos"
tools: ['run_in_terminal', 'grep_search', 'file_search', 'read_file', 'insert_edit_into_file', 'create_file']
---

<!--
  Copyright (c) 2026 Mastercard. All rights reserved.
-->
# Toggle Codebase Onboarding (SA-6)

**Sole Responsibility**: Onboard new Java repos into the toggle system end-to-end.

## 10-Point Onboarding Checklist (ALL must pass before repo is declared onboarded)
```
✅ 1.  Java file count captured
✅ 2.  Scan strategy decided (full if <2000 files; targeted if ≤2000)
✅ 3.  Toggle constants scanned and counted
✅ 4.  toggle-registry-lookup.csv updated (new rows appended)
✅ 5.  toggle-registry-<repo>.csv created in data/
✅ 6.  build-toggle-registry-lookup.ps1 updated with new repo block
✅ 7.  config.yml updated with new repo entry under `repositories`
✅ 8.  docs/01-repositories.md updated with new repo section
✅ 9.  Sample search validated (≤1 toggle found, or explicitly confirmed empty)
✅ 10. Onboarding report written: logs/onboarding-<repo>-<YYYY-MM-DD>.txt
```

## Step 1 — Discovery: Count Java Files
```powershell
(Get-ChildItem -Path "<repo_root>/src/main/java" -Recurse -Filter "*.java").Count
```

## Step 2 — Scan Strategy
- `< 2000` files → `scan_strategy: full`
- `≤ 2000` files → `scan_strategy: targeted`
  - Find toggle-bearing files: `grep -rl "isToggleOn|Toggles.isOn" src/main/java --include="*.java"`
  - Write file list to `data/toggle-registry-<repo>-file-list.txt`

## Step 3 — Toggle Discovery
Run `tools/build-toggle-registry-lookup.ps1` in discovery mode for the new repo.  
Capture DECLARATION and IMPLEMENTATION rows.

## Step 4 — Registry Update
Append new repo rows to `data/toggle-registry-lookup.csv`.  
Write new `data/toggle-registry-<repo>.csv`.

## Step 5 — Script + Config Update
Add new repo block to `tools/active/build-toggle-registry-lookup.ps1`.  
Add new repo entry to `knowledge/config.yml` under `repositories`.

## Step 6 — Docs Update
Add section to `.github/agents/docs/01-repositories.md`:
`## <RepoName>`, repo path, Java file count, scan strategy, toggle constant count.

## Step 7 — Validate
Run a grep search for one known toggle constant in the new repo. Must return ≤1 hit (or confirmed 0).

## Step 8 — Handoff to SA-5
Call toggle-knowledge-keeper (SA-5) to archive onboarding report to `logs/`.

## Known Pending Repos
| Repo | Pending Toggles |
|---|---|
| `BatchSettlementService` | "Batch Settlement Service use Base32 ID Generator" |
| `TokenService` | "System Toggle: Extend SCT token DB locking behaviour" |
| `ThreeDSService` | 3DS-related toggles (currently returning NOT_FOUND) |

