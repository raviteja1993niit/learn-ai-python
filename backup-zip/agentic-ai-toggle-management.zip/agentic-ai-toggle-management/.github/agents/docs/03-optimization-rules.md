﻿<!--
  Copyright (c) 2026 Mastercard. All rights reserved.
-->

# Optimization Rules for Fast Lookup

## Rule 1: Pre-Build Toggle Registry Cache (One-Time Setup)
**When**: Before processing any toggles
**How**:
1. The registry is pre-built at `ToggleRegistryLookup.csv` (**802 entries** across **6 repositories**)

   | Repository | Entries | IMPLEMENTATION | IMPORT | DECLARATION |
   |---|---|---|---|---|
   | CPE | 524 | 323 | 2 | 199 |
   | Orchestrator | 135 | 89 | 7 | 39 |
   | MSOUI | 77 | 51 | 10 | 16 |
   | DirectAPI | 37 | 19 | 2 | 16 |
   | BusinessService | 24 | 5 | 16 | 3 |
   | Console | 5 | 3 | 0 | 2 |

2. Each row has **7 columns**: `toggle_name`, `registry_class_name`, `registry_file_path`, `constant_name`, `repository`, `usage_type`, `line_number`
   - `line_number` = actual line of the `isToggleOn` / `isOn` / `.isEnabled` / `ToggleHelper` call (IMPLEMENTATION rows)
                   = static import line (IMPORT rows)
                   = declaration line (DECLARATION rows — fallback only)
3. `DECLARATION` rows → included **only** when no IMPLEMENTATION or IMPORT row exists for that toggle+repo+constant combination
4. `IMPLEMENTATION` rows → there may be **multiple per toggle** (one per caller class) — use ALL of them for Phase 3B
5. **Dual search strategy**: search by BOTH display string AND every `constant_name` — CPE often aliases the constant
6. **Rebuild registry**: run `tools/BuildToggleRegistryLookup.ps1`
   - Normal (fast, DirectAPI 22-file targeted): run without switches
   - Full DirectAPI refresh (~5 min): run with `-RefreshDirectAPIFileList`

> ⚡ **DirectAPI**: Only 22 of ~10,367 files hold toggle constants. Builder hard-codes these paths — <1 sec scan.

> ⚠️ **Multi-class toggles**: A single toggle (e.g. `Enable Network Transaction ID`) can have 5+ IMPLEMENTATION rows
> across different classes. Do NOT stop at the first match — process ALL rows for that toggle.

## Rule 2: Use Tree Files for Fast File Lookup
Parse `cardpaymentengine.tree.txt` / `orchestrator.tree.txt` → build `CPEJavaFileLookup.csv` and `OrchestratorJavaFileLookup.csv` indexed by class name and package prefix. Reduces search scope 60-70%.

## Rule 3: Create S2A Keywords Lookup Index
Search `.java` files for `S2A|Streamlined|JsonMegaMessageMap|MegaMessageMap|TSPI|Acquirer|S2I`. Store in `S2AKeywordsLookup.csv` with columns: `java_class_name`, `relative_path`, `s2a_keywords`, `has_megamessagemap`, `has_jsonmegamessagemap`, `has_tspi`. Eliminates redundant Phase 5 searches.

## Rule 4: Batch Toggle Name Variant Generation
Pre-generate per batch: original, camelCase, snake_case, UPPER_CASE, 2-3 word chunks. Store in `ToggleSearchVariants_Batch_N.csv`. Priority order: exact → normalized → partial.

## Rule 5: Filter Search Scope to .java Files Only
- ALWAYS use `includePattern: "src/main/java/**/*.java"` in every `grep_search`
- Exclude: `/target/`, `/build/`, `/docs/`, `/.git/`, `/test/`

## Rule 5B: Skip Test Classes (CRITICAL)
- NEVER search `/src/test/java/**`, `*Test.java`, `*Tests.java`, `*Spec.java`
- Rationale: test code toggles are test setup/assertions, NOT production behavior

```
✓ grep_search: pattern="toggleName" includePattern="src/main/java/**/*.java"
✗ grep_search: pattern="toggleName" includePattern="**/*.java"  ← matches /test/
✗ grep_search: pattern="toggleName"  ← no filter at all
```

## Rule 5C: Four-Pattern Toggle Detection (CRITICAL — 2026-04-11)
The registry builder and agent Phase 3A searches must detect ALL four usage patterns:

| Pattern | Example | Detection Method |
|---|---|---|
| **Named static import** | `import static pkg.Toggle.CONSTANT_NAME;` | Match `\.([A-Z][A-Z0-9_]+)\s*;` on import lines |
| **Wildcard static import** | `import static pkg.ToggleConstants.*;` | Match `\.ClassName\.\*\s*;` → expand ALL constants from that class |
| **Fully-qualified body reference** | `isToggleOn(S2IAcquirerToggleConstants.TOGGLE_X)` | Scan body lines for `ClassName.CONSTANT_NAME` where ClassName is a known declaring class |
| **isOn() short form** | `Toggles.isOn(CONSTANT_NAME)` | Match `\.isOn\s*\(` in addition to `isToggleOn\s*\(` |

```
Complete $implPatterns list (BuildToggleRegistryLookup.ps1):
  'isToggleOn\s*\('     → Toggles.isToggleOn() or static-imported isToggleOn()
  '\.isEnabled\s*\('    → toggle object .isEnabled()
  '\.isOn\s*\('         → Toggles.isOn() short form (e.g. CassandraThreeDsTogglesUtils)
  'ToggleHelper\.'      → wrapper method delegation (e.g. ToggleHelper.isToggleOn84PanMasking())

Window match must check ALL three forms:
  1. bare CONSTANT_NAME
  2. ClassName.CONSTANT_NAME  (fully-qualified — affects ~25 S2IAcquirerToggleConstants toggles)
  3. toggle value string literal (e.g. "Enable Network Transaction ID")
```

## Rule 6: Batch Caching — Consolidate Multi-Variant Results
Cache all search results in-memory within batch. Store in `ToggleBatch_{N}_SearchResults.csv`. Remove duplicates (same toggle + class + line) before output. Consolidate to `ToggleBatch_{N}_Consolidated.csv`.

## Rule 7: Incremental Processing with Checkpoint Validation
After each batch, create `ToggleBatch_{N}_Checkpoint.txt` with: toggles processed, files searched, matches found, S2A classes identified, CSV rows written, status (SUCCESS/PARTIAL/FAILED). Continue to next batch only after checkpoint passes.

## Rule 8: Avoid Redundant Registry Class Lookups
- If match file = `registry_file_path` AND file is a pure constants class (no `isToggleOn`/`isOn` calls) → SKIP (declaration, not usage)
- If match file ≠ `registry_file_path` → INCLUDE (implementation)
- Exception: if same file contains both declaration AND `isToggleOn`/`isOn` calls → it is a **HYBRID class** → INCLUDE
- **Multi-class rule**: for any given toggle, there may be multiple non-declaration files → include ALL of them as separate IMPLEMENTATION rows

## Rule 9: Batch Consolidation Before Output
1. Combine results, remove exact duplicates, merge multi-line-number usages
2. Apply Rule 1 + 8 filtering
3. Analyze ON/OFF behavior from code context
4. Cross-reference S2A keywords lookup (Rule 3)
5. Append only consolidated, validated rows to `ToggleCodebaseUsageAnalysis.csv`

## Rule 10: One Row Per Implementation Class Per Toggle (NEW — 2026-04-11)
**Problem**: Collapsing all usage rows for a toggle to a single "best" winner discards real implementation classes.

**Rule**: The registry and output CSV must store **one row per (toggle_name, repository, constant_name, registry_class_name)** tuple.

```
Correct merge key: toggle_name + registry_file_path + repository + registry_class_name
WRONG merge key:   toggle_name + repository + constant_name   ← collapses multiple classes to one

DECLARATION suppression rule:
  Track coveredKeys = set of (toggle_name + repo + constant_name) that have ≥1 IMPL or IMPORT row
  Only add DECLARATION row if (toggle_name + repo + constant_name) NOT in coveredKeys
  → Guarantees DECLARATION only appears when genuinely no implementation was found
```

**Impact**: Enable Network Transaction ID went from 1 row → 7 rows (5 IMPL + 2 DECL).

## Optimization Quick Reference
| Rule | Purpose | When |
|------|---------|------|
| 1 | Registry Cache (802 entries, 6 repos, 7 cols) | Phase 0 once, reuse 73× |
| 2 | Java File Index | Phase 0 once, 60-70% scope reduction |
| 3 | S2A Keywords Index | Phase 0 once, replaces Phase 5 codebase search |
| 4 | Batch Variants | Per batch, before searching |
| 5 | Java-Only Search | Every grep_search call |
| 5B | Skip Test Classes | Every grep_search call |
| 5C | Four-Pattern Detection | Registry rebuild + Phase 3A search |
| 6 | Batch Caching | During batch, deduplicate before output |
| 7 | Checkpoints | After each batch |
| 8 | Filter Registry (with hybrid + multi-class) | Filter search results |
| 9 | Consolidation | Before CSV append |
| 10 | One Row Per Impl Class | Registry build + Phase 6 output |
