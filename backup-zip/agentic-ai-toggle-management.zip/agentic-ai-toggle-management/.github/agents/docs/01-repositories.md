﻿<!--
  Copyright (c) 2026 Mastercard. All rights reserved.
-->

# Target Repositories

## CardPaymentEngine (CPE)
- **Base Path**: `C:\Users\e135408\IdeaProjects\MPGS\SourceCode\cardpaymentengine`
- **Source Root**: `src/main/java`
- **Resources**: `src/main/resources`, `src/main/webapp`
- **Config**: `pom.xml`, Spring XML configs
- **Focus Areas**:
  - `com/mastercard/gateway/` (main package structure)
  - `QSI/` (custom implementations)
  - `config/` (configuration classes)
  - `target/classes/` (compiled resources)

## Orchestrator
- **Base Path**: `C:\Users\e135408\IdeaProjects\MPGS\SourceCode\orchestrator`
- **Source Root**: `src/main/java`
- **Resources**: `src/main/resources`
- **Config**: `pom.xml`, Spring XML configs
- **Focus Areas**:
  - `com/mastercard/` (main package structure)
  - Application configuration and routing logic

## BusinessService
- **Base Path**: `C:\Users\e135408\IdeaProjects\MPGS\SourceCode\businessservice`
- **Source Root**: `src/main/java`
- **Java Files**: ~581
- **Toggle Classes**: `CertificateChecker`, `ToggleUtils`, `MerchantCacheEntryFactory`
- **Scan Strategy**: Full scan

## Console
- **Base Path**: `C:\Users\e135408\IdeaProjects\MPGS\SourceCode\console\console`
- **Source Root**: `src/main/java`
- **Java Files**: ~749
- **Toggle Classes**: `BlacklistDomainsController`, `FailoverController`
- **Scan Strategy**: Full scan

## MSOUI
- **Base Path**: `C:\Users\e135408\IdeaProjects\MPGS\SourceCode\msoui`
- **Source Root**: `src/main/java`
- **Java Files**: ~1,065
- **Toggle Classes**: `ToggleConstant`, `ServicesSupport`, `SchemeTokenizationConstants`, `MerchantOrganisationHelper`, `FinicityConstants`
- **Scan Strategy**: Full scan

## DirectAPI ⚡ OPTIMIZED
- **Base Path**: `C:\Users\e135408\IdeaProjects\MPGS\SourceCode\directapi`
- **Source Root**: `src/main/java`
- **Java Files**: ~10,367 total — **only 22 contain toggle constants**
- **Scan Strategy**: **Targeted scan of 22 pre-identified files** (99.8% file reduction, <1 sec vs ~5 min full scan)
- **Refresh**: Run `BuildToggleRegistryLookup.ps1 -RefreshDirectAPIFileList` to rediscover if new toggle files added
- **Toggle Classes**: `AkamaiDecorator`, `PANMaskingHelper`, `RequestExecutor`, `ResponseFieldLogHandler`, `RestOperation`, `ProtocolPathTemplate`, `JsonWithJweEncryptedContentToPlainStringConverter`, `TestingMerchantsRateLimiter`, `UnauthenticatedPaymentRateLimiter`, `AuthorizationPayGatewayRecommendationConverter` (v64/v67/v69/v70/v73/v74/v77), `CreateOrUpdateMerchantRequestCanon` (v71/v72/v73), `HistoricalTransactionDataConfiguration`

## BatchSettlementService 🆕 ONBOARDED (2026-04-11)
- **Base Path**: `C:\Users\e135408\IdeaProjects\MPGS\SourceCode\batchsettlementservice`
- **Source Root**: `src/main/java`
- **Java Files**: 285 total
- **Scan Strategy**: Full scan
- **Toggle Constants**: 11 discovered (see toggle list below)
- **Key Toggle Classes**: `ToggleHelper`, `AccountValidationToggleHelper`, `RoutingConfigurationRetriever`, `MegaJsonEndPoint`, `CryptoServiceClient`, `JpaTransactionSubmissionDao`, `NotificationTransactionManager`, `StripeServiceClient`
- **Toggle Constant Inventory**:
  1. `TOGGLE_USE_ORIGINAL_BULKY_SQL_FOR_ACKS` → "System Toggle: Revert cut down SQL fix in BatchSettlementService for Acknowledgement"
  2. `TOGGLE_USE_ORIGINAL_BULKY_SQL_FOR_TRANSACTIONSUBMISSIONS` → "System Toggle: Revert cut down SQL fix in BatchSettlementService for Notification"
  3. `ENABLE_HSM_ENCRYPTION_FOR_BSS_PTS` → "System Toggle:Enable HSM Encryption For BatchSettlementService and PTS"
  4. `TOGGLE_TO_ENABLE_DEBUGINFORMATION_FOR_S2A` → "Enable debugInformation mapping in the response for S2A"
  5. `TOGGLE_TO_SET_CLEARTEXT_VALUE_TO_PAYMENT_RECIPIENT_ACCOUNT_NUMBER` → "System Toggle: Cleartext value for PaymentRecipientAccountNumber in BSS for AFT settlements"
  6. `ACQUIRER_TRANSACTION_ID_TOGGLE_NAME` → "Enable TSPI Response Mapping of AcquirerTransactionId from Acquiring Service to BSS"
  7. `ACCOUNT_VALIDATION_TOGGLE_NAME` → "ACH Account Validation for Paymentech Salem ACH Acquirer"
  8. `BSS_USE_BASE32_ID_GENERATOR` → "Batch Settlement Service use Base32 ID Generator"
  9. `ENABLE_FETCHING_NEW_VM_CONFIG` → "System Toggle:Enable fetching new VM config"
  10. `ACQ_SUBSYSTEM_SWITCH_SETTLEMENT_TXNS_TO_NEW_VM_FOR` → "System Toggle:AcqSubsystem - Switch Settlement to new VM for " (dynamic with acquirerId)
  11. `TOGGLE_SUPPORT_STRIPE_FAILOVER_USING_OPERATIONS_CONSOLE` → "Support STRIPE failover using Operations console"
  12. `SYSTEM_TOGGLE_ENABLE_TO_READ_ACQUIRER_CONFIG_FROM_DB` → "System Toggle: Enable T-SPI Batch Settlement Service to read Acquirer Configurations From Database"
