﻿<!--
  Copyright (c) 2026 Mastercard. All rights reserved.
-->

# S2A-Focused Analysis — Field Notation Rules

## 1. S2A Trigger Detection
Trigger S2A analysis if implementation class name or registry file path matches:
- `*S2IAcquirer*`, `*S2IAcquirerV1*`, `*S2IAcquirerV2*` → S2I ISO message builder
- `*JsonMegaMessageRequestBuilder*`, `*JsonMegaMessageMap*`, `*MegaMessageMap*` → S2A MEGA/TSPI JSON builder
- `*TspiRequestMessageBuilder*` → T-SPI message builder
- `*acquirer/messagemapimpl/*` (path pattern) → always S2A-adjacent
- `*S2AProcessor*`, `*StreamlinedAcquirer*` → direct S2A flow classes

---

## 2. S2I ISO 8583 Field Context (`S2IAcquirerV1`, `S2IAcquirerV2`, `IsoDataField*`)

S2I sends **ISO 8583 binary messages**. **Notation**: `ISO DE<number> [SE<number>] [SF<number>]`

| ISO DE | Description | Toggle Impact Examples |
|--------|-------------|----------------------|
| `ISO DE48` | Additional Data — Private Use | `DE48 SE36 SF05` = purposeOfPayment; `DE48 SE37 SF4` = aggregator data; `DE48 SE78 SF06` = ATRI; `DE48 SE86` = COF; `DE48 SE91` = CIT TID |
| `ISO DE54` | Additional Amounts | Foreign Exchange Fee for Visa AFT; cashback amount |
| `ISO DE61 SF<n>` | Point of Service Data | `SF3` = POS terminal type; `SF10` = Cardholder-activated; `SF11` = Terminal input capability |
| `ISO DE108` | Money Transfer Information | `SF01` = Transaction Reference; `SE03 SF05` = purpose code |
| `ISO DE120` | Record Data / Unique Transaction ID | `SE96` = unique transaction identifier |
| `ISO DE123` | Address Verification / Tag Data | OTD tag, CTI tag, statement descriptor, network data tag, clearing tag |
| `ISO DE52/53` | PIN Block / Security Related | Online PIN translation |
| `ISO DE15` | Settlement Date | Absent in void auth when toggle on |
| `ISO DE26` | POS PIN Capture Code | Amex PIN transactions |

---

## 3. S2A MEGA / TSPI JSON Message Structure (`JsonMegaMessageRequestBuilder`, `TspiRequestMessageBuilder`)

S2A sends **JSON messages**. **Notation**: `TSPI: <ContextObject>.<FieldName>`

```
JsonMegaMessage {
  Transaction { ... }     ← Transaction-level fields
  Acquirer { ... }        ← Acquirer routing & identification
  Merchant { ... }        ← Merchant configuration
  RoutingHeader { ... }   ← Message routing metadata
}
```

| TSPI Context | Toggle Impact Examples |
|---|---|
| **Transaction** | `Transaction.Amount`, `Transaction.CardNumber`, `Transaction.TransactionType`, `Transaction.AuthenticationStatus` |
| **Transaction.AccountFunding** | `AccountFundingPurpose`, `AccountFundingPaymentPurpose`, `AccountFundingForeignExchangeFee`, `PaymentReference` |
| **Transaction.AccountFunding.Recipient** | `PaymentRecipientFirstName`, `PaymentRecipientLastName`, `PaymentRecipientMiddleName` *(toggle-gated)*, `PaymentRecipientCountry`, `PaymentRecipientDateOfBirth` |
| **Transaction.AccountFunding.Recipient.Address** *(toggle-gated)* | `PaymentRecipientStreet`, `PaymentRecipientStreet2`, `PaymentRecipientCity` |
| **Transaction.AccountFunding.Recipient.Identification** *(toggle-gated)* | `PaymentRecipientIdenficationCountry`, `PaymentRecipientIdentificationType` |
| **Transaction.CustomerIdentification** *(toggle-gated)* | `CustomerIdentificationType`, `CustomerIdentificationCountry`, `CustomerIdentificationValue` |
| **Acquirer** | `Acquirer.AcquirerId`, `Acquirer.AcquirerBin`, `Acquirer.NetworkTransactionId` (FNT) |
| **Merchant** | `Merchant.MerchantId`, `Merchant.MerchantCategoryCode`, `Merchant.SubMerchant.Id`, `Merchant.AggregatorName` |
| **RoutingHeader** | `RoutingHeader.MessageType`, `RoutingHeader.AcquirerType`, `RoutingHeader.RoutingStrategy` |

---

## 4. Which Notation to Use — Decision Table

| Implementation Class Found | Acquirer Format | Field Notation |
|---|---|---|
| `S2IAcquirerV1`, `S2IAcquirerV2` | S2I ISO 8583 | `ISO DE<n> [SE<n>] [SF<n>]` |
| `IsoDataField*Populator`, `S2IAcquirerHelper` | S2I ISO 8583 sub-field | `ISO DE<n> SE<n> SF<n>` |
| `JsonMegaMessageRequestBuilder` | S2A MEGA JSON | `TSPI: Transaction.<Field>`, `TSPI: Merchant.<Field>`, `TSPI: Acquirer.<Field>` |
| `TspiRequestMessageBuilder` | T-SPI JSON | `TSPI: Transaction.<Field>`, `TSPI: RoutingHeader.<Field>` |
| `AccountFundingValidator` (Orchestrator) | TSPI/Merchant API | `accountFunding.<field>` |
| `TransactionRequestValidator` (CPE) | TSPI/Merchant API | `accountFunding.<field>` |
| Both S2I + MEGA classes | Both formats | **Separate rows** — ISO DE notation for S2I row; TSPI JSON for MEGA row |

---

## 5. S2A Toggle Type Classification
- **S2I DE Field Toggle**: ON adds/modifies ISO DE sub-elements; OFF omits them
- **S2A JSON Field Toggle**: ON populates TSPI JSON context fields; OFF omits/defaults them
- **S2A Flow Toggle**: ON routes to S2A/TSPI path; OFF uses legacy S2I path
- **S2A Feature Toggle**: ON enables feature within S2A (both paths stay in S2A)
- **API Validation Toggle**: ON applies/relaxes validation on TSPI API request fields

---

## 6. Field Impact Documentation Examples

```
S2I ISO 8583:
  Field Impact: ISO DE48 SE36 SF05 — purposeOfPayment from merchant used directly (not enum default);
    ISO DE48 SE03 SF05 — purpose sub-field populated (CRYPTO→11, HIGH_RISK→16, PAYROLL→09);
    ISO DE54 (Additional Amounts) — Foreign Exchange Fee validated and mapped for Visa AFT.

S2A MEGA JSON:
  Field Impact: TSPI: Transaction.AccountFunding.Recipient.Address
    (PaymentRecipientStreet, PaymentRecipientStreet2, PaymentRecipientCity) included;
    TSPI: Transaction.CustomerIdentification
    (CustomerIdentificationType, CustomerIdentificationCountry, CustomerIdentificationValue) included.

Dual-format toggle (separate rows):
  S2I row — Field Impact: ISO DE108 SF01 set to accountFunding.reference; ISO DE54 FX fee mapped.
  MEGA row — Field Impact: TSPI: Transaction.AccountFunding (AccountFundingPaymentPurpose,
    AccountFundingForeignExchangeFee); TSPI: Transaction.AccountFunding.Recipient
    (PaymentRecipientMiddleName, PaymentRecipientStreet, PaymentRecipientCity).
```

