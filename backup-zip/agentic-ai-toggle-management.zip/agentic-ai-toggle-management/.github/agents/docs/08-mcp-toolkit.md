﻿<!--
  Copyright (c) 2026 Mastercard. All rights reserved.
-->

# MCP Toolkit — Optimized Search & Publish Utilities

## Tools Overview

| Tool | Location | Status |
|---|---|---|
| `Toggle-SearchUtility.ps1` | `tools/` | ⚠️ Output issue (use file redirect) |
| `Toggle-PublishUtility.ps1` | `tools/` | ⚠️ Writes file OK, verify with read_file |
| `Toggle-AnalysisBatchProcessor.ps1` | `tools/` | Not recommended — use agent batch loop |
| `BuildToggleRegistryLookup.ps1` | `tools/` | ✅ Works (file output) — **primary registry builder** |
| `build-toggle-registry.ps1` | root | ✅ Legacy (CPE+Orch only) |

> **PS1 Output Issue**: PowerShell child-process stdout is not captured by JetBrains terminal.
> Scripts execute and write files correctly, but `Write-Host` / `ConvertTo-Json` piped to stdout produces no visible output.
> **Workaround**: Redirect output to a temp file and read back with `read_file`.

### PS1 Workaround Pattern
```powershell
# Step 1 — Run PS1 redirecting output to file
.\Toggle-SearchUtility.ps1 `
    -ToggleName "Enable TAF fields support for Passthrough" `
    -Repository "Both" `
    -ExcludeDeclarations `
    | Out-File -FilePath "C:\Temp\ts_result.json" -Force -Encoding UTF8
```
```
# Step 2 — Agent reads the file
Tool: read_file
filePath: C:\Temp\ts_result.json
```

---

## 1. Toggle-SearchUtility.ps1

**Purpose**: Search for toggle usage patterns across CPE and Orchestrator repositories  
**Usage**: `.\Toggle-SearchUtility.ps1 -ToggleName "Toggle Name" -Repository "Both"`  
**Output**: JSON with line numbers, code context, and file paths  
**Features**: Dual search, test-file exclusion, deduplication, declaration filtering

## 2. Toggle-PublishUtility.ps1

**Purpose**: Publish validated analysis data to `ToggleCodebaseUsageAnalysis.csv`  
**Usage**: `.\Toggle-PublishUtility.ps1 -AnalysisData $analysisData -BatchName "Batch1"`  
**Features**: Data validation before write, CSV quote escaping, append/replace mode, dry-run validation mode

Input data structure:
```powershell
@{
    ToggleName = "Toggle Name"
    ImplementationClassName = "ClassName"
    LineNumber = "42"
    ONImpact = "Business: ... Field Impact: ..."
    OFFImpact = "Business: ... Field Impact: ..."
    Repository = "CPE"
}
```

## 3. Toggle-AnalysisBatchProcessor.ps1

**Purpose**: Master orchestration combining Search and Publish for batch processing  
**Usage**: `.\Toggle-AnalysisBatchProcessor.ps1 -BatchNumber 1`  
**Features**: 5 toggles per batch, automated Search → Analyze → Publish cycle, detailed progress reporting

## 4. BuildToggleRegistryLookup.ps1 (Primary Registry Builder)

**Purpose**: Scan all 6 repositories and build `ToggleRegistryLookup.csv`  
**Usage**:
```powershell
# Normal rebuild (fast — DirectAPI uses 22-file targeted list, <1 sec)
& "C:\Users\e135408\Downloads\mcp-servers\tools\BuildToggleRegistryLookup.ps1"

# Full DirectAPI refresh (slow, ~5 min — use after new releases)
& "C:\Users\e135408\Downloads\mcp-servers\tools\BuildToggleRegistryLookup.ps1" -RefreshDirectAPIFileList
```
**Key feature**: `Get-UsageType` function detects both direct `isToggleOn()` calls AND indirect `ToggleHelper.` wrapper calls

---

## Batch 1 Results (Reference)
- **Status**: ✓ COMPLETE — 7 analysis rows
- **Toggles**: CPE Load Balancer Uses Ping (×2), Enable Lookup 8-digit bin, Apply New Order ID Reuse Rule (CPE+Orch), Disables orderCache loading, Enable TAF fields (0 hits)
- **Performance**: <3 sec per toggle, ~15 sec total, 4,278 files scanned

## Recommended Workflow for Batches 2–15

**Option A: Agent-driven (recommended)**
- Agent reads this guide, processes 5 toggles per batch using `grep_search` + `read_file` directly
- Appends rows to CSV using `insert_edit_into_file`

**Option B: PowerShell automated**
```powershell
2..15 | ForEach-Object {
    .\Toggle-AnalysisBatchProcessor.ps1 -BatchNumber $_
    Start-Sleep -Seconds 5
}
```

**Option C: Python parallel search**
```bash
python toggle_search_optimized.py  # Fast parallel search
# Then agent analysis + PS1 publish
```

---

## Post-Analysis Next Steps
1. Review `ToggleCodebaseUsageAnalysis.csv` — verify all rows have two-part ON/OFF impacts
2. For S2A toggles (`is_s2a=TRUE`): verify field-level ISO DE or TSPI JSON notation present
3. Coordinate with S2A development team for critical toggle findings
4. Re-run `BuildToggleRegistryLookup.ps1` after new releases to keep registry current

---

## ⚠️ Terminal & PowerShell Traps and Tricks

All issues below were encountered in live sessions. Read before running any terminal command.

---

### 🔴 TRAP 1: Terminal Output Buffer Floods Subsequent Commands

**Problem**: A large `Get-ChildItem | Select-String` scan across 3,000+ Java files generates hundreds of KB of output. This output **buffers and flushes slowly** — every command you run after shows the **previous scan's output**, not your new command's output.

**Symptom**: You run `Write-Host "DONE"` and see old search results instead.

**Detection**:
```powershell
Write-Host "CHECK_$(Get-Date -Format HHmmss)"
# If you don't see YOUR exact timestamp → buffer still flushing → wait
```

**Fixes**:
1. Use `isBackground=true` terminal — returns a terminal ID; poll with `get_terminal_output(id)` when ready
2. Scan one repo at a time (smaller output → faster flush)
3. Add a `Start-Sleep -Seconds 5` + marker before reading results
4. Never chain results from a slow scan directly into another command

---

### 🔴 TRAP 2: Pipe `|` Inside `-Pattern` String Breaks the Command

**Problem**: Regex alternation `|` inside a Select-String pattern conflicts with PowerShell's pipeline `|` operator.

```powershell
# BROKEN — parser sees this as 3 separate pipe stages
Get-ChildItem ... | Select-String "PatternA|PatternB|PatternC"
```

**Fix — Use `-SimpleMatch` for literal searches, or loop**:
```powershell
# SAFE option 1: SimpleMatch (treats | as literal character)
Select-String "Scheme Transaction Throttle for WS API - Passive Mode" -SimpleMatch

# SAFE option 2: foreach loop
foreach ($q in @("PatternA", "PatternB", "PatternC")) {
    Get-ChildItem $CPE -Recurse -Include "*.java" | Select-String $q -SimpleMatch
}
```

---

### 🔴 TRAP 3: Multi-Line Foreach Block Freezes Terminal in `>>` Mode

**Problem**: Pasting a multi-line block into the terminal can leave PowerShell waiting for the closing `}`. Terminal shows `>>` prompt and ignores all new commands.

**Fix**: Type `}` + Enter repeatedly until `PS C:\...>` prompt returns.

**Prevention**: Submit all multi-line code as one complete block via `run_in_terminal`. Never paste incrementally.

---

### 🔴 TRAP 4: `replace_string_in_file` Fails Silently on CSV Rows

**Problem**: `replace_string_in_file` on a 200-character CSV row fails in two ways:
- **Silent no-op** — no exact match found; row unchanged; tool reports "success"
- **Duplicate row** — match found in wrong location; new row inserted; original row preserved

Both modes hit in Session 4: OptimisticLock (line 42) and SchemeThrottle (line 52) stayed NOT_FOUND; Remove Orchestrator Session Merge (line 124) got duplicated.

**Fix — Use direct array index write**:
```powershell
$path = "C:\Users\e135408\Downloads\mcp-servers\jobs\TogglePageEnquiry\data\ToggleCodebaseUsageAnalysis.csv"
$lines = [System.IO.File]::ReadAllLines($path, [System.Text.Encoding]::UTF8)

# Find target line index
$idx = -1
for ($i = 0; $i -lt $lines.Length; $i++) {
    if ($lines[$i] -match [regex]::Escape("Toggle Name To Update")) { $idx = $i; break }
}
Write-Host "Found at index: $idx"  # Confirm before writing

# Replace
$lines[$idx] = '"New","CSV","Row"'
[System.IO.File]::WriteAllLines($path, $lines, [System.Text.Encoding]::UTF8)

# Remove a duplicate row (skip by index)
$clean = [System.Collections.Generic.List[string]]::new()
for ($i = 0; $i -lt $lines.Length; $i++) {
    if ($i -eq $duplicateIdx) { continue }
    $clean.Add($lines[$i])
}
[System.IO.File]::WriteAllLines($path, $clean, [System.Text.Encoding]::UTF8)
```

**Always verify after every CSV write**:
```powershell
$rows = Import-Csv $path
$rows | Where-Object { $_."Toggle Name" -eq "Target" } |
    Select-Object "Toggle Name","Implementation Class Name","Repository" | Format-Table
Write-Host "Total rows: $($rows.Count)"
```

---

### 🟡 CAUTION 1: `Get-ChildItem $CPE,$ORC` Cannot Distinguish Which Repo a Match Came From

**Problem**: Combined two-repo scan gives you `Filename:LineNumber` but you can't tell if it's CPE or Orchestrator when the same filename exists in both repos.

**Fix**: Always search repos separately and prefix results:
```powershell
$cpe = Get-ChildItem $CPE -Recurse -Include "*.java" | Select-String $q -SimpleMatch
$orc = Get-ChildItem $ORC -Recurse -Include "*.java" | Select-String $q -SimpleMatch
$cpe | ForEach-Object { "CPE:$($_.Filename):$($_.LineNumber)" }
$orc | ForEach-Object { "ORC:$($_.Filename):$($_.LineNumber)" }
```

---

### 🟡 CAUTION 2: `$i:` in String Interpolation Causes `DriveNotFound` Error

**Problem**: `"LINE $i: $preview"` → `ParserError: ':' was not followed by a valid variable name character`

**Fix**:
```powershell
Write-Host "LINE ${i}: $preview"        # use ${}
# or
Write-Host ("LINE " + $i + ": " + $preview)  # string concatenation
```

---

### 🟡 CAUTION 3: `get_terminal_output(id)` Must Be Polled — Returns Partial Output If Called Too Early

**Problem**: Background terminal is still running. `get_terminal_output` returns only captured-so-far output — no error, just incomplete results. If you read too early you miss most matches.

**Fix**: Add a completion marker and poll until you see it:
```powershell
# At end of your background command:
Write-Host "=SEARCH_COMPLETE_$(Get-Date -Format HHmmss)="

# Poll get_terminal_output(id) until marker appears in output
```

---

### 🟡 CAUTION 4: `Format-Table` Truncates Long CSV Cell Content

**Problem**: Toggle ON/OFF impact text is 200–500 chars. `Format-Table` shows `...` — you can't verify the full content was written correctly.

**Fix**:
```powershell
# See full content of any field
$rows | Where-Object { $_."Toggle Name" -eq "target" } | Format-List *

# Or select only the columns you need to verify
$rows | Where-Object { $_."Toggle Name" -eq "target" } |
    Select-Object "Toggle Name","Implementation Class Name","Line Number Code","Repository" |
    Format-Table -AutoSize
```

---

### ✅ PROVEN COPY-PASTE PATTERNS

#### Literal-string search — single repo, safe
```powershell
$CPE = "C:\Users\e135408\IdeaProjects\MPGS\SourceCode\cardpaymentengine\src\main\java"
$hits = Get-ChildItem $CPE -Recurse -Include "*.java" |
        Select-String '"Toggle Display Name"' -SimpleMatch |
        Select-Object Filename, LineNumber | Select-Object -First 5
$hits | ForEach-Object { Write-Host "CPE:$($_.Filename):$($_.LineNumber)" }
Write-Host "DONE"
```

#### CSV row replacement by exact index
```powershell
$p = "C:\Users\e135408\Downloads\mcp-servers\jobs\TogglePageEnquiry\data\ToggleCodebaseUsageAnalysis.csv"
$lines = [System.IO.File]::ReadAllLines($p, [System.Text.Encoding]::UTF8)
$lines[41] = '"ToggleName","ClassName","161","ON impact","OFF impact","CPE"'
[System.IO.File]::WriteAllLines($p, $lines, [System.Text.Encoding]::UTF8)
(Import-Csv $p) | Where-Object { $_."Toggle Name" -match "ToggleName" } | Format-Table -AutoSize
```

#### Dedup CSV (remove exact duplicate rows)
```powershell
$p = "C:\Users\e135408\Downloads\mcp-servers\jobs\TogglePageEnquiry\data\ToggleCodebaseUsageAnalysis.csv"
$lines = [System.IO.File]::ReadAllLines($p, [System.Text.Encoding]::UTF8)
$seen = @{}; $clean = [System.Collections.Generic.List[string]]::new()
foreach ($line in $lines) {
    $k = $line.Substring(0, [Math]::Min(80,$line.Length))
    if (!$seen[$k]) { $seen[$k]=$true; $clean.Add($line) }
}
[System.IO.File]::WriteAllLines($p, $clean, [System.Text.Encoding]::UTF8)
Write-Host "After dedup: $($clean.Count) lines"
```

#### Terminal buffer flush check
```powershell
Start-Sleep -Seconds 3; Write-Host "BUFFER_OK_$(Get-Date -Format HHmmss)"
```

