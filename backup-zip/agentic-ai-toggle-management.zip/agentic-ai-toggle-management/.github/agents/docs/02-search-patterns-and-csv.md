﻿<!--
  Copyright (c) 2026 Mastercard. All rights reserved.
-->

# Key Search Patterns

## Toggle Name Patterns
```
Original: "Enable Account Funding enhanced functionality for Mastercard and Visa"
Variants:
  - CamelCase: enableAccountFundingEnhancedFunctionality
  - snake_case: enable_account_funding_enhanced_functionality
  - UPPER_CASE: ENABLE_ACCOUNT_FUNDING_ENHANCED_FUNCTIONALITY
  - Partial: account.funding, AccountFunding, ACCOUNT_FUNDING
  - Constant: FEATURE_TOGGLE_ACCOUNT_FUNDING
```

## S2A Related Keywords and Patterns
```
Direct Keywords:
  - S2A, Streamlined, S2I (Streamlined-to-Interchange), S2A_ACQUIRER_TRANSACTION
  - JsonMegaMessageMap, MegaMessageMap, MEGA_MESSAGE_MAP
  - TSPI (Terminal Service Provider Interface), T-SPI
  - Acquirer, acquirer, ACQUIRER_TRANSACTION

Class Patterns:
  - *S2A*, *S2I*, *Streamlined*
  - *MegaMessage*, *JsonMega*, *TSPI*
  - *Acquirer*, *AcquirerTransaction*, *AcquirerProcessing*

Method Patterns:
  - *process*S2A*, *handle*S2A*, *route*S2A*
  - *build*MegaMessage*, *create*MegaMessage*
  - *isS2A*, *isStreamlined*, *requiresS2A*
```

## File Type Priorities
1. **Java Source** (`.java`): Primary focus
2. **XML Configuration** (`.xml`): Secondary — Spring bean definitions, toggle property configuration
3. **Properties** (`.properties`): Tertiary — toggle default values
4. **YAML** (`.yml`, `.yaml`): If present — Spring Boot configuration

---

# CSV Resources

## Input CSV
| Property | Value |
|---|---|
| **File path** | `jobs/TogglePageEnquiry/data/FeatureToggleConfluencePageEnquiryResults.csv` |
| **Key column** | `toggle_name` |
| **Filter column** | `is_s2a` |
| **Encoding** | UTF-8 |

## Output CSV: Toggle Codebase Usage Analysis

### Combined file (one, all repos)
| Property | Value |
|---|---|
| **File path** | `data/toggle-codebase-usage-analysis.csv` (from `config.yml → data.analysis_output`) |
| **Header** | `Toggle Name,Implementation Class Name,Line Number Code,Toggle ON Impact,Toggle OFF Impact,Repository` |
| **Contains** | Every row from every repo — used for cross-repo queries and per-toggle detail reports |

### Per-repo files (one per repo — rows are repo-exclusive)
| `Repository` value | Per-Repo Analysis File | Per-Repo Registry Lookup |
|---|---|---|
| `CPE` | `data/toggle-codebase-usage-analysis-cpe.csv` | `data/toggle-registry-cpe.csv` |
| `Orchestrator` | `data/toggle-codebase-usage-analysis-orchestrator.csv` | `data/toggle-registry-orchestrator.csv` |
| `BusinessService` | `data/toggle-codebase-usage-analysis-business-service.csv` | `data/toggle-registry-business-service.csv` |
| `Console` | `data/toggle-codebase-usage-analysis-console.csv` | `data/toggle-registry-console.csv` |
| `MSOUI` | `data/toggle-codebase-usage-analysis-msoui.csv` | `data/toggle-registry-msoui.csv` |
| `DirectAPI` | `data/toggle-codebase-usage-analysis-direct-api.csv` | `data/toggle-registry-direct-api.csv` |

> All paths from `config.yml → repositories[name=X].analysis_file`. Never hard-code.

**Same toggle in multiple repos** → one row in each matching per-repo file + one row in combined.

### Column definitions
| Column | Description |
|---|---|
| `Toggle Name` | Original toggle name from input CSV (no line-number prefix) |
| `Implementation Class Name` | Class where toggle is evaluated in conditional logic |
| `Line Number Code` | Exact line number in the implementation class |
| `Toggle ON Impact` | **Mandatory two-part format**: `Business: ... Field Impact: ...` |
| `Toggle OFF Impact` | Same two-part format, describing disabled/fallback behavior |
| `Repository` | Exactly one of the 6 valid values — must match `config.yml → repositories[*].name` |

### Dual-Write Rule (MANDATORY — SA-2b)
Every row is written to TWO destinations:
```
1. data/toggle-codebase-usage-analysis-{repo-kebab}.csv   ← per-repo file
2. data/toggle-codebase-usage-analysis.csv                ← combined file
```
Toggle in CPE + Orchestrator = 4 total writes (2 per-repo + 2 combined).

### Where Each Agent Reads From
| Use Case | Read from |
|---|---|
| Per-repo summary report (SA-4) | Per-repo file directly — no filtering needed |
| S2A report for CPE (SA-4) | `toggle-codebase-usage-analysis-cpe.csv` |
| Per-toggle detail across all repos (SA-4) | Combined file |
| In-place row update / correction | Per-repo file — unique key = `Toggle Name + Class Name` |
| Missing toggle check (SA-1) | Combined file |

## Repo-Specific Registry Lookup (SA-2a pattern)
Before searching Java source, SA-2a loads only the per-repo registry for the target repo:
```
CPE search      → data/toggle-registry-cpe.csv           → search CPE java root only
Orchestrator    → data/toggle-registry-orchestrator.csv  → search Orchestrator java root only
BusinessService → data/toggle-registry-business-service.csv → search BS java root only
... etc.
```
After the primary repo, **always also scan all remaining repos** for cross-repo usage.

## Repo-Specific Report Filtering (SA-4 pattern)

The `Repository` column is the key for all per-repo report generation:

```
# Filter for a per-repo summary report:
rows WHERE Repository = "CPE"           → CPE report
rows WHERE Repository = "Orchestrator"  → Orchestrator report
rows WHERE Repository = "BusinessService" → BusinessService report

# Filter for S2A-only report:
rows WHERE Repository = "CPE" AND Toggle ON Impact CONTAINS "ISO DE"
rows WHERE Repository = "CPE" AND Toggle ON Impact CONTAINS "TSPI:"

# Filter for update/correction targeting:
rows WHERE Repository = "CPE" AND Toggle Name = "Enable Foo"
→ target only these rows for in-place update (array-index write)
```

## Toggle ON/OFF Impact Format (MANDATORY)
```
✓ CORRECT — Business + Field Impact two-part format:
Toggle ON: "Business: For Visa AFT submitted at API v1.0.0+, gateway auto-populates purposeOfPayment field
  (defaults to ISOTHR) if merchant omits it.
  Field Impact: accountFunding.purposeOfPayment (TSPI/Orchestrator request field) auto-set to ISOTHR;
  validated against 6-char uppercase alpha format."

Toggle OFF: "Business: purposeOfPayment not auto-populated — merchants must supply it for Visa AFT.
  Field Impact: accountFunding.purposeOfPayment not defaulted or validated by gateway; passes through as-is."

✓ CORRECT — Internal only (no external fields):
Toggle ON: "Business: Transactions distributed randomly across available terminals.
  Field Impact: Internal only — no TSPI/ISO/acquirer fields affected."

✗ WRONG — code-centric (prohibited):
Toggle ON: "When enabled: Scheduled bean executes pingServers() method; checks toggle at line 82..."
Toggle ON: "Enables S2A feature"  (too vague, no business context, no field impact)
```
