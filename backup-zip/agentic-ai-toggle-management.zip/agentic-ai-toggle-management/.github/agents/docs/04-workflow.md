﻿<!--
  Copyright (c) 2026 Mastercard. All rights reserved.
-->

# Workflow — Toggle Code-Usage Enquiry (OPTIMIZED)

## Phase 0: Optimization Setup (One-Time Per Session)

1. **Load Toggle Registry** (Rule 1) — `jobs/TogglePageEnquiry/data/ToggleRegistryLookup.csv`
   - 279 entries across 6 repos; `IMPLEMENTATION` rows → priority Phase 3B targets
   - DirectAPI: 22 targeted files, <1 sec scan (see `docs/03-optimization-rules.md`)

2. **Index Java Files from Tree Files** (Rule 2) → `CPEJavaFileLookup.csv`, `OrchestratorJavaFileLookup.csv`

3. **Build S2A Keywords Index** (Rule 3) → `S2AKeywordsLookup.csv`

4. **Validate** → create `OptimizationSetup_Checkpoint.txt`, proceed only if all 3 lookups built

---

## Phase 1: Batch Input Processing
1. Read 5 toggles at a time from `FeatureToggleConfluencePageEnquiryResults.csv`
2. **Clean toggle names**: strip `^\d+\s*\|\s*` prefix corruption (e.g. `"61 | Enable..."` → `"Enable..."`)
3. Extract `toggle_name` (cleaned) and `is_s2a` for each batch

---

## Phase 2: Toggle Registry Lookup
1. Lookup `toggle_name` in `ToggleRegistryLookup.csv`
2. Retrieve: `registry_class_name`, `registry_file_path`, `constant_name`, `usage_type`, `repository`
3. Build dual-search pattern: `[display_string] + [all constant_names]` → pass to Phase 3A
4. `IMPLEMENTATION` rows → add `fullPath` to Phase 3B priority list
5. `DECLARATION` rows → DO NOT blindly exclude — still check same file for `isToggleOn` (hybrid check)
6. If toggle NOT in registry → note `REGISTRY_NOT_FOUND`, continue with display-string-only search

---

## Phase 3: Usage Tracing

### Phase 3A: Locate
1. **Dual Search — MANDATORY**: search by display string AND all `constant_name` values
   - Tool: `Toggle-SearchUtility.ps1 -ToggleName "<name>" -Repository "Both" -ExcludeDeclarations`
   - Scope: `src/main/java` only; test files excluded
2. Parse JSON output — each result has: `repository`, `className`, `filePath`, `fullPath`, `lineNumber`, `blockStart`, `blockEnd`, `isDeclaration`
3. **Declaration filter WITH hybrid check**:
   - If `isDeclaration == true` OR `filePath` matches `registry_file_path`:
     - Search that same file for `isToggleOn|isEnabled` calls
     - IF found → HYBRID class → keep, use isToggleOn line numbers as usage locations
     - IF NOT found → pure constants class → skip
4. **Cross-Repo Search — MANDATORY**: After finding in primary repo, always scan the other repo

### Phase 3B: Read
```
read_file(fullPath, offset=blockStart, limit=blockEnd - blockStart + 5)
```
- Returns COMPLETE enclosing method block
- Skip any match in `/test/` path or class ending with `Test`, `Tests`, `Spec`, `IT`, `ITest`

---

## Phase 4: Code Analysis — Two-Part Impact Format (MANDATORY)

For each toggle usage block:

1. Read ENTIRE if block AND else block (no shortcuts)
2. **Toggle ON (TRUE)** — two-part format:
   - `Business:` — what merchant/cardholder/acquirer CAN do or gains
   - `Field Impact:` — exact TSPI field names / ISO DE elements / acquirer fields gated; OR `Internal only — no TSPI/ISO/acquirer fields affected`
3. **Toggle OFF (FALSE)** — same format: what is NOT available, what fallback applies, which fields absent
4. **PROHIBITED patterns**: "When enabled: executes method...", "Enables S2A feature", placeholders

**Field Impact Reference**:
| Category | Examples |
|---|---|
| TSPI / Merchant API | `accountFunding.purposeOfPayment`, `accountFunding.reference`, `order.id`, `sourceOfFunds.provided.card.securityCode` |
| ISO 8583 DE (S2I) | `ISO DE48 SE36 SF05`, `ISO DE54`, `ISO DE108 SF01`, `ISO DE123` |
| MEGA / TSPI JSON | `AccountFundingPaymentPurpose`, `PaymentRecipientStreet`, `CustomerIdentificationType` |

---

## Phase 5: S2A Impact Analysis (Use Cached Lookup — NO Codebase Search)

1. Lookup implementation class in `S2AKeywordsLookup.csv` → get `s2a_keywords`, `has_megamessagemap`, `has_jsonmegamessagemap`, `has_tspi`
2. Select correct field notation based on class (see `docs/05-s2a-field-notation.md`)
3. Classify toggle type: `S2I DE Field Toggle` / `S2A JSON Field Toggle` / `S2A Flow Toggle` / `S2A Feature Toggle` / `API Validation Toggle`
4. Document S2A field impact using correct notation

---

## Phase 6: Results Compilation

1. Consolidate batch: remove exact duplicates, merge multi-line usages, apply Rule 1 + 8 filter
2. Validate: BOTH if + else blocks captured; S2A field notation correct; two-part format used
3. Output rows (6 columns): `Toggle Name`, `Implementation Class Name`, `Line Number Code`, `Toggle ON Impact`, `Toggle OFF Impact`, `Repository` — one row per usage location per repo
4. Append to `ToggleCodebaseUsageAnalysis.csv`; verify row count with `read_file`
5. Create `ToggleBatch_{N}_Checkpoint.txt`

---

## Batch Processing Cycle

1. **Phase 0**: Run once per session (registry + file index + S2A index)
2. **Per batch of 5**: Phase 1 → 2 → 3A → 3B → 4 → 5 → 6 → checkpoint
3. 15 iterations covers all 73 toggles (batches 1–15)
4. Continue to next batch only after checkpoint validation passes

**Performance**: Toggle Registry = 1 load, reused 73×. Search scope: ~5,566 Java files total (vs full 6-repo scan).

