﻿<!--
  Copyright (c) 2026 Mastercard. All rights reserved.
-->

# Analysis Guidelines — Code Analysis Requirements & Error Handling

## Complete Boolean Path Capture (MANDATORY)
For every toggle usage found, BOTH code paths must be fully analyzed:
- **IF Path**: Capture ALL statements, method calls, object instantiations
- **ELSE Path**: Capture ALL statements (or explicitly document absence of else block)
- **No Shortcuts**: Must read complete if/else blocks, not just summarize
- **Nested Conditionals**: Trace all code paths
- **Method Calls**: Note method name, class, and parameters
- **Data Transformations**: Document all variable assignments, format changes

## S2A Impact Analysis Accuracy
- **No Generic Descriptions**: Avoid "enables S2A" or "disables S2A" — be specific
- **Exact Classes**: Name specific S2A classes involved (MegaMessageMap, JsonMegaMessageMap, TSPI)
- **Control Type**: Specify if toggle controls flow selection, feature enablement, routing, or message format
- **Transaction Routing**: Document if toggle affects routing decisions
- **Message Format**: Document if toggle affects message generation or format

## Code Context Recording
- **Minimum**: Always record at least 5-10 lines of code around toggle usage
- **Full Block**: If method is small (<30 lines), record entire method
- **Related Code**: If toggle result used in subsequent statements, record those too

---

## Error Handling
| Situation | Action |
|---|---|
| Toggle not found | Document `STATUS = NOT_FOUND`, continue to next toggle |
| File access error | Document `ERROR: File access denied` with path, attempt to continue |
| Phase 4 analysis incomplete | Document `STATUS = INCOMPLETE`, record what was understood |
| S2A analysis indeterminate | Mark `S2A_IMPACT = INDETERMINATE` with explanation |
| Duplicate rows after dedup | Log which duplicates removed and why |

---

## Output Examples

### Example 1: Toggle with S2A Impact
```
Toggle Name: "Enable Account Funding enhanced functionality for Mastercard and Visa"
Implementation Class: com.mastercard.gateway.processor.AccountFundingProcessor
Line Number: 45

if (toggles.isEnabled("Enable Account Funding enhanced functionality...")) {
    accountFundingProcessor = new AccountFundingProcessor(transaction);
    JsonMegaMessageMap builder = new JsonMegaMessageMap();
    Message msg = builder.buildAccountFundingMessage(transaction);
    router.routeToS2AAcquirer(msg);
} else {
    legacyProcessor = new LegacyAccountProcessor();
    message = legacyProcessor.processTransaction(transaction);
    router.routeToDefaultAcquirer(message);
}

Toggle ON: "Business: Merchants can submit enhanced AFT via S2A path — full Visa/MC AFT processing
  including purpose mapping and FX fee.
  Field Impact: TSPI: Transaction.AccountFunding (AccountFundingPaymentPurpose,
  AccountFundingForeignExchangeFee); routes via JsonMegaMessageMap to S2A acquirer."

Toggle OFF: "Business: Legacy AFT path used — enhanced fields dropped, standard acquirer routing.
  Field Impact: TSPI Transaction.AccountFunding enhanced fields not populated; uses LegacyAccountProcessor."
```

### Example 2: Internal-only Toggle
```
Toggle ON: "Business: Transactions distributed randomly across available terminals — prevents hotspots.
  Field Impact: Internal only — no TSPI/ISO/acquirer fields affected."

Toggle OFF: "Business: Sequential terminal allocation used — no randomization.
  Field Impact: Internal only — no TSPI/ISO/acquirer fields affected."
```

### Multiple Usage Locations (same toggle → multiple rows)
```
Row 1: Toggle "Enable Account Funding" in AccountFundingProcessor at line 45 — CPE
Row 2: Toggle "Enable Account Funding" in JsonMegaMessageMap at line 156 — CPE
Row 3: Toggle "Enable Account Funding" in AccountFundingOrchestrator at line 234 — Orchestrator
```

---

## Progress Tracking
After each batch of 10 toggles, report:
- Number of toggles analyzed
- Total files found / total occurrences found
- S2A keywords identified
- Row count in output CSV

Checkpoint verification:
- Read output CSV after each batch to confirm persistence
- Validate row counts match expected batch size

