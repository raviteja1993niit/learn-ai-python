﻿<!--
  Copyright (c) 2026 Mastercard. All rights reserved.
-->

# Lessons Learned — Critical Failure Mode RCA

## ⚠️ CRITICAL FAILURE: Toggle #8 — Missed Initially (RESOLVED)
- **Toggle**: "Enable issuer country code in transaction response"
- **Original finding**: NOT_FOUND
- **Actual location**: `CardTypeDetailsDecorator.java` line 124

### Three-Part Root Cause
1. **Fragmented Search**: Used decomposed keywords instead of full literal string → missed multi-word constant
2. **Package Assumption**: Expected `acquirer/messagemapimpl/` pattern → actual location was `retrieval/decorator/`
3. **Missed Literal String Search**: Should grep for `"Enable issuer country code..."` (with quotes) first

### Three-Step Validation Search (MANDATORY for every toggle)
1. `grep_search('"Toggle display name as-is"', includePattern='**/*.java')` — PRIMARY
2. `grep_search('CONSTANT_NAME', includePattern='src/main/java/**/*.java')` — SECONDARY
3. `grep_search('key.*business.*terms', includePattern='**/*.java')` — VALIDATION (HIGH false-positive risk)

---

## Validation Checklist (BEFORE MARKING NOT_FOUND or DECLARATION_ONLY)

```
☐ Step 1:  Literal string search in BOTH CPE and Orchestrator?
☐ Step 2:  Registry constant_name variations checked?
☐ Step 3:  Cross-repository search completed?
☐ Step 4:  Implementation class ≠ declaration class verified?
☐ Step 5:  Keyword fallback search executed if Steps 1-2 returned nothing?
☐ Step 6:  Similar class names manually inspected (e.g., *CardType* for issuer toggles)?
☐ Step 7:  Decorator/Helper classes checked (*Decorator, *Helper)?
☐ Step 8:  Search NOT limited to expected packages — entire codebase searched?
☐ Step 9:  HYBRID CHECK — same declaration file scanned for isToggleOn/isEnabled?
            IF found → HYBRID class → classify as IMPLEMENTATION, analyze it
            IF not found → pure constants class → DECLARATION_ONLY is correct
☐ Step 10: TOGGLEHELPER INDIRECTION CHECK — if no direct isToggleOn callers found,
            search for a ToggleHelper wrapper method across both repos:
            grep_search('CONSTANT_NAME') → find ToggleHelper wrapper method name →
            grep_search('isToggleOnXxx') → find caller classes (IMPLEMENTATION)
☐ Step 11: FULLY-QUALIFIED USAGE CHECK — search for ClassName.CONSTANT_NAME in body:
            grep_search('ClassName.CONSTANT_NAME') across both repos
            e.g. isToggleOn(S2IAcquirerToggleConstants.TOGGLE_VISA_MANDATE_COF)
            The constant identifier alone WON'T match — must include class prefix
☐ Step 12: WILDCARD IMPORT CHECK — search for  import static pkg.ClassName.*  pattern:
            grep_search('import static.*ClassName\.\*') across both repos
            Wildcard imports make ALL constants from that class available without
            named imports — they are invisible to named-import-only search
☐ Step 13: isOn() METHOD CHECK — search for .isOn( variant in addition to isToggleOn(:
            grep_search('Toggles.isOn(CONSTANT_NAME)') — some classes (e.g.
            CassandraThreeDsTogglesUtils) use Toggles.isOn() not Toggles.isToggleOn()
☐ Step 14: MULTIPLE IMPLEMENTATION CLASSES CHECK — a single toggle can be used by
            MANY different classes; do not stop at the first match:
            All callers of isToggleOn(CONSTANT_NAME) are separate IMPLEMENTATION rows
            e.g. Enable Network Transaction ID → S2IAcquirerV1, IsoField105DataMapper,
            MITIndustryPracticeValidator, AgreementDataService, RecurringPaymentAgreementService
☐ Step 15: PRIVATE/PROTECTED DECLARATION CHECK — if toggle not found in registry at all,
            the constant may be declared private/protected (not public) within an
            implementation class itself. Search the implementation file directly:
            grep_search('static final String.*=.*"<display name>"', includePattern='**/*.java')
            These constants never appear in the shared constants-class registries.
☐ Step 16: CONSTANT-NAME PREFIX CHECK — if constant present but not in registry,
            its name prefix may be outside the recognized set. Check these underused
            prefixes: ACCEPT_, PREVENT_, FIX_, SUPPORT_, INDUSTRY_
            e.g. ACCEPT_CSC_IN_SCHEME_TOKEN_TRANSACTIONS, PREVENT_FORMAT_4_PIN_BLOCK_*
☐ Step 17: INPUT-TO-REGISTRY NAME MISMATCH CHECK — if toggle name not found in registry by
            exact match, perform keyword fallback: split input name into significant keywords
            (≥4 chars), search all registry toggle_name values for ≥2 keyword overlap,
            resolve to best-match registry entry.
            e.g. "Shared Memory CPE PersistenceTable" → matches
            "System Toggle: Allow lenient updates to CPE PersistenceTable based off Shared Memory state"
☐ Step 18: DECLARATION-ONLY REGISTRY ENTRY FOLLOW-UP — if registry has only DECLARATION rows
            for a toggle, do NOT stop there. Run Phase 3A grep_search for the constant_name
            in src/main/java of ALL repos — separate implementation classes not in registry
            may exist (e.g. HistoricalTransactionDataAggregator found for toggle declared only in
            HistoricalTransactionDataConfiguration).
☐ Step 19: ACRONYM FALLBACK SEARCH — if full toggle name yields zero hits, extract any
            acronym or brand token from the name (DPG, COF, BCI, HSM, SCT, AFT, FRR, TSPI)
            and grep for it as a keyword in likely implementation classes before marking NOT_FOUND.
☐ Step 20: INLINE STRING LITERAL TOGGLE CHECK — some toggles are never declared as named
            constants at all; the display string is passed directly to Toggles.isOn() inline:
              if (Toggles.isOn("Remove Orchestrator Session Merge")) {
            These are COMPLETELY INVISIBLE to constant-based registry search.
            Always include a literal-string grep across the codebase:
              grep_search('"<toggle display name>"') across src/main/java of ALL repos
            Real examples found: "Remove Orchestrator Session Merge" (CardDetailsDecorator),
            "Scheme Transaction Throttle for WS API - Passive Mode" (SchemeTransactionThrottleHelper),
            "System Toggle: Use Enhanced Optimistic Lock With Terminal Batch Counters" (TerminalBatchCounterDaoImpl)
            All three used the display string directly in isToggleOn()/isOn() calls — no named constant.
☐ NOT_FOUND / DECLARATION_ONLY only if ALL 20 checks pass with zero implementation hits
```

---

## Toggle Categories Most Prone to Being Missed

| Category | Risk Pattern | Solution |
|---|---|---|
| Card/Cardholder Data | Decorator, helper, service classes across multiple packages | Search `/retrieval/`, `/cardservice/`, `/decorator/` |
| Acquirer/Routing | Mostly `acquirer/messagemapimpl/` but exceptions exist | Search both `/acquirer/` and root payment server packages |
| Transaction Protection | Usually `/protectionService/` but may be in validators | Expand to `*Validator`, `*Helper` classes |
| Multi-word Toggle Names | Fragmentation risk (e.g., "Enable issuer country code...") | ALWAYS literal string search FIRST |
| System/Operational | Utility classes, base transaction classes, logging | Don't assume package — search broadly |
| Fully-Qualified Usage | `ClassName.CONSTANT_NAME` in isToggleOn() body, no static import | Search `ClassName.CONSTANT` not just bare `CONSTANT` |
| Wildcard Import Classes | `import static pkg.ClassName.*` — all constants available implicitly | Detect `.*;` imports, expand all class constants |
| isOn() Variant | `Toggles.isOn()` instead of `Toggles.isToggleOn()` | Always include `.isOn(` in toggle call patterns |
| Multi-class Toggles | One toggle used by 5+ different classes (e.g. AFT, Network TXN ID) | Scan whole codebase; collect ALL callers, not just first |
| Private/Local Declaration | Toggle constant declared `private`/`protected` inside implementation class | Search for string value directly; don't rely solely on constants-class registry |
| Non-standard Prefix | Constant uses ACCEPT_, PREVENT_, FIX_, SUPPORT_, INDUSTRY_ — not in registry filter | Expand `$isToggle` prefix filter; search by display string if constant missed |
| Short/Symbol Value | Non-toggle constant (e.g. `REMOVE_PRIVILEGE = "-"`) captured by broad prefix filter → poisons regex | Value guard: reject values < 5 chars or with no spaces; exclude known culprits |
| Input Name Mismatch | Input CSV toggle name differs from registry toggle_name (partial/abbreviated/reworded) | Keyword fallback matching: split name → find ≥2 keyword overlap in registry before REGISTRY_NOT_FOUND |
| Declaration-Only Registry | Registry has only DECLARATION rows — implementation class(es) not yet registered | Always run Phase 3A grep for constant_name even when registry shows DECLARATION; new impl classes may exist |
| Acronym-Only Toggle Names | Toggle name contains only an acronym (DPG, BCI, HSM, SCT) — full-string grep yields nothing | Grep for acronym token in likely class files as fallback before NOT_FOUND |
| Inline String Literal Toggle | Display string passed directly to `Toggles.isOn("string")` — no named constant declared anywhere | ALWAYS run literal-string grep `'"<display name>"'` across all repos; invisible to constant-based registry |

---

## Cardinal Errors to Avoid

**❌ ERROR 1: Fragmenting Long Toggle Names**
- WRONG: Search `[issuer, country, code]` separately
- RIGHT: Search `"Enable issuer country code in transaction response"` as one phrase

**❌ ERROR 2: Assuming Single Package Hierarchy**
- WRONG: All card toggles are in `acquirer/messagemapimpl/`
- RIGHT: Toggles scatter across `decorator/`, `helper/`, `service/`, `retrieval/` based on architectural concern

**❌ ERROR 3: Skipping Literal String Search**
- WRONG: Only search constant name identifiers
- RIGHT: ALWAYS include literal display string search with quotes

**❌ ERROR 4: Not Cross-Checking Both Repositories**
- WRONG: Found in CPE → stop
- RIGHT: ALWAYS verify Orchestrator after CPE search

**❌ ERROR 5: Dismissing Decorator/Helper Classes**
- WRONG: Only core S2I/MEGA classes implement toggles
- RIGHT: `*Decorator`, `*Helper`, `*Validator` classes are PRIMARY toggle locations

**❌ ERROR 6: Stopping at Declaration When Same File Has Implementation**
```
WRONG: Found declaration in File X → mark DECLARATION_ONLY → stop
RIGHT: After finding declaration, search SAME file for isToggleOn/isEnabled

Known hybrid classes:
  CardTypeDetailsDecorator.java   — declaration line 70,  usage line 124
  SanctionHelper.java             — declaration line 327, usage lines 1568, 1708, 1729, 1755
  TransactionDataCommonService.java — declaration line 157, usage lines 550, 1540
```

**❌ ERROR 7: Misclassifying Pure Constants Class vs Hybrid Class**
```
Detection:
  grep_search('isToggleOn|isEnabled', includePattern='<exact file path>')
  0 results → pure constants class → DECLARATION_ONLY correct
  >0 results → hybrid class → IMPLEMENTATION, must analyze
```

**❌ ERROR 8: Never Searching Constant Name Across Full Codebase**
```
WRONG: Declared in S2IAcquirerToggleConstants → DECLARATION_ONLY → stop
RIGHT: grep_search(CONSTANT_NAME) across BOTH repos → find isToggleOn() callers → analyze

Key Insight: Constants classes declare the string. IMPLEMENTATION is in a DIFFERENT
class that imports the constant and calls isToggleOn(CONSTANT_NAME).
Registry tells WHERE it's declared, NOT where it's consumed.

Affected in Session 3 (18 toggles fixed): All S2IAcquirerToggleConstants declarations,
  CassandraThreeDsTogglesUtils, DoNotProcessAfterTimeHandler, ToggleConstants entries.
```

**❌ ERROR 9: Missing Toggle Through ToggleHelper Indirection (2026-04-10)**
```
WRONG: No direct isToggleOn(CONSTANT) callers found → DECLARATION_ONLY → stop
RIGHT:
  Step A: Search CONSTANT_NAME → find ToggleHelper.java wrapping it:
          public static boolean isToggleOn84PanMasking() { return isToggleOn(CONSTANT); }
  Step B: Search 'isToggleOn84PanMasking' across BOTH repos → find caller classes
  Step C: Caller classes are the IMPLEMENTATION rows in the registry

Real example:
  ToggleConstants → TOGGLE_ENABLE_8_4_PAN_MASKING
  → ToggleHelper.isToggleOn84PanMasking() (wrapper)
  → TokenDetailsContainer.java:119 (Orchestrator IMPLEMENTATION)
  → CardPaymentDecoratorPostRetrieveAction.java:62 (CPE IMPLEMENTATION, direct call)

Script fix: BuildToggleRegistryLookup.ps1 Get-UsageType now also detects ToggleHelper. calls
```

**❌ ERROR 10: Matching Only Bare CONSTANT_NAME — Missing Fully-Qualified Usage (2026-04-11)**
```
WRONG: Search window for bare "TOGGLE_VISA_MANDATE_COF" → no match → classify DECLARATION
RIGHT: The usage line is:  isToggleOn(S2IAcquirerToggleConstants.TOGGLE_VISA_MANDATE_COF)
       Window contains "S2IAcquirerToggleConstants.TOGGLE_VISA_MANDATE_COF" NOT bare "TOGGLE_VISA_MANDATE_COF"

Root Cause: BuildToggleRegistryLookup.ps1 window-match only checked for bare CONSTANT_NAME.
Fix Applied: Also match ClassName.CONSTANT_NAME pattern in window:
   ($w -match [regex]::Escape($declaringClassName) + '\.' + [regex]::Escape($constName))

Affected toggles (examples): Enable S2I Visa Mandate CardOnFile, Enable S2I Mastercard Mandate
  CardOnFile, Send JCB CAVV in B20 format, Use DPD Data Element for DSRP Cryptogram,
  Populating DE122 and flagging of Message version code for MDQ-Gateway, Sub-merchant
  Marketplace ID for Visa, and ~25 other S2IAcquirerToggleConstants-declared toggles.

Also required: Section C body scan — detect ClassName.CONSTANT_NAME references in body lines
  (not just imports) and register them as available constants for that file.
```

**❌ ERROR 11: Wildcard Static Import Not Detected (2026-04-11)**
```
WRONG: Only named  import static pkg.ClassName.CONSTANT_NAME;  detected
       → file with  import static pkg.S2IAcquirerConstants.*;  gets zero constants registered
       → ALL constants from that class are invisible to the import scanner
RIGHT: Also detect wildcard imports  import static pkg.ClassName.*;
       → expand to ALL known constants from that declaring class
       → register them with the wildcard import line number

S2IAcquirerV1.java line 36:  import static ...S2IAcquirerConstants.*;
This one import makes ALL S2IAcquirerConstants constants available, but the old scanner
only looked for individual named imports and found none → missed all constant references.

Fix Applied: Two-phase import scan:
  Phase A1 — named:    \.([A-Z][A-Z0-9_]+)\s*;  → direct constant entry
  Phase A2 — wildcard: \.([A-Za-z][A-Za-z0-9_]+)\.\*\s*; → expand all class constants
```

**❌ ERROR 12: isOn() vs isToggleOn() Call Pattern (2026-04-11)**
```
WRONG: Only match  isToggleOn\s*\(  and  \.isEnabled\s*\(  as implementation patterns
       → miss  Toggles.isOn(TOGGLE_PERSIST_3DS_DOCUMENTS_IN_CASSANDRA_ONLY)
RIGHT: Also match  \.isOn\s*\(  as a valid toggle-evaluation call pattern

Real example: CassandraThreeDsTogglesUtils.java
  static boolean isCassandraPersistenceAvailable() {
      return !Toggles.isOn(TOGGLE_DISABLE_CASSANDRA_PERSISTENCE);
  }
  → Was classified DECLARATION_ONLY because isOn() not in implPatterns

Fix Applied: Added '\.isOn\s*\(' to $implPatterns array in BuildToggleRegistryLookup.ps1

Complete list of valid toggle evaluation patterns:
  isToggleOn(...)           → static import of Toggles.isToggleOn
  Toggles.isToggleOn(...)   → fully qualified
  .isEnabled(...)           → toggle object method
  .isOn(...)                → Toggles.isOn() short form
  ToggleHelper.*()          → wrapper method delegation
```

**❌ ERROR 13: One Row Per Toggle Instead of One Row Per Implementation Class (2026-04-11)**
```
WRONG: Merge key = toggle_name + repo + constant_name
       → Multiple implementation classes for same toggle collapse to ONE row
       → Only the "winner" (highest priority or lowest line number) is kept
       → All other callers are silently discarded

RIGHT: Keep ALL IMPLEMENTATION and IMPORT rows — one row per (toggle, file, class)
       → Merge key must include registry_class_name:
          toggle_name + registry_file_path + repo + registry_class_name

Real example: Enable Network Transaction ID had 5 caller classes:
  S2IAcquirerV1 (CPE, line 6531)              → IMPLEMENTATION
  IsoField105DataMapper (CPE, line 72)        → IMPLEMENTATION
  MITIndustryPracticeValidator (Orch, line 97) → IMPLEMENTATION
  AgreementDataService (Orch, line 201)       → IMPLEMENTATION
  RecurringPaymentAgreementService (Orch, line 695) → IMPLEMENTATION

Old behavior: only ONE row survived per toggle+repo+constant key.

Fix Applied (BuildToggleRegistryLookup.ps1 2026-04-11):
  1. usageRegistry key: toggle + file + repo + className  (keeps all per-class rows)
  2. Merge strategy: additive — all IMPL/IMPORT rows kept; DECLARATION only when
     zero IMPL/IMPORT exists for that toggle+repo+constant combination
  3. coveredKeys HashSet tracks which toggle+repo+constant combos have been claimed
     by IMPL/IMPORT → DECLARATION suppressed when covered
```

**❌ ERROR 18: Input Toggle Name Differs from Registry Toggle Name — Partial Keyword Matching Required (2026-04-11)**
```
WRONG: Cross-reference input CSV toggle_name against registry toggle_name with exact match only
       → "Shared Memory CPE PersistenceTable" (input) not found in registry by exact match
       → Classified as NOT_FOUND or REGISTRY_NOT_FOUND and skipped

RIGHT: When an exact registry match fails, perform partial keyword matching:
       1. Split input toggle name into significant keywords (≥4 chars, ignore stop words)
       2. Search registry toggle_name column for entries containing 2+ of those keywords
       3. Resolve to best-match registry entry (highest keyword overlap score)
       4. Confirm by checking the implementation class for the matched constant

Real example:
  Input: "Shared Memory CPE PersistenceTable"
  Registry: "System Toggle: Allow lenient updates to CPE PersistenceTable based off Shared Memory state"
  Keywords matched: "CPE", "PersistenceTable", "Shared", "Memory" → 4/4 → strong match
  Resolved to: PersistenceTableDao.java, TOGGLE_LESS_STRICT_UPDATE_VERSION, line 283 (IMPLEMENTATION)

Prevention: Before marking REGISTRY_NOT_FOUND, run keyword fallback search against all
  registry toggle_name values; only escalate to NOT_FOUND after both exact AND keyword match fail.
```

**❌ ERROR 19: DECLARATION-Only Registry Entry Hides Separate Implementation Class (2026-04-11)**
```
WRONG: Toggle found in registry with usage_type=DECLARATION only → conclude no isToggleOn callers
       → Skip Phase 3A grep search because "already in registry as DECLARATION"
       → Mark DECLARATION_ONLY

RIGHT: A DECLARATION entry in the registry means only that the constant was found at declaration level.
       It does NOT mean there are no implementation classes — the implementation class may simply not
       have been picked up by the registry builder (especially if it's in a differently-named class or
       uses the constant via a ToggleHelper wrapper).

Real example:
  Registry: "Enable historical transaction data aggregation..." →
    HistoricalTransactionDataConfiguration.java (DirectAPI), DECLARATION only, line 13
  Actual implementation: HistoricalTransactionDataAggregator.java line 87
                    AND  HistoricalTransactionDataCollector.java line 88 (both DirectAPI)
  Both were found via grep_search for the constant name — not in registry at all

Action: For ANY toggle that has only DECLARATION rows in the registry:
  → ALWAYS run Phase 3A grep_search for the constant_name in src/main/java
  → A DECLARATION entry is a starting hint, not a final classification
  → Validate the DECLARATION file itself for hybrid usage (Cardinal Error 6 rule still applies)
```

**❌ ERROR 20: Assuming NOT_FOUND After Single Search Pass on Unusual Toggle Names (2026-04-11)**
```
WRONG: Toggle not found after first grep_search of display string → mark NOT_FOUND

RIGHT: For unusual or ambiguous toggle names (e.g. "System Toggle:Enable DPG New Mapping"),
       the constant may be declared under a different string variation or abbreviation:
       1. Try both exact display string AND key-phrase subsets (e.g. "DPG New Mapping")
       2. Try the implementation class name if hinted by the toggle category (e.g. "DPG" → AcquirerResponse*)
       3. Try the constant's likely name pattern manually (TOGGLE_DPG_*, ENABLE_DPG_*)

Real example:
  "System Toggle:Enable DPG New Mapping" — 0 hits on full string search in CPE
  BUT: grep for "DPG" in AcquirerResponseJsonProcessor found the constant at line 126
  AND: grep for "DPG" in JsonMessageParserImpl found it at line 119
  Both used TOGGLE_ENABLE_DPG_NEW_MAPPING or equivalent reference inside the if-block

Prevention: When a toggle name contains an acronym (DPG, COF, BCI, HSM, SCT) always search
  for the acronym itself as a fallback when full-string search yields zero results.
```

**❌ ERROR 21: Inline String Literal Toggle Completely Invisible to Registry-Based Search (2026-04-11)**
```
WRONG: Registry search finds no constant for toggle → CONFIRMED_NOT_FOUND → stop
       Assumption: all toggles are declared as static final String constants somewhere

RIGHT: Some toggles pass the display string DIRECTLY to Toggles.isOn() or Toggles.isToggleOn()
       inline — no named constant is ever declared:
         if (Toggles.isOn("Remove Orchestrator Session Merge")) { ... }
         if (isToggleOn("Scheme Transaction Throttle for WS API - Passive Mode")) { ... }
         if (Toggles.isToggleOn("System Toggle: Use Enhanced Optimistic Lock With Terminal Batch Counters")) { ... }

       These are COMPLETELY INVISIBLE to:
         - ToggleRegistryLookup.csv (registry builder only scans named constants)
         - Constant-name grep (no constant to search for)
         - Registry keyword fallback (no entry to match against)

       The ONLY way to find them: literal-string grep with quotes across all repos:
         PowerShell: Get-ChildItem $ROOT -Recurse -Include "*.java" |
                     Select-String '"Remove Orchestrator Session Merge"' -SimpleMatch

Real examples found in this session (all previously marked NOT_FOUND):
  "Remove Orchestrator Session Merge"
    → CardDetailsDecorator.java:167 (Orchestrator) — Toggles.isOn("Remove Orchestrator Session Merge")
  "Scheme Transaction Throttle for WS API - Passive Mode"
    → SchemeTransactionThrottleHelper.java:378 (CPE) — isToggleOn(SCHEME_TRANSACTION_THROTTLE_FOR_WS_API_PASSIVE_MODE)
      [constant declared in same class — hybrid; but key search was on display string]
  "System Toggle: Use Enhanced Optimistic Lock With Terminal Batch Counters"
    → TerminalBatchCounterDaoImpl.java:161 (CPE) — isToggleOn(SYSTEM_TOGGLE_USE_ENHANCED_OPTIMISITIC_LOCK_...)
      [constant declared in same class — hybrid; invisible to cross-class registry]

Root cause: BuildToggleRegistryLookup.ps1 only harvests public/private static final String
  constants and cross-references callers. Classes that declare AND immediately use the
  string literal without exporting the constant are invisible — registry builder never
  sees the string value to add to $declMap.

Prevention: Step 20 of validation checklist — literal-string grep MANDATORY before NOT_FOUND.
  Also: update BuildToggleRegistryLookup.ps1 to detect inline string literals in isToggleOn()
  calls that don't match any harvested constant value.
```

**❌ ERROR 22: replace_string_in_file Silently Fails or Creates Duplicate Row Instead of Replacing (2026-04-11)**
```
PROBLEM: replace_string_in_file tool was used to update NOT_FOUND rows in a CSV file.
         Two different failure modes occurred:

  FAILURE MODE A — Silent no-op:
    The tool found no match (long CSV cell content didn't match oldString exactly due to
    line-ending differences, encoding, or partial content) → did NOT update the row →
    returned "success" without actually changing anything → row remained NOT_FOUND
    undetected.
    Affected: "System Toggle: Use Enhanced Optimistic Lock With Terminal Batch Counters" (line 42)
              "Scheme Transaction Throttle for WS API - Passive Mode" (line 52)

  FAILURE MODE B — Duplicate insertion:
    The tool matched in an unexpected location and appended a new row rather than
    replacing the target → original NOT_FOUND row remained AND a new correct row was
    added → duplicate rows for same toggle (lines 124 AND 125 both identical).
    Affected: "Remove Orchestrator Session Merge"

RIGHT: For CSV files, NEVER use replace_string_in_file for cell-level edits.
       Use PowerShell [System.IO.File]::ReadAllLines() + direct array index assignment:

  $lines = [System.IO.File]::ReadAllLines($path, [System.Text.Encoding]::UTF8)
  $lines[$targetIndex] = '"New,CSV,Row,Content"'
  # To remove a duplicate: filter out the unwanted index
  $newLines = $lines | Where-Object { $_ -ne $duplicateLine }  # or by index
  [System.IO.File]::WriteAllLines($path, $newLines, [System.Text.Encoding]::UTF8)

  This approach:
  - Targets exact line index (zero-based) — no matching uncertainty
  - Never creates duplicates
  - Preserves UTF-8 encoding
  - Returns exact line count for verification

ALWAYS verify after any CSV edit:
  $rows = Import-Csv $path
  $rows | Where-Object { $_."Toggle Name" -eq "target" } | Select-Object * | Format-Table
  Confirm: correct class name, line number, repository, no duplicates, row count as expected.
```

**❌ ERROR 14: TOGGLE_NAME Identifier Blanket-Excluded from Registry (2026-04-11)**
```
WRONG: $excludedConstantNames = @("ENABLED","ENABLED_TO_UPPER","ENABLED_FOR_MERCHANTS","TOGGLE_NAME")
       → TOGGLE_NAME excluded by identifier BEFORE the $isToggle prefix filter runs
       → ALL classes using TOGGLE_NAME as their constant identifier are invisible

RIGHT: TOGGLE_NAME is a valid identifier for toggle constants.  It passes the ^TOGGLE_
       prefix filter legitimately.  Only truly generic non-toggle utility flags belong
       in the exclusion list (ENABLED, etc.).

Affected classes (DirectAPI — both HYBRID: declare AND call isToggleOn in same file):
  MerchantInvalidRequestRateLimiter:
    public static final String TOGGLE_NAME = "Apply per-merchant limits for invalid
    operation rates in WSAPI"  → was invisible; registry never showed this toggle
  MerchantPrioritisedRequestRateLimiter:
    public static final String TOGGLE_NAME = "Apply per-merchant maximum request
    rate limits in WSAPI"  → was invisible; NOT_FOUND stub in ToggleCodebaseUsageAnalysis.csv

Both are HYBRID classes (declare TOGGLE_NAME AND call Toggles.isToggleOn(TOGGLE_NAME)
in the same file) so they were doubly invisible: excluded before prefix filter ran,
AND would have been blocked by the pre-Bug-1 $isDeclaringFile guard.

Fix Applied (BuildToggleRegistryLookup.ps1 2026-04-11):
  Removed "TOGGLE_NAME" from $excludedConstantNames array.

Detection hint: If a DirectAPI (or any other) class uses TOGGLE_NAME as its constant
  identifier and the toggle is NOT in ToggleRegistryLookup.csv, check the exclusion list.
```

**❌ ERROR 15: Short/Symbol Constant Value Poisoning $allToggleValuesRegex (2026-04-11)**
```
WRONG: Pass 1 captures every constant whose NAME matches the $isToggle prefix filter,
       regardless of the VALUE.  Non-toggle constants like:
         public static final String REMOVE_PRIVILEGE = "-"
       are harvested with toggle_name = "-".
       When Pass 2 builds $allToggleValuesRegex (alternation of all known values),
       the escaped "-" matches the literal hyphen character, which appears on virtually
       every Java source line (method signatures, generics, operators, comments, imports).
       RESULT: EVERY isToggleOn() call in EVERY file matches the "-" toggle → 53+
       spurious IMPLEMENTATION rows with toggle_name="-" overwrite real data.

RIGHT: Validate toggle values at harvest time.  Real toggle display names are human-
       readable English phrases: ≥ 5 characters AND contain at least one space.
       A single-character or symbol-only value can NEVER be a meaningful toggle name.

Affected: BulkMerchantPrivilegeUpdateServiceImpl.java
  public static final String REMOVE_PRIVILEGE = "-"
  → REMOVE_ was added in Bug 3 fix; caused this non-toggle to enter $declMap

Fix Applied (BuildToggleRegistryLookup.ps1 2026-04-11):
  FIX 1: Add REMOVE_PRIVILEGE to $excludedConstantNames (blocks it before prefix filter)
  FIX 2: Add minimum-value guard in Harvest-Declarations:
          if ($toggleValue.Length -lt 5 -or $toggleValue -notmatch '\s') { continue }
          This is a safety net that rejects any future short/symbol-only value,
          regardless of how it entered past the prefix and exclusion filters.

Detection: If ToggleRegistryLookup.csv contains rows where toggle_name is a single
  character, symbol, or very short string — the value guard is not working correctly.
  Current threshold: ≥ 5 chars AND ≥ 1 space (multi-word phrase required).
```

**❌ ERROR 16: private/protected Toggle Constants Invisible to Pass 1 (2026-04-11)**
```
WRONG: Pass 1 regex: public\s+static\s+final\s+String\s+(\w+)\s*=\s*"([^"]+)"
       → ONLY matches constants with "public" access modifier
       → "private static final String" and "protected static final String" declarations
         in hybrid implementation classes are completely invisible to declaration harvest
       → toggle_name for these constants is never added to $declMap
       → Pass 2 finds the isToggleOn() call but cannot resolve the toggle display name

Affected examples:
  SchemeTokenValidator (Orchestrator): line 61
    private static final String ACCEPT_CSC_IN_SCHEME_TOKEN_TRANSACTIONS =
      "Accept CSC in scheme token transactions"
    → used at line 286: if(!Toggles.isToggleOn(ACCEPT_CSC_IN_SCHEME_TOKEN_TRANSACTIONS))
    → Pass 2 detected the call but toggle_name stayed "-"

  RefundServiceImpl (CPE):
    private static final String TOGGLE_SUPPORT_TRANSACTION_LEVEL_POSTERMINAL_DETAILS_FOR_LINKED_REFUND
  StripeServiceImpl (BusinessService):
    private static final String TOGGLE_SUPPORT_STRIPE_FAILOVER_USING_OPERATIONS_CONSOLE
  MerchantAcquirerFilterFactory, CreditCardPaymentTypeBuilder (BusinessService):
    private static final String ENABLE_ALLOW_CONSUMER_CHOICE_ROUTING_FOR_CO_BRANDED_CARDS

RIGHT: A toggle constant can be declared with ANY access modifier.  The access modifier
  governs visibility to other classes but does NOT change the fact that the constant IS
  a toggle name referenced by isToggleOn() in the same file.

Fix Applied (BuildToggleRegistryLookup.ps1 2026-04-11):
  Changed regex from:  public\s+static\s+final\s+String
  To:  (?:public|private|protected)?\s*static\s+final\s+String
  This matches all access modifiers (including package-private — no modifier at all).

Detection: If a toggle appears in isToggleOn() calls but is NOT in ToggleRegistryLookup.csv
  and NOT imported from a constants class, check if the constant is declared private/protected
  in the same file (hybrid class pattern with non-public visibility).
```

**❌ ERROR 17: Non-Standard Constant Prefixes Missing from $isToggle Filter (2026-04-11)**
```
WRONG: $isToggle prefix filter covers only: TOGGLE_ | ENABLE_ | FEATURE | _TOGGLE suffix |
       DO_NOT_ | ALLOW_ | USE_ | SET_ | REMOVE_ | OPTIMIZE_ | POPULATE_ | APPLY_ | GET_
       → Constants with other valid toggle-purpose prefixes silently dropped before
         entering $declMap, even when Bug 16 is fixed (private → visible)

Affected constants and their classes:
  ACCEPT_CSC_IN_SCHEME_TOKEN_TRANSACTIONS
    → SchemeTokenValidator (CPE and Orchestrator) — "Accept CSC in scheme token transactions"
  PREVENT_FORMAT_4_PIN_BLOCK_PASSTHROUGH_IN_DE_110
  PREVENT_FORMAT_4_PIN_BLOCK_PASSTHROUGH_IN_DE_110_FOR_AMEX
    → S2IAcquirerConstants (CPE) — used in IsoDataField110Populator
  FIX_CREDENTIAL_ON_FILE_FOR_STANDALONE_REFUND
    → JsonMegaMessageRequestBuilder, TspiRequestMessageBuilder (CPE)
  SUPPORT_POS_ENTRY_MODE_FOR_INCREMENTAL_AUTHORIZATION_PER_VISA_MANDATE
    → S2IAcquirerConstants (CPE)
  INDUSTRY_PRACTICE_PARTIAL_SHIPMENT_SUPPORT_FOR_3RI_AUTHENTICATION_TRANSACTIONS
    → S2IAcquirerToggleConstants (CPE) — used in RoutedServicesDelegate

RIGHT: When adding a new prefix category (Bug 3), verify it does NOT introduce
  non-toggle constants with that prefix (see Bug 15 for the REMOVE_ / REMOVE_PRIVILEGE
  example).  Also scan the codebase for any isToggleOn() calls whose argument constant
  does NOT match the current filter — those are candidates for filter expansion.

Fix Applied (BuildToggleRegistryLookup.ps1 2026-04-11):
  Added to $isToggle pattern: |^ACCEPT_|^PREVENT_|^FIX_|^SUPPORT_|^INDUSTRY_
  Same prefixes added to $refreshPattern for DirectAPI targeted-scan mode.

Additional fix — SQL/JPQL query pollution from GET_ prefix (2026-04-11):
  The GET_ prefix (added in Bug 3) caused DAO constants like:
    public static final String GET_MERCHANT_IN_SAME_PKI_GROUP = "SELECT r FROM..."
  to be harvested.  These SQL strings contain spaces (pass the Bug 15 length guard)
  but are obviously not toggle display names.
  Fix: Added value content guard rejecting values that start with SQL keywords
  (SELECT, INSERT, UPDATE, DELETE, FROM, WHERE, JOIN, CREATE, DROP, ALTER), Java
  class path prefixes (com., QSI., java., org., net.), or URL prefixes (http://).
    if ($toggleValue -match '^\s*(SELECT|INSERT|...|ALTER)\s' ...) { continue }
```

---

## Validation Checkpoints

**Checkpoint 1 (Phase 2 — Registry Lookup)**
```
IF toggle_found_in_registry:
  IF usage_type == DECLARATION: flag → need extra implementation search
  IF constant_name != display_string: flag → plan dual search
ELSE: flag → literal string search only
```

**Checkpoint 2 (Phase 3A — Multi-Method Search)**
```
METHOD 1: Literal string (with quotes) → if no hits, try METHOD 2
METHOD 2: Constant name → if no hits, try METHOD 3
METHOD 3: Keyword regex (HIGH false-positive risk) → validate manually
COMBINE + DEDUPLICATE results from all methods

MANDATORY STEP 2B — Same-File Hybrid Check:
  FOR each file with a DECLARATION line:
    Search same file for isToggleOn|isEnabled|isOn
    IF found → HYBRID → extract isToggleOn/isOn line numbers → classify IMPLEMENTATION → analyze
    IF not found → pure constants class → DECLARATION_ONLY

NEW STEP 2C — Fully-Qualified Body Scan:
  FOR each file: scan body lines (non-import) for ClassName.CONSTANT_NAME references
  IF ClassName matches a known declaring class → register constant as available in file
  Then check if any isToggleOn/isOn line references ClassName.CONSTANT_NAME

NEW STEP 2D — Wildcard Import Expansion:
  FOR each file: detect  import static pkg.ClassName.*;
  Expand ALL known constants from that ClassName into the file's available-constants set
  Then proceed with normal implementation line matching
```

**Checkpoint 3 (Before NOT_FOUND)**
```
INSPECT similar class names (e.g., *CardType* for issuer-related toggles)
INSPECT related packages (e.g., *Transaction* classes for transaction toggles)
INSPECT Decorator pattern classes (highest false-negative rate)
ONLY assign NOT_FOUND if ALL inspections yield zero matches
```

---

## BuildToggleRegistryLookup.ps1 — Architecture History

| Date | Change | Impact |
|---|---|---|
| 2026-04-10 | Initial two-pass architecture | Pass 1: declaration harvest; Pass 2: usage scan |
| 2026-04-10 | Priority: IMPLEMENTATION > IMPORT > DECLARATION | Correct usage_type classification |
| 2026-04-10 | line_number column added | Points to actual isToggleOn call line |
| 2026-04-11 | Dedup key includes className | Multiple impl classes per toggle all preserved |
| 2026-04-11 | Additive merge (no collapse) | All IMPL rows kept; DECLARATION only if uncovered |
| 2026-04-11 | Section C: qualified body scan | Detects `ClassName.CONSTANT_NAME` without static import |
| 2026-04-11 | Section A2: wildcard import expansion | `import static pkg.Class.*` expands all constants |
| 2026-04-11 | `declaringClassName` in window match | `ClassName.CONST` pattern matched in ±5 line window |
| 2026-04-11 | Added `\.isOn\s*\(` to implPatterns | Catches `Toggles.isOn()` short form |
| 2026-04-11 | Registry: 519 → 688 → 794 → **802 entries** | 37 → 4 → **2** DECLARATION-only toggles remaining |
| 2026-04-11 | **Bug 4**: Removed `"TOGGLE_NAME"` from `$excludedConstantNames` | MerchantInvalidRequestRateLimiter + MerchantPrioritisedRequestRateLimiter (DirectAPI) now visible; +4 entries → **1231** |
| 2026-04-11 | **Bug 5a**: Added `REMOVE_PRIVILEGE` to exclusion list + minimum value guard (≥5 chars + space) | Eliminated 53+ spurious `toggle_name="-"` rows caused by `REMOVE_PRIVILEGE="-"` poisoning regex |
| 2026-04-11 | **Bug 5b**: Pass 1 regex expanded to match `private`/`protected`/package-private access | Previously invisible private/protected constants now harvested (e.g. `ACCEPT_CSC_IN_SCHEME_TOKEN_TRANSACTIONS`) |
| 2026-04-11 | **Bug 5c**: Added `ACCEPT_` `PREVENT_` `FIX_` `SUPPORT_` `INDUSTRY_` to `$isToggle` filter | 10 more unique toggle names discovered (405 total in Pass 1) |
| 2026-04-11 | **Bug 5d**: SQL/JPQL value content guard added | `GET_*` DAO constants holding SQL queries excluded; ~80 non-toggle rows removed |
| 2026-04-11 | **Final clean registry: 325 unique toggle names, 1068 total entries** | `toggle_name="-"` rows: 0 · SQL rows: 0 · All 6 repos correct |
| 2026-04-11 | **Session close — missing toggle sweep (5 toggles)**: "System Toggle:Enable DPG New Mapping" (2 impls), "Unify Order Creation Time In Retrieval" (1), "Enable historical transaction data aggregation..." (2), "Shared Memory CPE PersistenceTable" (1 — name mismatch resolved), "Get Most Recent Transaction as Initial Transaction..." (NOT_FOUND confirmed) | 7 new rows appended to ToggleCodebaseUsageAnalysis.csv (rows 142-148); all 99 input toggles now accounted for |
| 2026-04-11 | **NOT_FOUND crosscheck sweep (17 toggles)**: literal-string grep across all 6 repos revealed 3 inline-literal toggles previously missed — "System Toggle: Use Enhanced Optimistic Lock With Terminal Batch Counters" (TerminalBatchCounterDaoImpl:161 CPE), "Scheme Transaction Throttle for WS API - Passive Mode" (SchemeTransactionThrottleHelper:378 CPE), "Remove Orchestrator Session Merge" (CardDetailsDecorator:167 Orchestrator). 14 remaining confirmed NOT_FOUND (in repos not in workspace: BatchSettlement, SCT, MCS, Protection Service, etc.). 3 new Cardinal Errors documented (21–22 + Step 20 checklist). | CSV fixed via PowerShell direct array index writes; duplicate row removed; final row count: 147 data rows |
| 2026-04-11 | **BatchSettlementService onboarding completed (SA-6)**: New repository successfully onboarded into toggle management system with full 10-point checklist verification. 12 unique toggles discovered across 285 Java files. Registry updated with 24 entries (8 IMPLEMENTATION, 16 DECLARATION). Known discovery pattern: Multiple toggles with DECLARATION_ONLY usage — suggests Phase 3A analysis will be needed to identify actual implementation callers in future batches. Hybrid class pattern observed in 6 toggle declarations (constants declared and used in same file). Dynamic toggle name construction detected in one entry (acquirerId suffix added at runtime). | 24 new registry rows added to toggle-registry-lookup.csv; new per-repo registry file created (toggle-registry-batch-settlement-service.csv); config.yml updated; 01-repositories.md updated with comprehensive toggle inventory; ready for Phase 2 batch analysis. |
