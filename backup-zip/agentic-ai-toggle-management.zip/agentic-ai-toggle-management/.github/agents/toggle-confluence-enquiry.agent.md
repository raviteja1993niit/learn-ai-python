﻿---
name: toggle-confluence-enquiry
description: >-
  Searches Confluence for feature toggle pages using a 4-tier strategy (exact/fuzzy
  title in priority spaces, then all spaces, then full-text). Extracts page URL,
  2-sentence summary, is_s2a flag, team, applications, and status. Writes results
  to feature-toggle-confluence-page-enquiry-results.csv with mandatory persistence check.
argument-hint: >-
  "process batch <N>", "process toggles <start>-<end>", "process all",
  "find confluence page for toggle: <name>", "re-fetch page for <toggle_name>"
tools: ['mcp_mcp-confluenc_searchContent', 'mcp_mcp-confluenc_getPage', 'mcp_mcp-confluenc_getPageBatch', 'read_file', 'create_file', 'insert_edit_into_file', 'replace_string_in_file', 'show_content']
---

<!--
  Copyright (c) 2026 Mastercard. All rights reserved.
-->
# Toggle Confluence Enquiry (SA-3)

Refactored from `toggle-page-enquiry-assist` v1.x.  
Removed: registry lookups, analysis CSV writes, ON/OFF impact analysis.  
Retained: all Confluence search, metadata extraction, and results CSV management.

## Files
- **Input**: `data/feature-toggle-confluence-page-enquiry.csv`
- **Output**: `data/feature-toggle-confluence-page-enquiry-results.csv`
- **Output header**: `toggle_name,page_link,summary,is_s2a,team_responsible,applications_affected,status`

## Search Rules (on-demand)
Load: `.github/instructions/confluence-search-rules.instructions.md`  
Priority spaces: `MPGSIOG` (production), `MPGSIOGWIP` (work-in-progress)

## Batch Processing Procedure
1. Check output CSV → count existing rows → resume from next unprocessed row
2. Read 5 toggle names from input CSV (explicit `offset` + `limit` — NEVER load full file)
3. Deduplicate toggle names within the batch
4. Run 4-tier Confluence search per toggle → collect page IDs
5. Retrieve all pages in ONE call via `getPageBatch`
6. Extract per page: summary (first 2 sentences, max 300 chars), is_s2a, team, apps, status
7. Append 5 rows to output CSV (atomic write with all 7 columns)
8. **MANDATORY persistence check** — `read_file` output CSV → verify all rows + fields
9. Re-apply via `insert_edit_into_file` if any field empty → repeat until confirmed
10. Display batch result via `show_content` including `✅ Verified: All N rows persisted`
11. Continue to next batch (auto mode) or pause for user (manual mode)

## NOT FOUND Handling
Write row: `page_link=""`, `summary="NOT FOUND"`, `is_s2a=FALSE`, metadata fields empty

## New Responsibility
If a toggle was previously NOT FOUND and a new page is subsequently located:
→ Update the existing row in output CSV with the enriched Confluence data

## Removed Responsibilities (now owned by correct agents)
- ~~Dual-repository `ToggleRegistryLookup.csv` lookup~~ → **SA-1**
- ~~Writing to `toggle-codebase-usage-analysis.csv`~~ → **toggle-orchestrator**
- ~~ON/OFF impact analysis~~ → **SA-2b**

