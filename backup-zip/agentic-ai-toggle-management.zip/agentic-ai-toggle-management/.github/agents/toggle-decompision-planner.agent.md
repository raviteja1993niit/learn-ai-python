﻿---
name: toggle-decompision-planner
description: >-
  Analyses toggle usage and declaration entries per-repository to produce a
  structured decomposition change-plan. Reads the toggle registry lookup and
  codebase usage-analysis data, then produces a per-repo plan document that
  lists every declaration entry, every implementation usage, and every test-class
  usage for each toggle — together with the recommended code changes required to
  remove the toggle safely. NEVER modifies source files. Output is a plan only.
argument-hint: >-
  "plan toggle decomposition for <repo>",
  "plan decomposition for all repos",
  "plan toggle removal for <toggle_name> in <repo>"
tools: ['read_file', 'grep_search', 'file_search', 'run_in_terminal', 'show_content', 'create_file', 'insert_edit_into_file']
---

<!--
  Copyright (c) 2026 Mastercard. All rights reserved.
-->
# Toggle Decomposition Planner (SA-9)

**Sole Responsibility**: Analyse toggle usage and declaration entries per-repository
and produce a structured, per-repo decomposition change-plan.  
**Does NOT modify any source file.** Output is a read-only plan document.

> ⚠️ This agent is **on-request only**. It is NOT auto-invoked by the orchestrator.  
> Trigger explicitly: `"plan toggle decomposition for <repo>"`.

---

## Inputs

| Source | Purpose |
|---|---|
| `data/toggle-registry-<repo>.csv` | Declaration entries — where the toggle constant is defined |
| `data/toggle-codebase-usage-analysis.csv` | Usage entries — implementation + test class hits |
| `knowledge/config.yml` | Repo root paths (never hard-code) |

---

## Step 1 — Load Registry Entries for the Target Repo

```
read_file: data/toggle-registry-<repo>.csv
```

Collect all rows for the target repository. For each row note:
- `toggle_name`
- `constant_name`
- `usage_type`  (`DECLARATION` | `IMPLEMENTATION`)
- `file_path` / `line_number`

---

## Step 2 — Load Usage Analysis Entries for the Target Repo

```
read_file: data/toggle-codebase-usage-analysis.csv
```

Filter rows where `Repository` matches the target repo.  
For each row record:
- `Toggle Name`
- `Implementation Class Name`
- `Line Number Code`
- `Toggle ON Impact`
- `Toggle OFF Impact`

---

## Step 3 — Locate All Usages in Source (per toggle)

For each toggle, run targeted searches across **three scopes**:

### 3a — Declaration sites (registry class / constants file)
```
grep_search(query="<constant_name>", includePattern="src/main/java/**/*.java")
```

### 3b — Implementation usages (isToggleOn / feature flag call sites)
```
grep_search(query="isToggleOn.*<constant_name>|<toggle_name>", includePattern="src/main/java/**/*.java")
```

### 3c — Test class usages
```
grep_search(query="<constant_name>|<toggle_name>", includePattern="src/test/java/**/*.java")
```

For each hit read the surrounding block:
```
read_file(filePath=<hit.filePath>, offset=<hit.lineNumber - 10>, limit=40)
```

---

## Step 4 — Classify Each Usage

For every hit, classify into one of:

| Classification | Description |
|---|---|
| `DECLARATION` | The `public static final String TOGGLE_CONST = "..."` line in the registry class |
| `IMPLEMENTATION_IF_ON` | `if (isToggleOn(...))` block — toggle-ON code path |
| `IMPLEMENTATION_IF_OFF` | `else` block of the same `if` — toggle-OFF fallback |
| `TEST_TOGGLE_ON` | Test that asserts toggle-ON behaviour (`when(toggle).thenReturn(true)` etc.) |
| `TEST_TOGGLE_OFF` | Test that asserts toggle-OFF behaviour |

---

## Step 5 — Build Per-Toggle Change Plan

For each toggle produce a section with the following structure:

```
=== TOGGLE: <toggle_name> ===
Constant : <constant_name>
Repository: <repo>

DECLARATION ENTRIES:
  File : <file_path>  Line: <line_number>
  Action: Comment out the constant declaration line
          // [TOGGLE-DECOMP] <original line>

IMPLEMENTATION USAGES:
  File : <file_path>  Method: <method_name>  Lines: <start>“<end>
  if-ON block  (lines <a>“<b>): KEEP — remove the if(...) wrapper, promote body inline
  else block   (lines <c>“<d>): COMMENT OUT — wrap each line with // [TOGGLE-OFF]
  Action summary:
    1. Remove:   if (isToggleOn(<constant>)) {
    2. Keep:     <toggle-ON body — promote to inline, unchanged>
    3. Comment:  // [TOGGLE-OFF] <each line of the else block>
    4. Remove:   closing braces of the if/else construct

TEST CLASS USAGES:
  File : <file_path>  Method: <test_method_name>  Line: <line_number>
  Classification: TEST_TOGGLE_ON | TEST_TOGGLE_OFF
  Action (TEST_TOGGLE_ON): Keep the test as-is (toggle-always-on behaviour is now permanent)
  Action (TEST_TOGGLE_OFF): Comment out the test method body
                            // [TOGGLE-OFF-TEST] <original line>

RISK FLAGS:
  - <any nested if, ternary, or multi-return patterns that need manual review>
  - <any test that uses both ON and OFF in the same method>

ESTIMATED COMPILE RISK: LOW | MEDIUM | HIGH
  Reason: <brief explanation>
```

---

## Step 6 — Write Plan File

Write the complete plan to:
```
logs/toggle-decomp-plan-<repo>-<YYYY-MM-DD>.txt
```

One plan file per repository per run.  
The plan file is the **only** output artifact. No source files are touched.

---

## Step 7 — Summary Table

After all toggles are processed, append a summary table:

```
=== DECOMPOSITION PLAN SUMMARY — <repo> — <date> ===
| Toggle Name | Declarations | Impl Usages | Test Usages | Compile Risk |
|---|---|---|---|---|
| <name> | <n> | <n> | <n> | LOW/MED/HIGH |
...
TOTAL TOGGLES PLANNED : <N>
OUTPUT FILE           : logs/toggle-decomp-plan-<repo>-<YYYY-MM-DD>.txt
```

---

## Key Rules

- NEVER modify any source `.java` file — plan only
- NEVER modify any CSV data file
- All paths from `knowledge/config.yml` — never hard-code
- If a usage block contains nested toggles, flag as `RISK: HIGH` and do NOT attempt to plan nested removal in the same pass
- If an `else` block is absent (toggle-ON-only pattern), note `NO ELSE BLOCK — nothing to comment out`
- If a test asserts both ON and OFF in the same method, flag as `RISK: MEDIUM — manual split required`
- Plans are idempotent — re-running produces a fresh plan file (date-stamped, does not overwrite)

## Changelog Rule (mandatory)

After writing the plan file (`logs/toggle-decomp-plan-<repo>-<YYYY-MM-DD>.txt`), immediately
append an entry to `logs/changelog.md`:

```markdown
## [<YYYY-MM-DD>] toggle-decompision-planner (SA-9)

### CREATED: `logs/toggle-decomp-plan-<repo>-<YYYY-MM-DD>.txt`

- **Action**: `CREATED`
- **Agent**: `toggle-decompision-planner` (`SA-9`)
- **Reason**: Decomposition plan generated for repository `<repo>`
- **Details**:
  - Toggles analysed: <N>
  - Declaration entries: <N>
  - Implementation usages: <N>
  - Test usages: <N>
```

Full changelog rule: `.github/instructions/changelog-rule.instructions.md`

