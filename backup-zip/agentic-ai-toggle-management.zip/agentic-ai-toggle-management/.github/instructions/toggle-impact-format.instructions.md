﻿---
applyTo: "on-demand"
category: "impact-analysis"
usedBy: ["toggle-impact-analyzer", "toggle-s2a-specialist"]
description: "Mandatory two-part format rules for Toggle ON/OFF impact descriptions"
---

<!--
  Copyright (c) 2026 Mastercard. All rights reserved.
-->
# Toggle Impact Analysis Format

## Mandatory Two-Part Format (EVERY ON and OFF impact)
```
Business: <business outcome — what merchant/cardholder/acquirer gains or loses>
Field Impact: <specific fields, ISO DEs, TSPI JSON fields, or API fields affected>
```
If no external fields: `Field Impact: Internal only — no TSPI/ISO/acquirer fields affected`

## Prohibited Patterns (NEVER use)
- `"When enabled: executes pingServers() method..."` — code-centric, no business context
- `"Enables S2A feature"` — too vague, no field impact
- `"ON Impact: Based on code at ClassName.java:LineNumber"` — placeholder, never acceptable
- `"OFF Impact: Complementary behavior when toggle disabled"` — placeholder, never acceptable

## Correct Format Examples
```
Toggle ON:
  "Business: For Scheme Token transactions the gateway accepts payment without CSC/CVV
  validation — tokenized payments proceed even when CSC is absent.
  Field Impact: sourceOfFunds.provided.card.securityCode not validated;
  isCscProvided() / wasCscPreviouslyProvided() / validateEmptyCsc() all bypassed."

Toggle OFF:
  "Business: Legacy order reuse rules apply — only narrow conditions permitted;
  risk-blocked or reversed Order IDs rejected.
  Field Impact: order.id reuse evaluated using legacy logic;
  order.status history not checked for new reuse conditions."
```

## Field Notation by Class Type
| Implementation Class Found | Format to Use |
|---|---|
| `S2IAcquirerV1`, `S2IAcquirerV2` | `ISO DE<n> [SE<n>] [SF<n>]` |
| `IsoDataField*Populator`, `S2IAcquirerHelper` | `ISO DE<n> SE<n> SF<n>` |
| `JsonMegaMessageRequestBuilder` | `TSPI: Transaction.<field>`, `TSPI: Merchant.<field>` |
| `TspiRequestMessageBuilder` | `TSPI: RoutingHeader.<field>` |
| `AccountFundingValidator` (Orchestrator) | `accountFunding.<field>` (API field) |
| `TransactionRequestValidator` (CPE) | `accountFunding.<field>` (API field) |
| Both S2I + MEGA classes | Document ISO DE row AND TSPI JSON row — separate rows |

## Code Block Reading Rule
```
read_file(fullPath, offset=blockStart, limit=blockEnd-blockStart+5)
```
Read the COMPLETE if/else block. Never summarize from partial reads.  
Read both the if-block AND else-block (document what does NOT execute when no else exists).

## Output Row Columns (6 columns)
`Toggle Name, Implementation Class Name, Line Number Code, Toggle ON Impact, Toggle OFF Impact, Repository`

## Per-Repo Analysis Output Files (MANDATORY dual-write)

Every row SA-2b produces must be written to **TWO files simultaneously**:

| Write Target | File | Purpose |
|---|---|---|
| **Combined** | `data/toggle-codebase-usage-analysis.csv` | All repos — used for cross-repo reports and full dataset queries |
| **Per-repo** | `data/toggle-codebase-usage-analysis-{repo}.csv` | Repo-specific — used for per-repo reports, targeted lookups, and row updates |

### Per-Repo File Mapping (from `config.yml → repositories[*].analysis_file`)

| `Repository` value | Per-Repo Registry Lookup | Per-Repo Analysis Output |
|---|---|---|
| `CPE` | `data/toggle-registry-cpe.csv` | `data/toggle-codebase-usage-analysis-cpe.csv` |
| `Orchestrator` | `data/toggle-registry-orchestrator.csv` | `data/toggle-codebase-usage-analysis-orchestrator.csv` |
| `BusinessService` | `data/toggle-registry-business-service.csv` | `data/toggle-codebase-usage-analysis-business-service.csv` |
| `Console` | `data/toggle-registry-console.csv` | `data/toggle-codebase-usage-analysis-console.csv` |
| `MSOUI` | `data/toggle-registry-msoui.csv` | `data/toggle-codebase-usage-analysis-msoui.csv` |
| `DirectAPI` | `data/toggle-registry-direct-api.csv` | `data/toggle-codebase-usage-analysis-direct-api.csv` |

> The `Repository` value and the per-repo file are always read from `config.yml → repositories[name=X]`.
> Never hard-code the file path — always derive it from config.

### Why per-repo files?
- **Search is repo-scoped** — SA-2a searches one repo at a time using its per-repo registry file
- **Reports are repo-scoped** — SA-4 reads the per-repo analysis file directly (no filter needed)
- **Updates are repo-scoped** — when correcting a row, load only the relevant per-repo file (faster, safer)
- **Same toggle, multiple repos** → appears in both the per-repo files AND the combined file

### Multi-Repo Row Example
Toggle found in CPE and Orchestrator → 4 total writes:
```
data/toggle-codebase-usage-analysis-cpe.csv          ← append CPE row
data/toggle-codebase-usage-analysis-orchestrator.csv ← append Orchestrator row
data/toggle-codebase-usage-analysis.csv              ← append CPE row
data/toggle-codebase-usage-analysis.csv              ← append Orchestrator row
```

## Row Identification for Updates
To target a specific row for in-place correction, open the **per-repo file** and match on:
```
Toggle Name + Implementation Class Name
```
Within a per-repo file this pair is unique (same toggle, same class, only one repo in the file).
Use PowerShell array-index write pattern (CMD-03) — never `replace_string_in_file` on CSV rows.

