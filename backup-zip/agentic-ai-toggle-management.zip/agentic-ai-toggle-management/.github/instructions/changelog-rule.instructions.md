﻿---
applyTo: "all"
category: "cross-cutting-rule"
usedBy: ["all-agents"]
description: "Mandatory changelog rule — every file change by any agent must be recorded in logs/changelog.md"
---

<!--
  Copyright (c) 2026 Mastercard. All rights reserved.
-->
# Changelog Rule — Mandatory for ALL Agents

> ⚠️ **This rule applies to every agent in the system, irrespective of which agent makes the change.**  
> No file modification of any kind is complete until an entry is written to the changelog.

---

## Rule

**Every time any agent creates, modifies, or deletes a file, it MUST append an entry to:**

```
logs/changelog.md
```

Path resolved from `knowledge/config.yml` → `logs.changelog` (`"logs/changelog.md"`).

---

## Entry Format

```markdown
## [<YYYY-MM-DD>] <Agent Name> (<Agent ID>)

### <Action>: `<relative/path/to/file>`

- **Action**: `CREATED` | `MODIFIED` | `DELETED`
- **Agent**: `<agent-name>` (`<SA-ID>`)
- **Reason**: <one-line description of why the file was changed>
- **Details**:
  - <bullet — what specifically changed, e.g. "Added sa-9 block", "Updated total_agents from 13 to 15">
  - <bullet — …>
```

### Multiple files in one session

Group all changes under a single date heading if they occur in the same agent invocation:

```markdown
## [2026-04-11] toggle-decompision-implementer (SA-10)

### MODIFIED: `src/main/java/com/example/MyService.java`

- **Action**: `MODIFIED`
- **Agent**: `toggle-decompision-implementer` (`SA-10`)
- **Reason**: Dry-run decomposition of toggle "Enable New Flow" — if-wrapper removed, else block commented out
- **Details**:
  - Line 42: if-wrapper `if (isToggleOn(ENABLE_NEW_FLOW, ctx)) {` removed
  - Lines 43–48: toggle-ON body promoted inline
  - Lines 49–53: else block commented out with `// [TOGGLE-OFF]` markers

### MODIFIED: `src/test/java/com/example/MyServiceTest.java`

- **Action**: `MODIFIED`
- **Agent**: `toggle-decompision-implementer` (`SA-10`)
- **Reason**: Dry-run — toggle-OFF test method body commented out
- **Details**:
  - Lines 88–95: test method `testLegacyFallback` body commented out with `// [TOGGLE-OFF-TEST]` markers
```

---

## Scope — What Counts as a "File Change"

| Change Type | Must Be Logged? |
|---|---|
| Creating a new file (any type) | ✅ Yes |
| Modifying an existing file | ✅ Yes |
| Deleting a file | ✅ Yes |
| Appending rows to a CSV | ✅ Yes (log file path + row count added) |
| Archiving a file (move to archive/) | ✅ Yes |
| Reading a file (no write) | ❌ No |
| Generating an in-memory plan (no write) | ❌ No |

---

## Timing

- Append to `logs/changelog.md` **immediately after** each file write, before moving to the next file.
- Do NOT batch changelog entries for the end of a session — log in real time.
- If multiple files are changed in a single operation, log each file as a separate sub-section under the same date heading.

---

## File Format Requirements

- The changelog MUST remain a valid **Markdown** file (`.md`).
- Use `##` for date + agent headings, `###` for individual file actions.
- Do NOT convert or rename `logs/changelog.md` to `.txt`, `.csv`, or any other format.
- Do NOT overwrite the file — always **append** new entries at the **bottom**.

---

## Applicable Agents (all agents, no exceptions)

| Agent | When to log |
|---|---|
| `toggle-orchestrator` | Any direct file write (rare — orchestrator mostly delegates) |
| `toggle-registry-manager` (SA-1) | Every registry CSV write/update |
| `toggle-search-locator` (SA-2a) | N/A — read-only agent; no writes |
| `toggle-impact-analyzer` (SA-2b) | Every append to analysis CSV |
| `toggle-s2a-specialist` (SA-2c) | N/A — read-only agent; no writes |
| `toggle-confluence-enquiry` (SA-3) | Every write to confluence results CSV |
| `toggle-report-generator` (SA-4) | Every report file created |
| `toggle-knowledge-keeper` (SA-5) | Every doc/registry/guide update |
| `toggle-codebase-onboarding` (SA-6) | Every file written during onboarding |
| `toggle-change-notifier` (SA-7) | Every change-report file created |
| `toggle-file-organizer` (SA-8) | Every dedup, archive, or cleanup write |
| `toggle-decompision-planner` (SA-9) | Every plan file created in `logs/` |
| `toggle-decompision-implementer` (SA-10) | Every Java source edit + every change-log file created |
| `toggle-polished-report-writer` (SA-11) | Every report file created in `reports/` |
| `toggle-session-analyst` (SA-13) | N/A — read-only agent; no writes to data or source files |

---

## Verification

After appending, confirm the entry was written by reading the last 30 lines:

```
read_file(filePath="logs/changelog.md", offset=-30)
```

If the entry is missing, re-append before proceeding.
