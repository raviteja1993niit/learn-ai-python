﻿---
applyTo: "on-demand"
category: "confluence"
usedBy: ["toggle-confluence-enquiry"]
description: "4-tier Confluence search strategy, metadata extraction rules, and persistence protocol"
---

<!--
  Copyright (c) 2026 Mastercard. All rights reserved.
-->
# Confluence Search & Persistence Rules

## Priority Spaces
| Space Key | Purpose |
|---|---|
| `MPGSIOG` | Production feature toggle documentation (primary) |
| `MPGSIOGWIP` | Work-in-progress/draft toggle documentation (secondary) |

## 4-Tier Search Strategy (follow in order — stop at first hit)
| Tier | CQL Pattern | When to Use |
|---|---|---|
| 1 | `title = "<toggle_name>" AND space in (MPGSIOG, MPGSIOGWIP)` | Always first |
| 2 | `title = "<toggle_name>"` | Only when Tier 1 returns 0 results |
| 3 | `title ~ "<toggle_name>" AND space in (MPGSIOG, MPGSIOGWIP)` | Only when Tier 2 returns 0 results |
| 4 | `text ~ "<toggle_name>"` | Last resort — all spaces, full-text |

## Batch Retrieval Optimization
1. Run Tier searches for all 5 toggles in batch → collect page IDs
2. Call `getPageBatch` with all IDs in ONE request → fetch all pages at once
3. Extract summaries and metadata from batch response

## Metadata Extraction (ALWAYS perform — even if page not found)
From `contentText`, extract:
- `team_responsible` — from "Team Responsible" section
- `applications_affected` — comma-separated from "Applications Affected" section
- `status` — from "Status" section

## S2A Flag Detection
Set `is_s2a = TRUE` if Description section contains (case-insensitive):
`S2A`, `JsonMegaMessageMap`, `TSPI`

## Output CSV Row Format
Header: `toggle_name,page_link,summary,is_s2a,team_responsible,applications_affected,status`  
Summary: first 2 non-empty sentences, max 300 chars, HTML tags stripped

## NOT FOUND Handling
Write row with: `page_link=""`, `summary="NOT FOUND"`, `is_s2a=FALSE`, all metadata fields empty

## CSV Escaping Rules
- Wrap any field containing commas, double quotes, or newlines in double quotes
- Escape inner double quotes by doubling them (`""`)

## Mandatory Persistence Protocol (NEVER skip)
After EVERY batch write:
1. Call `read_file` on output CSV
2. Verify all 5 rows present with all 7 columns populated
3. If any field is empty or missing → re-apply immediately via `insert_edit_into_file`
4. Repeat until confirmed
5. Include `✅ Verified: All N rows permanently persisted` in batch completion report
6. **NEVER proceed to next batch until persistence is confirmed**

## Resume Logic
On session start or batch restart:
- Count rows in output CSV → determine last processed row
- Resume from next unprocessed row in input CSV

