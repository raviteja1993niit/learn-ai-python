---
/*
 * Copyright (c) 2026 Mastercard. All rights reserved.
 */
---
# Agentic AI — Toggle Management System

> **Author:** Ravi Teja Thota (E135408)— raviteja.thota@mastercard.com  
> **Date:** April 11, 2026  
> **Status:** Active — Analysis in progress  
> **Architecture:** Multi-agent system with 1 orchestrator + 14 sub-agents (11 workflow + 3 on-request-only)  
> **Platform:** Mastercard Payment Gateway Services (MPGS)

---

## Table of Contents

1. [Overview](#overview)
2. [Repository Structure](#repository-structure)
3. [Source Repositories](#source-repositories)
4. [Agent Architecture](#agent-architecture)
5. [Supported Workflows](#supported-workflows)
6. [Workflow Examples — Sample Prompts](#workflow-examples--sample-prompts)
7. [Session Management — How to Resume](#session-management--how-to-resume)
8. [User Guide](#user-guide)
9. [Key Design Principles](#key-design-principles)
10. [Current Progress](#current-progress)

---

## Overview

This is the **framework repository** for the Toggle Management System — an enterprise-grade, multi-agent AI system that performs comprehensive feature toggle analysis across all registered MPGS payment gateway repositories.

The system contains all **agent definitions**, **shared knowledge documents**, **active tooling scripts**, and **session state** required to:

1. Locate where each registered feature toggle is used across all configured Java repositories
2. Analyze the business and field-level impact when each toggle is in the ON versus OFF state
3. Fetch and associate Confluence documentation pages for each toggle
4. Generate structured analysis reports (per-toggle, per-repository, S2A-only, status dashboard, polished summary)
5. Maintain analysis currency following code releases and toggle additions
6. Support seamless onboarding of additional repositories into the toggle registry

The system is **fully extensible** — new repositories are registered in `knowledge/config.yml`, and new toggles are added to the input CSV file. No changes to any agent definition or tooling script are required when the scope grows.

---

## Repository Structure

```
agentic-ai-toggle-management/
├── .github/
│   ├── agent-registry.yml              ← Authoritative catalogue of all registered agents (SA-5 owns)
│   ├── agents/
│   │   ├── toggle-orchestrator.agent.md          ← Main session entry point
│   │   ├── toggle-registry-manager.agent.md      ← SA-1
│   │   ├── toggle-search-locator.agent.md        ← SA-2a
│   │   ├── toggle-impact-analyzer.agent.md       ← SA-2b
│   │   ├── toggle-s2a-specialist.agent.md        ← SA-2c
│   │   ├── toggle-confluence-enquiry.agent.md    ← SA-3
│   │   ├── toggle-report-generator.agent.md      ← SA-4
│   │   ├── toggle-knowledge-keeper.agent.md      ← SA-5
│   │   ├── toggle-codebase-onboarding.agent.md   ← SA-6
│   │   ├── toggle-change-notifier.agent.md       ← SA-7
│   │   ├── toggle-file-organizer.agent.md        ← SA-8
│   │   ├── toggle-decompision-planner.agent.md   ← SA-9  (on-request only)
│   │   ├── toggle-decompision-implementer.agent.md ← SA-10 (on-request only)
│   │   ├── toggle-polished-report-writer.agent.md  ← SA-11 (on-request only)
│   │   ├── toggle-s2a-csv-updater.agent.md         ← SA-12
│   │   └── docs/
│   │       ├── 01-repositories.md            ← Registered repository inventory
│   │       ├── 02-search-patterns-and-csv.md ← Toggle search patterns and CSV schemas
│   │       ├── 03-optimization-rules.md      ← Performance and scan optimisation rules
│   │       ├── 04-workflow.md                ← Per-agent workflow definitions
│   │       ├── 05-s2a-field-notation.md      ← S2A ISO DE / TSPI JSON notation guide
│   │       ├── 06-analysis-guidelines.md     ← Analysis quality and accuracy guidelines
│   │       ├── 07-lessons-learned.md         ← Cardinal Errors registry, NOT_FOUND checklist
│   │       └── 08-mcp-toolkit.md             ← MCP tool reference and usage
│   └── instructions/
│       ├── file-naming-standards.instructions.md
│       ├── workflow-commands.instructions.md
│       └── *.instructions.md
├── knowledge/
│   ├── config.yml                      ← Central configuration — ALL paths, repo roots, tool locations (read 1st)
│   ├── new-session-execution-guide.md  ← Batch queue, current analysis state, per-toggle workflow (read 2nd)
│   ├── tool-command-registry.yml       ← Fast-lookup: all scripts, commands, traps, decision matrix
│   └── index.md                        ← Master file index for the entire system
├── data/
│   ├── feature-toggle-confluence-page-enquiry.csv          ← Input: extensible toggle registry (never modified)
│   ├── feature-toggle-confluence-page-enquiry-results.csv  ← SA-3 output: Confluence metadata per toggle
│   ├── toggle-registry-lookup.csv                          ← SA-1 output: combined multi-repo registry
│   ├── toggle-registry-{repo}.csv                          ← SA-1 output: per-repository registry files
│   ├── toggle-codebase-usage-analysis.csv                  ← SA-2b output: consolidated analysis across all repos
│   ├── toggle-codebase-usage-analysis-{repo}.csv           ← SA-2b output: per-repository analysis files
│   ├── s2a-keywords-lookup.csv                             ← SA-2c input: S2A class keyword index
│   └── toggle-dependency-on-card-payment-engine.csv        ← Reference: CPE toggle dependency map
├── tools/
│   ├── active/
│   │   ├── build-toggle-registry-lookup.ps1    ← Rebuild registry across all configured repositories
│   │   ├── toggle-search-utility.ps1           ← Toggle pattern search utility (fallback)
│   │   ├── toggle-publish-utility.ps1          ← Bulk CSV writer (fallback)
│   │   ├── toggle-analysis-batch-processor.ps1 ← Batch orchestration script (not recommended for primary use)
│   │   ├── generate-java-tree.ps1              ← Java class tree generator
│   │   ├── repo-memory-mapper.ps1              ← Repository S2A class mapper
│   │   └── fix-csv-encoding.py                 ← UTF-8 BOM encoding repair utility
│   └── recyclebin/                             ← Retired and superseded scripts
├── logs/
│   ├── changelog.md                    ← Append-only change log (all agents write here)
│   ├── toggle-batch-{N}-checkpoint.txt ← Per-batch completion checkpoint
│   └── archive/                        ← Archived logs (retention: 30 days)
├── reports/
│   └── archive/                        ← Archived report files
└── sessions/                           ← Historical session notes (informational, not consumed by agents)
```

---

## Source Repositories

All source repositories are defined in `knowledge/config.yml` under the `repositories` key. The system is fully extensible — additional repositories are onboarded via `SA-6` and registered in the configuration without modification to any agent or script.

| Repository | Approx. Java Files | Scan Strategy | Registry File |
|---|---|---|---|
| CardPaymentEngine (CPE) | ~2,420 | Full | `toggle-registry-cpe.csv` |
| Orchestrator | ~751 | Full | `toggle-registry-orchestrator.csv` |
| BusinessService | ~581 | Full | `toggle-registry-business-service.csv` |
| Console | ~749 | Full | `toggle-registry-console.csv` |
| MSOUI | ~1,065 | Full | `toggle-registry-msoui.csv` |
| DirectAPI | ~10,367 | Targeted (known toggle-bearing files) | `toggle-registry-direct-api.csv` |
| BatchSettlementService | ~285 | Full | `toggle-registry-batch-settlement-service.csv` |
| *(additional repositories)* | — | Configured via `config.yml` | `toggle-registry-{repo-kebab}.csv` |

> **Note:** All Java source roots and scan strategies are configured exclusively in `knowledge/config.yml`. No paths are hard-coded in any agent definition or PowerShell script. Repositories listed as pending in `config.yml` are onboarded on demand using Workflow F.

---

## Agent Architecture

```
┌─────────────────────────────────────────────────────────┐
│          toggle-orchestrator  (Main Agent)               │
│  Session entry point — routes all commands to sub-agents │
└──────────────────────────┬──────────────────────────────┘
                           │ delegates to
      ┌────────────────────┼──────────────────────────────────┐
      ▼                    ▼                  ▼               ▼
   [SA-1]              [SA-2]            [SA-3]           [SA-6]
   Registry            Search &          Confluence       Codebase
   Manager             Analysis          Enquiry          Onboarding
                          │
               ┌──────────┼──────────┐
               ▼          ▼          ▼
            [SA-2a]    [SA-2b]    [SA-2c]
            Search     ON/OFF      S2A
            Locator    Analyzer    Specialist

   [SA-4]         [SA-5]         [SA-7]         [SA-8]
   Report         Knowledge      Change          File
   Generator      Keeper         Notifier        Organizer
```

| ID | Agent | Role |
|---|---|---|
| main | `toggle-orchestrator` | Session entry point, workflow routing, batch progress tracking |
| SA-1 | `toggle-registry-manager` | Registry ownership, lookup service, per-repository CSV management |
| SA-2a | `toggle-search-locator` | Locate toggle usages in Java source code (grep + Cardinal Error validation) |
| SA-2b | `toggle-impact-analyzer` | Read code blocks and produce ON/OFF business and field-level impact |
| SA-2c | `toggle-s2a-specialist` | S2A ISO DE / TSPI JSON deep analysis |
| SA-3 | `toggle-confluence-enquiry` | Confluence 4-tier search and metadata extraction |
| SA-4 | `toggle-report-generator` | Generate all report types from collected analysis data |
| SA-5 | `toggle-knowledge-keeper` | Maintain all session knowledge documents between sessions |
| SA-6 | `toggle-codebase-onboarding` | Onboard new repositories into the toggle system |
| SA-7 | `toggle-change-notifier` | Detect toggle additions, removals, renames, and stale analysis after releases |
| SA-8 | `toggle-file-organizer` | Deduplication, re-encoding, archival, and file naming hygiene (auto-runs every 5 batches) |
| SA-9 | `toggle-decompision-planner` | ⚡ **On-request only** — analyse per-repository toggle entries and produce a decomposition change plan (no source edits) |
| SA-10 | `toggle-decompision-implementer` | ⚡ **On-request only** — refactor source to remove toggles; dry run is the default, actual run requires explicit user confirmation |
| SA-11 | `toggle-polished-report-writer` | ⚡ **On-request only** — generate a final polished Markdown usage report joining Confluence metadata and codebase analysis; S2A/S2I impact correctly flagged |
| SA-12 | `toggle-s2a-csv-updater` | Write SA-2c enriched S2A impact back into analysis CSVs in-place (per-repository and combined); invoked by SA-2c after every S2A enrichment |

---

## Supported Workflows

| Command | Workflow | Agents Involved |
|---|---|---|
| `analyze toggles batch <N>` | A | SA-1 → SA-2a → SA-2b → [SA-2c → SA-12] → SA-5 |
| `rebuild registry` | B | SA-1 |
| `fetch confluence data for batch <N>` | C | SA-3 |
| `generate report` | D | SA-4 |
| `check for missing toggles` | E | SA-1 |
| `onboard repo <path>` | F | SA-6 → SA-5 |
| `check for toggle changes` | G | SA-7 → SA-1 → SA-2a → SA-3 |
| `clean up files` | H | SA-8 → SA-5 |
| `plan toggle decomposition for <repo>` | I ⚡ on-request | SA-9 only |
| `decompose toggles in <repo> dry run` / `confirm actual run for <repo>` | J ⚡ on-request | SA-9 → SA-10 |
| `generate polished report` / `generate polished report for <repo>` | K ⚡ on-request | SA-11 only |

---

## Workflow Examples — Sample Prompts

The following sample prompts are copy-paste ready for use at the start of or during any session. The orchestrator will automatically load session state and route to the appropriate sub-agents.

---

### Workflow A — Analyze Toggles (Batch Processing)

Perform a full analysis pass on a batch of toggles: locate usages, assess ON/OFF impact, enrich S2A fields, and persist results.

```
analyze toggles batch 2
```

```
analyze toggles batch 3 for CPE only
```

```
resume batch 2 from toggle ENABLE_ENHANCED_AUTH
```

---

### Workflow B — Rebuild Toggle Registry

Rebuild the combined toggle registry CSV and all per-repository registry files by re-scanning all configured Java source roots.

```
rebuild registry
```

```
rebuild registry for CPE
```

```
rebuild registry for all repositories
```

---

### Workflow C — Fetch Confluence Data

Retrieve and persist Confluence page metadata (page title, space, URL, last-modified date) for all toggles in the specified batch using the 4-tier search strategy.

```
fetch confluence data for batch 2
```

```
fetch confluence data for all pending toggles
```

```
fetch confluence data for toggle ENABLE_NETWORK_TOKEN_PROVISIONING
```

---

### Workflow D — Generate Reports

Generate structured analysis reports from the data collected to date. Report types include: per-toggle detail, per-repository summary, S2A-only, status dashboard, and missing-toggle report.

```
generate report
```

```
generate per-repo summary report
```

```
generate status dashboard report
```

```
generate S2A-only report for CPE
```

```
generate per-toggle detail report
```

---

### Workflow E — Check for Missing Toggles

Cross-reference the input toggle list against the combined registry and analysis output to identify any toggles not yet located or analysed.

```
check for missing toggles
```

```
check for missing toggles in CPE
```

```
which toggles have no Confluence data yet
```

---

### Workflow F — Onboard a New Repository

Register a new Java repository into the toggle system. SA-6 will scan the repository, build its registry file, update `knowledge/config.yml`, and invoke SA-5 to persist the updated session state.

```
onboard repo C:/Users/e135408/IdeaProjects/MPGS/SourceCode/tokenservice
```

```
onboard repo C:/path/to/threedsservice with scan strategy full
```

```
onboard repo C:/path/to/new-service and rebuild registry after
```

---

### Workflow G — Check for Toggle Changes

Detect toggle additions, removals, and renames introduced since the last analysis run. Re-triggers SA-1 and SA-2a for any newly discovered toggles, and SA-3 if Confluence metadata is stale.

```
check for toggle changes
```

```
check for toggle changes after release 6.2.1
```

```
check for new or removed toggles since last session
```

---

### Workflow H — Clean Up Files

Run the file organiser to deduplicate analysis rows, re-encode any malformed CSV files, archive stale logs and reports, and enforce kebab-case file naming across the workspace.

```
clean up files
```

```
clean up and archive old reports
```

```
run file organizer and fix encoding issues
```

---

### Workflow I — Backfill Missing Analysis Rows *(Auto-Internal + On-Request)*

The Orchestrator automatically detects toggles in the master input CSV that have no rows in `toggle-codebase-usage-analysis.csv` and triggers this workflow without requiring a user command. It can also be triggered explicitly.

```
backfill missing analysis
```

```
fill analysis gaps
```

> ⚠️ This workflow is also **auto-triggered internally** by the Orchestrator during Workflow D-P (coverage check), after Workflow E (missing toggle check), and when a chat enquiry references a toggle with no analysis row.

---

### Workflow J — Plan Toggle Decomposition *(On-Request Only)*

Analyse the current toggle entries for a given repository and produce a structured decomposition change plan — identifying which code paths to consolidate, which branches to remove, and what the expected diff will look like. **No source file modifications are made during this workflow.**

```
plan toggle decomposition for CPE
```

```
plan toggle decomposition for Orchestrator
```

```
plan toggle decomposition for all repositories
```

---

### Workflow K — Decompose Toggles *(On-Request Only)*

Execute the decomposition plan produced by Workflow J. A dry run is always performed first; actual source modifications require explicit confirmation.

```
decompose toggles in CPE dry run
```

```
confirm actual run for CPE
```

```
decompose toggles in BusinessService dry run
```

---

### Workflow L — Generate Polished Report *(On-Request Only)*

Produce a final, publication-ready Markdown report that joins Confluence metadata with codebase analysis results, with correct S2A/S2I impact flagging and executive-level narrative.

```
generate polished report
```

```
generate polished report for CPE
```

```
generate polished report for all repositories
```

---

## Session Management — How to Resume

The orchestrator reads the following files in order at every session start:

| Priority | File | Purpose |
|---|---|---|
| 1st | `knowledge/config.yml` | All paths, registered repository roots, tool locations |
| 2nd | `knowledge/new-session-execution-guide.md` | Current batch state, toggle processing queue, per-toggle workflow |
| 3rd | `.github/agents/docs/07-lessons-learned.md` | Cardinal Errors registry, NOT_FOUND validation checklist |
| On-demand | `knowledge/tool-command-registry.yml` | All scripts, commands, known traps, and the decision matrix |

To resume an active analysis session, use the quick-start prompt defined in `knowledge/new-session-execution-guide.md`, Section 11. This will restore full context — including the current batch position, pending toggle queue, and last-known registry state — without requiring manual re-initialisation.

---

## User Guide

### Prerequisites

Before running any workflow, ensure the following are in place:

- **JetBrains AI Assistant** (or compatible agentic AI environment) is active in the workspace
- All MPGS source repositories are cloned and accessible at the paths configured in `knowledge/config.yml`
- PowerShell 5.1 or later is available (required for `.ps1` tooling scripts)
- Python 3.x is available (required for `fix-csv-encoding.py`)
- The `data/` directory is writable by the agent session

---

### Initial Setup — First Run

1. Open the workspace in JetBrains and activate the AI Assistant agent panel.
2. Load the orchestrator as the active agent: `.github/agents/toggle-orchestrator.agent.md`
3. The orchestrator will automatically read `knowledge/config.yml` and `knowledge/new-session-execution-guide.md` on startup.
4. Verify the registry exists at `data/toggle-registry-lookup.csv`. If it does not, run:
   ```
   rebuild registry
   ```
5. Confirm the input toggle file is present at `data/feature-toggle-confluence-page-enquiry.csv`. This file is the authoritative source of all toggles to be analysed and must not be modified.
6. Begin analysis with:
   ```
   analyze toggles batch 1
   ```

---

### How to Add New Repositories (Onboarding)

New repositories are onboarded without any manual modification to agent definitions or scripts. The full procedure is:

1. Ensure the repository is cloned locally and the Java source root is accessible.
2. Issue the onboarding command (Workflow F):
   ```
   onboard repo <absolute-path-to-repository-root>
   ```
3. SA-6 will:
   - Scan the repository and build its per-repository registry CSV under `data/`
   - Register the repository in `knowledge/config.yml` under the `repositories` key
   - Invoke SA-5 to update `knowledge/new-session-execution-guide.md` and `.github/agents/docs/01-repositories.md`
4. Rebuild the combined registry to include the new repository:
   ```
   rebuild registry
   ```
5. The repository is now active and will be included in all subsequent batch analysis runs.

> To manually register a repository without using the onboarding workflow, add a new entry to the `repositories` list in `knowledge/config.yml` following the existing entry format, then run `rebuild registry`.

---

### How to Add New Toggles

New toggles are added by appending rows to the input CSV file. No changes to any agent or script are required.

1. Open `data/feature-toggle-confluence-page-enquiry.csv`.
2. Append one row per new toggle, following the existing column schema.
3. Save the file with UTF-8 encoding (without BOM). If encoding issues occur, run:
   ```
   clean up files
   ```
   SA-8 will invoke `tools/active/fix-csv-encoding.py` automatically.
4. Update the toggle processing queue in `knowledge/new-session-execution-guide.md` to include the new toggle names and assign them to an upcoming batch.
5. Run `check for missing toggles` to confirm the new toggles are recognised by the registry.
6. Proceed with `analyze toggles batch <N>` as normal.

---

### Session Management

The system is designed for **incremental, resumable analysis**. Each batch processes a defined subset of the toggle queue. Session state is fully persisted between sessions by SA-5.

**To resume a session:**
- Start a new AI Assistant session in the workspace.
- Load the orchestrator agent.
- The orchestrator will auto-load `knowledge/config.yml` and `knowledge/new-session-execution-guide.md`.
- Use the quick-start prompt from Section 11 of the execution guide.

**To check current progress:**
```
what is the current batch status
```

**To resume a partially completed batch:**
```
resume batch <N> from toggle <TOGGLE_NAME>
```

**Batch checkpoints** are written to `logs/toggle-batch-{N}-checkpoint.txt` after each batch completes. These serve as durable audit records and can be used to reconstruct the analysis timeline.

---

### Troubleshooting

| Symptom | Likely Cause | Resolution |
|---|---|---|
| Agent reports toggle NOT_FOUND in a repository | Toggle constant not directly referenced; may be inherited or conditionally used | Follow the NOT_FOUND validation checklist in `.github/agents/docs/07-lessons-learned.md` |
| CSV file unreadable (encoding error) | BOM or encoding mismatch in output CSV | Run `clean up files`; SA-8 will invoke `fix-csv-encoding.py` |
| Registry is empty or missing rows | Registry not rebuilt after new repository onboarding | Run `rebuild registry` |
| Confluence search returns no results | Toggle name does not match page title; try alternate search tier | SA-3 uses a 4-tier fallback strategy; review results in `data/feature-toggle-confluence-page-enquiry-results.csv` |
| Agent reads stale session state | `new-session-execution-guide.md` not updated after last batch | Run `clean up files` and verify SA-5 has written the latest checkpoint |
| Duplicate rows in analysis CSV | Batch re-run without prior deduplication | Run `clean up files`; SA-8 will deduplicate all analysis output files |
| New repository not appearing in analysis | Repository entry missing from `knowledge/config.yml` | Use Workflow F to onboard, or manually add entry to `config.yml` and run `rebuild registry` |

---

## Key Design Principles

- **One agent, one responsibility** — no agent performs work outside its declared role boundary
- **Registry is the source of truth** — SA-1 is authoritative; all agents query the registry and never bypass it
- **All paths from `config.yml`** — no hard-coded file paths in any agent definition (`.md`) or PowerShell script (`.ps1`)
- **Kebab-case file naming** — all generated files use `lowercase-words-with-hyphens` format, enforced by SA-8
- **Read is free, write is exclusive** — any agent may read any file; only the designated owner agent writes to each file
- **Knowledge keeper runs last** — SA-5 updates all knowledge documents after every batch, ensuring session context survives between AI sessions
- **Extensibility by design** — adding repositories or toggles requires configuration changes only; no agent code modifications
- **Dry run before destructive operations** — SA-10 (decomposition implementer) always runs in dry-run mode first; actual source modifications require explicit user confirmation

---

## Current Progress

Progress is tracked dynamically through the batch checkpoint system and the session execution guide. Consult `knowledge/new-session-execution-guide.md` for the authoritative current state.

| Tracked Item | Location |
|---|---|
| Toggle registry (all configured repositories) | `data/toggle-registry-lookup.csv` + per-repository CSV files |
| Batch completion status | `logs/toggle-batch-{N}-checkpoint.txt` |
| Per-toggle analysis state | `knowledge/new-session-execution-guide.md` — Toggle Processing Queue |
| Confluence data retrieval status | `data/feature-toggle-confluence-page-enquiry-results.csv` |
| Agent activity log | `logs/changelog.md` |

**Primary Analysis Output:**  
`data/toggle-codebase-usage-analysis.csv`  
Schema: `Toggle Name, Implementation Class Name, Line Number Code, Toggle ON Impact, Toggle OFF Impact, Repository`

**Per-Repository Analysis Output:**  
`data/toggle-codebase-usage-analysis-{repo-kebab}.csv` — one file per configured repository, maintained in parallel with the consolidated output.

---

*This document is maintained by SA-5 (toggle-knowledge-keeper). For the authoritative session state, always refer to `knowledge/new-session-execution-guide.md`.*

