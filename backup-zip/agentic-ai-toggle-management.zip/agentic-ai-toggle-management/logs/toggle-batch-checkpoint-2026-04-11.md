# Toggle Codebase Usage Analysis — Session Checkpoint
**Date**: April 11, 2026  
**Workflow**: Workflow I — Backfill Missing Analysis (v2 Confluence file → analysis CSV)  
**Status**: 🔄 IN PROGRESS — 114 of 334 toggles complete, 247 remaining

---

## 1. What Was Requested

Process all toggles in:
```
data/archive/feature-toggle-confluence-page-enquiry-v2.csv   (334 toggles)
```
and update:
```
data/toggle-codebase-usage-analysis.csv
```
with codebase ON/OFF impact analysis rows for every toggle not yet covered.

---

## 2. Current State (end of April 11 session)

| Metric | Value |
|--------|-------|
| Total toggles in v2 file | **334** |
| Unique toggles already in analysis CSV | **114** |
| Data rows in analysis CSV | **178** |
| **Toggles still pending** | **247** |
| Batches completed today | **3** (Batches 1–3, toggles processed sequentially from the v2 list) |

### Per-Repo Analysis Files Status
| File | Status |
|------|--------|
| `data/toggle-codebase-usage-analysis.csv` | ✅ Active — 178 rows |
| `data/toggle-codebase-usage-analysis-cpe.csv` | ✅ Created today |
| `data/toggle-codebase-usage-analysis-orchestrator.csv` | ✅ Created today |
| `data/toggle-codebase-usage-analysis-business-service.csv` | ✅ Created today |
| `data/toggle-codebase-usage-analysis-msoui.csv` | ✅ Created today |
| `data/toggle-codebase-usage-analysis-direct-api.csv` | ⚠️ Not yet created (no DirectAPI toggles hit today) |
| `data/toggle-codebase-usage-analysis-batch-settlement-service.csv` | ⚠️ Partially written |

---

## 3. Toggles COMPLETED (114 unique)

These are already in `toggle-codebase-usage-analysis.csv` and require **NO further work**:

```
Accept CSC in scheme token transactions
Account Updater
ACH Account Validation for Paymentech Salem ACH Acquirer
Add DE48SE86 to COF Captures
Add Payment Parameter Group
Aggregator Support Amex Acquirers via RSC
Allow both auth and purchase operations for the merchant
Allow Card Type Indicator Tag in DE123 for domestic card brand transactions
Allow Clearing Tag in DE123 for domestic card brand transactions
Allow Consumer Choice Routing for EFTPOS Co-branded Cards
Allow MDES Token Repository Sharing
Allow MID with 40 characters
Allow Network Data Tag in DE123 for domestic card brand transactions
Allow Optional Exp Date for Amex Cards on Recurring Transactions in CPE
Allow Override Of Order Level Fields
Allow P2PE for merchant initiated transit transactions
Allow payment transaction with authentication return surcharge
Allow SCOF Registration via Merchant Manager
Allow tokenization with referenceOrderId
AMEX Guest Checkout Alt-ID
Apply New Order ID Reuse Rule
Apply overrideCardStoredOnFileIndicator
Apply per-merchant limits for invalid operation rates in WSAPI
Apply per-merchant maximum request rate limits in WSAPI
Auto reversals on final capture
Batch Settlement Service use Base32 ID Generator
Bypass 3DS Transaction Filtering for TAS Passkey transactions
Bypass CSC checks for Scheme Token Transactions
Derive Amount Variability For CIT And MIT Recurring Transactions
Derive MASTERCARD FinancialNetworkTransactionId from authorizing txn for FIRSTDATA_2
Derive VISA FinancialNetworkTransactionId from authorizing txn for FIRSTDATA_2
Do not persist verification authorisation codes
Enable Account Funding enhanced functionality for Mastercard and Visa
Enable Activity Calls to Protection Service
Enable Card Identification Service
Enable CIT MIT indicators for Mastercard
Enable Exclusion Rule in Merchant Acquirer Link Resolution
Enable first ride risk for transit
Enable historical transaction data aggregation for prioritised merchant flow control
Enable issuer country code in transaction response
Enable known fare transit with transportationMode
Enable Lookup up to 11 digit bin for Card Identification
Enable MC Account Funding Transactions
Enable Merchant configured BinSet Lookup
Enable MerchantAdvice and MerchantAdviceCode mapping in response for S2A
Enable New COF Token Value for Target
Enable New COF Token Value for T-SPI
Enable pay operation for EMV Request
Enable Payment Token in TFTO Block
Enable Protection Blocking Of Unusual Transactions
Enable replication lag tracking by MCS
Enable Single Tap Transactions
Enable TAF fields support for Passthrough
Enable Transaction Filtering BIN Range White listing
Enable Transaction Identifier and Financial Network Info in Verify Response
Enable transit transaction without sourceOfFunds
Enable Unusual Transaction Protection
Enable Update Authorization for Card Payments
Enable VISA Account Funding Transactions
Filter out transactions unrelated to current order
Get Most Recent Transaction as Initial Transaction If Auto-Capture Failed in Settlement Transaction
Industry Practice Partial Shipment support for 3RI Authentication transactions
Log Acquirer Details for Sanctioned Transactions
Mastercard QR Transaction Identifiers
MEA PVL and Co-branded Card Transaction Processing
Merchant Initiated Industry Practice Phase 2 Transactions- TSPI
Optimize loading of terminal batch counters
Populate payer authentication details on pre-risk RSPI
Random Terminal Allocation
Remove Orchestrator Session Merge
Retrieve Card Bin Set Id for Subsequent Transactions
Return refund authorization data to merchants
Revised Standards to Introduce BPSP Category to Support B2B
Route Risk Operations via the R-SPI Service and enable Merchant Risk
RSPI Mapping: Send Fields to Risk Provider - SubMerchant
Scheme Transaction Throttle for WS API - Passive Mode
Send Authentication fields in RiskSPI and AuthenticationStatusCode field in TSPI
Set approvedAmount only when the transaction is approved
Shared Memory CPE PersistenceTable
Store PARes and VERes in Postgres only
Submit EDQP Phase 3 fields in standalone transactions to WSAPI
Submit EDQP Phase 3 fields to RSC for Standalone Refunds
Support Additional TSPI Mappings for COF Transactions
Support New Merchant Advice Codes with optimal retry advice for Mastercard
Support STRIPE failover using Operations console
System Toggle: CPE - Recovery actions bypass Shared Memory CPE PersistenceTable to go straight to DB
System Toggle: CPE Load Balancer Uses Ping
System Toggle: Disables loading from orderCache in CPE for Transaction Retrieval
System Toggle: Enable 8-4 PAN Masking in API Response
System Toggle: Enable Activity Analyzer in Protection Service
System Toggle: Enable BCI Pagos Custom Payment Plans
System Toggle: Enable Cross Region Routing
System Toggle: Enable Data Instrumentation Logging for WSAPI requests
System Toggle: Enable Data Instrumentation Logging for WSAPI Transactions
System Toggle: Enable DC Replication Locks
System Toggle: Enable Lookup up to 8 digit bin for Card Identification
System Toggle: Enable Rate Limit For Test Merchants
System Toggle: Enable SCOF as a Network Token Provider
System Toggle: Enable timeout on merchant cache load
System Toggle: Enable Version Deprecation for Transactions
System Toggle: Extend SCT token DB locking behaviour
System Toggle: Honour DoNotProcessAfterTime for transaction processing
System Toggle: Reversal Daemon delays remote takeovers
System Toggle: Streamline SQL update for token use
System Toggle: Update AssociatedTransaction For Excessive Capture
System Toggle: Use 8_4 Masked PAN for Scheme Token Transaction Response
System Toggle: Use Enhanced Optimistic Lock With Terminal Batch Counters
System Toggle:Enable DPG New Mapping
System Toggle:Enable HSM Encryption For BatchSettlementService and PTS
Unify Order Creation Time In Retrieval
Use Authentication Status when performing Transaction Filtering
Use Enhanced Certificate Sets
Use partitioned tables for CPE transaction storage
Use Status Code when calculating if PSD2 Exemption has been granted by Visa
```

---

## 4. Toggles PENDING (247 remaining)

These are in `feature-toggle-confluence-page-enquiry-v2.csv` but **not yet in** `toggle-codebase-usage-analysis.csv`.  
Process them in order, in batches of 5, using **Workflow I** (SA-1 → SA-2a → SA-2b → SA-5).

| # | Toggle Name |
|---|-------------|
| 1 | Allow MDES Token Respository Sharing *(note: typo in source — "Respository")* |
| 2 | Allow Subsequent Refund Without Expiry For Recurring Payment |
| 3 | Allow Verify request - drop authentication data for S2I acquirers without threeDSinVerify capability |
| 4 | Allow Visa scheme tokens to bypass ECI field requirement in Target |
| 5 | Allow card identification using China Union Pay BIN set |
| 6 | Allow non ISO-8859-1 characters |
| 7 | Allow the pipe character in S2I field DE 123 Tag Data |
| 8 | Amex PAR Support for OAS acquirers |
| 9 | Apply Agreement Validation to API Version 54 |
| 10 | CPE - Avoid nulling out additional data for pending transactions |
| 11 | CPE Enable handling of multiple subfields in DE48SE37 |
| 12 | Card Brand Overrides Supports Lookup by Application ID |
| 13 | CommsXl - Custom RC Mapping Enabled |
| 14 | Derive Amount Variability For CIT And MIT for Recurring Captures |
| 15 | Disable Card Brand Data Population for Subsequent Transactions |
| 16 | Disable Financial Network Date storage in Auto Capture |
| 17 | Disable Notify To Wallet Provider From Orchestrator |
| 18 | Do Not Check CPE For Terminal Batch Totals |
| 19 | Do not allow refund if last transaction in a order is void |
| 20 | Do not assume cardOnFile status based on merchant tokenization privilege |
| 21 | Do not comply with password requirements introduced by F105059 |
| 22 | Do not send DE15 for Void Authorizations |
| 23 | Enable 3DS Egress End Point via ThreeDSRouter |
| 24 | Enable AFT recipient account identifier validation |
| 25 | Enable Acquirer transactionId usage to populate Invoice Reference Number |
| 26 | Enable Authorization Response Codes - D2D - GLB 10401 |
| 27 | Enable Base64-encoded Fields for IsoWebGateway |
| 28 | Enable CashBack And Gratuity For S2I |
| 29 | Enable Check RuPay BIN File before BinBase File |
| 30 | Enable Deferred Authorization for transit |
| 31 | Enable Device Payments Changes for Edit 8 criteria for DE 61 Subfield 3 and 11 |
| 32 | Enable Disbursement Screening Rule for Gaming Winning |
| 33 | Enable Dynamic 3-D Secure Authentication for this merchant.\<br/\>\<br/\> |
| 34 | Enable EMV MADA CHP For S2I |
| 35 | Enable EMV for Diners and Discover in S2I |
| 36 | Enable Exclusion Rule configuration through UI and API |
| 37 | Enable External Plan ID for Installment Plans |
| 38 | Enable External Plan ID for Installment Plans in TSPI |
| 39 | Enable FPAN Tokenization Block for SCOF |
| 40 | Enable HSM Encryption For BatchSettlementService and PTS |
| 41 | Enable HSM key cryptography for Risk Rule Input Management |
| 42 | Enable HSM key cryptography for Token search UI |
| 43 | Enable ISO Mapping for Surcharge and Convenience fee |
| 44 | Enable ISO20022 Data Quality Standard for Mastercard |
| 45 | Enable Incremental Authorization |
| 46 | Enable Known Fare Transit for Deferred Auth and Debt Recovery on S2I |
| 47 | Enable Known Fare Transit for Real Time Auth on S2I |
| 48 | Enable Known Fare Transit on S2I for AMEX |
| 49 | Enable MADA DMS transaction |
| 50 | Enable MADA S2A operations |
| 51 | Enable MADA SMS Refund Reversal |
| 52 | Enable MDQ Edit 38 For WSAPI |
| 53 | Enable MIT Industry Practice and Resubmission transaction for Non-Stored COF |
| 54 | Enable MSO enroll merchant in C2P |
| 55 | Enable Merchant Charge Disclosure Statement |
| 56 | Enable Merchant End of Business Day |
| 57 | Enable Net Amount and Charge Amounts in TSPI |
| 58 | Enable Network Transaction ID |
| 59 | Enable New RRN for capture transaction |
| 60 | Enable New RRN for void transaction |
| 61 | Enable Online Refund |
| 62 | Enable PAR functionality for S2I transactions |
| 63 | Enable PAR functionality in S2I for Verify transaction |
| 64 | Enable PSD2 Exemptions for Discover Protect Buy Authentications |
| 65 | Enable Partner solution identifier configuration |
| 66 | Enable PayPal V2 Functionality |
| 67 | Enable Payer and Tap Initiated Debt Recovery For Mastercard and Visa |
| 68 | Enable Rate Limit For Unauthenticated Requests |
| 69 | Enable ReAuthorization |
| 70 | Enable S2I Mastercard Mandate CardOnFile |
| 71 | Enable S2I Visa Mandate CardOnFile |
| 72 | Enable SRC V2 Services |
| 73 | Enable STX indicator for CIT transaction for S2I acquirers |
| 74 | Enable Scheme Token Provisioning Mode |
| 75 | Enable Scheme Tokenization Indicator Tag |
| 76 | Enable Software Online Pin for S2I |
| 77 | Enable T-SPI Batch Settlement Service to read Acquirer Configurations From Database |
| 78 | Enable TAS for SCOF |
| 79 | Enable TSPI Mastercard Mandate CardOnFile |
| 80 | Enable TSPI Response Mapping of AcquirerTransactionId from Acquiring Service to BSS |
| 81 | Enable Transit Aggregated Fare in Verify for Amex |
| 82 | Enable Transit Aggregation Rule for US Region |
| 83 | Enable Update Application Transaction Counter for Amex |
| 84 | Enable Update Application Transaction Counter for Mastercard |
| 85 | Enable VISA Tap Initiated Debt Recovery DE61SF11=4 mapping |
| 86 | Enable Verify POS Fields Validation |
| 87 | Enable Visa Deferred Authorization for transit |
| 88 | Enable Visa Transit |
| 89 | Enable Visa Transit Terminal mapping for NOT_CARDHOLDER_ACTIVATED DE61SF10=2 |
| 90 | Enable additional response codes |
| 91 | Enable alternate S2I transport |
| 92 | Enable card resolution using cardbinsets for Agreements |
| 93 | Enable data element mapping DE61SF11=0 for Visa MIDR transit transactions |
| 94 | Enable debugInformation mapping in the response for S2A |
| 95 | Enable domestic transactions mandates for MADA |
| 96 | Enable eftpos under transit for S2I |
| 97 | Enable emv tags for first class fields for Pay S2I |
| 98 | Enable fetching new VM config |
| 99 | Enable gratuity for AMEX in S2I |
| 100 | Enable indicators for Mastercard Stored CIT for Target |
| 101 | Enable maestro transactions for S2I |
| 102 | Enable mapping of new S2I acquirer response codes |
| 103 | Enable merchant reference number(PNR) mapping for MADA |
| 104 | Enable multi-layer MO hierarchy data for search orders and transactions |
| 105 | Enable new GatewayRecommendation for Auth Pay and Authentication Operation |
| 106 | Enable new GatewayRecommendation for UNKNOWN and UNSPECIFIED_FAILURE Response Codes |
| 107 | Enable new ISO Mapping for MIT transaction with MDES token based on CIT transaction source |
| 108 | Enable new MC Account Funding TTIs for MCC 6538 |
| 109 | Enable new TSPI message builder |
| 110 | Enable returning 3DS1 password as Dummy value |
| 111 | Enable rounding currency with three decimal places and update third decimal with zero for VISA |
| 112 | Enable scheme tokenization for Verification |
| 113 | Enable sending valid SubField DE61_11 to ISOWebGateway |
| 114 | Enable service fee and convenience fee and extended surcharge |
| 115 | Enable tag 9F1C in S2I |
| 116 | Enable the support for Transaction Link Identifier (DE105) |
| 117 | Enable tokenization extended logging |
| 118 | Enables Extended Refund up to 24 months |
| 119 | Feature Toggle: Allow Aggregators to use Gateway Tokenization |
| 120 | Feature Toggle: Enable Merchant Freeze for Create and Update operations |
| 121 | Filter out unsupported transaction sources when saving merchant transaction reference |
| 122 | FirstData Partial Capture Auth Reduction |
| 123 | Fix S2I Subfield DE61_13_14 POS Location Capability |
| 124 | Flag Stored in Standalone Refunds for FirstData2 |
| 125 | Include Custom Data in AVS Request |
| 126 | Include Original TID in Visa S2I Reversals |
| 127 | Industry Practice Partial Shipment support for 3RI Authentication transactions -S2I changes |
| 128 | Limit Authentication Transactions Per Order |
| 129 | Limiting visa transaction identifier to the first 15 characters |
| 130 | MDES Scheme specific values for tokenized MOTO transactions |
| 131 | Mada Recurring Payment Counter |
| 132 | Maintain consistent STAN on recovery message for S2I acquirers |
| 133 | Mastercard Issuer Finance Installment Plan |
| 134 | Merchant Initiated Industry Practice Phase 2 Transactions S2I- Target |
| 135 | Online Refund S2I Mapping in DE48SE43 for Device Payments |
| 136 | Orchestrator uses DPAN for DCC to determine the card number |
| 137 | Orchestrator uses the DPAN to determine the card type when it exists in the Order Retrieval Response |
| 138 | Pass OnlinePin data in DE110 for Amex in S2I message |
| 139 | Pass OnlinePin data in DE110 for Mastercard and Visa in S2I message |
| 140 | PayPal REST API |
| 141 | Perform disbursement eligibility check (Payment ASI) with BNET |
| 142 | Populate ATRI Indicator in DE48 SE78 SF06 |
| 143 | Populate AuthenticationFrameworkIndicator and SourceReasonCode |
| 144 | Populate Canada Domestic Indicator For S2I |
| 145 | Populate Card Level field for Global Pay East |
| 146 | Populate Credential on File Indicator in TSPI message for all VOID Transactions |
| 147 | Populate DE48SE37SF4 for Mastercard transactions |
| 148 | Populate DE48SE63 for offline refunds for S2I |
| 149 | Populate DE48SE95 for Amex Verify Card Present Transactions |
| 150 | Populate DE61SF4 correct value for CIT transactions |
| 151 | Populate Initial Amount Total Amount in DE123 in Capture for S2I |
| 152 | Populate Initial CIT TID in DE48SE91 for Visa subsequent MIT Transactions |
| 153 | Populate Level2and3 Data for S2I Acquirer |
| 154 | Populate PAR field for subsequent CAPTURE Request for S2I acquirers |
| 155 | Populate Statement Descriptor for S2I Acquirer |
| 156 | Populate TAM and TRID fields for subsequent CAPTURE Request for S2I acquirers |
| 157 | Populate Terminal Foreign Indicator tag in DE121 for subsequent transactions |
| 158 | Populate TerminalId from request to S2I Acquirers |
| 159 | Populate product code for offline refunds for S2I |
| 160 | Populate service code in DE123 in Capture for S2I |
| 161 | Populating DE122 and flagging of Message version code for MDQ-Gateway |
| 162 | Population of VISA Marketplace ID and Independent sales organization ID |
| 163 | Prevent unexpected Reversal Daemon actions for approved transactions |
| 164 | Prevent usage of Agreement type OTHER on V100 |
| 165 | Prevent usage of Payment Reason with Agreements on V100 |
| 166 | RBI e-mandate for Recurring Payment Data (Visa Only) |
| 167 | Reduce terminal wait time when too many transactions are waiting for a terminal |
| 168 | Remove DE15 Field from the Auth Response |
| 169 | Remove Invalid Characters From FirstName and LastName Fields in S2I Acquirer Messages |
| 170 | Remove transaction data storage from CPERiskAssessment postgres table to Cassandra |
| 171 | Restrict MPGS direct integration for Apple Pay in Kuwait |
| 172 | Restrict Merchant organisation loops |
| 173 | Retrieve Risk Assessment Data from RiskSPI via Orchestrator |
| 174 | Return Funding Method for Device Payment and Scheme Token Transactions |
| 175 | Return previous error explanation when 3DS authentication is attempted with DPAN |
| 176 | Revert cut down SQL fix in BatchSettlementService for Acknowledgement |
| 177 | Revert cut down SQL fix in BatchSettlementService for Notification |
| 178 | Route ITMX EMV3DS To Payair Adapter |
| 179 | S2A: messages include authentication data based on EMV 3DS privilege |
| 180 | S2I Restrict Visa Transaction Identifier field length to 15 characters |
| 181 | Send 3DS Method Notification to Merchants |
| 182 | Send DE123 OTD tag in local date |
| 183 | Send EMV 3DS2 Program Protocol data in S2I |
| 184 | Send JCB CAVV in B20 format |
| 185 | Send Merchant Payment Gateway ID in DE48 SE37 SF5 |
| 186 | Send new TSPI message |
| 187 | Set Account Type to Default in RSC Interface |
| 188 | Set EMV tags mapping in DE123 |
| 189 | Set Gateway Token Status to Invalid Based on Merchant Advice Codes |
| 190 | Set Order Status to Cancelled for Auth Capture Risk Blocked Orders |
| 191 | Set Order Status to Cancelled for Risk Blocked Orders |
| 192 | Store PARes and VERes in Cassandra only |
| 193 | Sub-merchant Marketplace ID for Visa |
| 194 | Sub-merchant Marketplace ID for Visa - TSP-I |
| 195 | Submit ECI 07 for unauthenticated ITMX transactions |
| 196 | Submit EDQP Phase 2 fields in subsequent transactions to RSC |
| 197 | Submit EDQP fields in subsequent transactions to RSC |
| 198 | Submit MRP Values in Subsequent Transactions |
| 199 | Support 3rd Party Installment Service Providers for Target |
| 200 | Support POS Entry Mode for Incremental Authorization per VISA Mandate |
| 201 | Support Sequence Count and Sequence Number Tags in DE123 |
| 202 | Support Transaction Level Posterminal Details for Linked Refund |
| 203 | Support new Scheme Ids (MAID and VMID) in TSPI |
| 204 | Support new Scheme Ids (MAID and VMID) in Target |
| 205 | Support submerchant dispute phone |
| 206 | System Toggle: AggregatorTokenization: enable Tokenization for Aggregators functionality |
| 207 | System Toggle: Align AuthAmount when voiding a Standalone Capture |
| 208 | System Toggle: Allow lenient updates to CPE PersistenceTable based off Shared Memory state |
| 209 | System Toggle: CPE ISO-WG Circuit Breaker does not terminate TLS connections |
| 210 | System Toggle: Cleartext value for PaymentRecipientAccountNumber in BSS for AFT settlements |
| 211 | System Toggle: Do not allow subsequent AUTH or PAY on UNKNOWN status for Union Pay transactions |
| 212 | System Toggle: Enable Akamai Transactions processing |
| 213 | System Toggle: Enable Amex mPos in S2I |
| 214 | System Toggle: Enable Auth Decline response codes for Mastercard |
| 215 | System Toggle: Enable Merchant Provided URL validation against blacklist |
| 216 | System Toggle: Enable Monitoring of Authentication Transactions Per Order |
| 217 | System Toggle: Enable Order With Existing Transactions Processing in Boost |
| 218 | System Toggle: Enable SPT For Card Brand Resolution |
| 219 | System Toggle: Enable Synchronous Network Tokenization |
| 220 | System Toggle: Enable Version Deprecation for Documentation |
| 221 | System Toggle: Enable fallback query for RBI order archiving |
| 222 | System Toggle: Enables order archiving for extended refund |
| 223 | System Toggle: Fix S2I Subfield DE61.11 Terminal Input Capability for Internet |
| 224 | System Toggle: Include DE26 in S2I Messages for AMEX PIN Transactions |
| 225 | System Toggle: Leaner reversal handling for S2I acquirer response codes |
| 226 | System Toggle: Prevent Format 4 Pin Block pass through in DE110 |
| 227 | System Toggle: Prevent Format 4 Pin Block pass through in DE110 for Amex |
| 228 | System Toggle: S2I recovery action support for VOID transactions |
| 229 | System Toggle: Send DE48SE37SF4 with GovernmentCountryCode to RSC |
| 230 | System Toggle: Trigger recovery action on S2I Acquirer Response Code 91 |
| 231 | System Toggle: Use Override BIN set data in Card Identification Flow |
| 232 | System Toggle: Use order amounts to derive CANCELLED status |
| 233 | System Toggle:AcqSubsystem - Switch Settlement to new VM for |
| 234 | System Toggle:Enable Checkmarx toggle for Console application |
| 235 | The MSO must have the useAuthenticationViaTASforSCOF privilege enable in order to alter \ |
| 236 | Toggle to Enable MADA COF Acquire Message Mapping |
| 237 | Unable to Get the Ruleset Details By Operation Group |
| 238 | Unique Transaction Identifier DE 120 SE 96 |
| 239 | Use 280 as Germany Country Code in S2I Request Message DE61SF13 |
| 240 | Use DPD Data Element for DSRP Cryptogram |
| 241 | Use Expanded Max Body Size Configuration in Direct API |
| 242 | Use Third Party Certificate For Test Merchants |
| 243 | Use corrected source of funds deviceSpecific fields mapping |
| 244 | Use latest order for Order ID Reuse amount check |
| 245 | Use unique identifier from JSON for field DE120SE96 |
| 246 | Validate Card Numbers in Authentication Requests |
| 247 | Visa Transit Terminal Entry Capability Mapping for Contactless DE61SF11=4 |

---

## 5. How to Resume Next Session

### Exact Start Command
Paste this into the chat at the start of the next session:

```
process and update toggle-codebase-usage-analysis.csv for the toggles in 
feature-toggle-confluence-page-enquiry-v2.csv — continue from where we left off.

Checkpoint: logs/toggle-batch-checkpoint-2026-04-11.md
Already done: 114 toggles (178 rows in CSV)
Start from pending toggle #1: "Allow MDES Token Respository Sharing"
Process in batches of 5 using Workflow I (SA-2a → SA-2b → SA-5).
```

### Key Files
| File | Purpose |
|------|---------|
| `data/archive/feature-toggle-confluence-page-enquiry-v2.csv` | Source of all 334 toggle names to process |
| `data/toggle-codebase-usage-analysis.csv` | **Output file** — append new rows here |
| `data/toggle-registry-lookup.csv` | Registry for constant names and file paths |
| `knowledge/config.yml` | All repo paths and system config |
| `logs/toggle-batch-checkpoint-2026-04-11.md` | **This file** |

### Repo Source Roots (for grep_search)
| Repo | Root Path |
|------|-----------|
| CPE | `C:\Users\e135408\IdeaProjects\MPGS\SourceCode\cardpaymentengine\src\main\java` |
| Orchestrator | `C:\Users\e135408\IdeaProjects\MPGS\SourceCode\orchestrator\src\main\java` |
| BusinessService | `C:\Users\e135408\IdeaProjects\MPGS\SourceCode\businessservice\src\main\java` |
| Console | `C:\Users\e135408\IdeaProjects\MPGS\SourceCode\console\console\src\main\java` |
| MSOUI | `C:\Users\e135408\IdeaProjects\MPGS\SourceCode\msoui\src\main\java` |
| DirectAPI | `C:\Users\e135408\IdeaProjects\MPGS\SourceCode\directapi\src\main\java` |
| BatchSettlementService | `C:\Users\e135408\IdeaProjects\MPGS\SourceCode\batchsettlementservice\src\main\java` |

---

## 6. Workflow I — Per-Toggle Processing Steps

For each toggle in each batch of 5:

1. **Registry lookup** — find `constant_name` in `data/toggle-registry-lookup.csv`
2. **Search CPE** — `grep_search(constant_name, includePattern="src/main/java/**/*.java")`
3. **Search Orchestrator** — same pattern
4. **Search other repos** (BSS, BusinessService, MSOUI, Console) if registry shows hits there
5. **CE-6 hybrid check** — for any declaration hit: also search `isToggleOn|isEnabled` in that same file
6. **Read code block** — `read_file(offset=matchLine-20, limit=60)` for each IMPLEMENTATION hit
7. **Write impacts** — two-part format: `Business: ... Field Impact: ...` for both ON and OFF
8. **Append CSV row** — via PowerShell `[System.IO.File]::AppendAllText`
9. **Verify** — `read_file` last 10 lines of CSV to confirm write

### CSV Row Format
```csv
"<Toggle Name>","<ImplementationClassName>","<LineNumber>","<Toggle ON Impact>","<Toggle OFF Impact>","<Repository>"
```
- All fields double-quoted
- Inner double-quotes escaped as `""`
- One row per implementation class (not per call site)
- NOT_FOUND format: `"<Name>","NOT_FOUND","N/A","Business: No implementation found...","...","UNKNOWN"`

---

## 7. Known Special Cases in Pending List

| # | Toggle | Note |
|---|--------|------|
| 1 | Allow MDES Token Respository Sharing | ⚠️ Typo in source: "Respository" — match exactly as-is |
| 33 | Enable Dynamic 3-D Secure Authentication for this merchant.\<br/\>\<br/\> | ⚠️ HTML in toggle name — DirectAPI DECLARATION only (likely NOT_FOUND impl) |
| 40 | Enable HSM Encryption For BatchSettlementService and PTS | ⚠️ Similar to `System Toggle:Enable HSM Encryption For BatchSettlementService and PTS` (already done) — check if same toggle or separate |
| 235 | The MSO must have the useAuthenticationViaTASforSCOF privilege enable in order to alter \ | ⚠️ Truncated toggle name with backslash — treat as-is |

---

## 8. Progress Summary

```
Overall progress: [███████░░░░░░░░░░░░░░░░░░░░░░░░░░░] 114/334 toggles (34%)
                  178 data rows in analysis CSV
                  247 toggles remaining
                  ~50 more batches of 5 needed
```

